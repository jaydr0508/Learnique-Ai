from flask import Blueprint, request, jsonify, g
from backend.auth.routes import require_auth
from backend.auth.security import hash_password
from backend.database.db import query_one, query_all, execute_query, get_db
from backend.utils.audit import log_audit

admin_bp = Blueprint("admin", __name__)

@admin_bp.route("/stats", methods=["GET"])
@require_auth(["ADMIN"])
def get_stats():
    """Retrieve top-level platform statistics for the administrator dashboard."""
    teachers_count = query_one("SELECT COUNT(*) as cnt FROM teachers")["cnt"]
    students_count = query_one("SELECT COUNT(*) as cnt FROM students")["cnt"]
    subjects_count = query_one("SELECT COUNT(*) as cnt FROM subjects")["cnt"]
    divisions_count = query_one("SELECT COUNT(*) as cnt FROM divisions")["cnt"]
    active_quizzes = query_one("SELECT COUNT(*) as cnt FROM quizzes WHERE status IN ('ACTIVE', 'SCHEDULED')")["cnt"]
    attendance_sessions = query_one("SELECT COUNT(*) as cnt FROM attendance_sessions")["cnt"]

    recent_logs = query_all("SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 8")

    return jsonify({
        "success": True,
        "counts": {
            "teachers": teachers_count,
            "students": students_count,
            "subjects": subjects_count,
            "divisions": divisions_count,
            "active_quizzes": active_quizzes,
            "attendance_sessions": attendance_sessions
        },
        "recent_logs": recent_logs
    })

# --- TEACHERS MANAGEMENT ---
@admin_bp.route("/teachers", methods=["GET"])
@require_auth(["ADMIN"])
def list_teachers():
    """List all registered academic faculty."""
    teachers = query_all(
        """
        SELECT t.*, u.login_id, u.email, u.full_name, u.phone, u.is_active,
               (SELECT COUNT(*) FROM teacher_assignments ta WHERE ta.teacher_id = t.id) as assignments_count
        FROM teachers t
        JOIN users u ON t.user_id = u.id
        ORDER BY u.full_name ASC
        """
    )
    return jsonify({"success": True, "teachers": teachers})

@admin_bp.route("/teachers", methods=["POST"])
@require_auth(["ADMIN"])
def create_teacher():
    """Register a new faculty member."""
    data = request.get_json(silent=True) or {}
    login_id = str(data.get("login_id", "")).strip()
    email = str(data.get("email", "")).strip().lower()
    full_name = str(data.get("full_name", "")).strip()
    password = str(data.get("password", "")).strip()
    phone = str(data.get("phone", "")).strip()
    employee_code = str(data.get("employee_code", "")).strip() or login_id
    department = str(data.get("department", "Computer Science")).strip()
    designation = str(data.get("designation", "Assistant Professor")).strip()

    if not login_id or not email or not full_name or not password:
        return jsonify({"success": False, "error": "Login ID, email, full name, and password are required"}), 400

    # Uniqueness check
    existing = query_one("SELECT id FROM users WHERE login_id = ? OR email = ?", (login_id, email))
    if existing:
        return jsonify({"success": False, "error": "Login ID or email is already taken"}), 400

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO users (login_id, email, password_hash, role, full_name, phone, is_active)
            VALUES (?, ?, ?, 'TEACHER', ?, ?, 1)
            """,
            (login_id, email, hash_password(password), full_name, phone)
        )
        u_id = cursor.lastrowid
        cursor.execute(
            """
            INSERT INTO teachers (user_id, employee_code, department, designation)
            VALUES (?, ?, ?, ?)
            """,
            (u_id, employee_code, department, designation)
        )
        t_id = cursor.lastrowid

    log_audit("TEACHER_CREATED", "TEACHER", str(t_id), g.user["id"], g.user["full_name"], {"login_id": login_id, "name": full_name}, request.remote_addr)
    return jsonify({"success": True, "teacher_id": t_id, "message": "Teacher created successfully"})

@admin_bp.route("/teachers/<int:teacher_id>/assignments", methods=["GET", "POST", "DELETE"])
@require_auth(["ADMIN"])
def manage_teacher_assignments(teacher_id: int):
    """View, assign, or remove teaching duties (Subject + Division + Batch)."""
    if request.method == "GET":
        assignments = query_all(
            """
            SELECT ta.id, s.id as subject_id, s.code as subject_code, s.name as subject_name,
                   d.id as division_id, d.name as division_name,
                   b.id as batch_id, b.name as batch_name
            FROM teacher_assignments ta
            JOIN subjects s ON ta.subject_id = s.id
            JOIN divisions d ON ta.division_id = d.id
            LEFT JOIN batches b ON ta.batch_id = b.id
            WHERE ta.teacher_id = ?
            ORDER BY s.code, d.name
            """,
            (teacher_id,)
        )
        return jsonify({"success": True, "assignments": assignments})

    elif request.method == "POST":
        data = request.get_json(silent=True) or {}
        subject_id = data.get("subject_id")
        division_id = data.get("division_id")
        batch_id = data.get("batch_id") or None

        if not subject_id or not division_id:
            return jsonify({"success": False, "error": "Subject and division are required"}), 400

        try:
            ta_id = execute_query(
                "INSERT INTO teacher_assignments (teacher_id, subject_id, division_id, batch_id) VALUES (?, ?, ?, ?)",
                (teacher_id, subject_id, division_id, batch_id)
            )
            log_audit("TEACHER_ASSIGNMENT_ADDED", "TEACHER", str(teacher_id), g.user["id"], g.user["full_name"], {
                "subject_id": subject_id, "division_id": division_id, "batch_id": batch_id
            }, request.remote_addr)
            return jsonify({"success": True, "assignment_id": ta_id})
        except Exception as e:
            return jsonify({"success": False, "error": "This assignment already exists or is invalid"}), 400

    else:
        # DELETE assignment
        assignment_id = request.args.get("assignment_id")
        if not assignment_id:
            return jsonify({"success": False, "error": "assignment_id is required"}), 400
        execute_query("DELETE FROM teacher_assignments WHERE id = ? AND teacher_id = ?", (assignment_id, teacher_id))
        log_audit("TEACHER_ASSIGNMENT_REMOVED", "TEACHER", str(teacher_id), g.user["id"], g.user["full_name"], {"assignment_id": assignment_id}, request.remote_addr)
        return jsonify({"success": True, "message": "Assignment removed"})

# --- STUDENTS MANAGEMENT ---
@admin_bp.route("/students", methods=["GET"])
@require_auth(["ADMIN", "TEACHER"])
def list_students():
    """List students with division/batch filters."""
    div_id = request.args.get("division_id")
    batch_id = request.args.get("batch_id")

    query = """
        SELECT s.*, u.login_id, u.email, u.full_name, u.phone, u.is_active,
               d.name as division_name, b.name as batch_name
        FROM students s
        JOIN users u ON s.user_id = u.id
        JOIN divisions d ON s.division_id = d.id
        JOIN batches b ON s.batch_id = b.id
        WHERE 1=1
    """
    params = []
    if div_id:
        query += " AND s.division_id = ?"
        params.append(div_id)
    if batch_id:
        query += " AND s.batch_id = ?"
        params.append(batch_id)

    query += " ORDER BY s.enrollment_no ASC"
    students = query_all(query, tuple(params))
    return jsonify({"success": True, "students": students})

@admin_bp.route("/students", methods=["POST"])
@require_auth(["ADMIN", "TEACHER"])
def create_student():
    """Enroll a new student."""
    data = request.get_json(silent=True) or {}
    enrollment_no = str(data.get("enrollment_no", "")).strip().upper()
    email = str(data.get("email", "")).strip().lower()
    full_name = str(data.get("full_name", "")).strip()
    password = str(data.get("password", "")).strip() or "Student@123"
    division_id = data.get("division_id")
    batch_id = data.get("batch_id")
    branch = str(data.get("branch", "Computer Science")).strip()
    semester = int(data.get("semester", 4))
    gender = str(data.get("gender", "Unspecified")).strip()
    dob = str(data.get("dob", "2004-01-01")).strip()
    phone = str(data.get("phone", "")).strip()

    if not enrollment_no or not email or not full_name or not division_id or not batch_id:
        return jsonify({"success": False, "error": "Enrollment number, email, name, division, and batch are required"}), 400

    existing = query_one("SELECT id FROM users WHERE login_id = ? OR email = ?", (enrollment_no, email))
    if existing:
        return jsonify({"success": False, "error": "Enrollment number or email already in use"}), 400

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO users (login_id, email, password_hash, role, full_name, phone, is_active)
            VALUES (?, ?, ?, 'STUDENT', ?, ?, 1)
            """,
            (enrollment_no, email, hash_password(password), full_name, phone)
        )
        u_id = cursor.lastrowid
        cursor.execute(
            """
            INSERT INTO students (user_id, enrollment_no, branch, semester, gender, dob, division_id, batch_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (u_id, enrollment_no, branch, semester, gender, dob, division_id, batch_id)
        )
        s_id = cursor.lastrowid

    log_audit("STUDENT_ENROLLED", "STUDENT", str(s_id), g.user["id"], g.user["full_name"], {
        "enrollment_no": enrollment_no, "name": full_name, "division_id": division_id, "batch_id": batch_id
    }, request.remote_addr)
    return jsonify({"success": True, "student_id": s_id, "message": "Student successfully enrolled"})

# --- ACADEMIC ENTITIES (Subjects, Divisions, Batches) ---
@admin_bp.route("/academic-entities", methods=["GET"])
@require_auth()
def get_academic_entities():
    """Retrieve all divisions, batches, and subjects for dropdown menus."""
    divisions = query_all("SELECT * FROM divisions ORDER BY name ASC")
    batches = query_all("SELECT * FROM batches ORDER BY name ASC")
    subjects = query_all("SELECT * FROM subjects ORDER BY code ASC")
    return jsonify({
        "success": True,
        "divisions": divisions,
        "batches": batches,
        "subjects": subjects
    })

# --- TIMETABLE MANAGEMENT ---
@admin_bp.route("/timetable", methods=["GET", "POST", "DELETE"])
@require_auth(["ADMIN"])
def manage_timetable():
    """Admin CRUD for institutional timetable schedules."""
    if request.method == "GET":
        entries = query_all(
            """
            SELECT t.*, s.name as subject_name, s.code as subject_code,
                   u.full_name as teacher_name, d.name as division_name, b.name as batch_name
            FROM timetables t
            JOIN subjects s ON t.subject_id = s.id
            JOIN teachers tch ON t.teacher_id = tch.id
            JOIN users u ON tch.user_id = u.id
            JOIN divisions d ON t.division_id = d.id
            LEFT JOIN batches b ON t.batch_id = b.id
            ORDER BY t.day_of_week, t.start_time
            """
        )
        return jsonify({"success": True, "timetable": entries})

    elif request.method == "POST":
        data = request.get_json(silent=True) or {}
        academic_year = str(data.get("academic_year", "2026-2027")).strip()
        semester = int(data.get("semester", 4))
        day = str(data.get("day_of_week", "Monday")).strip()
        start_time = str(data.get("start_time", "10:00")).strip()
        end_time = str(data.get("end_time", "10:50")).strip()
        teacher_id = data.get("teacher_id")
        subject_id = data.get("subject_id")
        session_type = str(data.get("session_type", "THEORY")).upper()
        division_id = data.get("division_id")
        batch_id = data.get("batch_id") or None
        room = str(data.get("room", "EA-511")).strip()
        building = str(data.get("building", "Academic Block")).strip()

        if not teacher_id or not subject_id or not division_id:
            return jsonify({"success": False, "error": "Teacher, subject, and division are required"}), 400

        tt_id = execute_query(
            """
            INSERT INTO timetables (
                academic_year, semester, day_of_week, start_time, end_time, teacher_id,
                subject_id, session_type, division_id, batch_id, room, building
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (academic_year, semester, day, start_time, end_time, teacher_id, subject_id, session_type, division_id, batch_id, room, building)
        )
        log_audit("TIMETABLE_ENTRY_CREATED", "TIMETABLE", str(tt_id), g.user["id"], g.user["full_name"], {
            "day": day, "start": start_time, "subject_id": subject_id
        }, request.remote_addr)
        return jsonify({"success": True, "timetable_id": tt_id, "message": "Timetable entry created"})

    else:
        # DELETE
        entry_id = request.args.get("id")
        if not entry_id:
            return jsonify({"success": False, "error": "Entry id is required"}), 400
        execute_query("DELETE FROM timetables WHERE id = ?", (entry_id,))
        log_audit("TIMETABLE_ENTRY_DELETED", "TIMETABLE", str(entry_id), g.user["id"], g.user["full_name"], {}, request.remote_addr)
        return jsonify({"success": True, "message": "Entry removed"})

# --- AUDIT LOGS ---
@admin_bp.route("/audit-logs", methods=["GET"])
@require_auth(["ADMIN"])
def get_audit_logs():
    """Retrieve searchable, chronological audit trails."""
    limit = int(request.args.get("limit", 100))
    action_filter = request.args.get("action")

    query = "SELECT * FROM audit_logs"
    params = []
    if action_filter:
        query += " WHERE action LIKE ?"
        params.append(f"%{action_filter}%")
    query += " ORDER BY created_at DESC LIMIT ?"
    params.append(limit)

    logs = query_all(query, tuple(params))
    return jsonify({"success": True, "logs": logs})
