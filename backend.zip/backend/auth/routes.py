from functools import wraps
from datetime import datetime, timedelta
from flask import Blueprint, request, jsonify, g
from backend.config import config
from backend.database.db import query_one, query_all, execute_query
from backend.auth.security import (
    verify_password,
    hash_password,
    generate_jwt_token,
    decode_jwt_token,
    generate_secure_token,
    hash_token,
)
from backend.auth.email_service import send_password_reset_email
from backend.utils.audit import log_audit

auth_bp = Blueprint("auth", __name__)

def require_auth(allowed_roles=None):
    """Decorator to enforce authenticated JWT sessions and role-based access control (RBAC)."""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            auth_header = request.headers.get("Authorization")
            if not auth_header or not auth_header.startswith("Bearer "):
                return jsonify({"success": False, "error": "Authentication token missing or invalid format"}), 401

            token = auth_header.split(" ")[1]
            payload = decode_jwt_token(token)
            if not payload:
                return jsonify({"success": False, "error": "Session token has expired or is invalid"}), 401

            user_id = payload.get("user_id")
            user = query_one("SELECT * FROM users WHERE id = ? AND is_active = 1", (user_id,))
            if not user:
                return jsonify({"success": False, "error": "User account not found or deactivated"}), 401

            # Role verification
            if allowed_roles:
                roles = [allowed_roles] if isinstance(allowed_roles, str) else allowed_roles
                if user["role"] not in roles:
                    return jsonify({"success": False, "error": f"Access denied. Requires one of roles: {roles}"}), 403

            # Attach user and payload to Flask's request context
            g.user = user
            g.jwt_payload = payload
            return f(*args, **kwargs)
        return decorated_function
    return decorator

@auth_bp.route("/login", methods=["POST"])
def login():
    """Unified login endpoint for ADMIN, TEACHER, and STUDENT roles."""
    data = request.get_json(silent=True) or {}
    identifier = str(data.get("identifier", "")).strip()
    password = str(data.get("password", "")).strip()

    if not identifier or not password:
        return jsonify({"success": False, "error": "Login identifier and password are required"}), 400

    # Search by login_id OR email (Case-insensitive check)
    user = query_one(
        "SELECT * FROM users WHERE LOWER(login_id) = LOWER(?) OR LOWER(email) = LOWER(?)",
        (identifier, identifier)
    )

    if not user or not verify_password(password, user["password_hash"]):
        log_audit("FAILED_LOGIN_ATTEMPT", "USER", identifier, None, "Anonymous", {"reason": "Invalid credentials"}, request.remote_addr)
        return jsonify({"success": False, "error": "Invalid login credentials"}), 401

    if not user["is_active"]:
        return jsonify({"success": False, "error": "Account has been deactivated. Contact institution administrator."}), 403

    # Fetch role-specific details
    teacher_id = None
    student_id = None
    role_meta = {}

    if user["role"] == "TEACHER":
        teacher = query_one("SELECT * FROM teachers WHERE user_id = ?", (user["id"],))
        if teacher:
            teacher_id = teacher["id"]
            role_meta["teacher_id"] = teacher_id
            role_meta["employee_code"] = teacher["employee_code"]
            role_meta["department"] = teacher["department"]
            # Fetch assigned subjects and divisions
            assignments = query_all(
                """
                SELECT ta.id, s.id as subject_id, s.code as subject_code, s.name as subject_name,
                       d.id as division_id, d.name as division_name,
                       b.id as batch_id, b.name as batch_name
                FROM teacher_assignments ta
                JOIN subjects s ON ta.subject_id = s.id
                JOIN divisions d ON ta.division_id = d.id
                LEFT JOIN batches b ON ta.batch_id = b.id
                WHERE ta.teacher_id = ?
                """,
                (teacher_id,)
            )
            role_meta["assignments"] = assignments

    elif user["role"] == "STUDENT":
        student = query_one(
            """
            SELECT s.*, d.name as division_name, b.name as batch_name
            FROM students s
            JOIN divisions d ON s.division_id = d.id
            JOIN batches b ON s.batch_id = b.id
            WHERE s.user_id = ?
            """,
            (user["id"],)
        )
        if student:
            student_id = student["id"]
            role_meta["student_id"] = student_id
            role_meta["enrollment_no"] = student["enrollment_no"]
            role_meta["branch"] = student["branch"]
            role_meta["semester"] = student["semester"]
            role_meta["division_id"] = student["division_id"]
            role_meta["batch_id"] = student["batch_id"]
            role_meta["division_name"] = student["division_name"]
            role_meta["batch_name"] = student["batch_name"]

    # Generate JWT Token
    jwt_payload = {
        "user_id": user["id"],
        "login_id": user["login_id"],
        "email": user["email"],
        "role": user["role"],
        "full_name": user["full_name"],
        "teacher_id": teacher_id,
        "student_id": student_id,
    }
    token = generate_jwt_token(jwt_payload, expires_in_hours=config.JWT_EXPIRATION_HOURS)

    log_audit("USER_LOGIN", "USER", str(user["id"]), user["id"], user["full_name"], {"role": user["role"]}, request.remote_addr)

    return jsonify({
        "success": True,
        "token": token,
        "user": {
            "id": user["id"],
            "login_id": user["login_id"],
            "email": user["email"],
            "role": user["role"],
            "full_name": user["full_name"],
            "phone": user["phone"],
            "avatar_url": user["avatar_url"],
            **role_meta
        }
    })

@auth_bp.route("/me", methods=["GET"])
@require_auth()
def get_current_user():
    """Retrieve verified profile data for current session."""
    user = g.user
    role_meta = {}

    if user["role"] == "TEACHER":
        teacher = query_one("SELECT * FROM teachers WHERE user_id = ?", (user["id"],))
        if teacher:
            role_meta["teacher_id"] = teacher["id"]
            role_meta["employee_code"] = teacher["employee_code"]
            role_meta["department"] = teacher["department"]
            assignments = query_all(
                """
                SELECT ta.id, s.id as subject_id, s.code as subject_code, s.name as subject_name,
                       d.id as division_id, d.name as division_name,
                       b.id as batch_id, b.name as batch_name
                FROM teacher_assignments ta
                JOIN subjects s ON ta.subject_id = s.id
                JOIN divisions d ON ta.division_id = d.id
                LEFT JOIN batches b ON ta.batch_id = b.id
                WHERE ta.teacher_id = ?
                """,
                (teacher["id"],)
            )
            role_meta["assignments"] = assignments

    elif user["role"] == "STUDENT":
        student = query_one(
            """
            SELECT s.*, d.name as division_name, b.name as batch_name
            FROM students s
            JOIN divisions d ON s.division_id = d.id
            JOIN batches b ON s.batch_id = b.id
            WHERE s.user_id = ?
            """,
            (user["id"],)
        )
        if student:
            role_meta["student_id"] = student["id"]
            role_meta["enrollment_no"] = student["enrollment_no"]
            role_meta["branch"] = student["branch"]
            role_meta["semester"] = student["semester"]
            role_meta["division_id"] = student["division_id"]
            role_meta["batch_id"] = student["batch_id"]
            role_meta["division_name"] = student["division_name"]
            role_meta["batch_name"] = student["batch_name"]

    return jsonify({
        "success": True,
        "user": {
            "id": user["id"],
            "login_id": user["login_id"],
            "email": user["email"],
            "role": user["role"],
            "full_name": user["full_name"],
            "phone": user["phone"],
            "avatar_url": user["avatar_url"],
            **role_meta
        }
    })

@auth_bp.route("/forgot-password", methods=["POST"])
def forgot_password():
    """Trigger secure password reset token and email delivery without account enumeration."""
    data = request.get_json(silent=True) or {}
    email = str(data.get("email", "")).strip().lower()

    if not email:
        return jsonify({"success": False, "error": "Email address is required"}), 400

    # Look up user
    user = query_one("SELECT * FROM users WHERE LOWER(email) = ? AND is_active = 1", (email,))
    if user:
        raw_token = generate_secure_token(32)
        tok_hash = hash_token(raw_token)
        expires_at = (datetime.now() + timedelta(minutes=config.RESET_TOKEN_EXPIRATION_MINUTES)).strftime("%Y-%m-%d %H:%M:%S")

        execute_query(
            "INSERT INTO password_resets (user_id, token_hash, expires_at) VALUES (?, ?, ?)",
            (user["id"], tok_hash, expires_at)
        )

        reset_url = f"{config.APP_BASE_URL}/#reset-password?token={raw_token}"
        send_password_reset_email(user["email"], user["full_name"], reset_url)

        log_audit("PASSWORD_RESET_REQUESTED", "USER", str(user["id"]), user["id"], user["full_name"], {"email": email}, request.remote_addr)

    # Generic response protects against user enumeration attacks
    return jsonify({
        "success": True,
        "message": "If an active account exists for this email, password reset instructions have been dispatched."
    })

@auth_bp.route("/reset-password", methods=["POST"])
def reset_password():
    """Verify single-use token and update user password."""
    data = request.get_json(silent=True) or {}
    token = str(data.get("token", "")).strip()
    new_password = str(data.get("new_password", "")).strip()

    if not token or not new_password:
        return jsonify({"success": False, "error": "Reset token and new password are required"}), 400

    if len(new_password) < 6:
        return jsonify({"success": False, "error": "Password must be at least 6 characters long"}), 400

    tok_hash = hash_token(token)
    reset_entry = query_one(
        """
        SELECT * FROM password_resets
        WHERE token_hash = ? AND used_at IS NULL AND datetime(expires_at) > datetime('now')
        ORDER BY id DESC LIMIT 1
        """,
        (tok_hash,)
    )

    if not reset_entry:
        return jsonify({"success": False, "error": "Password reset token is invalid or has expired"}), 400

    user_id = reset_entry["user_id"]
    hashed_pw = hash_password(new_password)

    # Update password and mark token used
    execute_query("UPDATE users SET password_hash = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?", (hashed_pw, user_id))
    execute_query("UPDATE password_resets SET used_at = CURRENT_TIMESTAMP WHERE id = ?", (reset_entry["id"],))

    # Invalidate all remaining open reset tokens for this user
    execute_query("UPDATE password_resets SET used_at = CURRENT_TIMESTAMP WHERE user_id = ? AND used_at IS NULL", (user_id,))

    log_audit("PASSWORD_RESET_COMPLETED", "USER", str(user_id), user_id, "User", {"reset_id": reset_entry["id"]}, request.remote_addr)

    return jsonify({
        "success": True,
        "message": "Password successfully reset. You may now log in with your new credentials."
    })

@auth_bp.route("/change-password", methods=["POST"])
@require_auth()
def change_password():
    """Allow logged in user to update their password by confirming current password."""
    data = request.get_json(silent=True) or {}
    current_password = str(data.get("current_password", "")).strip()
    new_password = str(data.get("new_password", "")).strip()

    if not current_password or not new_password:
        return jsonify({"success": False, "error": "Current and new passwords are required"}), 400

    if len(new_password) < 6:
        return jsonify({"success": False, "error": "New password must be at least 6 characters"}), 400

    user = g.user
    if not verify_password(current_password, user["password_hash"]):
        return jsonify({"success": False, "error": "Current password does not match"}), 400

    hashed_pw = hash_password(new_password)
    execute_query("UPDATE users SET password_hash = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?", (hashed_pw, user["id"]))

    log_audit("PASSWORD_CHANGED", "USER", str(user["id"]), user["id"], user["full_name"], {}, request.remote_addr)

    return jsonify({"success": True, "message": "Password successfully updated"})
