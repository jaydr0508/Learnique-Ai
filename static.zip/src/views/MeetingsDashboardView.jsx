import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNotifications } from '../context/NotificationContext';
import { 
  Video, Calendar, PlusCircle, Users, ArrowRight, Play, 
  History, Clock, Copy, Shield, Sparkles, Check, Search, AlertCircle 
} from 'lucide-react';

export default function MeetingsDashboardView({ onNavigate, onOpenSchedule, onJoinMeetingWithCode }) {
  const { user, token } = useAuth();
  const { notify } = useNotifications();

  const [meetings, setMeetings] = useState([]);
  const [history, setHistory] = useState([]);
  const [activeTab, setActiveTab] = useState('active'); // 'active' | 'history'
  const [meetingCodeInput, setMeetingCodeInput] = useState('');
  const [loading, setLoading] = useState(true);
  const [startingInstant, setStartingInstant] = useState(false);

  useEffect(() => {
    fetchMeetings();
    if (user) fetchHistory();
  }, [token]);

  const fetchMeetings = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/meetings');
      const data = await res.json();
      setMeetings(data.meetings || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const fetchHistory = async () => {
    try {
      const res = await fetch('/api/meetings/history', {
        headers: token ? { Authorization: `Bearer ${token}` } : {}
      });
      const data = await res.json();
      setHistory(data.history || []);
    } catch (err) {}
  };

  const handleStartInstant = async () => {
    try {
      setStartingInstant(true);
      const res = await fetch('/api/meetings/instant', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify({
          title: `${user?.name || 'Instant'} Live Meeting Room`
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to start meeting');

      notify(`Meeting room ready: ${data.meeting.code}`, 'success');
      if (onJoinMeetingWithCode) onJoinMeetingWithCode(data.meeting.code);
    } catch (err) {
      notify(err.message, 'danger');
    } finally {
      setStartingInstant(false);
    }
  };

  const handleJoinSubmit = (e) => {
    e.preventDefault();
    const clean = meetingCodeInput.trim().toLowerCase();
    if (!clean) {
      notify('Please enter a valid meeting code', 'warning');
      return;
    }
    if (onJoinMeetingWithCode) onJoinMeetingWithCode(clean);
  };

  const liveMeetings = meetings.filter(m => m.status === 'LIVE');
  const scheduledMeetings = meetings.filter(m => m.status === 'SCHEDULED');

  return (
    <div style={{ maxWidth: '1280px', margin: '0 auto', padding: '10px 20px 80px 20px', display: 'flex', flexDirection: 'column', gap: '36px' }}>
      {/* Hero Header */}
      <div style={{
        padding: '38px 36px',
        borderRadius: '24px',
        background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.15), rgba(79, 70, 229, 0.1))',
        border: '1px solid var(--border-glass)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '24px'
      }}>
        <div style={{ maxWidth: '640px' }}>
          <span className="badge" style={{ background: 'rgba(6, 182, 212, 0.15)', color: '#06b6d4', marginBottom: '10px' }}>
            <Video size={12} /> High-Definition Virtual Classrooms
          </span>
          <h1 style={{ fontSize: '2.4rem', fontWeight: '800', margin: '6px 0 10px 0', letterSpacing: '-0.02em' }}>
            Online Meetings & Collaboration
          </h1>
          <p style={{ fontSize: '0.98rem', color: 'var(--text-secondary)', lineHeight: 1.5 }}>
            Real-time video conferencing designed for academic lectures, team code reviews, student doubt-solving, and symposium discussions.
          </p>
        </div>

        {/* Quick Launch Buttons */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
          <button
            onClick={handleStartInstant}
            disabled={startingInstant}
            className="btn-primary"
            style={{ padding: '13px 24px', borderRadius: '12px', fontSize: '0.95rem', fontWeight: '700', gap: '8px' }}
          >
            <Video size={18} /> {startingInstant ? 'Initializing...' : 'Start Instant Meeting'}
          </button>
          {user?.role !== 'STUDENT' && (
            <button
              onClick={() => {
                if (!user) onNavigate('login');
                else if (onOpenSchedule) onOpenSchedule();
              }}
              className="btn-secondary"
              style={{ padding: '12px 24px', borderRadius: '12px', fontSize: '0.92rem', gap: '8px' }}
            >
              <Calendar size={18} style={{ color: 'var(--accent-primary)' }} /> Schedule a Future Meeting
            </button>
          )}
        </div>
      </div>

      {/* Join With Meeting Code Strip */}
      <div style={{
        padding: '20px 24px',
        borderRadius: '16px',
        background: 'var(--bg-secondary)',
        border: '1px solid var(--border-glass)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '16px'
      }}>
        <div>
          <div style={{ fontWeight: '700', fontSize: '1rem' }}>Join an Existing Meeting</div>
          <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
            Enter the 10-character code provided by your host or lecturer
          </div>
        </div>

        <form onSubmit={handleJoinSubmit} style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
          <input
            type="text"
            placeholder="e.g. quiz-cs401-algo"
            value={meetingCodeInput}
            onChange={e => setMeetingCodeInput(e.target.value)}
            style={{
              padding: '10px 16px',
              borderRadius: '10px',
              background: 'var(--bg-tertiary)',
              border: '1px solid var(--border-glass)',
              color: 'var(--text-primary)',
              fontFamily: 'var(--font-mono)',
              fontSize: '0.9rem',
              minWidth: '220px'
            }}
          />
          <button
            type="submit"
            className="btn-primary"
            style={{ padding: '10px 20px', borderRadius: '10px', fontSize: '0.9rem' }}
          >
            Join Room
          </button>
        </form>
      </div>

      {/* Navigation Tabs */}
      <div style={{ display: 'flex', gap: '12px', borderBottom: '1px solid var(--border-subtle)', paddingBottom: '8px' }}>
        <button
          onClick={() => setActiveTab('active')}
          style={{
            padding: '8px 16px',
            borderRadius: '10px',
            border: 'none',
            background: activeTab === 'active' ? 'var(--accent-light)' : 'transparent',
            color: activeTab === 'active' ? 'var(--accent-primary)' : 'var(--text-secondary)',
            fontWeight: activeTab === 'active' ? '700' : '500',
            fontSize: '0.9rem',
            cursor: 'pointer'
          }}
        >
          Live & Upcoming Meetings ({meetings.length})
        </button>

        {user && (
          <button
            onClick={() => setActiveTab('history')}
            style={{
              padding: '8px 16px',
              borderRadius: '10px',
              border: 'none',
              background: activeTab === 'history' ? 'var(--accent-light)' : 'transparent',
              color: activeTab === 'history' ? 'var(--accent-primary)' : 'var(--text-secondary)',
              fontWeight: activeTab === 'history' ? '700' : '500',
              fontSize: '0.9rem',
              cursor: 'pointer'
            }}
          >
            Meeting History ({history.length})
          </button>
        )}
      </div>

      {/* Main Tab Content */}
      {activeTab === 'active' ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '30px' }}>
          {/* Live Now Section */}
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '16px' }}>
              <div style={{
                width: '10px',
                height: '10px',
                borderRadius: '50%',
                background: 'var(--success)',
                boxShadow: '0 0 10px var(--success)'
              }} />
              <h3 style={{ fontSize: '1.25rem', margin: 0 }}>Currently Live Rooms</h3>
            </div>

            {liveMeetings.length === 0 ? (
              <div style={{ padding: '28px', borderRadius: '14px', background: 'var(--bg-secondary)', border: '1px solid var(--border-glass)', textAlign: 'center', color: 'var(--text-muted)' }}>
                No meetings currently in session. Click 'Start Instant Meeting' to host one now!
              </div>
            ) : (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(350px, 1fr))', gap: '18px' }}>
                {liveMeetings.map(m => (
                  <div
                    key={m.id}
                    className="glass-panel"
                    style={{
                      padding: '22px',
                      borderRadius: '16px',
                      background: 'var(--bg-secondary)',
                      border: '1px solid rgba(16, 185, 129, 0.4)',
                      display: 'flex',
                      flexDirection: 'column',
                      justifyContent: 'space-between',
                      gap: '16px'
                    }}
                  >
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
                        <span className="badge badge-present" style={{ fontSize: '0.72rem' }}>
                          ● IN PROGRESS
                        </span>
                        <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>
                          {m.code}
                        </span>
                      </div>

                      <h4 style={{ fontSize: '1.1rem', margin: '4px 0 6px 0' }}>{m.title}</h4>
                      <p style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', lineHeight: 1.4 }}>
                        {m.description}
                      </p>
                    </div>

                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: '0.78rem', color: 'var(--text-muted)', marginBottom: '14px' }}>
                        <span>Host: <strong style={{ color: 'var(--text-primary)' }}>{m.host_name}</strong></span>
                        {m.active_count > 0 && (
                          <span style={{ color: 'var(--success)', display: 'flex', alignItems: 'center', gap: '4px' }}>
                            <Users size={13} /> {m.active_count} active
                          </span>
                        )}
                      </div>

                      <button
                        onClick={() => onJoinMeetingWithCode && onJoinMeetingWithCode(m.code)}
                        className="btn-primary"
                        style={{ width: '100%', padding: '10px', borderRadius: '10px', fontSize: '0.88rem', background: 'linear-gradient(135deg, var(--success), #059669)' }}
                      >
                        Enter Meeting Room
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Scheduled Section */}
          <div>
            <h3 style={{ fontSize: '1.25rem', marginBottom: '16px' }}>Upcoming Scheduled Meetings</h3>
            {scheduledMeetings.length === 0 ? (
              <div style={{ padding: '28px', borderRadius: '14px', background: 'var(--bg-secondary)', border: '1px solid var(--border-glass)', textAlign: 'center', color: 'var(--text-muted)' }}>
                No scheduled meetings ahead.
              </div>
            ) : (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(350px, 1fr))', gap: '18px' }}>
                {scheduledMeetings.map(m => (
                  <div
                    key={m.id}
                    className="glass-panel"
                    style={{
                      padding: '22px',
                      borderRadius: '16px',
                      background: 'var(--bg-secondary)',
                      border: '1px solid var(--border-glass)',
                      display: 'flex',
                      flexDirection: 'column',
                      justifyContent: 'space-between',
                      gap: '16px'
                    }}
                  >
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
                        <span className="badge" style={{ background: 'var(--accent-light)', color: 'var(--accent-primary)', fontSize: '0.72rem' }}>
                          SCHEDULED
                        </span>
                        <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>
                          {m.code}
                        </span>
                      </div>

                      <h4 style={{ fontSize: '1.1rem', margin: '4px 0 6px 0' }}>{m.title}</h4>
                      <p style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', lineHeight: 1.4 }}>
                        {m.description}
                      </p>
                    </div>

                    <div>
                      <div style={{ padding: '10px', borderRadius: '10px', background: 'var(--bg-surface)', fontSize: '0.78rem', color: 'var(--text-muted)', marginBottom: '14px', display: 'flex', justifyContent: 'space-between' }}>
                        <span>{m.scheduled_date} at {m.scheduled_start_time}</span>
                        <span>{m.duration_minutes} Mins</span>
                      </div>

                      <button
                        onClick={() => onJoinMeetingWithCode && onJoinMeetingWithCode(m.code)}
                        className="btn-secondary"
                        style={{ width: '100%', padding: '10px', borderRadius: '10px', fontSize: '0.88rem' }}
                      >
                        Open Meeting Lobby
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      ) : (
        /* History Section */
        <div>
          {history.length === 0 ? (
            <div style={{ padding: '40px', textAlign: 'center', color: 'var(--text-muted)' }}>
              No past meeting records found.
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {history.map(h => (
                <div
                  key={h.id}
                  style={{
                    padding: '16px 20px',
                    borderRadius: '14px',
                    background: 'var(--bg-secondary)',
                    border: '1px solid var(--border-subtle)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    flexWrap: 'wrap',
                    gap: '12px'
                  }}
                >
                  <div>
                    <h4 style={{ fontSize: '0.98rem', margin: 0 }}>{h.title}</h4>
                    <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginTop: '2px' }}>
                      Host: {h.host_name} • Date: {new Date(h.created_at).toLocaleDateString()} • Code: {h.code}
                    </div>
                  </div>

                  <span className="badge" style={{ background: 'var(--bg-surface)', color: 'var(--text-secondary)' }}>
                    Completed
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
