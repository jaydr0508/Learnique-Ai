import json
from datetime import datetime, timedelta
from flask import Blueprint, request, jsonify, g
from backend.config import config
from backend.auth.routes import require_auth
from backend.database.db import query_one, query_all, execute_query, get_db
from backend.ai.quiz_generator import generate_and_validate_quiz
from backend.ai.file_processor import extract_text_from_file
from backend.auth.security import generate_secure_token
from backend.utils.qr_generator import generate_qr_data_url
from backend.quiz.service import (
    generate_quiz_code,
    check_quiz_eligibility,
    start_or_resume_quiz_attempt,
    record_quiz_violation,
    save_quiz_answer,
    submit_quiz_attempt,
    classify_performance
)
from backend.utils.audit import log_audit

quiz_bp = Blueprint("quiz", __name__)

@quiz_bp.route("/generate", methods=["POST"])
@require_auth(["TEACHER", "ADMIN"])
def generate_questions_preview():
    """Generate structured examination questions via AI with strict count enforcement."""
    data = request.get_json(silent=True) or {}
    subject = str(data.get("subject", "Computer Science")).strip()
    topic = str(data.get("topic", "General Examination")).strip()
    instructions = str(data.get("instructions", "")).strip()

    total_q = int(data.get("total_questions", 10))
    mcq_cnt = int(data.get("mcq_count", 5))
    num_cnt = int(data.get("numerical_count", 3))
    ans_cnt = int(data.get("answer_count", 2))

    easy_cnt = int(data.get("easy_count", 3))
    med_cnt = int(data.get("medium_count", 4))
    hard_cnt = int(data.get("hard_count", 3))

    ref_text = data.get("reference_text")

    try:
        res = generate_and_validate_quiz(
            subject=subject,
            topic=topic,
            instructions=instructions,
            total_questions=total_q,
            mcq_count=mcq_cnt,
            numerical_count=num_cnt,
            answer_count=ans_cnt,
            easy_count=easy_cnt,
            medium_count=med_cnt,
            hard_count=hard_cnt,
            reference_text=ref_text
        )
        return jsonify({"success": True, "data": res})
    except ValueError as ve:
        return jsonify({"success": False, "error": str(ve)}), 400
    except Exception as e:
        return jsonify({"success": False, "error": f"AI Generation error: {str(e)}"}), 500

@quiz_bp.route("/upload-material", methods=["POST"])
@require_auth(["TEACHER", "ADMIN"])
def upload_study_material():
    """Upload PDF, DOCX, or TXT notes/question papers for AI quiz synthesis."""
    if "file" not in request.files:
        return jsonify({"success": False, "error": "No file uploaded"}), 400

    file = request.files["file"]
    if not file.filename:
        return jsonify({"success": False, "error": "Selected file is empty"}), 400

    success, text, category = extract_text_from_file(file, file.filename)
    if not success:
        return jsonify({"success": False, "error": category}), 400

    return jsonify({
        "success": True,
        "filename": file.filename,
        "category": category,
        "text_sample": text[:1500],
        "extracted_text": text
    })

@quiz_bp.route("/create", methods=["POST"])
@require_auth(["TEACHER", "ADMIN"])
def create_quiz():
    """Save and schedule a verified examination."""
    data = request.get_json(silent=True) or {}
    user = g.user
    teacher_id = None

    if user["role"] == "TEACHER":
        teacher = query_one("SELECT id FROM teachers WHERE user_id = ?", (user["id"],))
        if not teacher:
            return jsonify({"success": False, "error": "Teacher profile not found"}), 404
        teacher_id = teacher["id"]
    else:
        teacher_id = data.get("teacher_id")

    title = str(data.get("title", "")).strip()
    subject_id = data.get("subject_id")
    division_id = data.get("division_id")
    batch_id = data.get("batch_id")
    topic = str(data.get("topic", "")).strip()
    instructions = str(data.get("instructions", "")).strip()
    duration_minutes = int(data.get("duration_minutes", 30))
    start_time = data.get("start_time")
    end_time = data.get("end_time")
    result_release_time = data.get("result_release_time")
    passing_marks = float(data.get("passing_marks", 4.0))
    max_tab_switches = int(data.get("max_tab_switches", 3))

    attendance_req_type = str(data.get("attendance_requirement_type", "NONE")).upper()
    linked_sess_id = data.get("linked_attendance_session_id")
    min_att_pct = float(data.get("min_attendance_percentage", 0.0))

    questions = data.get("questions", [])
    if not title or not subject_id or not division_id or not questions:
        return jsonify({"success": False, "error": "Title, subject, division, and questions are required"}), 400

    if not start_time or not end_time or not result_release_time:
        return jsonify({"success": False, "error": "Start time, end time, and result release time are required"}), 400

    code = generate_quiz_code()
    join_token = generate_secure_token(16)
    total_marks = 0.0
    for q in questions:
        try:
            total_marks += float(q.get("marks") if q.get("marks") is not None else 1.0)
        except (ValueError, TypeError):
            total_marks += 1.0

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO quizzes (
                code, join_token, title, teacher_id, subject_id, division_id, batch_id,
                topic, instructions, duration_minutes, start_time, end_time, result_release_time,
                total_marks, passing_marks, max_tab_switches, attendance_requirement_type,
                linked_attendance_session_id, min_attendance_percentage, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'SCHEDULED')
            """,
            (
                code, join_token, title, teacher_id, subject_id, division_id, batch_id,
                topic, instructions, duration_minutes, start_time, end_time, result_release_time,
                total_marks, passing_marks, max_tab_switches, attendance_req_type,
                linked_sess_id, min_att_pct
            )
        )
        quiz_id = cursor.lastrowid

        for idx, q in enumerate(questions):
            opts_json = json.dumps(q.get("options")) if q.get("options") else None
            try:
                m_val = float(q.get("marks") if q.get("marks") is not None else 1.0)
            except (ValueError, TypeError):
                m_val = 1.0
            try:
                tol_val = float(q.get("numerical_tolerance") if q.get("numerical_tolerance") is not None else 0.05)
            except (ValueError, TypeError):
                tol_val = 0.05
            cursor.execute(
                """
                INSERT INTO quiz_questions (
                    quiz_id, question_order, question_type, question_text, options_json,
                    correct_answer, explanation, difficulty, marks, numerical_tolerance, rubric_text
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    quiz_id, idx + 1, q.get("type", "MCQ"), q.get("question", ""), opts_json,
                    str(q.get("correct_answer", "")), q.get("explanation"),
                    q.get("difficulty", "MEDIUM"), m_val, tol_val, q.get("rubric_text")
                )
            )

    log_audit("QUIZ_CREATED", "QUIZ", str(quiz_id), user["id"], user["full_name"], {
        "title": title, "code": code, "questions_count": len(questions)
    }, request.remote_addr)

    return jsonify({
        "success": True,
        "quiz_id": quiz_id,
        "code": code,
        "join_token": join_token,
        "join_url": f"{config.APP_BASE_URL}/join/quiz/{join_token}"
    })

@quiz_bp.route("/<int:quiz_id>/qr", methods=["GET"])
@require_auth()
def get_quiz_join_qr(quiz_id: int):
    """Generate high-resolution scannable QR code encoding the genuine Quiz Join Web URL."""
    quiz = query_one(
        """
        SELECT q.*, s.name as subject_name, s.code as subject_code, d.name as division_name
        FROM quizzes q
        JOIN subjects s ON q.subject_id = s.id
        JOIN divisions d ON q.division_id = d.id
        WHERE q.id = ?
        """,
        (quiz_id,)
    )
    if not quiz:
        return jsonify({"success": False, "error": "Quiz not found"}), 404

    join_url = f"{config.APP_BASE_URL}/join/quiz/{quiz['join_token']}"
    qr_data_url = generate_qr_data_url(join_url)

    return jsonify({
        "success": True,
        "quiz_id": quiz["id"],
        "code": quiz["code"],
        "title": quiz["title"],
        "subject_name": quiz["subject_name"],
        "division_name": quiz["division_name"],
        "join_url": join_url,
        "qr_image": qr_data_url
    })

@quiz_bp.route("/verify-eligibility", methods=["POST"])
@require_auth(["STUDENT"])
def verify_eligibility():
    """Check student examination access by either Exam Code or Scanned QR Join Token."""
    data = request.get_json(silent=True) or {}
    identifier = str(data.get("identifier", "")).strip() # Can be Code (QZ-XXX) or Join Token

    if not identifier:
        return jsonify({"success": False, "error": "Quiz Code or QR Token required"}), 400

    student = query_one("SELECT id FROM students WHERE user_id = ?", (g.user["id"],))
    if not student:
        return jsonify({"success": False, "error": "Student profile not found"}), 404

    # Search quiz by code or join_token
    quiz = query_one(
        "SELECT * FROM quizzes WHERE code = ? OR join_token = ?",
        (identifier, identifier)
    )
    if not quiz:
        return jsonify({"success": False, "error": "Invalid Quiz Code or QR scan."}), 404

    eligible, msg, meta = check_quiz_eligibility(student["id"], quiz["id"])
    if not eligible:
        return jsonify({"success": False, "error": msg, "quiz_id": quiz["id"]}), 403

    q_data = meta["quiz"]
    return jsonify({
        "success": True,
        "eligible": True,
        "message": msg,
        "quiz": {
            "id": q_data["id"],
            "code": q_data["code"],
            "title": q_data["title"],
            "subject_name": q_data["subject_name"],
            "duration_minutes": q_data["duration_minutes"],
            "total_marks": q_data["total_marks"],
            "max_tab_switches": q_data["max_tab_switches"],
            "remaining_seconds": meta["remaining_seconds"],
            "is_resumed": meta["is_resumed"]
        }
    })

@quiz_bp.route("/<int:quiz_id>/start", methods=["POST"])
@require_auth(["STUDENT"])
def start_quiz(quiz_id: int):
    """Start or resume examination attempt and return proctored questions."""
    student = query_one("SELECT id FROM students WHERE user_id = ?", (g.user["id"],))
    if not student:
        return jsonify({"success": False, "error": "Student profile not found"}), 404

    success, msg, attempt_data = start_or_resume_quiz_attempt(student["id"], quiz_id)
    if not success:
        return jsonify({"success": False, "error": msg}), 403

    return jsonify({"success": True, "data": attempt_data})

@quiz_bp.route("/attempt/<int:attempt_id>/save-answer", methods=["POST"])
@require_auth(["STUDENT"])
def save_answer(attempt_id: int):
    """Auto-save question responses during active examination."""
    data = request.get_json(silent=True) or {}
    question_id = data.get("question_id")
    answer = str(data.get("answer", "")).strip()

    if not question_id:
        return jsonify({"success": False, "error": "Question ID required"}), 400

    save_quiz_answer(attempt_id, question_id, answer)
    return jsonify({"success": True})

@quiz_bp.route("/attempt/<int:attempt_id>/violation", methods=["POST"])
@require_auth(["STUDENT"])
def report_violation(attempt_id: int):
    """Record tab/window switch violation and trigger auto-submit if limit exceeded."""
    data = request.get_json(silent=True) or {}
    v_type = str(data.get("type", "TAB_SWITCH"))
    duration = int(data.get("duration_seconds", 1))

    success, auto_sub, count, reason = record_quiz_violation(attempt_id, v_type, duration)
    return jsonify({
        "success": success,
        "auto_submitted": auto_sub,
        "violations_count": count,
        "reason": reason
    })

@quiz_bp.route("/attempt/<int:attempt_id>/submit", methods=["POST"])
@require_auth(["STUDENT"])
def submit_attempt(attempt_id: int):
    """Submit examination attempt for scoring."""
    res = submit_quiz_attempt(attempt_id, is_auto=False)
    return jsonify(res)

@quiz_bp.route("/<int:quiz_id>/live", methods=["GET"])
@require_auth(["TEACHER", "ADMIN"])
def live_monitor(quiz_id: int):
    """Teacher live dashboard showing attempting students, progress, and violations."""
    quiz = query_one("SELECT * FROM quizzes WHERE id = ?", (quiz_id,))
    if not quiz:
        return jsonify({"success": False, "error": "Quiz not found"}), 404

    attempts = query_all(
        """
        SELECT a.*, st.enrollment_no, u.full_name, b.name as batch_name,
               (SELECT COUNT(*) FROM quiz_answers ans WHERE ans.attempt_id = a.id AND ans.student_answer IS NOT NULL AND ans.student_answer != '') as answered_count,
               (SELECT COUNT(*) FROM quiz_questions qq WHERE qq.quiz_id = a.quiz_id) as total_questions
        FROM quiz_attempts a
        JOIN students st ON a.student_id = st.id
        JOIN users u ON st.user_id = u.id
        JOIN batches b ON st.batch_id = b.id
        WHERE a.quiz_id = ?
        ORDER BY a.start_time DESC
        """,
        (quiz_id,)
    )

    return jsonify({"success": True, "quiz": quiz, "attempts": attempts})

@quiz_bp.route("/attempt/<int:attempt_id>/evaluate", methods=["GET", "POST"])
@require_auth(["TEACHER", "ADMIN"])
def evaluate_attempt(attempt_id: int):
    """Faculty reviews subjective questions, awards marks, and adds pedagogical feedback."""
    if request.method == "GET":
        attempt = query_one(
            """
            SELECT a.*, u.full_name, st.enrollment_no, q.title as quiz_title
            FROM quiz_attempts a
            JOIN students st ON a.student_id = st.id
            JOIN users u ON st.user_id = u.id
            JOIN quizzes q ON a.quiz_id = q.id
            WHERE a.id = ?
            """,
            (attempt_id,)
        )
        if not attempt:
            return jsonify({"success": False, "error": "Attempt not found"}), 404

        answers = query_all(
            """
            SELECT ans.*, q.question_order, q.question_type, q.question_text,
                   q.marks as max_marks, q.correct_answer, q.explanation, q.rubric_text
            FROM quiz_answers ans
            JOIN quiz_questions q ON ans.question_id = q.id
            WHERE ans.attempt_id = ?
            ORDER BY q.question_order ASC
            """,
            (attempt_id,)
        )
        return jsonify({"success": True, "attempt": attempt, "answers": answers})

    # POST: Save evaluation
    data = request.get_json(silent=True) or {}
    evaluations = data.get("evaluations", []) # list of {answer_id, marks_awarded, feedback}

    with get_db() as conn:
        cursor = conn.cursor()
        for ev in evaluations:
            cursor.execute(
                """
                UPDATE quiz_answers
                SET marks_awarded = ?, teacher_feedback = ?, is_evaluated = 1,
                    evaluated_by = ?, evaluated_at = CURRENT_TIMESTAMP
                WHERE id = ?
                """,
                (float(ev["marks_awarded"]), ev.get("feedback", ""), g.user["id"], ev["answer_id"])
            )

        # Recalculate total score
        cursor.execute("SELECT SUM(marks_awarded) as total FROM quiz_answers WHERE attempt_id = ?", (attempt_id,))
        new_total = cursor.fetchone()["total"] or 0.0
        cursor.execute("UPDATE quiz_attempts SET total_score = ? WHERE id = ?", (new_total, attempt_id))

    log_audit("QUIZ_ATTEMPT_EVALUATED", "QUIZ_ATTEMPT", str(attempt_id), g.user["id"], g.user["full_name"], {
        "new_total": new_total
    }, request.remote_addr)

    return jsonify({"success": True, "message": "Evaluation successfully saved", "new_total": new_total})

@quiz_bp.route("/attempt/<int:attempt_id>/result", methods=["GET"])
@require_auth()
def get_attempt_result(attempt_id: int):
    """Retrieve detailed examination report for student or teacher, respecting publication timing."""
    user = g.user
    attempt = query_one(
        """
        SELECT a.*, q.id as quiz_id, q.title as quiz_title, q.code as quiz_code,
               q.total_marks as quiz_total_marks, q.passing_marks, q.result_release_time,
               s.name as subject_name, s.code as subject_code,
               u.full_name as student_name, st.enrollment_no
        FROM quiz_attempts a
        JOIN quizzes q ON a.quiz_id = q.id
        JOIN subjects s ON q.subject_id = s.id
        JOIN students st ON a.student_id = st.id
        JOIN users u ON st.user_id = u.id
        WHERE a.id = ?
        """,
        (attempt_id,)
    )
    if not attempt:
        return jsonify({"success": False, "error": "Attempt not found"}), 404

    # Result release gate: Students cannot see answers until result release time
    now = datetime.now()
    release_time = datetime.strptime(attempt["result_release_time"], "%Y-%m-%d %H:%M:%S")
    is_published = now >= release_time or user["role"] in ("TEACHER", "ADMIN")

    pct = round((attempt["total_score"] / attempt["quiz_total_marks"] * 100), 2) if attempt["quiz_total_marks"] > 0 else 0.0
    classification = classify_performance(pct)

    if not is_published and user["role"] == "STUDENT":
        return jsonify({
            "success": True,
            "published": False,
            "message": f"Results will be officially released on {attempt['result_release_time']}.",
            "attempt": {
                "id": attempt["id"],
                "quiz_title": attempt["quiz_title"],
                "subject_name": attempt["subject_name"],
                "status": attempt["status"],
                "submit_time": attempt["submit_time"],
                "result_release_time": attempt["result_release_time"]
            }
        })

    # Fetch question-wise details
    answers = query_all(
        """
        SELECT ans.id, ans.question_id, ans.student_answer, ans.marks_awarded,
               ans.is_evaluated, ans.teacher_feedback,
               qq.question_order, qq.question_type, qq.question_text, qq.options_json,
               qq.correct_answer, qq.explanation, qq.marks as max_marks, qq.difficulty
        FROM quiz_answers ans
        JOIN quiz_questions qq ON ans.question_id = qq.id
        WHERE ans.attempt_id = ?
        ORDER BY qq.question_order ASC
        """,
        (attempt_id,)
    )

    questions_res = []
    for a in answers:
        questions_res.append({
            "order": a["question_order"],
            "type": a["question_type"],
            "question": a["question_text"],
            "options": json.loads(a["options_json"]) if a["options_json"] else None,
            "student_answer": a["student_answer"],
            "correct_answer": a["correct_answer"],
            "explanation": a["explanation"],
            "max_marks": a["max_marks"],
            "marks_awarded": a["marks_awarded"],
            "teacher_feedback": a["teacher_feedback"],
            "difficulty": a["difficulty"]
        })

    return jsonify({
        "success": True,
        "published": True,
        "attempt": {
            "id": attempt["id"],
            "quiz_title": attempt["quiz_title"],
            "quiz_code": attempt["quiz_code"],
            "subject_name": attempt["subject_name"],
            "subject_code": attempt["subject_code"],
            "student_name": attempt["student_name"],
            "enrollment_no": attempt["enrollment_no"],
            "start_time": attempt["start_time"],
            "submit_time": attempt["submit_time"],
            "time_spent_seconds": attempt["time_spent_seconds"],
            "status": attempt["status"],
            "score": attempt["total_score"],
            "total_marks": attempt["quiz_total_marks"],
            "percentage": pct,
            "classification": classification,
            "violations_count": attempt["violations_count"],
            "auto_submit_reason": attempt["auto_submit_reason"]
        },
        "questions": questions_res
    })

@quiz_bp.route("/list", methods=["GET"])
@require_auth()
def list_quizzes():
    """Retrieve quizzes list according to authenticated user role."""
    user = g.user
    if user["role"] == "TEACHER":
        teacher = query_one("SELECT id FROM teachers WHERE user_id = ?", (user["id"],))
        quizzes = query_all(
            """
            SELECT q.*, s.name as subject_name, s.code as subject_code,
                   d.name as division_name, b.name as batch_name,
                   (SELECT COUNT(*) FROM quiz_attempts a WHERE a.quiz_id = q.id) as attempts_count
            FROM quizzes q
            JOIN subjects s ON q.subject_id = s.id
            JOIN divisions d ON q.division_id = d.id
            LEFT JOIN batches b ON q.batch_id = b.id
            WHERE q.teacher_id = ?
            ORDER BY q.created_at DESC
            """,
            (teacher["id"],)
        )
    elif user["role"] == "STUDENT":
        student = query_one("SELECT * FROM students WHERE user_id = ?", (user["id"],))
        quizzes = query_all(
            """
            SELECT q.*, s.name as subject_name, s.code as subject_code,
                   u.full_name as teacher_name,
                   a.id as student_attempt_id, a.status as attempt_status, a.total_score,
                   a.submit_time
            FROM quizzes q
            JOIN subjects s ON q.subject_id = s.id
            JOIN teachers tch ON q.teacher_id = tch.id
            JOIN users u ON tch.user_id = u.id
            LEFT JOIN quiz_attempts a ON a.quiz_id = q.id AND a.student_id = ?
            WHERE q.division_id = ? AND (q.batch_id IS NULL OR q.batch_id = ?)
            ORDER BY q.start_time DESC
            """,
            (student["id"], student["division_id"], student["batch_id"])
        )
    else:
        # Admin
        quizzes = query_all(
            """
            SELECT q.*, s.name as subject_name, s.code as subject_code,
                   u.full_name as teacher_name, d.name as division_name, b.name as batch_name,
                   (SELECT COUNT(*) FROM quiz_attempts a WHERE a.quiz_id = q.id) as attempts_count
            FROM quizzes q
            JOIN subjects s ON q.subject_id = s.id
            JOIN teachers tch ON q.teacher_id = tch.id
            JOIN users u ON tch.user_id = u.id
            JOIN divisions d ON q.division_id = d.id
            LEFT JOIN batches b ON q.batch_id = b.id
            ORDER BY q.created_at DESC
            """
        )

    return jsonify({"success": True, "quizzes": quizzes})
