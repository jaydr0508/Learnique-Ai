const bcrypt = require('bcryptjs');
const { db, initSchema } = require('./db');
const config = require('../config');

function seedDatabase() {
  initSchema();

  const adminCount = db.prepare("SELECT COUNT(*) AS count FROM users WHERE role = 'ADMIN'").get().count;

  if (adminCount === 0) {
    console.log('Seeding initial administrator account from secure bootstrap configuration...');
    const salt = bcrypt.genSaltSync(10);
    const hash = bcrypt.hashSync(config.ADMIN_INITIAL.password, salt);

    db.prepare(`
      INSERT INTO users (identifier, email, password_hash, role, name)
      VALUES (?, ?, ?, 'ADMIN', ?)
    `).run(
      config.ADMIN_INITIAL.identifier,
      config.ADMIN_INITIAL.email,
      hash,
      config.ADMIN_INITIAL.name
    );
    console.log(`Initial admin (${config.ADMIN_INITIAL.identifier}) seeded successfully.`);
  }

  // Check if academic structure is seeded
  const courseCount = db.prepare("SELECT COUNT(*) AS count FROM courses").get().count;
  if (courseCount === 0) {
    console.log('Seeding academic structure: Courses, Semesters, Divisions, Batches, Subjects...');
    
    // Course
    const courseRes = db.prepare("INSERT INTO courses (code, name) VALUES ('BTECH-CSE', 'B.Tech Computer Science & Engineering')").run();
    const courseId = courseRes.lastInsertRowid;

    // Semester 5
    const semRes = db.prepare("INSERT INTO semesters (course_id, number, academic_year) VALUES (?, 5, '2025-2026')").run(courseId);
    const semesterId = semRes.lastInsertRowid;

    // Divisions
    const divA1Res = db.prepare("INSERT INTO divisions (semester_id, name) VALUES (?, 'A1')").run(semesterId);
    const divA1Id = divA1Res.lastInsertRowid;

    const divA2Res = db.prepare("INSERT INTO divisions (semester_id, name) VALUES (?, 'A2')").run(semesterId);
    const divA2Id = divA2Res.lastInsertRowid;

    // Batches under A1: B1, B2, B3
    const batchA1B1 = db.prepare("INSERT INTO batches (division_id, name) VALUES (?, 'B1')").run(divA1Id).lastInsertRowid;
    const batchA1B2 = db.prepare("INSERT INTO batches (division_id, name) VALUES (?, 'B2')").run(divA1Id).lastInsertRowid;
    const batchA1B3 = db.prepare("INSERT INTO batches (division_id, name) VALUES (?, 'B3')").run(divA1Id).lastInsertRowid;

    // Batches under A2: B1, B3
    const batchA2B1 = db.prepare("INSERT INTO batches (division_id, name) VALUES (?, 'B1')").run(divA2Id).lastInsertRowid;
    const batchA2B3 = db.prepare("INSERT INTO batches (division_id, name) VALUES (?, 'B3')").run(divA2Id).lastInsertRowid;

    // Subjects
    const subCep = db.prepare("INSERT INTO subjects (semester_id, code, name, type) VALUES (?, 'CS501', 'Comprehensive English Proficiency', 'BOTH')").run(semesterId).lastInsertRowid;
    const subAds = db.prepare("INSERT INTO subjects (semester_id, code, name, type) VALUES (?, 'CS502', 'Advanced Data Structures', 'BOTH')").run(semesterId).lastInsertRowid;
    const subDbms = db.prepare("INSERT INTO subjects (semester_id, code, name, type) VALUES (?, 'CS503', 'Database Management Systems', 'BOTH')").run(semesterId).lastInsertRowid;

    // Seed Teachers
    const salt = bcrypt.genSaltSync(10);
    const teacherPass = bcrypt.hashSync('TeacherPass@2026', salt);

    const t1Res = db.prepare(`
      INSERT INTO users (identifier, email, password_hash, role, name, phone)
      VALUES ('prof.sharma', 'sharma@quizify.edu', ?, 'TEACHER', 'Prof. Rajesh Sharma', '+91 98765 43210')
    `).run(teacherPass);
    const teacher1Id = t1Res.lastInsertRowid;

    const t2Res = db.prepare(`
      INSERT INTO users (identifier, email, password_hash, role, name, phone)
      VALUES ('dr.verma', 'verma@quizify.edu', ?, 'TEACHER', 'Dr. Sunita Verma', '+91 98765 43211')
    `).run(teacherPass);
    const teacher2Id = t2Res.lastInsertRowid;

    // Teacher 1 assignments (CEP & ADS for A1 and A2)
    // CEP: Div A1 (all batches) and Div A2
    db.prepare("INSERT INTO teacher_assignments (teacher_id, subject_id, division_id, batch_id) VALUES (?, ?, ?, NULL)").run(teacher1Id, subCep, divA1Id);
    db.prepare("INSERT INTO teacher_assignments (teacher_id, subject_id, division_id, batch_id) VALUES (?, ?, ?, NULL)").run(teacher1Id, subCep, divA2Id);
    // ADS: Div A1 (Batch B1, B2)
    db.prepare("INSERT INTO teacher_assignments (teacher_id, subject_id, division_id, batch_id) VALUES (?, ?, ?, ?)").run(teacher1Id, subAds, divA1Id, batchA1B1);
    db.prepare("INSERT INTO teacher_assignments (teacher_id, subject_id, division_id, batch_id) VALUES (?, ?, ?, ?)").run(teacher1Id, subAds, divA1Id, batchA1B2);

    // Teacher 2 assignments (DBMS for A1 and batches)
    db.prepare("INSERT INTO teacher_assignments (teacher_id, subject_id, division_id, batch_id) VALUES (?, ?, ?, NULL)").run(teacher2Id, subDbms, divA1Id);

    // Seed Students
    const studentPass = bcrypt.hashSync('StudentPass@2026', salt);

    const studentsData = [
      { id: '2026CSE001', name: 'Aarav Patel', email: 'aarav@quizify.edu', div: divA1Id, batch: batchA1B1, branch: 'CSE', gender: 'Male', dob: '2005-04-12' },
      { id: '2026CSE002', name: 'Diya Sen', email: 'diya@quizify.edu', div: divA1Id, batch: batchA1B2, branch: 'CSE', gender: 'Female', dob: '2005-08-23' },
      { id: '2026CSE003', name: 'Rohan Kumar', email: 'rohan@quizify.edu', div: divA1Id, batch: batchA1B1, branch: 'CSE', gender: 'Male', dob: '2004-11-05' },
      { id: '2026CSE004', name: 'Ananya Gupta', email: 'ananya@quizify.edu', div: divA2Id, batch: batchA2B1, branch: 'CSE', gender: 'Female', dob: '2005-02-18' }
    ];

    for (const stu of studentsData) {
      const uRes = db.prepare(`
        INSERT INTO users (identifier, email, password_hash, role, name, phone)
        VALUES (?, ?, ?, 'STUDENT', ?, '+91 98111 22333')
      `).run(stu.id, stu.email, studentPass, stu.name);
      
      const stuUserId = uRes.lastInsertRowid;

      db.prepare(`
        INSERT INTO student_profiles (user_id, enrollment_number, branch, semester_id, division_id, batch_id, gender, date_of_birth)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `).run(stuUserId, stu.id, stu.branch, semesterId, stu.div, stu.batch, stu.gender, stu.dob);
    }

    // Timetable Entries for every weekday (1 to 5)
    for (let day = 1; day <= 5; day++) {
      // 10:00 - 10:50 CEP Theory
      db.prepare(`
        INSERT INTO timetable_entries (academic_year, semester_id, day_of_week, start_time, end_time, teacher_id, subject_id, session_type, division_id, batch_id, room, building, attendance_required)
        VALUES ('2025-2026', ?, ?, '10:00', '10:50', ?, ?, 'THEORY', ?, NULL, 'EA-511', 'Engineering Block A', 1)
      `).run(semesterId, day, teacher1Id, subCep, divA1Id);

      // 11:00 - 12:40 ADS Practical (Batch B1)
      db.prepare(`
        INSERT INTO timetable_entries (academic_year, semester_id, day_of_week, start_time, end_time, teacher_id, subject_id, session_type, division_id, batch_id, room, building, attendance_required)
        VALUES ('2025-2026', ?, ?, '11:00', '12:40', ?, ?, 'PRACTICAL', ?, ?, 'Lab-204', 'Computing Center', 1)
      `).run(semesterId, day, teacher1Id, subAds, divA1Id, batchA1B1);

      // 14:00 - 14:50 DBMS Theory
      db.prepare(`
        INSERT INTO timetable_entries (academic_year, semester_id, day_of_week, start_time, end_time, teacher_id, subject_id, session_type, division_id, batch_id, room, building, attendance_required)
        VALUES ('2025-2026', ?, ?, '14:00', '14:50', ?, ?, 'THEORY', ?, NULL, 'EA-502', 'Engineering Block A', 1)
      `).run(semesterId, day, teacher2Id, subDbms, divA1Id);
    }

    console.log('Seeded academic structure, teachers, students, and weekly timetable.');
  }
}

module.exports = { seedDatabase };

if (require.main === module) {
  seedDatabase();
}
