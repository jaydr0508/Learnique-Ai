import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNotifications } from '../context/NotificationContext';
import { 
  Mic, MicOff, Video, VideoOff, ScreenShare, StopCircle, 
  Users, MessageSquare, Hand, Info, Copy, Check, PhoneOff, 
  Grid, Maximize2, Shield, Send, X, AlertCircle, Sparkles, Volume2 
} from 'lucide-react';

const RTC_CONFIG = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
    { urls: 'stun:stun2.l.google.com:19302' }
  ]
};

export default function LiveMeetingRoomView({ 
  meetingData, 
  displayName, 
  initialCameraOn = true, 
  initialMicOn = true, 
  initialStream = null, 
  onLeave 
}) {
  const { user, token } = useAuth();
  const { notify } = useNotifications();

  const meetingCode = meetingData?.code;
  const meetingTitle = meetingData?.title || 'Academic Meeting';

  // State
  const [sessionId] = useState(() => `sess_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`);
  const [role, setRole] = useState('PARTICIPANT');
  const [isHost, setIsHost] = useState(false);

  // Media state
  const [isMicOn, setIsMicOn] = useState(initialMicOn);
  const [isCameraOn, setIsCameraOn] = useState(initialCameraOn);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [isHandRaised, setIsHandRaised] = useState(false);
  const [layoutMode, setLayoutMode] = useState('GRID'); // 'GRID' | 'SPOTLIGHT'

  // Panels
  const [activeDrawer, setActiveDrawer] = useState(null); // 'CHAT' | 'PARTICIPANTS' | 'INFO' | null

  // Participants & Peers
  const [participants, setParticipants] = useState([]);
  const [chatMessages, setChatMessages] = useState([]);
  const [chatInput, setChatInput] = useState('');
  const [copiedLink, setCopiedLink] = useState(false);
  const [spotlightSessionId, setSpotlightSessionId] = useState(null);

  // References
  const localVideoRef = useRef(null);
  const localStreamRef = useRef(null);
  const screenStreamRef = useRef(null);
  const peerConnectionsRef = useRef({}); // { [peerSessionId]: RTCPeerConnection }
  const remoteStreamsRef = useRef({}); // { [peerSessionId]: MediaStream }
  const [remotePeersState, setRemotePeersState] = useState({}); // reactive trigger for video elements
  const lastSignalIdRef = useRef(0);
  const lastChatIdRef = useRef(0);
  const heartbeatTimerRef = useRef(null);
  const signalTimerRef = useRef(null);

  // 1. Initialize local media & Join room
  useEffect(() => {
    let isCancelled = false;

    const setupSession = async () => {
      try {
        // Use initialStream if passed from lobby, or obtain new stream
        let stream = initialStream;
        if (!stream) {
          try {
            stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
          } catch (e) {
            console.warn('Initial media access fallback to audio or none:', e);
            try {
              stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            } catch (e2) {
              console.warn('No media devices accessible:', e2);
              stream = new MediaStream();
            }
          }
        }

        localStreamRef.current = stream;

        // Apply initial mic/camera states to tracks
        const vTrack = stream.getVideoTracks()[0];
        if (vTrack) vTrack.enabled = initialCameraOn;
        const aTrack = stream.getAudioTracks()[0];
        if (aTrack) aTrack.enabled = initialMicOn;

        if (localVideoRef.current && vTrack) {
          localVideoRef.current.srcObject = stream;
        }

        // Join meeting in backend
        const joinRes = await fetch(`/api/meetings/${meetingCode}/join`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...(token ? { Authorization: `Bearer ${token}` } : {})
          },
          body: JSON.stringify({
            session_id: sessionId,
            participant_name: displayName
          })
        });

        const joinData = await joinRes.json();
        if (!joinRes.ok) {
          throw new Error(joinData.error || 'Failed to join meeting room');
        }

        if (isCancelled) return;

        setRole(joinData.session.role);
        setIsHost(joinData.session.is_host);

        // Initiate WebRTC peer connections with existing peers
        const peers = joinData.peers || [];
        for (const peer of peers) {
          createPeerConnection(peer.session_id, true);
        }

        // Start polling loops for signals, chat, and heartbeat
        startPolling();
      } catch (err) {
        notify(err.message, 'danger');
        if (onLeave) onLeave();
      }
    };

    setupSession();

    return () => {
      isCancelled = true;
      cleanup();
    };
  }, [meetingCode]);

  // Cleanup on unmount
  const cleanup = () => {
    clearInterval(heartbeatTimerRef.current);
    clearInterval(signalTimerRef.current);

    // Stop local media
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach(t => t.stop());
    }
    if (screenStreamRef.current) {
      screenStreamRef.current.getTracks().forEach(t => t.stop());
    }

    // Close peer connections
    Object.values(peerConnectionsRef.current).forEach(pc => pc.close());
    peerConnectionsRef.current = {};

    // Leave endpoint
    fetch(`/api/meetings/${meetingCode}/leave`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session_id: sessionId }),
      keepalive: true
    }).catch(() => {});
  };

  // 2. WebRTC Peer Connection Factory
  const createPeerConnection = (peerSessionId, isInitiator = false) => {
    if (peerConnectionsRef.current[peerSessionId]) {
      return peerConnectionsRef.current[peerSessionId];
    }

    const pc = new RTCPeerConnection(RTC_CONFIG);
    peerConnectionsRef.current[peerSessionId] = pc;

    // Add local tracks to peer connection
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach(track => {
        pc.addTrack(track, localStreamRef.current);
      });
    }

    // Handle ICE candidates
    pc.onicecandidate = (event) => {
      if (event.candidate) {
        sendSignal(peerSessionId, 'ice-candidate', event.candidate);
      }
    };

    // Handle incoming remote track
    pc.ontrack = (event) => {
      const [remoteStream] = event.streams;
      if (remoteStream) {
        remoteStreamsRef.current[peerSessionId] = remoteStream;
        setRemotePeersState(prev => ({ ...prev, [peerSessionId]: Date.now() }));
      }
    };

    // If initiator, create and send Offer
    if (isInitiator) {
      pc.onnegotiationneeded = async () => {
        try {
          const offer = await pc.createOffer();
          await pc.setLocalDescription(offer);
          sendSignal(peerSessionId, 'offer', offer);
        } catch (e) {
          console.error('Error creating offer:', e);
        }
      };
    }

    return pc;
  };

  const sendSignal = async (toSession, signalType, payload) => {
    try {
      await fetch(`/api/meetings/${meetingCode}/signal`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          from_session: sessionId,
          to_session: toSession,
          signal_type: signalType,
          payload: payload
        })
      });
    } catch (e) {
      console.error('Signal sending error:', e);
    }
  };

  // 3. Signaling & Heartbeat Polling
  const startPolling = () => {
    // A. Heartbeat & Participants poll every 3s
    heartbeatTimerRef.current = setInterval(async () => {
      try {
        const res = await fetch(`/api/meetings/${meetingCode}/heartbeat`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            session_id: sessionId,
            is_muted: !isMicOn ? 1 : 0,
            is_camera_off: !isCameraOn ? 1 : 0,
            is_hand_raised: isHandRaised ? 1 : 0,
            is_screen_sharing: isScreenSharing ? 1 : 0
          })
        });
        const data = await res.json();
        if (data.status === 'ENDED') {
          notify('The host has ended this meeting for everyone.', 'warning');
          if (onLeave) onLeave();
          return;
        }
        if (data.participants) {
          setParticipants(data.participants);
        }
      } catch (e) {}
    }, 3000);

    // B. Signals & Chat poll every 1.5s
    signalTimerRef.current = setInterval(async () => {
      // Fetch signals
      try {
        const sRes = await fetch(`/api/meetings/${meetingCode}/signals?session_id=${sessionId}&since_id=${lastSignalIdRef.current}`);
        const sData = await sRes.json();
        if (sData.signals && sData.signals.length > 0) {
          lastSignalIdRef.current = sData.max_id;
          for (const s of sData.signals) {
            handleIncomingSignal(s);
          }
        }
      } catch (e) {}

      // Fetch chat messages
      try {
        const cRes = await fetch(`/api/meetings/${meetingCode}/chat?since_id=${lastChatIdRef.current}`);
        const cData = await cRes.json();
        if (cData.messages && cData.messages.length > 0) {
          const maxId = Math.max(...cData.messages.map(m => m.id));
          lastChatIdRef.current = maxId;
          setChatMessages(prev => {
            const existingIds = new Set(prev.map(m => m.id));
            const fresh = cData.messages.filter(m => !existingIds.has(m.id));
            return [...prev, ...fresh];
          });
        }
      } catch (e) {}
    }, 1500);
  };

  const handleIncomingSignal = async (signal) => {
    const fromSession = signal.from_session;
    const type = signal.signal_type;
    const payload = signal.payload;

    if (type === 'peer-joined') {
      // New peer joined -> Initiate connection
      createPeerConnection(fromSession, true);
    } else if (type === 'peer-left') {
      // Peer left -> Clean up
      if (peerConnectionsRef.current[fromSession]) {
        peerConnectionsRef.current[fromSession].close();
        delete peerConnectionsRef.current[fromSession];
      }
      delete remoteStreamsRef.current[fromSession];
      setRemotePeersState(prev => {
        const next = { ...prev };
        delete next[fromSession];
        return next;
      });
    } else if (type === 'meeting-ended') {
      notify('This meeting has ended.', 'info');
      if (onLeave) onLeave();
    } else if (type === 'offer') {
      const pc = createPeerConnection(fromSession, false);
      await pc.setRemoteDescription(new RTCSessionDescription(payload));
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      sendSignal(fromSession, 'answer', answer);
    } else if (type === 'answer') {
      const pc = peerConnectionsRef.current[fromSession];
      if (pc) {
        await pc.setRemoteDescription(new RTCSessionDescription(payload));
      }
    } else if (type === 'ice-candidate') {
      const pc = peerConnectionsRef.current[fromSession];
      if (pc && payload) {
        try {
          await pc.addIceCandidate(new RTCIceCandidate(payload));
        } catch (e) {
          console.warn('ICE Candidate add error:', e);
        }
      }
    } else if (type === 'kick') {
      notify('You have been removed from the meeting by the host.', 'danger');
      if (onLeave) onLeave();
    } else if (type === 'mute-req') {
      // Host requested mute
      if (isMicOn) toggleMic();
      notify('Your microphone was muted by the host.', 'info');
    }
  };

  // 4. In-Meeting Controls
  const toggleMic = () => {
    if (localStreamRef.current) {
      const audioTrack = localStreamRef.current.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        setIsMicOn(audioTrack.enabled);
      }
    } else {
      setIsMicOn(!isMicOn);
    }
  };

  const toggleCamera = () => {
    if (localStreamRef.current) {
      const videoTrack = localStreamRef.current.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled;
        setIsCameraOn(videoTrack.enabled);
      }
    } else {
      setIsCameraOn(!isCameraOn);
    }
  };

  const toggleScreenShare = async () => {
    if (!isScreenSharing) {
      try {
        const screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
        screenStreamRef.current = screenStream;
        const screenTrack = screenStream.getVideoTracks()[0];

        // Replace track in all peer connections
        Object.values(peerConnectionsRef.current).forEach(pc => {
          const sender = pc.getSenders().find(s => s.track && s.track.kind === 'video');
          if (sender) {
            sender.replaceTrack(screenTrack);
          }
        });

        // Show screen share on local video ref
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = screenStream;
        }

        screenTrack.onended = () => {
          stopScreenShare();
        };

        setIsScreenSharing(true);
        notify('Screen sharing started', 'info');
      } catch (err) {
        console.warn('Screen share cancelled or failed:', err);
      }
    } else {
      stopScreenShare();
    }
  };

  const stopScreenShare = () => {
    if (screenStreamRef.current) {
      screenStreamRef.current.getTracks().forEach(t => t.stop());
      screenStreamRef.current = null;
    }

    // Revert to camera track
    if (localStreamRef.current) {
      const cameraTrack = localStreamRef.current.getVideoTracks()[0];
      Object.values(peerConnectionsRef.current).forEach(pc => {
        const sender = pc.getSenders().find(s => s.track && s.track.kind === 'video');
        if (sender && cameraTrack) {
          sender.replaceTrack(cameraTrack);
        }
      });

      if (localVideoRef.current) {
        localVideoRef.current.srcObject = localStreamRef.current;
      }
    }

    setIsScreenSharing(false);
  };

  const toggleHandRaise = () => {
    const next = !isHandRaised;
    setIsHandRaised(next);
    sendSignal('*', 'hand-raise', { sessionId, isHandRaised: next });
    notify(next ? 'Hand raised' : 'Hand lowered', 'info');
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(`${window.location.origin}/#meeting-${meetingCode}`);
    setCopiedLink(true);
    notify('Meeting link copied to clipboard!', 'info');
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    const content = chatInput.trim();
    setChatInput('');

    try {
      await fetch(`/api/meetings/${meetingCode}/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          session_id: sessionId,
          sender_name: displayName,
          sender_role: role,
          content: content
        })
      });
    } catch (err) {
      console.error(err);
    }
  };

  // Host Action: Kick Participant
  const handleKickParticipant = async (targetSession) => {
    sendSignal(targetSession, 'kick', {});
    notify('Removed participant from meeting', 'info');
  };

  // Host Action: Mute Participant
  const handleMuteParticipant = async (targetSession) => {
    sendSignal(targetSession, 'mute-req', {});
    notify('Sent mute request to participant', 'info');
  };

  // Host Action: End Meeting for Everyone
  const handleEndMeetingForAll = async () => {
    try {
      await fetch(`/api/meetings/${meetingCode}/end`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify({ session_id: sessionId })
      });
      notify('Meeting ended for all participants', 'info');
      if (onLeave) onLeave();
    } catch (e) {
      notify('Error ending meeting', 'danger');
    }
  };

  // Peers list excluding self
  const otherParticipants = participants.filter(p => p.session_id !== sessionId);

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: '#07090e',
      color: '#f8fafc',
      zIndex: 1000,
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden'
    }}>
      {/* Top Header Bar */}
      <header style={{
        height: '60px',
        padding: '0 24px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        borderBottom: '1px solid rgba(255, 255, 255, 0.08)',
        background: 'rgba(13, 18, 31, 0.95)',
        backdropFilter: 'blur(8px)',
        zIndex: 10
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
          <div style={{
            width: '32px',
            height: '32px',
            borderRadius: '10px',
            background: 'linear-gradient(135deg, var(--accent-primary), #06b6d4)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#ffffff'
          }}>
            <Video size={16} />
          </div>
          <div>
            <div style={{ fontSize: '0.98rem', fontWeight: '700', lineHeight: 1.2 }}>
              {meetingTitle}
            </div>
            <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span style={{ fontFamily: 'var(--font-mono)' }}>{meetingCode}</span>
              <span>•</span>
              <span style={{ color: 'var(--success)', display: 'inline-flex', alignItems: 'center', gap: '4px' }}>
                <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: 'var(--success)' }} />
                Encrypted Real-Time WebRTC
              </span>
            </div>
          </div>
        </div>

        {/* Top Right Quick Actions */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <button
            onClick={() => setLayoutMode(layoutMode === 'GRID' ? 'SPOTLIGHT' : 'GRID')}
            className="btn-secondary"
            style={{ padding: '6px 12px', fontSize: '0.78rem', gap: '6px', background: 'rgba(255,255,255,0.06)' }}
            title="Toggle View Mode"
          >
            {layoutMode === 'GRID' ? <Maximize2 size={14} /> : <Grid size={14} />}
            {layoutMode === 'GRID' ? 'Spotlight' : 'Grid'}
          </button>

          <button
            onClick={handleCopyLink}
            className="btn-secondary"
            style={{ padding: '6px 12px', fontSize: '0.78rem', gap: '6px', background: 'rgba(255,255,255,0.06)' }}
          >
            {copiedLink ? <Check size={14} style={{ color: 'var(--success)' }} /> : <Copy size={14} />}
            {copiedLink ? 'Copied' : 'Copy Link'}
          </button>
        </div>
      </header>

      {/* Main Video Conference Body + Side Drawers */}
      <div style={{ flex: 1, display: 'flex', position: 'relative', overflow: 'hidden' }}>
        {/* Video Tiles Stage */}
        <div style={{
          flex: 1,
          padding: '16px',
          display: 'grid',
          gridTemplateColumns: layoutMode === 'SPOTLIGHT' 
            ? '1fr' 
            : otherParticipants.length === 0 ? '1fr' : otherParticipants.length === 1 ? '1fr 1fr' : 'repeat(auto-fit, minmax(320px, 1fr))',
          gap: '14px',
          alignItems: 'center',
          justifyContent: 'center',
          overflowY: 'auto'
        }}>
          {/* Local User Video Tile */}
          <div style={{
            position: 'relative',
            borderRadius: '16px',
            background: '#0d121f',
            border: '2px solid rgba(255, 255, 255, 0.08)',
            overflow: 'hidden',
            aspectRatio: '16 / 9',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            maxHeight: '100%'
          }}>
            <video
              ref={localVideoRef}
              autoPlay
              playsInline
              muted
              style={{
                width: '100%',
                height: '100%',
                objectFit: 'cover',
                transform: isScreenSharing ? 'none' : 'scaleX(-1)',
                display: (isCameraOn || isScreenSharing) ? 'block' : 'none'
              }}
            />

            {!isCameraOn && !isScreenSharing && (
              <div style={{ textAlign: 'center' }}>
                <div style={{
                  width: '64px',
                  height: '64px',
                  borderRadius: '50%',
                  background: 'var(--accent-light)',
                  color: 'var(--accent-primary)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '1.6rem',
                  fontWeight: '800',
                  margin: '0 auto 8px auto',
                  border: '2px solid var(--border-glass)'
                }}>
                  {displayName ? displayName[0].toUpperCase() : 'U'}
                </div>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Camera is off</div>
              </div>
            )}

            {/* Badges Overlay */}
            <div style={{
              position: 'absolute',
              bottom: '12px',
              left: '12px',
              background: 'rgba(0, 0, 0, 0.65)',
              padding: '4px 10px',
              borderRadius: '8px',
              fontSize: '0.78rem',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              backdropFilter: 'blur(4px)'
            }}>
              <span>{displayName} (You)</span>
              {role === 'HOST' && <span style={{ color: 'var(--accent-primary)', fontWeight: '700' }}>• Host</span>}
              {!isMicOn && <MicOff size={13} style={{ color: 'var(--danger)' }} />}
            </div>

            {isHandRaised && (
              <div style={{
                position: 'absolute',
                top: '12px',
                right: '12px',
                background: 'rgba(245, 158, 11, 0.9)',
                color: '#ffffff',
                padding: '4px 8px',
                borderRadius: '8px',
                fontSize: '0.75rem',
                display: 'flex',
                alignItems: 'center',
                gap: '4px'
              }}>
                <Hand size={14} /> Hand Raised
              </div>
            )}
          </div>

          {/* Remote Peer Video Tiles */}
          {otherParticipants.map(peer => {
            const hasStream = remoteStreamsRef.current[peer.session_id];
            return (
              <div
                key={peer.session_id}
                style={{
                  position: 'relative',
                  borderRadius: '16px',
                  background: '#0d121f',
                  border: peer.is_hand_raised ? '2px solid var(--warning)' : '2px solid rgba(255, 255, 255, 0.08)',
                  overflow: 'hidden',
                  aspectRatio: '16 / 9',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  maxHeight: '100%'
                }}
              >
                {hasStream && !peer.is_camera_off ? (
                  <video
                    autoPlay
                    playsInline
                    ref={el => {
                      if (el && remoteStreamsRef.current[peer.session_id]) {
                        el.srcObject = remoteStreamsRef.current[peer.session_id];
                      }
                    }}
                    style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                  />
                ) : (
                  <div style={{ textAlign: 'center' }}>
                    <div style={{
                      width: '64px',
                      height: '64px',
                      borderRadius: '50%',
                      background: 'var(--bg-tertiary)',
                      color: '#06b6d4',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '1.6rem',
                      fontWeight: '800',
                      margin: '0 auto 8px auto',
                      border: '2px solid var(--border-glass)'
                    }}>
                      {peer.participant_name ? peer.participant_name[0].toUpperCase() : 'P'}
                    </div>
                    <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                      {peer.participant_name}
                    </div>
                  </div>
                )}

                {/* Badges Overlay */}
                <div style={{
                  position: 'absolute',
                  bottom: '12px',
                  left: '12px',
                  background: 'rgba(0, 0, 0, 0.65)',
                  padding: '4px 10px',
                  borderRadius: '8px',
                  fontSize: '0.78rem',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  backdropFilter: 'blur(4px)'
                }}>
                  <span>{peer.participant_name}</span>
                  {peer.role === 'HOST' && <span style={{ color: 'var(--accent-primary)', fontWeight: '700' }}>• Host</span>}
                  {peer.is_muted === 1 && <MicOff size={13} style={{ color: 'var(--danger)' }} />}
                </div>

                {peer.is_hand_raised === 1 && (
                  <div style={{
                    position: 'absolute',
                    top: '12px',
                    right: '12px',
                    background: 'rgba(245, 158, 11, 0.9)',
                    color: '#ffffff',
                    padding: '4px 8px',
                    borderRadius: '8px',
                    fontSize: '0.75rem',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '4px'
                  }}>
                    <Hand size={14} /> Hand Raised
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Side Drawer: Chat / Participants / Info */}
        {activeDrawer && (
          <div style={{
            width: '340px',
            background: 'var(--bg-secondary)',
            borderLeft: '1px solid var(--border-glass)',
            display: 'flex',
            flexDirection: 'column',
            zIndex: 20
          }}>
            {/* Drawer Header */}
            <div style={{
              padding: '16px 20px',
              borderBottom: '1px solid var(--border-subtle)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              background: 'var(--bg-tertiary)'
            }}>
              <h3 style={{ fontSize: '1rem', margin: 0 }}>
                {activeDrawer === 'CHAT' ? 'In-Meeting Chat' : activeDrawer === 'PARTICIPANTS' ? `Participants (${participants.length})` : 'Meeting Details'}
              </h3>
              <button 
                onClick={() => setActiveDrawer(null)}
                className="btn-secondary"
                style={{ padding: '6px', borderRadius: '8px' }}
              >
                <X size={16} />
              </button>
            </div>

            {/* Drawer Content */}
            <div style={{ flex: 1, overflowY: 'auto', padding: '16px' }}>
              {activeDrawer === 'CHAT' && (
                <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
                  <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '12px', marginBottom: '12px' }}>
                    {chatMessages.length === 0 ? (
                      <div style={{ textAlign: 'center', padding: '40px 10px', color: 'var(--text-muted)', fontSize: '0.82rem' }}>
                        No messages yet. Send a message to everyone in the meeting.
                      </div>
                    ) : (
                      chatMessages.map((m, idx) => {
                        const isMe = m.session_id === sessionId;
                        return (
                          <div key={idx} style={{
                            padding: '10px 12px',
                            borderRadius: '10px',
                            background: isMe ? 'var(--accent-light)' : 'var(--bg-surface)',
                            border: isMe ? '1px solid var(--accent-border)' : '1px solid var(--border-subtle)',
                            alignSelf: isMe ? 'flex-end' : 'flex-start',
                            maxWidth: '85%'
                          }}>
                            <div style={{ fontSize: '0.72rem', color: isMe ? 'var(--accent-primary)' : 'var(--text-muted)', fontWeight: '700', marginBottom: '2px' }}>
                              {m.sender_name} {m.sender_role === 'HOST' ? '(Host)' : ''}
                            </div>
                            <div style={{ fontSize: '0.85rem', color: 'var(--text-primary)', wordBreak: 'break-word' }}>
                              {m.content}
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>

                  <form onSubmit={handleSendMessage} style={{ display: 'flex', gap: '8px' }}>
                    <input
                      type="text"
                      placeholder="Type a message..."
                      value={chatInput}
                      onChange={e => setChatInput(e.target.value)}
                      style={{
                        flex: 1,
                        padding: '10px 12px',
                        borderRadius: '10px',
                        background: 'var(--bg-tertiary)',
                        border: '1px solid var(--border-subtle)',
                        color: 'var(--text-primary)',
                        fontSize: '0.85rem'
                      }}
                    />
                    <button type="submit" className="btn-primary" style={{ padding: '10px', borderRadius: '10px' }}>
                      <Send size={16} />
                    </button>
                  </form>
                </div>
              )}

              {activeDrawer === 'PARTICIPANTS' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  {participants.map(p => {
                    const isSelf = p.session_id === sessionId;
                    return (
                      <div
                        key={p.session_id}
                        style={{
                          padding: '10px 12px',
                          borderRadius: '10px',
                          background: 'var(--bg-surface)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'space-between'
                        }}
                      >
                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                          <div style={{
                            width: '32px',
                            height: '32px',
                            borderRadius: '50%',
                            background: 'var(--accent-light)',
                            color: 'var(--accent-primary)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontSize: '0.85rem',
                            fontWeight: '700'
                          }}>
                            {p.participant_name ? p.participant_name[0].toUpperCase() : 'U'}
                          </div>
                          <div>
                            <div style={{ fontSize: '0.85rem', fontWeight: '600' }}>
                              {p.participant_name} {isSelf ? '(You)' : ''}
                            </div>
                            <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                              {p.role === 'HOST' ? 'Meeting Host' : 'Participant'}
                            </div>
                          </div>
                        </div>

                        {/* Host controls over other participants */}
                        {isHost && !isSelf && (
                          <div style={{ display: 'flex', gap: '6px' }}>
                            <button
                              onClick={() => handleMuteParticipant(p.session_id)}
                              className="btn-secondary"
                              style={{ padding: '6px', borderRadius: '6px' }}
                              title="Request Mute"
                            >
                              <MicOff size={13} />
                            </button>
                            <button
                              onClick={() => handleKickParticipant(p.session_id)}
                              className="btn-secondary"
                              style={{ padding: '6px', borderRadius: '6px', color: 'var(--danger)' }}
                              title="Remove from room"
                            >
                              <X size={13} />
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}

              {activeDrawer === 'INFO' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                  <div>
                    <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Meeting Code</label>
                    <div style={{ fontSize: '1.1rem', fontFamily: 'var(--font-mono)', fontWeight: '700', color: 'var(--accent-primary)', marginTop: '2px' }}>
                      {meetingCode}
                    </div>
                  </div>

                  <div>
                    <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Share Link</label>
                    <div style={{ display: 'flex', gap: '8px', marginTop: '4px' }}>
                      <input
                        readOnly
                        value={`${window.location.origin}/#meeting-${meetingCode}`}
                        style={{
                          flex: 1,
                          padding: '8px 10px',
                          borderRadius: '8px',
                          background: 'var(--bg-tertiary)',
                          border: '1px solid var(--border-subtle)',
                          fontSize: '0.78rem',
                          color: 'var(--text-secondary)'
                        }}
                      />
                      <button onClick={handleCopyLink} className="btn-secondary" style={{ padding: '8px 12px' }}>
                        {copiedLink ? <Check size={14} /> : <Copy size={14} />}
                      </button>
                    </div>
                  </div>

                  <div style={{ padding: '12px', borderRadius: '10px', background: 'var(--bg-surface)', fontSize: '0.78rem', color: 'var(--text-muted)', lineHeight: 1.5 }}>
                    <Shield size={16} style={{ color: 'var(--success)', marginBottom: '4px' }} />
                    <div>All audio, video, and screen sharing streams run over end-to-end WebRTC peer connections.</div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Floating Bottom Control Bar */}
      <footer style={{
        height: '76px',
        padding: '0 24px',
        background: 'rgba(13, 18, 31, 0.95)',
        borderTop: '1px solid rgba(255, 255, 255, 0.08)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        position: 'relative',
        zIndex: 10
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          {/* Mic */}
          <button
            onClick={toggleMic}
            style={{
              width: '46px',
              height: '46px',
              borderRadius: '50%',
              border: 'none',
              background: isMicOn ? 'rgba(255, 255, 255, 0.12)' : 'var(--danger)',
              color: '#ffffff',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              transition: 'all 0.2s ease'
            }}
            title={isMicOn ? 'Mute Mic' : 'Unmute Mic'}
          >
            {isMicOn ? <Mic size={20} /> : <MicOff size={20} />}
          </button>

          {/* Camera */}
          <button
            onClick={toggleCamera}
            style={{
              width: '46px',
              height: '46px',
              borderRadius: '50%',
              border: 'none',
              background: isCameraOn ? 'rgba(255, 255, 255, 0.12)' : 'var(--danger)',
              color: '#ffffff',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              transition: 'all 0.2s ease'
            }}
            title={isCameraOn ? 'Turn Off Camera' : 'Turn On Camera'}
          >
            {isCameraOn ? <Video size={20} /> : <VideoOff size={20} />}
          </button>

          {/* Screen Share */}
          <button
            onClick={toggleScreenShare}
            style={{
              width: '46px',
              height: '46px',
              borderRadius: '50%',
              border: 'none',
              background: isScreenSharing ? 'var(--accent-primary)' : 'rgba(255, 255, 255, 0.12)',
              color: '#ffffff',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              transition: 'all 0.2s ease'
            }}
            title={isScreenSharing ? 'Stop Screen Share' : 'Share Screen'}
          >
            <ScreenShare size={20} />
          </button>

          {/* Raise Hand */}
          <button
            onClick={toggleHandRaise}
            style={{
              width: '46px',
              height: '46px',
              borderRadius: '50%',
              border: 'none',
              background: isHandRaised ? 'var(--warning)' : 'rgba(255, 255, 255, 0.12)',
              color: '#ffffff',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              transition: 'all 0.2s ease'
            }}
            title={isHandRaised ? 'Lower Hand' : 'Raise Hand'}
          >
            <Hand size={20} />
          </button>

          {/* Participants toggle */}
          <button
            onClick={() => setActiveDrawer(activeDrawer === 'PARTICIPANTS' ? null : 'PARTICIPANTS')}
            style={{
              width: '46px',
              height: '46px',
              borderRadius: '50%',
              border: 'none',
              background: activeDrawer === 'PARTICIPANTS' ? 'var(--accent-light)' : 'rgba(255, 255, 255, 0.12)',
              color: activeDrawer === 'PARTICIPANTS' ? 'var(--accent-primary)' : '#ffffff',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer'
            }}
            title="Participants List"
          >
            <Users size={20} />
          </button>

          {/* Chat toggle */}
          <button
            onClick={() => setActiveDrawer(activeDrawer === 'CHAT' ? null : 'CHAT')}
            style={{
              width: '46px',
              height: '46px',
              borderRadius: '50%',
              border: 'none',
              background: activeDrawer === 'CHAT' ? 'var(--accent-light)' : 'rgba(255, 255, 255, 0.12)',
              color: activeDrawer === 'CHAT' ? 'var(--accent-primary)' : '#ffffff',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer'
            }}
            title="In-Meeting Chat"
          >
            <MessageSquare size={20} />
          </button>

          {/* Info toggle */}
          <button
            onClick={() => setActiveDrawer(activeDrawer === 'INFO' ? null : 'INFO')}
            style={{
              width: '46px',
              height: '46px',
              borderRadius: '50%',
              border: 'none',
              background: activeDrawer === 'INFO' ? 'var(--accent-light)' : 'rgba(255, 255, 255, 0.12)',
              color: activeDrawer === 'INFO' ? 'var(--accent-primary)' : '#ffffff',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer'
            }}
            title="Meeting Information"
          >
            <Info size={20} />
          </button>

          {/* Leave Meeting (Red button) */}
          <button
            onClick={() => {
              cleanup();
              if (onLeave) onLeave();
            }}
            style={{
              padding: '0 20px',
              height: '46px',
              borderRadius: '24px',
              border: 'none',
              background: 'var(--danger)',
              color: '#ffffff',
              fontWeight: '700',
              fontSize: '0.88rem',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              cursor: 'pointer',
              marginLeft: '12px'
            }}
            title="Leave Meeting"
          >
            <PhoneOff size={18} /> Leave
          </button>

          {/* Host End Meeting for All */}
          {isHost && (
            <button
              onClick={handleEndMeetingForAll}
              style={{
                padding: '0 16px',
                height: '46px',
                borderRadius: '24px',
                border: '1px solid rgba(239, 68, 68, 0.5)',
                background: 'rgba(239, 68, 68, 0.15)',
                color: '#ef4444',
                fontWeight: '600',
                fontSize: '0.82rem',
                cursor: 'pointer'
              }}
              title="End Meeting for Everyone"
            >
              End for All
            </button>
          )}
        </div>
      </footer>
    </div>
  );
}
