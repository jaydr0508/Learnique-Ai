from flask import Blueprint, request, jsonify, g
from backend.auth.routes import require_auth
from backend.ai.doubt_solver import (
    get_or_create_conversation,
    send_doubt_message,
    get_user_conversations,
    get_conversation_messages
)

ai_bp = Blueprint("ai", __name__)

@ai_bp.route("/doubt/conversations", methods=["GET"])
@require_auth()
def list_conversations():
    """Retrieve private AI doubt conversations for authenticated user."""
    convs = get_user_conversations(g.user["id"])
    return jsonify({"success": True, "conversations": convs})

@ai_bp.route("/doubt/conversation/<int:conv_id>/messages", methods=["GET"])
@require_auth()
def get_messages(conv_id: int):
    """Retrieve chronological messages for private conversation."""
    try:
        messages = get_conversation_messages(g.user["id"], conv_id)
        return jsonify({"success": True, "messages": messages})
    except PermissionError as pe:
        return jsonify({"success": False, "error": str(pe)}), 403

@ai_bp.route("/doubt/ask", methods=["POST"])
@require_auth()
def ask_doubt():
    """Send question to academic AI tutor and retrieve pedagogical explanation."""
    data = request.get_json(silent=True) or {}
    message = str(data.get("message", "")).strip()
    if not message:
        return jsonify({"success": False, "error": "Message content cannot be blank."}), 400

    conv_id = data.get("conversation_id")
    subject_id = data.get("subject_id")

    if not conv_id:
        conv_id = get_or_create_conversation(g.user["id"], subject_id=subject_id)

    try:
        res = send_doubt_message(g.user["id"], conv_id, message)
        return jsonify({"success": True, "data": res})
    except PermissionError as pe:
        return jsonify({"success": False, "error": str(pe)}), 403
    except Exception as e:
        return jsonify({"success": False, "error": f"AI Assistant error: {str(e)}"}), 500

@ai_bp.route("/doubt/new", methods=["POST"])
@require_auth()
def create_new_conversation():
    """Explicitly start a fresh inquiry thread."""
    data = request.get_json(silent=True) or {}
    title = str(data.get("title", "")).strip() or None
    subject_id = data.get("subject_id")

    conv_id = get_or_create_conversation(g.user["id"], subject_id=subject_id, title=title)
    return jsonify({"success": True, "conversation_id": conv_id})
