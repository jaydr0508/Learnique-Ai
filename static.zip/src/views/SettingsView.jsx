import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTheme, ACCENT_PRESETS } from '../context/ThemeContext';
import {
  Palette,
  Moon,
  Sun,
  Lock,
  User,
  ShieldCheck,
  Check,
  AlertCircle
} from 'lucide-react';

export default function SettingsView() {
  const { user, token, refreshUser } = useAuth();
  const { theme, toggleTheme, accentColor, setAccentColor } = useTheme();

  const [name, setName] = useState(user?.name || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const [statusMessage, setStatusMessage] = useState(null);
  const [loading, setLoading] = useState(false);

  async function handleUpdateProfile(e) {
    e.preventDefault();
    setStatusMessage(null);

    if (newPassword && newPassword !== confirmPassword) {
      setStatusMessage({ success: false, message: 'New password and confirmation do not match.' });
      return;
    }
    if (newPassword && newPassword.length < 8) {
      setStatusMessage({ success: false, message: 'New password must be at least 8 characters.' });
      return;
    }

    setLoading(true);

    try {
      const res = await fetch('/api/auth/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          name: name.trim(),
          phone: phone.trim(),
          currentPassword: currentPassword || undefined,
          newPassword: newPassword || undefined
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to update profile');

      setStatusMessage({ success: true, message: 'Profile & credentials updated successfully.' });
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      refreshUser();
    } catch (err) {
      setStatusMessage({ success: false, message: err.message });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ maxWidth: '850px', margin: '0 auto', padding: '0 20px 40px 20px' }}>
      <div style={{ marginBottom: '24px' }}>
        <h2 style={{ fontSize: '1.5rem', fontWeight: '800' }}>Platform Preferences & Security</h2>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>
          Personalize workspace visual theme, color accents, and manage your authentication credentials
        </p>
      </div>

      {statusMessage && (
        <div style={{
          background: statusMessage.success ? 'rgba(16, 185, 129, 0.15)' : 'rgba(239, 68, 68, 0.15)',
          color: statusMessage.success ? '#10b981' : '#ef4444',
          border: `1px solid ${statusMessage.success ? 'rgba(16, 185, 129, 0.3)' : 'rgba(239, 68, 68, 0.3)'}`,
          padding: '14px 18px',
          borderRadius: '12px',
          marginBottom: '20px',
          display: 'flex',
          alignItems: 'center',
          gap: '10px',
          fontSize: '0.875rem'
        }}>
          {statusMessage.success ? <Check size={18} /> : <AlertCircle size={18} />}
          <span>{statusMessage.message}</span>
        </div>
      )}

      {/* APPEARANCE SECTION */}
      <div className="glass-panel" style={{ padding: '28px', borderRadius: '20px', marginBottom: '24px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '18px' }}>
          <Palette size={22} style={{ color: 'var(--accent-primary)' }} />
          <h3 style={{ fontSize: '1.15rem', fontWeight: '700' }}>Visual Theme & Accent Customizer</h3>
        </div>

        <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem', marginBottom: '20px' }}>
          Section 61 Compliance: Modifying appearance updates only accents, glows, and surface highlights. Layout, navigation, and spacing remain identical.
        </p>

        {/* Dark / Light Toggle */}
        <div style={{ marginBottom: '24px' }}>
          <label style={{ fontSize: '0.8rem', fontWeight: '600', color: 'var(--text-muted)', display: 'block', marginBottom: '10px', textTransform: 'uppercase' }}>
            Base Theme Mode
          </label>
          <div style={{ display: 'flex', gap: '12px' }}>
            <button
              type="button"
              onClick={() => theme !== 'dark' && toggleTheme()}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '10px',
                padding: '12px 20px',
                borderRadius: '12px',
                border: theme === 'dark' ? '2px solid var(--accent-primary)' : '1px solid var(--border-glass)',
                background: theme === 'dark' ? 'var(--accent-light)' : 'var(--bg-tertiary)',
                color: 'var(--text-primary)',
                fontWeight: '600',
                cursor: 'pointer'
              }}
            >
              <Moon size={18} style={{ color: '#818cf8' }} />
              <span>Dark Mode (High Contrast)</span>
            </button>
            <button
              type="button"
              onClick={() => theme !== 'light' && toggleTheme()}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '10px',
                padding: '12px 20px',
                borderRadius: '12px',
                border: theme === 'light' ? '2px solid var(--accent-primary)' : '1px solid var(--border-glass)',
                background: theme === 'light' ? 'var(--accent-light)' : 'var(--bg-tertiary)',
                color: 'var(--text-primary)',
                fontWeight: '600',
                cursor: 'pointer'
              }}
            >
              <Sun size={18} style={{ color: '#f59e0b' }} />
              <span>Light Mode (Clean Academic)</span>
            </button>
          </div>
        </div>

        {/* Accent Color Presets */}
        <div>
          <label style={{ fontSize: '0.8rem', fontWeight: '600', color: 'var(--text-muted)', display: 'block', marginBottom: '10px', textTransform: 'uppercase' }}>
            Dynamic Accent Palette
          </label>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: '10px', marginBottom: '16px' }}>
            {ACCENT_PRESETS.map((p) => (
              <button
                key={p.color}
                type="button"
                onClick={() => setAccentColor(p.color)}
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: '6px',
                  padding: '12px 8px',
                  background: accentColor === p.color ? 'var(--accent-light)' : 'var(--bg-tertiary)',
                  border: accentColor === p.color ? '2px solid var(--accent-primary)' : '1px solid var(--border-glass)',
                  borderRadius: '12px',
                  cursor: 'pointer',
                  color: 'var(--text-primary)',
                  fontSize: '0.75rem',
                  fontWeight: '600'
                }}
              >
                <span style={{
                  width: '20px',
                  height: '20px',
                  borderRadius: '50%',
                  background: p.color,
                  boxShadow: `0 0 10px ${p.color}88`
                }} />
                <span>{p.name.split(' ')[0]}</span>
              </button>
            ))}
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <span style={{ fontSize: '0.825rem', color: 'var(--text-muted)' }}>Custom Hex:</span>
            <input
              type="color"
              value={accentColor}
              onChange={e => setAccentColor(e.target.value)}
              style={{ width: '40px', height: '36px', borderRadius: '6px', border: 'none', cursor: 'pointer' }}
            />
            <input
              type="text"
              className="input-field"
              value={accentColor}
              onChange={e => setAccentColor(e.target.value)}
              style={{ width: '140px', fontFamily: 'var(--font-mono)' }}
            />
          </div>
        </div>
      </div>

      {/* ACCOUNT & CREDENTIALS SECTION */}
      <div className="glass-panel" style={{ padding: '28px', borderRadius: '20px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '20px' }}>
          <Lock size={22} style={{ color: 'var(--accent-primary)' }} />
          <h3 style={{ fontSize: '1.15rem', fontWeight: '700' }}>Account Details & Password Management</h3>
        </div>

        <form onSubmit={handleUpdateProfile} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '16px' }}>
            <div>
              <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'block', marginBottom: '6px' }}>
                Full Name
              </label>
              <input
                type="text"
                className="input-field"
                value={name}
                onChange={e => setName(e.target.value)}
                required
              />
            </div>
            <div>
              <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'block', marginBottom: '6px' }}>
                Contact Phone
              </label>
              <input
                type="text"
                className="input-field"
                value={phone}
                onChange={e => setPhone(e.target.value)}
              />
            </div>
          </div>

          <div style={{ paddingTop: '14px', borderTop: '1px solid var(--border-subtle)' }}>
            <h4 style={{ fontSize: '0.95rem', fontWeight: '700', marginBottom: '12px' }}>Change Password</h4>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '14px' }}>
              <div>
                <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)', display: 'block', marginBottom: '6px' }}>
                  Current Password
                </label>
                <input
                  type="password"
                  className="input-field"
                  placeholder="Verify existing password"
                  value={currentPassword}
                  onChange={e => setCurrentPassword(e.target.value)}
                />
              </div>
              <div>
                <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)', display: 'block', marginBottom: '6px' }}>
                  New Password
                </label>
                <input
                  type="password"
                  className="input-field"
                  placeholder="Min 8 characters"
                  value={newPassword}
                  onChange={e => setNewPassword(e.target.value)}
                />
              </div>
              <div>
                <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)', display: 'block', marginBottom: '6px' }}>
                  Confirm New Password
                </label>
                <input
                  type="password"
                  className="input-field"
                  placeholder="Re-enter new password"
                  value={confirmPassword}
                  onChange={e => setConfirmPassword(e.target.value)}
                />
              </div>
            </div>
          </div>

          <button
            type="submit"
            className="btn-primary"
            disabled={loading}
            style={{ alignSelf: 'flex-start', padding: '12px 28px', marginTop: '10px' }}
          >
            {loading ? 'Saving Preferences...' : 'Save Profile Changes'}
          </button>
        </form>
      </div>
    </div>
  );
}
