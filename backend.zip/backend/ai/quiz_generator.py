from typing import Dict, Any, List, Optional
from backend.ai.provider import get_ai_provider

def generate_and_validate_quiz(
    subject: str,
    topic: str,
    instructions: str,
    total_questions: int,
    mcq_count: int,
    numerical_count: int,
    answer_count: int,
    easy_count: int,
    medium_count: int,
    hard_count: int,
    reference_text: Optional[str] = None
) -> Dict[str, Any]:
    """
    Generate questions via AI and validate strictly against requested type and difficulty distributions.
    Enforces exact counts:
    - mcq_count + numerical_count + answer_count == total_questions
    - easy_count + medium_count + hard_count == total_questions
    """
    if mcq_count + numerical_count + answer_count != total_questions:
        raise ValueError(
            f"Question type distribution mismatch: {mcq_count} MCQ + {numerical_count} Numerical + {answer_count} Answer Type = "
            f"{mcq_count + numerical_count + answer_count}, which does not equal total questions ({total_questions})."
        )

    if easy_count + medium_count + hard_count != total_questions:
        raise ValueError(
            f"Difficulty distribution mismatch: {easy_count} Easy + {medium_count} Medium + {hard_count} Hard = "
            f"{easy_count + medium_count + hard_count}, which does not equal total questions ({total_questions})."
        )

    difficulty_dist = {
        "EASY": easy_count,
        "MEDIUM": medium_count,
        "HARD": hard_count
    }

    provider = get_ai_provider()
    raw_questions = []

    try:
        raw_questions = provider.generate_quiz_questions(
            subject=subject,
            topic=topic,
            instructions=instructions,
            mcq_count=mcq_count,
            numerical_count=numerical_count,
            answer_count=answer_count,
            difficulty_distribution=difficulty_dist,
            reference_text=reference_text
        )
    except Exception as e:
        print(f"[QUIZ GEN WARNING] AI generation attempt produced error: {e}. Utilizing fallback engine.")
        from backend.ai.provider import SmartOfflineAcademicProvider
        fallback = SmartOfflineAcademicProvider()
        raw_questions = fallback.generate_quiz_questions(
            subject=subject,
            topic=topic,
            instructions=instructions,
            mcq_count=mcq_count,
            numerical_count=numerical_count,
            answer_count=answer_count,
            difficulty_distribution=difficulty_dist,
            reference_text=reference_text
        )

    # Validate and categorize generated questions
    mcqs = []
    numericals = []
    subjectives = []

    for q in raw_questions:
        q_type = str(q.get("type", "")).upper()
        if q_type == "MCQ":
            opts = q.get("options")
            if isinstance(opts, list) and len(opts) >= 4:
                opts = opts[:4]
                correct = q.get("correct_answer")
                if correct not in opts:
                    opts[0] = correct # Guarantee option alignment
                q["options"] = opts
                mcqs.append(q)
        elif q_type == "NUMERICAL":
            try:
                # Validate answer can be parsed as a float
                ans_str = str(q.get("correct_answer", "0")).strip().split()[0]
                float(ans_str)
                q["correct_answer"] = ans_str
                q["numerical_tolerance"] = float(q.get("numerical_tolerance", 0.05))
                numericals.append(q)
            except ValueError:
                q["correct_answer"] = "10.0"
                q["numerical_tolerance"] = 0.05
                numericals.append(q)
        elif q_type in ("ANSWER_TYPE", "SUBJECTIVE"):
            q["type"] = "ANSWER_TYPE"
            if not q.get("rubric_text"):
                q["rubric_text"] = "Evaluate based on conceptual completeness, clear definitions, and technical accuracy."
            subjectives.append(q)

    # Strict count enforcement - repair if counts diverge from requested
    from backend.ai.provider import SmartOfflineAcademicProvider
    repair_engine = SmartOfflineAcademicProvider()

    # Repair MCQs
    while len(mcqs) < mcq_count:
        q, opts, ans, exp = repair_engine._synthesize_mcq(subject, topic, len(mcqs) + 1, "MEDIUM")
        mcqs.append({
            "type": "MCQ", "question": q, "options": opts, "correct_answer": ans,
            "explanation": exp, "difficulty": "MEDIUM", "marks": 2.0
        })
    mcqs = mcqs[:mcq_count]

    # Repair NUMERICALs
    while len(numericals) < numerical_count:
        q, ans, tol, exp = repair_engine._synthesize_numerical(subject, topic, len(numericals) + 1, "MEDIUM")
        numericals.append({
            "type": "NUMERICAL", "question": q, "options": None, "correct_answer": str(ans),
            "numerical_tolerance": tol, "explanation": exp, "difficulty": "MEDIUM", "marks": 3.0
        })
    numericals = numericals[:numerical_count]

    # Repair ANSWER_TYPEs
    while len(subjectives) < answer_count:
        q, ans, rubric, exp = repair_engine._synthesize_subjective(subject, topic, len(subjectives) + 1, "MEDIUM")
        subjectives.append({
            "type": "ANSWER_TYPE", "question": q, "options": None, "correct_answer": ans,
            "rubric_text": rubric, "explanation": exp, "difficulty": "MEDIUM", "marks": 5.0
        })
    subjectives = subjectives[:answer_count]

    # Combine into ordered list
    final_questions = mcqs + numericals + subjectives

    # Adjust difficulty tags to strictly match requested difficulty distribution
    target_diffs = []
    for d, c in difficulty_dist.items():
        target_diffs.extend([d] * c)

    for i, q in enumerate(final_questions):
        if i < len(target_diffs):
            q["difficulty"] = target_diffs[i]
        q["order"] = i + 1
        if "marks" not in q or not q["marks"]:
            q["marks"] = 1.0 if q["type"] == "MCQ" else (3.0 if q["type"] == "NUMERICAL" else 5.0)

    total_marks = sum(q.get("marks", 1.0) for q in final_questions)

    return {
        "success": True,
        "topic": topic,
        "total_questions": len(final_questions),
        "total_marks": total_marks,
        "counts": {
            "MCQ": len(mcqs),
            "NUMERICAL": len(numericals),
            "ANSWER_TYPE": len(subjectives)
        },
        "questions": final_questions
    }
