import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNotifications } from '../context/NotificationContext';
import { 
  PlusCircle, Calendar, Clock, MapPin, Ticket, ShieldCheck, 
  Trash2, ArrowLeft, Image, Check, AlertCircle, Loader2, Sparkles 
} from 'lucide-react';

export default function HostEventView({ onBack, onEventCreated }) {
  const { user, token } = useAuth();
  const { notify } = useNotifications();

  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 3);
  const defaultDate = tomorrow.toISOString().split('T')[0];

  const [formData, setFormData] = useState({
    title: '',
    short_description: '',
    description: '',
    category: 'Technology & AI',
    banner_url: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=1200&q=80',
    organizer_name: user?.name || '',
    event_date: defaultDate,
    start_time: '10:00',
    end_time: '16:00',
    venue_type: 'HYBRID',
    venue_address: 'Auditorium Hall 1, Campus Tech Hub',
    online_meeting_url: '',
    max_capacity: 150,
    contact_email: user?.email || '',
    contact_phone: user?.phone || '+91 98765 43210',
    rules_and_requirements: 'Bring your laptop with required development tools installed. Please carry institutional ID.',
    cancellation_policy: 'Free cancellation up to 24 hours prior to event start.',
    terms_and_conditions: 'Standard academic workshop code of conduct applies.',
    status: 'PUBLISHED'
  });

  const [tickets, setTickets] = useState([
    { name: 'General Admission', price: 0, quantity: 100, description: 'Standard pass with digital certificate' },
    { name: 'VIP & Delegate Pass', price: 299, quantity: 50, description: 'Priority seating and mentor Q&A' }
  ]);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  if (user && user.role === 'STUDENT') {
    return (
      <div style={{ maxWidth: '600px', margin: '60px auto', padding: '32px', textAlign: 'center', borderRadius: '16px', background: 'var(--bg-secondary)', border: '1px solid var(--border-glass)' }}>
        <h3 style={{ fontSize: '1.3rem', marginBottom: '8px' }}>Access Restricted</h3>
        <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', marginBottom: '20px' }}>
          Students are not permitted to host events. This feature is reserved for faculty and administrators.
        </p>
        <button onClick={onBack} className="btn-primary" style={{ padding: '10px 20px', borderRadius: '10px' }}>
          Back to Events
        </button>
      </div>
    );
  }

  const bannerPresets = [
    { label: 'Technology & AI', url: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&w=1200&q=80' },
    { label: 'Software & Code', url: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=1200&q=80' },
    { label: 'Hackathon & Innovation', url: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=1200&q=80' },
    { label: 'Auditorium Conference', url: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=1200&q=80' }
  ];

  const handleAddTicket = () => {
    setTickets([...tickets, { name: 'Student Pass', price: 0, quantity: 50, description: 'Standard admission' }]);
  };

  const handleRemoveTicket = (index) => {
    if (tickets.length <= 1) {
      notify('An event must have at least one ticket tier.', 'warning');
      return;
    }
    setTickets(tickets.filter((_, i) => i !== index));
  };

  const handleTicketChange = (index, field, value) => {
    const updated = [...tickets];
    updated[index][field] = value;
    setTickets(updated);
  };

  const handleSubmit = async (publishStatus = 'PUBLISHED') => {
    if (!formData.title.trim() || !formData.event_date || !formData.start_time || !formData.end_time) {
      setError('Event title, date, start time, and end time are required.');
      return;
    }

    try {
      setLoading(true);
      setError(null);

      const payload = {
        ...formData,
        status: publishStatus,
        tickets: tickets.map(t => ({
          name: t.name,
          price: Number(t.price),
          quantity: Number(t.quantity),
          description: t.description,
          currency: 'INR'
        }))
      };

      const res = await fetch('/api/events', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify(payload)
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to create event');
      }

      notify(
        publishStatus === 'PUBLISHED' ? 'Event published successfully!' : 'Event saved as draft!',
        'success'
      );

      if (onEventCreated) {
        onEventCreated(data.event_id);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: '960px', margin: '0 auto', padding: '10px 20px 80px 20px', display: 'flex', flexDirection: 'column', gap: '30px' }}>
      {/* Top Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '14px' }}>
        <button
          onClick={onBack}
          className="btn-secondary"
          style={{ padding: '8px 14px', borderRadius: '10px', fontSize: '0.85rem', gap: '6px' }}
        >
          <ArrowLeft size={16} /> Cancel & Back
        </button>

        <div style={{ display: 'flex', gap: '10px' }}>
          <button
            type="button"
            disabled={loading}
            onClick={() => handleSubmit('DRAFT')}
            className="btn-secondary"
            style={{ padding: '10px 18px', borderRadius: '10px', fontSize: '0.88rem' }}
          >
            Save as Draft
          </button>
          <button
            type="button"
            disabled={loading}
            onClick={() => handleSubmit('PUBLISHED')}
            className="btn-primary"
            style={{ padding: '10px 22px', borderRadius: '10px', fontSize: '0.88rem', fontWeight: '700', gap: '8px' }}
          >
            {loading ? <Loader2 size={16} className="animate-spin" /> : <PlusCircle size={16} />}
            Publish Event
          </button>
        </div>
      </div>

      {error && (
        <div style={{
          padding: '14px 18px',
          borderRadius: '12px',
          background: 'rgba(239, 68, 68, 0.12)',
          border: '1px solid rgba(239, 68, 68, 0.3)',
          color: '#ef4444',
          display: 'flex',
          alignItems: 'center',
          gap: '10px',
          fontSize: '0.9rem'
        }}>
          <AlertCircle size={20} />
          <span>{error}</span>
        </div>
      )}

      {/* Main Form Body */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '26px' }}>
        {/* Section 1: Basic Information */}
        <div className="glass-panel" style={{ padding: '28px', borderRadius: '20px', background: 'var(--bg-secondary)', border: '1px solid var(--border-glass)' }}>
          <h3 style={{ fontSize: '1.2rem', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Calendar size={18} style={{ color: 'var(--accent-primary)' }} /> 1. Event Fundamentals
          </h3>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            <div>
              <label style={{ fontSize: '0.82rem', fontWeight: '600', color: 'var(--text-secondary)', marginBottom: '4px', display: 'block' }}>
                Event Title *
              </label>
              <input
                type="text"
                placeholder="e.g. National Symposium on Deep Learning & Generative Models"
                value={formData.title}
                onChange={e => setFormData({ ...formData, title: e.target.value })}
                className="input-field"
                required
              />
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
              <div>
                <label style={{ fontSize: '0.82rem', fontWeight: '600', color: 'var(--text-secondary)', marginBottom: '4px', display: 'block' }}>
                  Category
                </label>
                <select
                  value={formData.category}
                  onChange={e => setFormData({ ...formData, category: e.target.value })}
                  className="input-field"
                >
                  <option value="Technology & AI">Technology & AI</option>
                  <option value="Software Engineering">Software Engineering</option>
                  <option value="Hackathon & Competitions">Hackathon & Competitions</option>
                  <option value="Academic Workshop">Academic Workshop</option>
                  <option value="Research & Seminar">Research & Seminar</option>
                  <option value="Career & Industry">Career & Industry</option>
                </select>
              </div>

              <div>
                <label style={{ fontSize: '0.82rem', fontWeight: '600', color: 'var(--text-secondary)', marginBottom: '4px', display: 'block' }}>
                  Organizer / Host Name *
                </label>
                <input
                  type="text"
                  value={formData.organizer_name}
                  onChange={e => setFormData({ ...formData, organizer_name: e.target.value })}
                  className="input-field"
                  placeholder="Department or Faculty name"
                  required
                />
              </div>
            </div>

            <div>
              <label style={{ fontSize: '0.82rem', fontWeight: '600', color: 'var(--text-secondary)', marginBottom: '4px', display: 'block' }}>
                Short Catchy Summary (1-2 sentences)
              </label>
              <input
                type="text"
                placeholder="Brief overview visible on preview cards..."
                value={formData.short_description}
                onChange={e => setFormData({ ...formData, short_description: e.target.value })}
                className="input-field"
              />
            </div>

            <div>
              <label style={{ fontSize: '0.82rem', fontWeight: '600', color: 'var(--text-secondary)', marginBottom: '4px', display: 'block' }}>
                Full Description & Agenda
              </label>
              <textarea
                rows={4}
                placeholder="Comprehensive details, keynote topics, prerequisites, and takeaway benefits..."
                value={formData.description}
                onChange={e => setFormData({ ...formData, description: e.target.value })}
                className="input-field"
              />
            </div>
          </div>
        </div>

        {/* Section 2: Banner Image Presets */}
        <div className="glass-panel" style={{ padding: '28px', borderRadius: '20px', background: 'var(--bg-secondary)', border: '1px solid var(--border-glass)' }}>
          <h3 style={{ fontSize: '1.2rem', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Image size={18} style={{ color: '#06b6d4' }} /> 2. Banner & Visual Identity
          </h3>

          <div style={{ marginBottom: '14px' }}>
            <label style={{ fontSize: '0.82rem', fontWeight: '600', color: 'var(--text-secondary)', marginBottom: '6px', display: 'block' }}>
              Choose a curated cover image preset or enter custom URL:
            </label>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '10px' }}>
              {bannerPresets.map((p, idx) => {
                const isSelected = formData.banner_url === p.url;
                return (
                  <div
                    key={idx}
                    onClick={() => setFormData({ ...formData, banner_url: p.url })}
                    style={{
                      height: '90px',
                      borderRadius: '12px',
                      overflow: 'hidden',
                      position: 'relative',
                      cursor: 'pointer',
                      border: isSelected ? '3px solid var(--accent-primary)' : '1px solid var(--border-glass)'
                    }}
                  >
                    <img src={p.url} alt={p.label} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    <div style={{
                      position: 'absolute',
                      bottom: 0,
                      left: 0,
                      right: 0,
                      background: 'rgba(0,0,0,0.7)',
                      padding: '4px 8px',
                      fontSize: '0.72rem',
                      color: '#ffffff',
                      fontWeight: '600'
                    }}>
                      {p.label}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div>
            <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '4px', display: 'block' }}>
              Banner Image URL
            </label>
            <input
              type="url"
              value={formData.banner_url}
              onChange={e => setFormData({ ...formData, banner_url: e.target.value })}
              className="input-field"
              placeholder="https://images.unsplash.com/..."
            />
          </div>
        </div>

        {/* Section 3: Date, Time & Venue */}
        <div className="glass-panel" style={{ padding: '28px', borderRadius: '20px', background: 'var(--bg-secondary)', border: '1px solid var(--border-glass)' }}>
          <h3 style={{ fontSize: '1.2rem', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Clock size={18} style={{ color: 'var(--warning)' }} /> 3. Schedule & Location Format
          </h3>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '16px', marginBottom: '16px' }}>
            <div>
              <label style={{ fontSize: '0.82rem', fontWeight: '600', color: 'var(--text-secondary)', marginBottom: '4px', display: 'block' }}>
                Event Date *
              </label>
              <input
                type="date"
                value={formData.event_date}
                onChange={e => setFormData({ ...formData, event_date: e.target.value })}
                className="input-field"
                required
              />
            </div>
            <div>
              <label style={{ fontSize: '0.82rem', fontWeight: '600', color: 'var(--text-secondary)', marginBottom: '4px', display: 'block' }}>
                Start Time *
              </label>
              <input
                type="time"
                value={formData.start_time}
                onChange={e => setFormData({ ...formData, start_time: e.target.value })}
                className="input-field"
                required
              />
            </div>
            <div>
              <label style={{ fontSize: '0.82rem', fontWeight: '600', color: 'var(--text-secondary)', marginBottom: '4px', display: 'block' }}>
                End Time *
              </label>
              <input
                type="time"
                value={formData.end_time}
                onChange={e => setFormData({ ...formData, end_time: e.target.value })}
                className="input-field"
                required
              />
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '16px' }}>
            <div>
              <label style={{ fontSize: '0.82rem', fontWeight: '600', color: 'var(--text-secondary)', marginBottom: '4px', display: 'block' }}>
                Format
              </label>
              <select
                value={formData.venue_type}
                onChange={e => setFormData({ ...formData, venue_type: e.target.value })}
                className="input-field"
              >
                <option value="HYBRID">Hybrid (Physical & Virtual)</option>
                <option value="ONLINE">Online Virtual Room</option>
                <option value="PHYSICAL">Physical On-Campus</option>
              </select>
            </div>

            <div>
              <label style={{ fontSize: '0.82rem', fontWeight: '600', color: 'var(--text-secondary)', marginBottom: '4px', display: 'block' }}>
                Venue Address or Virtual Meeting Code
              </label>
              <input
                type="text"
                value={formData.venue_address}
                onChange={e => setFormData({ ...formData, venue_address: e.target.value })}
                className="input-field"
                placeholder="Auditorium, Floor, Room No. or Virtual Meet Code"
              />
            </div>
          </div>
        </div>

        {/* Section 4: Tickets & Pricing Builder */}
        <div className="glass-panel" style={{ padding: '28px', borderRadius: '20px', background: 'var(--bg-secondary)', border: '1px solid var(--border-glass)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
            <h3 style={{ fontSize: '1.2rem', margin: 0, display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Ticket size={18} style={{ color: 'var(--accent-primary)' }} /> 4. Tickets & Passes Configuration
            </h3>
            <button
              type="button"
              onClick={handleAddTicket}
              className="btn-secondary"
              style={{ padding: '6px 12px', fontSize: '0.82rem', gap: '6px' }}
            >
              <PlusCircle size={14} /> Add Another Ticket Tier
            </button>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {tickets.map((t, idx) => (
              <div 
                key={idx}
                style={{
                  padding: '16px',
                  borderRadius: '14px',
                  background: 'var(--bg-surface)',
                  border: '1px solid var(--border-subtle)',
                  display: 'grid',
                  gridTemplateColumns: '2fr 1fr 1fr 2fr auto',
                  gap: '12px',
                  alignItems: 'center'
                }}
              >
                <div>
                  <label style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>Ticket Name</label>
                  <input
                    type="text"
                    value={t.name}
                    onChange={e => handleTicketChange(idx, 'name', e.target.value)}
                    className="input-field"
                    placeholder="General Admission"
                  />
                </div>
                <div>
                  <label style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>Price (INR)</label>
                  <input
                    type="number"
                    min="0"
                    value={t.price}
                    onChange={e => handleTicketChange(idx, 'price', e.target.value)}
                    className="input-field"
                    placeholder="0 for Free"
                  />
                </div>
                <div>
                  <label style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>Seats Limit</label>
                  <input
                    type="number"
                    min="1"
                    value={t.quantity}
                    onChange={e => handleTicketChange(idx, 'quantity', e.target.value)}
                    className="input-field"
                    placeholder="100"
                  />
                </div>
                <div>
                  <label style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>Brief Description</label>
                  <input
                    type="text"
                    value={t.description}
                    onChange={e => handleTicketChange(idx, 'description', e.target.value)}
                    className="input-field"
                    placeholder="Pass details"
                  />
                </div>
                <div style={{ paddingTop: '16px' }}>
                  <button
                    type="button"
                    onClick={() => handleRemoveTicket(idx)}
                    className="btn-secondary"
                    style={{ padding: '8px', color: 'var(--danger)', borderRadius: '8px' }}
                    title="Remove Tier"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Section 5: Capacity & Contact */}
        <div className="glass-panel" style={{ padding: '28px', borderRadius: '20px', background: 'var(--bg-secondary)', border: '1px solid var(--border-glass)' }}>
          <h3 style={{ fontSize: '1.2rem', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <ShieldCheck size={18} style={{ color: 'var(--success)' }} /> 5. Capacity & Organizer Contact
          </h3>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '16px' }}>
            <div>
              <label style={{ fontSize: '0.82rem', fontWeight: '600', color: 'var(--text-secondary)', marginBottom: '4px', display: 'block' }}>
                Max Capacity (All Attendees)
              </label>
              <input
                type="number"
                min="10"
                value={formData.max_capacity}
                onChange={e => setFormData({ ...formData, max_capacity: e.target.value })}
                className="input-field"
              />
            </div>
            <div>
              <label style={{ fontSize: '0.82rem', fontWeight: '600', color: 'var(--text-secondary)', marginBottom: '4px', display: 'block' }}>
                Contact Email
              </label>
              <input
                type="email"
                value={formData.contact_email}
                onChange={e => setFormData({ ...formData, contact_email: e.target.value })}
                className="input-field"
              />
            </div>
            <div>
              <label style={{ fontSize: '0.82rem', fontWeight: '600', color: 'var(--text-secondary)', marginBottom: '4px', display: 'block' }}>
                Contact Phone
              </label>
              <input
                type="tel"
                value={formData.contact_phone}
                onChange={e => setFormData({ ...formData, contact_phone: e.target.value })}
                className="input-field"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
