import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNotifications } from '../context/NotificationContext';
import { Calendar, Clock, Video, Users, X, Check, Copy, AlertCircle, Loader2 } from 'lucide-react';

export default function ScheduleMeetingModal({ isOpen, onClose, onScheduled }) {
  const { user, token } = useAuth();
  const { notify } = useNotifications();

  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const defaultDate = tomorrow.toISOString().split('T')[0];

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    scheduled_date: defaultDate,
    scheduled_start_time: '14:00',
    duration_minutes: 60,
    meeting_type: 'SCHEDULED',
    invitee_emails: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [scheduledResult, setScheduledResult] = useState(null);

  if (!isOpen || (user && user.role === 'STUDENT')) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.title.trim() || !formData.scheduled_date || !formData.scheduled_start_time) {
      setError('Title, date, and start time are required.');
      return;
    }

    try {
      setLoading(true);
      setError(null);

      const emails = formData.invitee_emails
        .split(',')
        .map(e => e.trim())
        .filter(e => e.length > 0);

      const res = await fetch('/api/meetings/schedule', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify({
          title: formData.title.trim(),
          description: formData.description.trim(),
          scheduled_date: formData.scheduled_date,
          scheduled_start_time: formData.scheduled_start_time,
          duration_minutes: Number(formData.duration_minutes),
          meeting_type: formData.meeting_type,
          invitee_emails: emails
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to schedule meeting');
      }

      setScheduledResult(data);
      notify('Meeting scheduled successfully!', 'success');
      if (onScheduled) onScheduled(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const copyMeetingLink = (code) => {
    const url = `${window.location.origin}/#meeting-${code}`;
    navigator.clipboard.writeText(url);
    notify('Meeting link copied to clipboard!', 'info');
  };

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: 'rgba(0, 0, 0, 0.65)',
      backdropFilter: 'blur(5px)',
      zIndex: 1050,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '20px'
    }} onClick={onClose}>
      <div 
        onClick={e => e.stopPropagation()}
        className="glass-panel"
        style={{
          width: '100%',
          maxWidth: '560px',
          maxHeight: '90vh',
          borderRadius: '20px',
          background: 'var(--bg-secondary)',
          border: '1px solid var(--border-glass)',
          boxShadow: 'var(--shadow-card)',
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column'
        }}
      >
        {/* Header */}
        <div style={{
          padding: '20px 24px',
          borderBottom: '1px solid var(--border-subtle)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          background: 'var(--bg-tertiary)'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div style={{
              width: '36px',
              height: '36px',
              borderRadius: '10px',
              background: 'rgba(6, 182, 212, 0.15)',
              color: '#06b6d4',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}>
              <Calendar size={18} />
            </div>
            <div>
              <h3 style={{ fontSize: '1.15rem', margin: 0 }}>Schedule a Video Meeting</h3>
              <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                Set up a virtual classroom, project sync, or office hours
              </div>
            </div>
          </div>
          <button onClick={onClose} className="btn-secondary" style={{ padding: '8px', borderRadius: '10px' }}>
            <X size={18} />
          </button>
        </div>

        {/* Form Body */}
        <div style={{ padding: '24px', overflowY: 'auto', flex: 1 }}>
          {error && (
            <div style={{
              padding: '12px 16px',
              borderRadius: '10px',
              background: 'rgba(239, 68, 68, 0.12)',
              border: '1px solid rgba(239, 68, 68, 0.3)',
              color: '#ef4444',
              fontSize: '0.85rem',
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
              marginBottom: '18px'
            }}>
              <AlertCircle size={18} />
              <span>{error}</span>
            </div>
          )}

          {!scheduledResult ? (
            <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div>
                <label style={{ fontSize: '0.8rem', fontWeight: '600', color: 'var(--text-secondary)', marginBottom: '4px', display: 'block' }}>
                  Meeting Title *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Operating Systems Lab Discussion or Capstone Review"
                  value={formData.title}
                  onChange={e => setFormData({ ...formData, title: e.target.value })}
                  className="input-field"
                />
              </div>

              <div>
                <label style={{ fontSize: '0.8rem', fontWeight: '600', color: 'var(--text-secondary)', marginBottom: '4px', display: 'block' }}>
                  Agenda / Description
                </label>
                <textarea
                  rows={2}
                  placeholder="Briefly describe topics to be covered..."
                  value={formData.description}
                  onChange={e => setFormData({ ...formData, description: e.target.value })}
                  className="input-field"
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
                <div>
                  <label style={{ fontSize: '0.8rem', fontWeight: '600', color: 'var(--text-secondary)', marginBottom: '4px', display: 'block' }}>
                    Scheduled Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={formData.scheduled_date}
                    onChange={e => setFormData({ ...formData, scheduled_date: e.target.value })}
                    className="input-field"
                  />
                </div>
                <div>
                  <label style={{ fontSize: '0.8rem', fontWeight: '600', color: 'var(--text-secondary)', marginBottom: '4px', display: 'block' }}>
                    Start Time *
                  </label>
                  <input
                    type="time"
                    required
                    value={formData.scheduled_start_time}
                    onChange={e => setFormData({ ...formData, scheduled_start_time: e.target.value })}
                    className="input-field"
                  />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
                <div>
                  <label style={{ fontSize: '0.8rem', fontWeight: '600', color: 'var(--text-secondary)', marginBottom: '4px', display: 'block' }}>
                    Estimated Duration
                  </label>
                  <select
                    value={formData.duration_minutes}
                    onChange={e => setFormData({ ...formData, duration_minutes: Number(e.target.value) })}
                    className="input-field"
                  >
                    <option value={30}>30 Minutes</option>
                    <option value={45}>45 Minutes</option>
                    <option value={60}>1 Hour</option>
                    <option value={90}>1.5 Hours</option>
                    <option value={120}>2 Hours</option>
                  </select>
                </div>
                <div>
                  <label style={{ fontSize: '0.8rem', fontWeight: '600', color: 'var(--text-secondary)', marginBottom: '4px', display: 'block' }}>
                    Session Type
                  </label>
                  <select
                    value={formData.meeting_type}
                    onChange={e => setFormData({ ...formData, meeting_type: e.target.value })}
                    className="input-field"
                  >
                    <option value="SCHEDULED">Standard Video Meeting</option>
                    <option value="CLASSROOM">Virtual Academic Classroom</option>
                  </select>
                </div>
              </div>

              <div>
                <label style={{ fontSize: '0.8rem', fontWeight: '600', color: 'var(--text-secondary)', marginBottom: '4px', display: 'block' }}>
                  Invite Participants (Emails separated by commas)
                </label>
                <input
                  type="text"
                  placeholder="student1@learnique.edu, student2@learnique.edu"
                  value={formData.invitee_emails}
                  onChange={e => setFormData({ ...formData, invitee_emails: e.target.value })}
                  className="input-field"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="btn-primary"
                style={{
                  padding: '14px',
                  borderRadius: '12px',
                  fontSize: '0.95rem',
                  fontWeight: '700',
                  marginTop: '10px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '8px'
                }}
              >
                {loading ? <Loader2 size={18} className="animate-spin" /> : <Calendar size={18} />}
                Confirm & Schedule Meeting
              </button>
            </form>
          ) : (
            <div style={{ textAlign: 'center', padding: '10px 0' }}>
              <div style={{
                width: '60px',
                height: '60px',
                borderRadius: '50%',
                background: 'rgba(16, 185, 129, 0.15)',
                color: 'var(--success)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 16px auto'
              }}>
                <Check size={32} />
              </div>

              <h4 style={{ fontSize: '1.2rem', marginBottom: '6px' }}>Meeting Successfully Scheduled</h4>
              <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: '20px' }}>
                Your meeting code has been generated. Share it with your participants to let them join.
              </p>

              <div style={{
                padding: '16px',
                borderRadius: '12px',
                background: 'var(--bg-surface)',
                border: '1px solid var(--border-glass)',
                marginBottom: '20px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between'
              }}>
                <div>
                  <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>Meeting Code:</div>
                  <div style={{ fontSize: '1.1rem', fontFamily: 'var(--font-mono)', fontWeight: '700', color: 'var(--accent-primary)' }}>
                    {scheduledResult.code}
                  </div>
                </div>
                <button
                  onClick={() => copyMeetingLink(scheduledResult.code)}
                  className="btn-secondary"
                  style={{ padding: '8px 14px', gap: '6px' }}
                >
                  <Copy size={14} /> Copy Link
                </button>
              </div>

              <button
                onClick={onClose}
                className="btn-primary"
                style={{ width: '100%', padding: '12px' }}
              >
                Done
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
