import React from 'react';
import { useTheme, ACCENT_PRESETS } from '../context/ThemeContext';
import { Palette, X, Check } from 'lucide-react';

export default function ColorPickerModal({ isOpen, onClose }) {
  const { accentColor, setAccentColor, theme } = useTheme();

  if (!isOpen) return null;

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      width: '100vw',
      height: '100vh',
      background: 'rgba(0, 0, 0, 0.65)',
      backdropFilter: 'blur(8px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 9999
    }}>
      <div className="glass-panel" style={{
        width: '420px',
        maxWidth: '90%',
        padding: '28px',
        borderRadius: '20px',
        position: 'relative'
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <Palette size={22} style={{ color: 'var(--accent-primary)' }} />
            <h3 style={{ fontSize: '1.25rem', fontWeight: '700' }}>Theme & Accent Color</h3>
          </div>
          <button 
            onClick={onClose}
            style={{
              background: 'transparent',
              border: 'none',
              color: 'var(--text-muted)',
              cursor: 'pointer',
              padding: '6px'
            }}
          >
            <X size={20} />
          </button>
        </div>

        <p style={{ color: 'var(--text-secondary)', fontSize: '0.875rem', marginBottom: '20px' }}>
          Personalize your workspace accent. The interface layout remains perfectly consistent while glints, glows, and interactive states dynamically adapt.
        </p>

        <div style={{ marginBottom: '24px' }}>
          <label style={{ fontSize: '0.8rem', fontWeight: '600', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', display: 'block', marginBottom: '10px' }}>
            Curated Presets
          </label>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '10px' }}>
            {ACCENT_PRESETS.map((preset) => (
              <button
                key={preset.color}
                onClick={() => setAccentColor(preset.color)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  padding: '10px 12px',
                  background: accentColor === preset.color ? 'var(--accent-light)' : 'var(--bg-tertiary)',
                  border: accentColor === preset.color ? '2px solid var(--accent-primary)' : '1px solid var(--border-glass)',
                  borderRadius: '10px',
                  cursor: 'pointer',
                  color: 'var(--text-primary)',
                  fontSize: '0.825rem',
                  fontWeight: '500',
                  transition: 'all 0.2s'
                }}
              >
                <span style={{
                  width: '16px',
                  height: '16px',
                  borderRadius: '50%',
                  background: preset.color,
                  boxShadow: `0 0 8px ${preset.color}88`,
                  display: 'inline-block'
                }} />
                <span style={{ flex: 1, textAlign: 'left', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {preset.name.split(' ')[0]}
                </span>
                {accentColor === preset.color && <Check size={14} style={{ color: 'var(--accent-primary)' }} />}
              </button>
            ))}
          </div>
        </div>

        <div style={{ marginBottom: '24px' }}>
          <label style={{ fontSize: '0.8rem', fontWeight: '600', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', display: 'block', marginBottom: '10px' }}>
            Custom Hex Color
          </label>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <input 
              type="color"
              value={accentColor}
              onChange={(e) => setAccentColor(e.target.value)}
              style={{
                width: '48px',
                height: '42px',
                borderRadius: '8px',
                border: '1px solid var(--border-glass)',
                cursor: 'pointer',
                background: 'transparent',
                padding: '2px'
              }}
            />
            <input 
              type="text"
              className="input-field"
              value={accentColor}
              onChange={(e) => setAccentColor(e.target.value)}
              placeholder="#4f46e5"
              style={{ fontFamily: 'var(--font-mono)', fontSize: '0.95rem' }}
            />
          </div>
        </div>

        <div style={{
          padding: '14px',
          borderRadius: '12px',
          background: 'var(--bg-tertiary)',
          border: '1px solid var(--border-glass)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: '20px'
        }}>
          <div>
            <div style={{ fontSize: '0.85rem', fontWeight: '600' }}>Active Accent Preview</div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Real-time CSS token injection</div>
          </div>
          <button className="btn-primary" style={{ padding: '6px 14px', fontSize: '0.8rem' }}>
            Sample Button
          </button>
        </div>

        <button 
          onClick={onClose}
          className="btn-primary" 
          style={{ width: '100%', padding: '12px' }}
        >
          Apply & Save Theme
        </button>
      </div>
    </div>
  );
}
