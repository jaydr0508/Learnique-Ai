import sys
import sqlite3
from pathlib import Path
from datetime import datetime, timedelta

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

DB_PATH = Path(__file__).resolve().parent / "quizify.db"

SCHEMA_SQL = """
-- Events Table
CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    short_description TEXT,
    description TEXT,
    category TEXT DEFAULT 'Academic Workshop',
    banner_url TEXT,
    organizer_name TEXT NOT NULL,
    organizer_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    event_date DATE NOT NULL,
    start_time TEXT NOT NULL,
    end_time TEXT NOT NULL,
    timezone TEXT DEFAULT 'Asia/Kolkata (IST)',
    registration_opens_at DATETIME,
    registration_deadline DATETIME,
    venue_type TEXT DEFAULT 'HYBRID', -- PHYSICAL, ONLINE, HYBRID
    venue_address TEXT,
    online_meeting_url TEXT,
    max_capacity INTEGER DEFAULT 100,
    current_registrations INTEGER DEFAULT 0,
    contact_email TEXT,
    contact_phone TEXT,
    rules_and_requirements TEXT,
    cancellation_policy TEXT,
    terms_and_conditions TEXT,
    status TEXT DEFAULT 'PUBLISHED', -- DRAFT, PUBLISHED, CANCELLED, COMPLETED
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Event Tickets
CREATE TABLE IF NOT EXISTS event_tickets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT,
    price REAL DEFAULT 0,
    currency TEXT DEFAULT 'INR',
    quantity INTEGER DEFAULT 100,
    sold_count INTEGER DEFAULT 0,
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Event Registrations
CREATE TABLE IF NOT EXISTS event_registrations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    registration_number TEXT UNIQUE NOT NULL,
    event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    ticket_id INTEGER REFERENCES event_tickets(id) ON DELETE SET NULL,
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    participant_name TEXT NOT NULL,
    participant_email TEXT NOT NULL,
    participant_phone TEXT,
    notes TEXT,
    ticket_name TEXT,
    ticket_price REAL DEFAULT 0,
    currency TEXT DEFAULT 'INR',
    payment_status TEXT DEFAULT 'COMPLETED', -- FREE, PENDING, PAID, FAILED, CANCELLED, REFUNDED
    payment_id TEXT,
    order_id TEXT,
    payment_method TEXT DEFAULT 'FREE', -- FREE, RAZORPAY_SANDBOX, EXTERNAL
    attendance_status TEXT DEFAULT 'REGISTERED', -- REGISTERED, CHECKED_IN, NO_SHOW
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Payment Transactions & Receipts
CREATE TABLE IF NOT EXISTS payment_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    receipt_number TEXT UNIQUE NOT NULL,
    registration_id INTEGER REFERENCES event_registrations(id) ON DELETE CASCADE,
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    event_id INTEGER REFERENCES events(id) ON DELETE SET NULL,
    amount REAL NOT NULL,
    currency TEXT DEFAULT 'INR',
    provider TEXT DEFAULT 'RAZORPAY',
    order_id TEXT NOT NULL,
    payment_id TEXT NOT NULL,
    signature TEXT,
    status TEXT DEFAULT 'SUCCESS',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Meetings Table
CREATE TABLE IF NOT EXISTS meetings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    host_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    host_name TEXT NOT NULL,
    scheduled_date DATE,
    scheduled_start_time TEXT,
    scheduled_end_time TEXT,
    duration_minutes INTEGER DEFAULT 60,
    timezone TEXT DEFAULT 'Asia/Kolkata (IST)',
    meeting_type TEXT DEFAULT 'INSTANT', -- INSTANT, SCHEDULED, CLASSROOM
    status TEXT DEFAULT 'LIVE', -- SCHEDULED, LIVE, ENDED, CANCELLED
    is_locked INTEGER DEFAULT 0,
    waiting_room_enabled INTEGER DEFAULT 0,
    started_at DATETIME,
    ended_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Meeting Participants
CREATE TABLE IF NOT EXISTS meeting_participants (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    meeting_id INTEGER NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    participant_name TEXT NOT NULL,
    session_id TEXT NOT NULL,
    role TEXT DEFAULT 'PARTICIPANT', -- HOST, CO_HOST, PARTICIPANT
    is_muted INTEGER DEFAULT 0,
    is_camera_off INTEGER DEFAULT 0,
    is_hand_raised INTEGER DEFAULT 0,
    is_screen_sharing INTEGER DEFAULT 0,
    status TEXT DEFAULT 'JOINED', -- JOINED, LEFT, REMOVED
    joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_heartbeat DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(meeting_id, session_id)
);

-- Meeting WebRTC Signaling Messages
CREATE TABLE IF NOT EXISTS meeting_signals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    meeting_id INTEGER NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
    from_session TEXT NOT NULL,
    to_session TEXT NOT NULL,
    signal_type TEXT NOT NULL,
    payload TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Meeting Chat Messages
CREATE TABLE IF NOT EXISTS meeting_chat_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    meeting_id INTEGER NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
    session_id TEXT NOT NULL,
    sender_name TEXT NOT NULL,
    sender_role TEXT DEFAULT 'PARTICIPANT',
    content TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Notifications Table
CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    type TEXT DEFAULT 'INFO',
    link TEXT,
    is_read INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Event Announcements
CREATE TABLE IF NOT EXISTS event_announcements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    author_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for lightning fast queries
CREATE INDEX IF NOT EXISTS idx_events_date ON events(event_date);
CREATE INDEX IF NOT EXISTS idx_events_status ON events(status);
CREATE INDEX IF NOT EXISTS idx_events_organizer ON events(organizer_id);
CREATE INDEX IF NOT EXISTS idx_registrations_user ON event_registrations(user_id);
CREATE INDEX IF NOT EXISTS idx_registrations_event ON event_registrations(event_id);
CREATE INDEX IF NOT EXISTS idx_meetings_code ON meetings(code);
CREATE INDEX IF NOT EXISTS idx_meetings_status ON meetings(status);
CREATE INDEX IF NOT EXISTS idx_meetings_host ON meetings(host_id);
CREATE INDEX IF NOT EXISTS idx_meeting_participants ON meeting_participants(meeting_id, session_id);
CREATE INDEX IF NOT EXISTS idx_meeting_signals ON meeting_signals(meeting_id, to_session);
CREATE INDEX IF NOT EXISTS idx_meeting_chat ON meeting_chat_messages(meeting_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, is_read);
"""

def migrate_and_seed():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.executescript(SCHEMA_SQL)
    conn.commit()

    # Check if seed events exist
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM events")
    if cur.fetchone()[0] == 0:
        print("🌱 Seeding high-quality initial events...")
        today = datetime.now().date()
        date1 = (today + timedelta(days=2)).isoformat()
        date2 = (today + timedelta(days=5)).isoformat()
        date3 = (today + timedelta(days=10)).isoformat()

        # Event 1: National AI & Machine Learning Symposium 2026
        cur.execute("""
            INSERT INTO events (
                title, slug, short_description, description, category, banner_url,
                organizer_name, organizer_id, event_date, start_time, end_time,
                venue_type, venue_address, online_meeting_url, max_capacity,
                contact_email, contact_phone, rules_and_requirements,
                cancellation_policy, terms_and_conditions, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            "National AI & Machine Learning Summit 2026",
            "national-ai-ml-summit-2026",
            "Explore cutting-edge breakthroughs in Generative AI, Large Language Models, and Deep Learning with leading academic scholars and industry pioneers.",
            "Welcome to the premier academic symposium on Artificial Intelligence and Next-Generation Foundation Models. Featuring keynote presentations by top AI researchers, interactive hands-on code labs on modern neural network architectures, and a panel discussion on ethical AI governance. All attendees receive official verification certificates, digital materials, and access to recorded sessions.",
            "Technology & AI",
            "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&w=1200&q=80",
            "Prof. Rajesh Sharma (Head of Department)",
            2,
            date1,
            "10:00",
            "16:30",
            "HYBRID",
            "Main Campus Auditorium, Hall 3, Quizify University",
            "quiz-ai-summit",
            250,
            "sharma@quizify.edu",
            "+91 98765 43210",
            "Bring your laptop with Python 3.10+ installed. Photo ID required at campus entrance.",
            "Cancellations accepted up to 24 hours before the event with 100% refund.",
            "By registering, participants agree to adhere to academic conduct and workshop guidelines.",
            "PUBLISHED"
        ))
        event1_id = cur.lastrowid

        # Tickets for Event 1
        cur.execute("""
            INSERT INTO event_tickets (event_id, name, description, price, currency, quantity, sold_count)
            VALUES (?, 'Student Pass', 'Standard access for verified university students with digital certificate.', 0, 'INR', 150, 24)
        """, (event1_id,))
        cur.execute("""
            INSERT INTO event_tickets (event_id, name, description, price, currency, quantity, sold_count)
            VALUES (?, 'Professional & Delegate Pass', 'Full symposium access, VIP networking lunch, and speaker Q&A.', 499, 'INR', 100, 12)
        """, (event1_id,))

        # Event 2: Full-Stack Web Architecture Masterclass
        cur.execute("""
            INSERT INTO events (
                title, slug, short_description, description, category, banner_url,
                organizer_name, organizer_id, event_date, start_time, end_time,
                venue_type, venue_address, online_meeting_url, max_capacity,
                contact_email, contact_phone, rules_and_requirements,
                cancellation_policy, terms_and_conditions, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            "Full-Stack Web Architecture & Cloud Masterclass",
            "fullstack-web-architecture-masterclass",
            "Deep dive into modern microservices, WebRTC video conferencing, distributed caching, and zero-downtime deployment pipelines.",
            "A comprehensive 4-hour hands-on masterclass focusing on high-performance web systems. We cover building scalable real-time video conferencing, WebSockets, Redis pub/sub, database indexing strategies, and automated containerized CI/CD. Ideal for Computer Science undergraduates and software engineers.",
            "Software Engineering",
            "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=1200&q=80",
            "Dr. Sunita Verma",
            3,
            date2,
            "14:00",
            "18:00",
            "ONLINE",
            "Virtual Classroom via Quizify Live Meet",
            "quiz-fullstack-mastery",
            300,
            "verma@quizify.edu",
            "+91 98765 43211",
            "Reliable high-speed internet and modern web browser (Chrome, Firefox, or Edge).",
            "Full refund available anytime prior to session start.",
            "Recordings will be provided to registered attendees within 24 hours.",
            "PUBLISHED"
        ))
        event2_id = cur.lastrowid

        cur.execute("""
            INSERT INTO event_tickets (event_id, name, description, price, currency, quantity, sold_count)
            VALUES (?, 'Free Online Admission', 'Complimentary access to live stream and chat.', 0, 'INR', 200, 45)
        """, (event2_id,))
        cur.execute("""
            INSERT INTO event_tickets (event_id, name, description, price, currency, quantity, sold_count)
            VALUES (?, 'Certified Developer Ticket', 'Includes project review, source code repo access, and verified certificate.', 299, 'INR', 100, 18)
        """, (event2_id,))

        # Event 3: Annual Inter-College Hackathon 2026
        cur.execute("""
            INSERT INTO events (
                title, slug, short_description, description, category, banner_url,
                organizer_name, organizer_id, event_date, start_time, end_time,
                venue_type, venue_address, online_meeting_url, max_capacity,
                contact_email, contact_phone, rules_and_requirements,
                cancellation_policy, terms_and_conditions, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            "HackQuizify 2026: 24-Hour Innovation Hackathon",
            "hackquizify-2026-innovation-hackathon",
            "Build impactful solutions across EdTech, Healthcare, and Sustainable Smart Cities. Prizes worth INR 1,50,000!",
            "Join over 500 brilliant developers, designers, and thinkers in the biggest university hackathon of the year. Mentorship from top engineers, free food, cloud credits, and exciting cash prizes. Teams of 2 to 4 members.",
            "Hackathon & Competitions",
            "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=1200&q=80",
            "System Administrator",
            1,
            date3,
            "09:00",
            "18:00",
            "PHYSICAL",
            "Quizify Innovation Hub, Tech Park Floor 4",
            "",
            500,
            "admin@quizify.edu",
            "+91 98765 00000",
            "Teams must register before the deadline. All code must be written during the hackathon.",
            "Non-refundable team registration fee.",
            "Standard hackathon code of conduct applies.",
            "PUBLISHED"
        ))
        event3_id = cur.lastrowid

        cur.execute("""
            INSERT INTO event_tickets (event_id, name, description, price, currency, quantity, sold_count)
            VALUES (?, 'Team Registration (Up to 4)', 'Complete team pass including meals, swag kit, and hardware lab access.', 399, 'INR', 100, 32)
        """, (event3_id,))

        # Seed sample registration for student (user_id 4: Aarav Patel)
        cur.execute("""
            INSERT INTO event_registrations (
                registration_number, event_id, ticket_id, user_id,
                participant_name, participant_email, participant_phone,
                ticket_name, ticket_price, payment_status, payment_method, attendance_status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            "REG-2026-AI-001",
            event1_id,
            1,
            4,
            "Aarav Patel",
            "aarav@quizify.edu",
            "+91 98765 11111",
            "Student Pass",
            0,
            "COMPLETED",
            "FREE",
            "REGISTERED"
        ))
        reg_id = cur.lastrowid

        # Seed receipt
        cur.execute("""
            INSERT INTO payment_transactions (
                receipt_number, registration_id, user_id, event_id,
                amount, currency, provider, order_id, payment_id, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            "RCPT-2026-0001",
            reg_id,
            4,
            event1_id,
            0,
            "INR",
            "FREE",
            "ORD-FREE-001",
            "PAY-FREE-001",
            "SUCCESS"
        ))

    # Check if meetings exist
    cur.execute("SELECT COUNT(*) FROM meetings")
    if cur.fetchone()[0] == 0:
        print("🌱 Seeding initial meetings...")
        today = datetime.now().date()
        date_today = today.isoformat()
        date_tmrw = (today + timedelta(days=1)).isoformat()

        # Meeting 1: Live Virtual Classroom
        cur.execute("""
            INSERT INTO meetings (
                code, title, description, host_id, host_name,
                scheduled_date, scheduled_start_time, scheduled_end_time,
                duration_minutes, meeting_type, status, started_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            "quiz-cs401-algo",
            "CS-401: Advanced Data Structures & Algorithm Optimization",
            "Live interactive lecture on Graph Theory, Shortest Path algorithms (Dijkstra & Bellman-Ford), and live coding examples.",
            2,
            "Prof. Rajesh Sharma (Head of Department)",
            date_today,
            "11:00",
            "12:30",
            90,
            "CLASSROOM",
            "LIVE",
            datetime.now().isoformat()
        ))

        # Meeting 2: Scheduled Project Discussion
        cur.execute("""
            INSERT INTO meetings (
                code, title, description, host_id, host_name,
                scheduled_date, scheduled_start_time, scheduled_end_time,
                duration_minutes, meeting_type, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            "quiz-capstone-review",
            "Capstone Project Review & Architecture Alignment",
            "Weekly virtual sync for final semester engineering capstone teams to review milestones, API schemas, and deployment pipelines.",
            3,
            "Dr. Sunita Verma",
            date_tmrw,
            "15:00",
            "16:00",
            60,
            "SCHEDULED",
            "SCHEDULED"
        ))

    # Seed initial notifications
    cur.execute("SELECT COUNT(*) FROM notifications")
    if cur.fetchone()[0] == 0:
        print("🌱 Seeding notifications...")
        cur.execute("""
            INSERT INTO notifications (user_id, title, message, type, link, is_read)
            VALUES (4, 'Event Registration Confirmed!', 'You are registered for National AI & Machine Learning Summit 2026. View your registration pass and receipt.', 'EVENT', 'my-activities', 0)
        """)
        cur.execute("""
            INSERT INTO notifications (user_id, title, message, type, link, is_read)
            VALUES (4, 'Live Classroom in Session', 'Prof. Rajesh Sharma has started CS-401: Advanced Data Structures. Click to join now.', 'MEETING', 'meetings', 0)
        """)
        cur.execute("""
            INSERT INTO notifications (user_id, title, message, type, link, is_read)
            VALUES (2, 'Welcome to Event & Meeting Portal', 'You can now host academic symposiums and conduct live HD video conferences with screen sharing and chat.', 'INFO', 'host-event', 1)
        """)

    conn.commit()
    conn.close()
    print("✅ Events and Meetings Database tables & seed records verified successfully!")

if __name__ == "__main__":
    migrate_and_seed()
