import json
import secrets
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Tuple
from backend.config import config
from backend.database.db import query_one, query_all, execute_query, get_db
from backend.auth.security import generate_secure_token
from backend.attendance.service import calculate_student_attendance
from backend.utils.audit import log_audit

def generate_quiz_code() -> str:
    """Generate a readable academic examination code like QZ-849201."""
    num = secrets.randbelow(900000) + 100000
    return f"QZ-{num}"

def check_quiz_eligibility(student_id: int, quiz_id: int) -> Tuple[bool, str, Optional[Dict[str, Any]]]:
    """
    Authoritative server-side eligibility check for a student attempting a quiz.
    Validates:
    1. Student account active.
    2. Quiz status and scheduling window.
    3. Division and Batch membership.
    4. Attendance Requirement (Linked Attendance Session or Threshold).
    5. Prior Attempt Status (Strictly prevents reattempts).
    """
    student = query_one(
        """
        SELECT s.*, u.is_active, u.full_name, d.name as division_name, b.name as batch_name
        FROM students s
        JOIN users u ON s.user_id = u.id
        JOIN divisions d ON s.division_id = d.id
        JOIN batches b ON s.batch_id = b.id
        WHERE s.id = ?
        """,
        (student_id,)
    )
    if not student or not student["is_active"]:
        return False, "Student account is invalid or deactivated.", None

    quiz = query_one(
        """
        SELECT q.*, s.name as subject_name, s.code as subject_code
        FROM quizzes q
        JOIN subjects s ON q.subject_id = s.id
        WHERE q.id = ?
        """,
        (quiz_id,)
    )
    if not quiz:
        return False, "Quiz not found.", None

    if quiz["status"] == "DRAFT":
        return False, "This quiz is currently in draft status and has not been scheduled.", None

    now = datetime.now()
    start_time = datetime.strptime(quiz["start_time"], "%Y-%m-%d %H:%M:%S")
    end_time = datetime.strptime(quiz["end_time"], "%Y-%m-%d %H:%M:%S")

    if now < start_time:
        return False, f"Quiz has not started yet. Configured start time is {quiz['start_time']}.", None

    if now > end_time:
        return False, f"Quiz submission window has closed at {quiz['end_time']}.", None

    # Division Check
    if student["division_id"] != quiz["division_id"]:
        return False, "You are not enrolled in the academic division designated for this quiz.", None

    # Batch Check
    if quiz["batch_id"] is not None and student["batch_id"] != quiz["batch_id"]:
        return False, "You are not enrolled in the specific batch designated for this quiz.", None

    # Attendance Requirement Check
    att_req = quiz["attendance_requirement_type"]
    if att_req == "LINKED_SESSION":
        linked_sess_id = quiz["linked_attendance_session_id"]
        if linked_sess_id:
            att_rec = query_one(
                "SELECT status FROM attendance_records WHERE session_id = ? AND student_id = ?",
                (linked_sess_id, student_id)
            )
            if not att_rec or att_rec["status"] != "PRESENT":
                return False, "You are not eligible for this quiz because the required attendance was not recorded.", None

    elif att_req == "PERCENTAGE_THRESHOLD":
        min_pct = float(quiz.get("min_attendance_percentage", 75.0))
        stats = calculate_student_attendance(student_id)
        # Find subject percentage
        sub_stat = next((s for s in stats["subjects"] if s["subject_id"] == quiz["subject_id"]), None)
        curr_pct = sub_stat["overall"]["percentage"] if sub_stat else 0.0
        if curr_pct < min_pct:
            return False, f"Attendance threshold not met. Required: {min_pct}%, your attendance: {curr_pct}%.", None

    # Check Attempt Status
    attempt = query_one("SELECT * FROM quiz_attempts WHERE quiz_id = ? AND student_id = ?", (quiz_id, student_id))
    if attempt:
        if attempt["status"] in ("SUBMITTED", "AUTO_SUBMITTED", "DISQUALIFIED"):
            return False, "You have already completed your attempt for this examination.", None
        # Existing in-progress attempt: compute remaining duration
        attempt_start = datetime.strptime(attempt["start_time"], "%Y-%m-%d %H:%M:%S")
        elapsed_sec = int((now - attempt_start).total_seconds())
        total_allowed_sec = quiz["duration_minutes"] * 60
        remaining_sec = max(0, total_allowed_sec - elapsed_sec)
        if remaining_sec <= 0:
            auto_submit_attempt(attempt["id"], "TIME_EXPIRED")
            return False, "Your examination time has expired.", None

        return True, "Eligible (Resuming in-progress attempt)", {
            "quiz": quiz,
            "attempt": attempt,
            "remaining_seconds": remaining_sec,
            "is_resumed": True
        }

    return True, "Eligible to start examination", {
        "quiz": quiz,
        "remaining_seconds": quiz["duration_minutes"] * 60,
        "is_resumed": False
    }

def start_or_resume_quiz_attempt(student_id: int, quiz_id: int) -> Tuple[bool, str, Optional[Dict[str, Any]]]:
    """Start a new attempt or resume an active one with questions."""
    eligible, msg, meta = check_quiz_eligibility(student_id, quiz_id)
    if not eligible:
        return False, msg, None

    quiz = meta["quiz"]
    now = datetime.now()
    now_str = now.strftime("%Y-%m-%d %H:%M:%S")

    attempt = meta.get("attempt")
    if not attempt:
        attempt_id = execute_query(
            """
            INSERT INTO quiz_attempts (quiz_id, student_id, start_time, status, violations_count, violations_log_json)
            VALUES (?, ?, ?, 'IN_PROGRESS', 0, '[]')
            """,
            (quiz_id, student_id, now_str)
        )
        attempt = query_one("SELECT * FROM quiz_attempts WHERE id = ?", (attempt_id,))
        remaining_seconds = quiz["duration_minutes"] * 60
    else:
        attempt_id = attempt["id"]
        remaining_seconds = meta["remaining_seconds"]

    # Fetch questions (WITHOUT correct answers or explanations!)
    questions_raw = query_all(
        """
        SELECT id, question_order, question_type, question_text, options_json, marks, difficulty, numerical_tolerance
        FROM quiz_questions
        WHERE quiz_id = ?
        ORDER BY question_order ASC
        """,
        (quiz_id,)
    )

    questions = []
    for q in questions_raw:
        opts = json.loads(q["options_json"]) if q["options_json"] else None
        questions.append({
            "id": q["id"],
            "order": q["question_order"],
            "type": q["question_type"],
            "question": q["question_text"],
            "options": opts,
            "marks": q["marks"],
            "difficulty": q["difficulty"]
        })

    # Fetch previously saved answers for this attempt
    saved_answers = query_all("SELECT question_id, student_answer FROM quiz_answers WHERE attempt_id = ?", (attempt_id,))
    answers_map = {a["question_id"]: a["student_answer"] for a in saved_answers}

    log_audit("QUIZ_ATTEMPT_STARTED", "QUIZ_ATTEMPT", str(attempt_id), None, "Student", {
        "quiz_id": quiz_id, "student_id": student_id
    })

    return True, "Attempt initiated", {
        "attempt_id": attempt_id,
        "quiz_title": quiz["title"],
        "subject_name": quiz["subject_name"],
        "duration_minutes": quiz["duration_minutes"],
        "max_tab_switches": quiz["max_tab_switches"],
        "remaining_seconds": remaining_seconds,
        "questions": questions,
        "saved_answers": answers_map
    }

def record_quiz_violation(attempt_id: int, violation_type: str, duration_sec: int) -> Tuple[bool, bool, int, str]:
    """
    Log an anti-cheating tab-switch or window blur violation.
    Returns: (success, auto_submitted, current_violations_count, reason)
    """
    attempt = query_one("SELECT a.*, q.max_tab_switches FROM quiz_attempts a JOIN quizzes q ON a.quiz_id = q.id WHERE a.id = ?", (attempt_id,))
    if not attempt or attempt["status"] != "IN_PROGRESS":
        return False, False, 0, "Attempt not active"

    violations = json.loads(attempt["violations_log_json"] or "[]")
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    new_violation_count = attempt["violations_count"] + 1
    violations.append({
        "violation_number": new_violation_count,
        "timestamp": now_str,
        "type": violation_type,
        "duration_seconds": duration_sec
    })

    auto_submitted = False
    reason = ""

    if new_violation_count > attempt["max_tab_switches"]:
        auto_submitted = True
        reason = "TAB_SWITCH_LIMIT_EXCEEDED"
        auto_submit_attempt(attempt_id, reason)
    else:
        execute_query(
            "UPDATE quiz_attempts SET violations_count = ?, violations_log_json = ? WHERE id = ?",
            (new_violation_count, json.dumps(violations), attempt_id)
        )

    return True, auto_submitted, new_violation_count, reason

def save_quiz_answer(attempt_id: int, question_id: int, answer_text: str):
    """Save an in-progress question answer without submitting attempt."""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM quiz_answers WHERE attempt_id = ? AND question_id = ?", (attempt_id, question_id))
        existing = cursor.fetchone()
        if existing:
            cursor.execute("UPDATE quiz_answers SET student_answer = ? WHERE id = ?", (answer_text, existing["id"]))
        else:
            cursor.execute("INSERT INTO quiz_answers (attempt_id, question_id, student_answer) VALUES (?, ?, ?)", (attempt_id, question_id, answer_text))

def auto_submit_attempt(attempt_id: int, reason: str = "TIME_EXPIRED"):
    """Server-authoritative auto-submission."""
    submit_quiz_attempt(attempt_id, is_auto=True, auto_reason=reason)

def submit_quiz_attempt(attempt_id: int, is_auto: bool = False, auto_reason: Optional[str] = None) -> Dict[str, Any]:
    """
    Finalize quiz attempt, evaluate objective questions (MCQ, Numerical),
    record subjective questions for grading, and compute total marks.
    """
    attempt = query_one(
        """
        SELECT a.*, q.id as quiz_id, q.title as quiz_title, q.total_marks as quiz_total_marks,
               q.passing_marks, q.result_release_time
        FROM quiz_attempts a
        JOIN quizzes q ON a.quiz_id = q.id
        WHERE a.id = ?
        """,
        (attempt_id,)
    )
    if not attempt or attempt["status"] not in ("IN_PROGRESS", "ACTIVE"):
        return {"success": False, "error": "Attempt has already been finalized."}

    now = datetime.now()
    now_str = now.strftime("%Y-%m-%d %H:%M:%S")
    start_time = datetime.strptime(attempt["start_time"], "%Y-%m-%d %H:%M:%S")
    time_spent = int((now - start_time).total_seconds())

    # Fetch all questions for this quiz
    questions = query_all("SELECT * FROM quiz_questions WHERE quiz_id = ?", (attempt["quiz_id"],))

    # Fetch all student answers submitted for this attempt
    student_answers = query_all("SELECT * FROM quiz_answers WHERE attempt_id = ?", (attempt_id,))
    answers_dict = {a["question_id"]: a for a in student_answers}

    total_score = 0.0

    with get_db() as conn:
        cursor = conn.cursor()

        for q in questions:
            q_id = q["id"]
            q_type = q["question_type"]
            q_marks = q["marks"]
            correct_ans = q["correct_answer"].strip()

            stu_ans_row = answers_dict.get(q_id)
            stu_ans = (stu_ans_row["student_answer"] or "").strip() if stu_ans_row else ""

            marks_awarded = 0.0
            is_eval = 0

            if q_type == "MCQ":
                if stu_ans and stu_ans.lower() == correct_ans.lower():
                    marks_awarded = q_marks
                is_eval = 1
                total_score += marks_awarded

            elif q_type == "NUMERICAL":
                if stu_ans:
                    try:
                        stu_num = float(stu_ans)
                        target_num = float(correct_ans)
                        tol = float(q.get("numerical_tolerance") or 0.05)
                        if abs(stu_num - target_num) <= tol:
                            marks_awarded = q_marks
                    except ValueError:
                        marks_awarded = 0.0
                is_eval = 1
                total_score += marks_awarded

            elif q_type == "ANSWER_TYPE":
                # Marked for subjective faculty grading
                is_eval = 0
                marks_awarded = 0.0

            # Upsert answer record
            if stu_ans_row:
                cursor.execute(
                    "UPDATE quiz_answers SET marks_awarded = ?, is_evaluated = ? WHERE id = ?",
                    (marks_awarded, is_eval, stu_ans_row["id"])
                )
            else:
                cursor.execute(
                    """
                    INSERT INTO quiz_answers (attempt_id, question_id, student_answer, marks_awarded, is_evaluated)
                    VALUES (?, ?, ?, ?, ?)
                    """,
                    (attempt_id, q_id, stu_ans, marks_awarded, is_eval)
                )

        new_status = "AUTO_SUBMITTED" if is_auto else "SUBMITTED"
        cursor.execute(
            """
            UPDATE quiz_attempts
            SET status = ?, submit_time = ?, time_spent_seconds = ?, total_score = ?, auto_submit_reason = ?
            WHERE id = ?
            """,
            (new_status, now_str, time_spent, total_score, auto_reason, attempt_id)
        )

    log_audit("QUIZ_ATTEMPT_SUBMITTED", "QUIZ_ATTEMPT", str(attempt_id), None, "Student", {
        "status": new_status, "score": total_score, "reason": auto_reason
    })

    return {
        "success": True,
        "status": new_status,
        "submit_time": now_str,
        "time_spent_seconds": time_spent,
        "auto_submitted": is_auto,
        "reason": auto_reason
    }

def classify_performance(percentage: float) -> str:
    """Classify student academic performance based on transparent grade bands."""
    if percentage >= 85.0:
        return "Advanced"
    elif percentage >= 70.0:
        return "Proficient"
    elif percentage >= 50.0:
        return "Developing"
    else:
        return "Needs Improvement"
