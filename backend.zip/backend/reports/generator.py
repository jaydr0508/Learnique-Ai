import io
import csv
from datetime import datetime
from typing import List, Dict, Any, Optional
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

def generate_pdf_report(title: str, subtitle: str, metadata: List[Tuple[str, str]], table_headers: List[str], table_rows: List[List[Any]]) -> bytes:
    """Generate a clean, institution-grade PDF document."""
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        rightMargin=36,
        leftMargin=36,
        topMargin=36,
        bottomMargin=36
    )

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "DocTitle",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=18,
        leading=22,
        textColor=colors.HexColor("#0f172a"),
        spaceAfter=4
    )
    sub_style = ParagraphStyle(
        "DocSub",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=11,
        leading=14,
        textColor=colors.HexColor("#475569"),
        spaceAfter=14
    )
    meta_style = ParagraphStyle(
        "DocMeta",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=9,
        leading=12,
        textColor=colors.HexColor("#334155")
    )
    cell_style = ParagraphStyle(
        "TableCell",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=8,
        leading=10,
        textColor=colors.HexColor("#1e293b")
    )
    header_cell_style = ParagraphStyle(
        "HeaderCell",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=8,
        leading=10,
        textColor=colors.white
    )

    story = []
    story.append(Paragraph("QUIZIFY ACADEMIC PLATFORM", title_style))
    story.append(Paragraph(f"{title} &bull; {subtitle}", sub_style))

    # Metadata block
    if metadata:
        meta_table_data = []
        for i in range(0, len(metadata), 2):
            row = [f"<b>{metadata[i][0]}:</b> {metadata[i][1]}"]
            if i + 1 < len(metadata):
                row.append(f"<b>{metadata[i+1][0]}:</b> {metadata[i+1][1]}")
            else:
                row.append("")
            meta_table_data.append([Paragraph(c, meta_style) for c in row])
        t_meta = Table(meta_table_data, colWidths=[270, 270])
        t_meta.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#f8fafc")),
            ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#cbd5e1")),
            ("INNERGRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#e2e8f0")),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ]))
        story.append(t_meta)
        story.append(Spacer(1, 14))

    # Main data table
    table_data = [[Paragraph(h, header_cell_style) for h in table_headers]]
    for row in table_rows:
        table_data.append([Paragraph(str(cell), cell_style) for cell in row])

    col_w = 540 / len(table_headers)
    t_main = Table(table_data, colWidths=[col_w] * len(table_headers))
    t_main.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0284c7")),
        ("ALIGN", (0, 0), (-1, -1), "LEFT"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#cbd5e1")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f8fafc")]),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    story.append(t_main)

    doc.build(story)
    return buffer.getvalue()

def generate_docx_report(title: str, subtitle: str, metadata: List[Tuple[str, str]], table_headers: List[str], table_rows: List[List[Any]]) -> bytes:
    """Generate a Microsoft Word (.docx) document."""
    doc = Document()
    
    # Title
    heading = doc.add_heading("QUIZIFY ACADEMIC PLATFORM", level=0)
    p_sub = doc.add_paragraph(f"{title} - {subtitle}")
    p_sub.style.font.color.rgb = RGBColor(71, 85, 105)

    # Metadata
    if metadata:
        meta_table = doc.add_table(rows=len(metadata), cols=2)
        meta_table.style = 'Light Shading Accent 1'
        for idx, (k, v) in enumerate(metadata):
            meta_table.cell(idx, 0).text = str(k)
            meta_table.cell(idx, 1).text = str(v)
        doc.add_paragraph("")

    # Main Table
    table = doc.add_table(rows=len(table_rows) + 1, cols=len(table_headers))
    table.style = 'Medium Shading 1 Accent 1'

    for col_idx, h in enumerate(table_headers):
        table.cell(0, col_idx).text = h

    for r_idx, row in enumerate(table_rows):
        for c_idx, val in enumerate(row):
            table.cell(r_idx + 1, c_idx).text = str(val)

    buffer = io.BytesIO()
    doc.save(buffer)
    return buffer.getvalue()

def generate_csv_report(table_headers: List[str], table_rows: List[List[Any]]) -> str:
    """Generate a clean CSV string."""
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(table_headers)
    for row in table_rows:
        writer.writerow(row)
    return output.getvalue()

def generate_excel_report(title: str, table_headers: List[str], table_rows: List[List[Any]]) -> bytes:
    """Generate a Microsoft Excel (.xlsx) file with formatting."""
    wb = Workbook()
    ws = wb.active
    ws.title = title[:30]

    # Header style
    hdr_font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    hdr_fill = PatternFill(start_color="0284C7", end_color="0284C7", fill_type="solid")
    border = Border(
        left=Side(style="thin", color="CBD5E1"),
        right=Side(style="thin", color="CBD5E1"),
        top=Side(style="thin", color="CBD5E1"),
        bottom=Side(style="thin", color="CBD5E1"),
    )

    ws.append(table_headers)
    for cell in ws[1]:
        cell.font = hdr_font
        cell.fill = hdr_fill
        cell.alignment = Alignment(horizontal="center", vertical="center")

    for row in table_rows:
        ws.append(row)

    # Auto-adjust column widths
    for col in ws.columns:
        max_len = max(len(str(cell.value or "")) for cell in col)
        col_letter = col[0].column_letter
        ws.column_dimensions[col_letter].width = max(max_len + 4, 12)

    buffer = io.BytesIO()
    wb.save(buffer)
    return buffer.getvalue()
