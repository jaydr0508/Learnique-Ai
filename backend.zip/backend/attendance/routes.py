from datetime import datetime
from flask import Blueprint, request, jsonify, g
from backend.auth.routes import require_auth
from backend.database.db import query_one, query_all, execute_query
from backend.attendance.service import (
    create_attendance_session,
    rotate_attendance_qr,
    close_attendance_session,
    record_student_attendance,
    calculate_student_attendance,
)
from backend.utils.audit import log_audit

attendance_bp = Blueprint("attendance", __name__)

@attendance_bp.route("/timetable/today", methods=["GET"])
@require_auth()
def get_today_timetable():
    """Retrieve today's scheduled classes based on user role."""
    user = g.user
    today_day = datetime.now().strftime("%A") # e.g. 'Monday', 'Friday'

    if user["role"] == "TEACHER":
        teacher = query_one("SELECT id FROM teachers WHERE user_id = ?", (user["id"],))
        if not teacher:
            return jsonify({"success": False, "error": "Teacher profile not found"}), 404

        entries = query_all(
            """
            SELECT t.*, s.name as subject_name, s.code as subject_code,
                   d.name as division_name, b.name as batch_name,
                   (SELECT COUNT(*) FROM attendance_sessions ses
                    WHERE ses.timetable_id = t.id AND ses.date = date('now') AND ses.status = 'ACTIVE') as is_session_active
            FROM timetables t
            JOIN subjects s ON t.subject_id = s.id
            JOIN divisions d ON t.division_id = d.id
            LEFT JOIN batches b ON t.batch_id = b.id
            WHERE t.teacher_id = ? AND t.day_of_week = ?
            ORDER BY t.start_time ASC
            """,
            (teacher["id"], today_day)
        )
        return jsonify({"success": True, "day": today_day, "entries": entries})

    elif user["role"] == "STUDENT":
        student = query_one("SELECT * FROM students WHERE user_id = ?", (user["id"],))
        if not student:
            return jsonify({"success": False, "error": "Student profile not found"}), 404

        entries = query_all(
            """
            SELECT t.*, s.name as subject_name, s.code as subject_code,
                   u.full_name as teacher_name, d.name as division_name, b.name as batch_name,
                   ses.id as active_session_id, ses.status as session_status,
                   rec.status as student_attendance_status
            FROM timetables t
            JOIN subjects s ON t.subject_id = s.id
            JOIN teachers tch ON t.teacher_id = tch.id
            JOIN users u ON tch.user_id = u.id
            JOIN divisions d ON t.division_id = d.id
            LEFT JOIN batches b ON t.batch_id = b.id
            LEFT JOIN attendance_sessions ses ON ses.timetable_id = t.id AND ses.date = date('now') AND ses.status != 'CANCELLED'
            LEFT JOIN attendance_records rec ON rec.session_id = ses.id AND rec.student_id = ?
            WHERE t.division_id = ? AND (t.batch_id IS NULL OR t.batch_id = ?) AND t.day_of_week = ?
            ORDER BY t.start_time ASC
            """,
            (student["id"], student["division_id"], student["batch_id"], today_day)
        )
        return jsonify({"success": True, "day": today_day, "entries": entries})

    else:
        # Admin: view all entries for today
        entries = query_all(
            """
            SELECT t.*, s.name as subject_name, s.code as subject_code,
                   u.full_name as teacher_name, d.name as division_name, b.name as batch_name
            FROM timetables t
            JOIN subjects s ON t.subject_id = s.id
            JOIN teachers tch ON t.teacher_id = tch.id
            JOIN users u ON tch.user_id = u.id
            JOIN divisions d ON t.division_id = d.id
            LEFT JOIN batches b ON t.batch_id = b.id
            WHERE t.day_of_week = ?
            ORDER BY t.start_time ASC
            """,
            (today_day,)
        )
        return jsonify({"success": True, "day": today_day, "entries": entries})

@attendance_bp.route("/session/start", methods=["POST"])
@require_auth(["TEACHER", "ADMIN"])
def start_session():
    """Start an attendance session with rotating QR credentials."""
    data = request.get_json(silent=True) or {}
    user = g.user
    teacher_id = None

    if user["role"] == "TEACHER":
        teacher = query_one("SELECT id FROM teachers WHERE user_id = ?", (user["id"],))
        if not teacher:
            return jsonify({"success": False, "error": "Teacher record not found"}), 404
        teacher_id = teacher["id"]
    else:
        teacher_id = data.get("teacher_id")
        if not teacher_id:
            return jsonify({"success": False, "error": "Teacher ID required for admin session creation"}), 400

    timetable_id = data.get("timetable_id")
    subject_id = data.get("subject_id")
    division_id = data.get("division_id")
    batch_id = data.get("batch_id")
    session_type = str(data.get("session_type", "THEORY")).upper()
    room = str(data.get("room", "Classroom")).strip()
    is_proxy = bool(data.get("is_proxy", False))
    proxy_teacher_id = data.get("proxy_teacher_id")

    # If timetable_id is provided, auto-populate from timetable
    if timetable_id:
        tt = query_one("SELECT * FROM timetables WHERE id = ?", (timetable_id,))
        if tt:
            subject_id = tt["subject_id"]
            division_id = tt["division_id"]
            batch_id = tt["batch_id"]
            session_type = tt["session_type"]
            room = tt["room"]

    if not subject_id or not division_id:
        return jsonify({"success": False, "error": "Subject and division are required"}), 400

    # Authorization check for teacher: verify teacher is assigned to this subject/division
    if user["role"] == "TEACHER" and not is_proxy:
        assigned = query_one(
            """
            SELECT id FROM teacher_assignments
            WHERE teacher_id = ? AND subject_id = ? AND division_id = ?
            """,
            (teacher_id, subject_id, division_id)
        )
        if not assigned and not timetable_id:
            return jsonify({"success": False, "error": "You are not assigned to teach this subject/division"}), 403

    qr_interval = int(data.get("qr_interval_seconds", 30))
    max_rotations = int(data.get("max_qr_rotations", 5))
    date_str = datetime.now().strftime("%Y-%m-%d")

    result = create_attendance_session(
        teacher_id=teacher_id,
        subject_id=subject_id,
        division_id=division_id,
        batch_id=batch_id,
        session_type=session_type,
        room=room,
        date=date_str,
        timetable_id=timetable_id,
        is_proxy=is_proxy,
        proxy_teacher_id=proxy_teacher_id,
        qr_interval_seconds=qr_interval,
        max_qr_rotations=max_rotations
    )

    return jsonify({"success": True, "data": result})

@attendance_bp.route("/session/<int:session_id>/rotate", methods=["POST"])
@require_auth(["TEACHER", "ADMIN"])
def rotate_session_qr(session_id: int):
    """Generate the next rotating QR generation and invalidate the previous one."""
    success, data, msg = rotate_attendance_qr(session_id)
    if not success:
        return jsonify({"success": False, "error": msg, "data": data}), 400
    return jsonify({"success": True, "data": data, "message": msg})

@attendance_bp.route("/session/<int:session_id>/end", methods=["POST"])
@require_auth(["TEACHER", "ADMIN"])
def end_session(session_id: int):
    """Explicitly conclude attendance session and invalidate active QRs."""
    close_attendance_session(session_id)
    log_audit("ATTENDANCE_SESSION_CLOSED", "ATTENDANCE_SESSION", str(session_id), g.user["id"], g.user["full_name"], {}, request.remote_addr)
    return jsonify({"success": True, "message": "Attendance session successfully completed and QRs invalidated"})

@attendance_bp.route("/session/<int:session_id>/live", methods=["GET"])
@require_auth(["TEACHER", "ADMIN"])
def live_session_monitor(session_id: int):
    """Provide real-time attendance statistics and scannable student list for teacher dashboard."""
    session = query_one(
        """
        SELECT ses.*, s.name as subject_name, s.code as subject_code,
               d.name as division_name, b.name as batch_name,
               qg.backup_code as current_backup_code
        FROM attendance_sessions ses
        JOIN subjects s ON ses.subject_id = s.id
        JOIN divisions d ON ses.division_id = d.id
        LEFT JOIN batches b ON ses.batch_id = b.id
        LEFT JOIN qr_generations qg ON qg.session_id = ses.id AND qg.generation_number = ses.current_qr_generation
        WHERE ses.id = ?
        """,
        (session_id,)
    )
    if not session:
        return jsonify({"success": False, "error": "Session not found"}), 404

    # Fetch marked students
    present_students = query_all(
        """
        SELECT ar.id as record_id, ar.status, ar.marked_at, ar.verification_method,
               st.id as student_id, st.enrollment_no, u.full_name, b.name as batch_name
        FROM attendance_records ar
        JOIN students st ON ar.student_id = st.id
        JOIN users u ON st.user_id = u.id
        JOIN batches b ON st.batch_id = b.id
        WHERE ar.session_id = ?
        ORDER BY ar.marked_at DESC
        """,
        (session_id,)
    )

    # Fetch total enrolled students eligible for this session
    batch_filter = "AND s.batch_id = ?" if session["batch_id"] else ""
    params = (session["division_id"], session["batch_id"]) if session["batch_id"] else (session["division_id"],)
    eligible_students = query_all(
        f"""
        SELECT s.id, s.enrollment_no, u.full_name, b.name as batch_name
        FROM students s
        JOIN users u ON s.user_id = u.id
        JOIN batches b ON s.batch_id = b.id
        WHERE s.division_id = ? {batch_filter} AND u.is_active = 1
        ORDER BY s.enrollment_no ASC
        """,
        params
    )

    return jsonify({
        "success": True,
        "session": session,
        "present_count": len(present_students),
        "total_eligible": len(eligible_students),
        "present_students": present_students,
        "eligible_students": eligible_students
    })

@attendance_bp.route("/mark", methods=["POST"])
@require_auth(["STUDENT"])
def mark_attendance():
    """Endpoint for student self-marking via scanned URL token or entered current backup code."""
    data = request.get_json(silent=True) or {}
    user = g.user
    student = query_one("SELECT id FROM students WHERE user_id = ?", (user["id"],))
    if not student:
        return jsonify({"success": False, "error": "Student profile not found"}), 404

    token = data.get("token")
    backup_code = data.get("backup_code")
    session_id = data.get("session_id")

    success, msg, details = record_student_attendance(
        student_id=student["id"],
        token=token,
        backup_code=backup_code,
        session_id=session_id,
        ip_address=request.remote_addr
    )

    if not success:
        return jsonify({"success": False, "error": msg}), 400

    return jsonify({"success": True, "message": msg, "data": details})

@attendance_bp.route("/student/overall", methods=["GET"])
@require_auth(["STUDENT"])
def get_student_overall():
    """Retrieve raw counts and exact calculated percentages for authenticated student."""
    user = g.user
    student = query_one("SELECT id FROM students WHERE user_id = ?", (user["id"],))
    if not student:
        return jsonify({"success": False, "error": "Student profile not found"}), 404

    stats = calculate_student_attendance(student["id"])
    return jsonify({"success": True, "data": stats})

@attendance_bp.route("/student/datewise", methods=["GET"])
@require_auth(["STUDENT"])
def get_student_datewise():
    """Retrieve datewise lecture attendance history."""
    user = g.user
    student = query_one("SELECT * FROM students WHERE user_id = ?", (user["id"],))
    if not student:
        return jsonify({"success": False, "error": "Student profile not found"}), 404

    date_filter = request.args.get("date", datetime.now().strftime("%Y-%m-%d"))

    sessions = query_all(
        """
        SELECT ses.id as session_id, ses.date, ses.session_type, ses.room,
               ses.scheduled_start, ses.scheduled_end, ses.status as session_status,
               sub.name as subject_name, sub.code as subject_code,
               u.full_name as teacher_name,
               COALESCE(ar.status, 'NOT_MARKED') as attendance_status,
               ar.marked_at, ar.verification_method
        FROM attendance_sessions ses
        JOIN subjects sub ON ses.subject_id = sub.id
        JOIN teachers tch ON ses.teacher_id = tch.id
        JOIN users u ON tch.user_id = u.id
        LEFT JOIN attendance_records ar ON ar.session_id = ses.id AND ar.student_id = ?
        WHERE ses.division_id = ? AND (ses.batch_id IS NULL OR ses.batch_id = ?)
          AND ses.date = ? AND ses.status != 'CANCELLED'
        ORDER BY ses.scheduled_start ASC
        """,
        (student["id"], student["division_id"], student["batch_id"], date_filter)
    )

    # Summary for this date
    present_cnt = sum(1 for s in sessions if s["attendance_status"] == "PRESENT")
    absent_cnt = sum(1 for s in sessions if s["attendance_status"] == "ABSENT")
    leave_cnt = sum(1 for s in sessions if s["attendance_status"] == "LEAVE")

    return jsonify({
        "success": True,
        "date": date_filter,
        "summary": {
            "total": len(sessions),
            "present": present_cnt,
            "absent": absent_cnt,
            "leave": leave_cnt
        },
        "sessions": sessions
    })

@attendance_bp.route("/corrections/request", methods=["POST"])
@require_auth(["TEACHER"])
def request_correction():
    """Teacher initiates an attendance correction for an existing session record."""
    data = request.get_json(silent=True) or {}
    teacher = query_one("SELECT id FROM teachers WHERE user_id = ?", (g.user["id"],))
    if not teacher:
        return jsonify({"success": False, "error": "Teacher profile not found"}), 404

    session_id = data.get("session_id")
    student_id = data.get("student_id")
    requested_status = str(data.get("requested_status", "PRESENT")).upper()
    reason = str(data.get("reason", "")).strip()

    if not session_id or not student_id or not reason:
        return jsonify({"success": False, "error": "Session, student, and reason are required"}), 400

    rec = query_one("SELECT status FROM attendance_records WHERE session_id = ? AND student_id = ?", (session_id, student_id))
    prev_status = rec["status"] if rec else "NOT_MARKED"

    corr_id = execute_query(
        """
        INSERT INTO attendance_corrections (session_id, student_id, requested_by_teacher_id, previous_status, requested_status, reason, status)
        VALUES (?, ?, ?, ?, ?, ?, 'PENDING')
        """,
        (session_id, student_id, teacher["id"], prev_status, requested_status, reason)
    )

    log_audit("ATTENDANCE_CORRECTION_REQUESTED", "ATTENDANCE_CORRECTION", str(corr_id), g.user["id"], g.user["full_name"], {
        "session_id": session_id, "student_id": student_id, "from": prev_status, "to": requested_status, "reason": reason
    }, request.remote_addr)

    return jsonify({"success": True, "message": "Correction request submitted for administrator review", "correction_id": corr_id})

@attendance_bp.route("/corrections", methods=["GET"])
@require_auth(["ADMIN"])
def list_corrections():
    """Administrator lists attendance correction requests."""
    corrections = query_all(
        """
        SELECT ac.*, u_tea.full_name as teacher_name, u_stu.full_name as student_name,
               st.enrollment_no, sub.code as subject_code, sub.name as subject_name,
               ses.date, ses.session_type
        FROM attendance_corrections ac
        JOIN teachers t ON ac.requested_by_teacher_id = t.id
        JOIN users u_tea ON t.user_id = u_tea.id
        JOIN students st ON ac.student_id = st.id
        JOIN users u_stu ON st.user_id = u_stu.id
        JOIN attendance_sessions ses ON ac.session_id = ses.id
        JOIN subjects sub ON ses.subject_id = sub.id
        ORDER BY ac.created_at DESC
        """
    )
    return jsonify({"success": True, "corrections": corrections})

@attendance_bp.route("/corrections/<int:corr_id>/review", methods=["POST"])
@require_auth(["ADMIN"])
def review_correction(corr_id: int):
    """Administrator approves or rejects an attendance correction request."""
    data = request.get_json(silent=True) or {}
    decision = str(data.get("decision", "")).upper() # 'APPROVE' or 'REJECT'

    corr = query_one("SELECT * FROM attendance_corrections WHERE id = ?", (corr_id,))
    if not corr:
        return jsonify({"success": False, "error": "Correction request not found"}), 404

    if corr["status"] != "PENDING":
        return jsonify({"success": False, "error": f"Correction already reviewed with status: {corr['status']}"}), 400

    new_status = "APPROVED" if decision == "APPROVE" else "REJECTED"

    execute_query(
        """
        UPDATE attendance_corrections
        SET status = ?, reviewed_by_admin_id = ?, reviewed_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (new_status, g.user["id"], corr_id)
    )

    if new_status == "APPROVED":
        # Upsert into attendance_records
        existing = query_one("SELECT id FROM attendance_records WHERE session_id = ? AND student_id = ?", (corr["session_id"], corr["student_id"]))
        if existing:
            execute_query(
                "UPDATE attendance_records SET status = ?, verification_method = 'CORRECTION' WHERE id = ?",
                (corr["requested_status"], existing["id"])
            )
        else:
            execute_query(
                "INSERT INTO attendance_records (session_id, student_id, status, verification_method) VALUES (?, ?, ?, 'CORRECTION')",
                (corr["session_id"], corr["student_id"], corr["requested_status"])
            )

    log_audit("ATTENDANCE_CORRECTION_REVIEWED", "ATTENDANCE_CORRECTION", str(corr_id), g.user["id"], g.user["full_name"], {
        "decision": new_status, "session_id": corr["session_id"], "student_id": corr["student_id"]
    }, request.remote_addr)

    return jsonify({"success": True, "message": f"Correction request successfully {new_status.lower()}."})
