// QUIZIFY CLIENT API INTERFACE
const API = {
  getToken() {
    return localStorage.getItem("quizify_jwt_token");
  },

  setToken(token) {
    if (token) {
      localStorage.setItem("quizify_jwt_token", token);
    } else {
      localStorage.removeItem("quizify_jwt_token");
    }
  },

  getCurrentUser() {
    try {
      const data = localStorage.getItem("quizify_user_profile");
      return data ? JSON.parse(data) : null;
    } catch {
      return null;
    }
  },

  setCurrentUser(user) {
    if (user) {
      localStorage.setItem("quizify_user_profile", JSON.stringify(user));
    } else {
      localStorage.removeItem("quizify_user_profile");
    }
  },

  clearSession() {
    localStorage.removeItem("quizify_jwt_token");
    localStorage.removeItem("quizify_user_profile");
  },

  async request(endpoint, options = {}) {
    const url = endpoint.startsWith("http") ? endpoint : `/api${endpoint.startsWith("/") ? "" : "/"}${endpoint}`;
    const headers = options.headers || {};

    const token = this.getToken();
    if (token) {
      headers["Authorization"] = `Bearer ${token}`;
    }

    if (!(options.body instanceof FormData) && !headers["Content-Type"]) {
      headers["Content-Type"] = "application/json";
    }

    try {
      const res = await fetch(url, { ...options, headers });
      
      if (res.status === 401) {
        // Token expired or invalid
        this.clearSession();
        window.dispatchEvent(new CustomEvent("quizify:unauthorized"));
        throw new Error("Your session has expired. Please log in again.");
      }

      // Check if response is JSON or binary file download
      const contentType = res.headers.get("content-type") || "";
      if (contentType.includes("application/json")) {
        const data = await res.json();
        if (!res.ok || data.success === false) {
          throw new Error(data.error || "An error occurred while communicating with the server.");
        }
        return data;
      } else {
        // Blob / file stream
        if (!res.ok) throw new Error("File export failed on server.");
        return await res.blob();
      }
    } catch (err) {
      console.error(`[API Request Error] ${url}:`, err);
      throw err;
    }
  },

  get(endpoint, params = null) {
    let url = endpoint;
    if (params) {
      const qs = new URLSearchParams(params).toString();
      url += (url.includes("?") ? "&" : "?") + qs;
    }
    return this.request(url, { method: "GET" });
  },

  post(endpoint, data = {}) {
    return this.request(endpoint, {
      method: "POST",
      body: JSON.stringify(data)
    });
  },

  postForm(endpoint, formData) {
    return this.request(endpoint, {
      method: "POST",
      body: formData
    });
  },

  delete(endpoint, params = null) {
    let url = endpoint;
    if (params) {
      const qs = new URLSearchParams(params).toString();
      url += (url.includes("?") ? "&" : "?") + qs;
    }
    return this.request(url, { method: "DELETE" });
  }
};
