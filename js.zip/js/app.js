// QUIZIFY MASTER CLIENT APPLICATION CONTROLLER
const App = {
  user: null,
  currentRoute: "dashboard",
  routeParams: {},
  liveAttendanceInterval: null,
  examTimerInterval: null,
  examState: null,

  init() {
    this.user = API.getCurrentUser();
    this.bindGlobalEvents();
    this.handleRouting();
    window.addEventListener("hashchange", () => this.handleRouting());
    window.addEventListener("quizify:unauthorized", () => {
      this.user = null;
      this.navigate("login");
    });
  },

  bindGlobalEvents() {
    // Mobile Drawer Toggle
    document.addEventListener("click", (e) => {
      if (e.target.closest("#menuToggleBtn")) {
        document.querySelector(".app-sidebar")?.classList.toggle("open");
        document.querySelector(".sidebar-overlay")?.classList.toggle("active");
      } else if (e.target.closest(".sidebar-overlay") || (e.target.closest(".nav-item") && window.innerWidth <= 768)) {
        document.querySelector(".app-sidebar")?.classList.remove("open");
        document.querySelector(".sidebar-overlay")?.classList.remove("active");
      }
    });

    // Anti-Cheating Tab Switch & Window Blur Detection
    document.addEventListener("visibilitychange", () => {
      if (document.hidden && this.examState && this.examState.status === "IN_PROGRESS") {
        this.reportExamViolation("TAB_SWITCH_OR_MINIMIZE");
      }
    });

    window.addEventListener("blur", () => {
      if (this.examState && this.examState.status === "IN_PROGRESS") {
        this.reportExamViolation("WINDOW_FOCUS_LOST");
      }
    });
  },

  navigate(route, params = {}) {
    this.routeParams = params;
    let hash = `#${route}`;
    if (Object.keys(params).length > 0) {
      const qs = new URLSearchParams(params).toString();
      hash += `?${qs}`;
    }
    window.location.hash = hash;
  },

  handleRouting() {
    const rawHash = window.location.hash.slice(1) || "dashboard";
    const [route, queryString] = rawHash.split("?");
    const params = {};
    if (queryString) {
      new URLSearchParams(queryString).forEach((val, key) => { params[key] = val; });
    }
    this.currentRoute = route;
    this.routeParams = params;

    // Direct QR Code Scan Handling (from Google Lens or Camera)
    if (route === "join-quiz" && params.token) {
      if (!this.user) {
        sessionStorage.setItem("quizify_redirect_after_login", window.location.hash);
        this.renderLoginView();
        return;
      }
      this.handleDirectQuizJoin(params.token);
      return;
    }

    if ((route === "mark-attendance" || route === "join-attendance") && params.token) {
      if (!this.user) {
        sessionStorage.setItem("quizify_redirect_after_login", window.location.hash);
        this.renderLoginView();
        return;
      }
      this.handleDirectAttendanceMark(params.token);
      return;
    }

    // Auth gating
    if (!this.user && !["login", "forgot-password", "reset-password"].includes(route)) {
      this.renderLoginView();
      return;
    }

    // Role-specific routing
    this.renderAppShell();
    this.renderRouteView(route, params);
  },

  // ----------------------------------------------------
  // APP SHELL (Sidebar + Navbar + Dynamic Container)
  // ----------------------------------------------------
  renderAppShell() {
    const root = document.getElementById("app");
    if (!root) return;

    if (!this.user) return; // Shell only for authenticated states

    // If shell not already in DOM
    if (!document.querySelector(".app-sidebar")) {
      root.innerHTML = `
        <div class="sidebar-overlay"></div>
        <aside class="app-sidebar">
          <div class="sidebar-header">
            <div style="display:flex; align-items:center; gap:8px;">
              <img src="/static/favicon.svg" alt="Quizify" width="32" height="32">
              <span style="font-family:var(--font-display); font-weight:800; font-size:1.3rem; letter-spacing:-0.5px;">QUIZ<span style="color:var(--primary)">IFY</span></span>
            </div>
          </div>
          <nav class="sidebar-nav" id="sidebarNav"></nav>
          <div class="sidebar-footer">
            <div class="user-snippet">
              <div class="avatar">${this.user.full_name ? this.user.full_name[0].toUpperCase() : 'U'}</div>
              <div class="user-info">
                <span class="user-name">${this.user.full_name || 'Academic User'}</span>
                <span class="user-role-badge">${this.user.role}</span>
              </div>
            </div>
            <button class="btn btn-secondary btn-icon" id="logoutBtn" title="Sign Out">
              <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
            </button>
          </div>
        </aside>

        <main class="app-main">
          <header class="app-navbar">
            <div style="display:flex; align-items:center; gap:16px;">
              <button class="menu-toggle-btn" id="menuToggleBtn">&#9776;</button>
              <h2 id="pageTitle" style="font-size:1.25rem;">Dashboard</h2>
            </div>
            <div class="navbar-actions">
              <button class="btn btn-secondary btn-icon" id="themeToggleBtn" title="Toggle Theme">
                <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="5"></circle><path d="M12 1v2m0 18v2M4.22 4.22l1.42 1.42m12.72 12.72l1.42 1.42M1 12h2m18 0h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"></path></svg>
              </button>
              <button class="btn btn-secondary btn-icon" id="settingsBtn" title="Appearance Settings">
                <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>
              </button>
            </div>
          </header>
          <div class="page-container" id="pageContent"></div>
        </main>
      `;

      document.getElementById("logoutBtn")?.addEventListener("click", () => this.handleLogout());
      document.getElementById("themeToggleBtn")?.addEventListener("click", () => ThemeManager.toggleTheme());
      document.getElementById("settingsBtn")?.addEventListener("click", () => this.navigate("settings"));
    }

    this.renderSidebarItems();
  },

  renderSidebarItems() {
    const nav = document.getElementById("sidebarNav");
    if (!nav) return;

    let items = [];
    const r = this.user.role;

    if (r === "ADMIN") {
      items = [
        { label: "Dashboard", route: "dashboard", icon: "📊" },
        { label: "Faculty Management", route: "admin-teachers", icon: "👨‍🏫" },
        { label: "Student Roster", route: "admin-students", icon: "🎓" },
        { label: "Timetable Schedule", route: "admin-timetable", icon: "📅" },
        { label: "Attendance Overview", route: "admin-attendance", icon: "📋" },
        { label: "All Quizzes", route: "quizzes", icon: "📝" },
        { label: "Security & Audit Logs", route: "admin-audit", icon: "🛡️" },
        { label: "Platform Settings", route: "settings", icon: "⚙️" }
      ];
    } else if (r === "TEACHER") {
      items = [
        { label: "Dashboard", route: "dashboard", icon: "📊" },
        { label: "Today's Schedule", route: "timetable", icon: "📅" },
        { label: "Start Attendance (QR)", route: "attendance", icon: "📲" },
        { label: "Examinations & Quizzes", route: "quizzes", icon: "📝" },
        { label: "Create AI Quiz", route: "create-quiz", icon: "✨" },
        { label: "Student Records", route: "admin-students", icon: "👥" },
        { label: "AI Faculty Assistant", route: "ai-doubt", icon: "💡" },
        { label: "Settings", route: "settings", icon: "⚙️" }
      ];
    } else if (r === "STUDENT") {
      items = [
        { label: "Dashboard", route: "dashboard", icon: "📊" },
        { label: "Mark Attendance", route: "attendance", icon: "📷" },
        { label: "Datewise Attendance", route: "attendance-datewise", icon: "📅" },
        { label: "Overall Attendance", route: "attendance-overall", icon: "📈" },
        { label: "Examinations", route: "quizzes", icon: "📝" },
        { label: "AI Academic Tutor", route: "ai-doubt", icon: "🤖" },
        { label: "Profile & Settings", route: "settings", icon: "⚙️" }
      ];
    }

    nav.innerHTML = items.map(item => `
      <div class="nav-item ${this.currentRoute === item.route ? 'active' : ''}" onclick="App.navigate('${item.route}')">
        <span class="icon">${item.icon}</span>
        <span>${item.label}</span>
      </div>
    `).join("");
  },

  // ----------------------------------------------------
  // ROUTE DISPATCHER
  // ----------------------------------------------------
  renderRouteView(route, params) {
    const content = document.getElementById("pageContent");
    const titleEl = document.getElementById("pageTitle");
    if (!content) return;

    // Clear live timers if moving away from exam or attendance
    if (route !== "quiz-hud") clearInterval(this.examTimerInterval);
    if (route !== "attendance") clearInterval(this.liveAttendanceInterval);

    switch (route) {
      case "dashboard":
        titleEl.textContent = "Academic Dashboard";
        this.renderDashboardView();
        break;
      case "timetable":
        titleEl.textContent = "Schedule & Lectures";
        this.renderTimetableView();
        break;
      case "attendance":
        titleEl.textContent = this.user.role === "STUDENT" ? "Mark Classroom Attendance" : "Rotating QR Attendance Session";
        this.renderAttendanceView();
        break;
      case "attendance-datewise":
        titleEl.textContent = "Datewise Attendance Roster";
        this.renderStudentDatewiseView();
        break;
      case "attendance-overall":
        titleEl.textContent = "Subjectwise Attendance Calculation";
        this.renderStudentOverallView();
        break;
      case "quizzes":
        titleEl.textContent = "Examinations & Quizzes";
        this.renderQuizzesListView();
        break;
      case "create-quiz":
        titleEl.textContent = "AI Quiz Generator & Question Editor";
        this.renderCreateQuizView();
        break;
      case "quiz-hud":
        titleEl.textContent = "Live Examination";
        this.renderQuizHudView(params.attempt_id);
        break;
      case "quiz-result":
        titleEl.textContent = "Examination Performance Report";
        this.renderQuizResultView(params.attempt_id);
        break;
      case "ai-doubt":
        titleEl.textContent = this.user.role === "STUDENT" ? "AI Doubt Solver" : "AI Faculty Assistant";
        this.renderAiDoubtView();
        break;
      case "admin-teachers":
        titleEl.textContent = "Faculty Directory & Assignments";
        this.renderAdminTeachersView();
        break;
      case "admin-students":
        titleEl.textContent = "Student Roster & Enrollments";
        this.renderAdminStudentsView();
        break;
      case "admin-timetable":
        titleEl.textContent = "Timetable Management";
        this.renderAdminTimetableView();
        break;
      case "admin-attendance":
        titleEl.textContent = "Attendance Policies & Corrections";
        this.renderAdminAttendanceView();
        break;
      case "admin-audit":
        titleEl.textContent = "Security Audit Trails";
        this.renderAdminAuditView();
        break;
      case "settings":
        titleEl.textContent = "System & Appearance Settings";
        this.renderSettingsView();
        break;
      default:
        this.renderDashboardView();
    }
  },

  // ----------------------------------------------------
  // AUTHENTICATION VIEWS
  // ----------------------------------------------------
  renderLoginView() {
    const root = document.getElementById("app");
    root.innerHTML = `
      <div class="login-wrapper">
        <div class="login-card">
          <div class="login-header">
            <div class="login-brand">
              <img src="/static/favicon.svg" width="40" height="40" alt="Quizify">
              <h1 style="font-size:2rem;">QUIZ<span style="color:var(--primary);">IFY</span></h1>
            </div>
            <p class="login-subtitle">Autonomous Academic Examination & Attendance Platform</p>
          </div>

          <div class="role-pill-selector">
            <div class="role-pill active" data-role="STUDENT">Student</div>
            <div class="role-pill" data-role="TEACHER">Faculty</div>
            <div class="role-pill" data-role="ADMIN">Admin</div>
          </div>

          <form id="loginForm">
            <div class="form-group">
              <label class="form-label" id="identifierLabel">Enrollment Number</label>
              <input type="text" class="form-input" id="loginIdentifier" placeholder="e.g. STU2026001" required autocomplete="username">
            </div>

            <div class="form-group">
              <div style="display:flex; justify-content:space-between; align-items:center;">
                <label class="form-label">Password</label>
                <a href="#forgot-password" style="font-size:0.8rem; font-weight:600;">Forgot Password?</a>
              </div>
              <div style="position:relative;">
                <input type="password" class="form-input" id="loginPassword" placeholder="••••••••" required autocomplete="current-password" style="padding-right:40px;">
                <button type="button" id="toggleLoginPassword" style="position:absolute; right:10px; top:50%; transform:translateY(-50%); background:none; border:none; cursor:pointer; color:var(--text-muted); padding:4px;" title="Show/Hide Password" aria-label="Toggle password visibility">👁</button>
              </div>
            </div>

            <div id="loginError" style="color:var(--danger); font-size:0.85rem; margin-bottom:14px; display:none;"></div>

            <button type="submit" class="btn btn-primary" style="width:100%; margin-top:8px;" id="loginSubmitBtn">
              Sign In to Platform
            </button>
          </form>
        </div>
      </div>
    `;

    // Role pill toggles helper text
    const pills = document.querySelectorAll(".role-pill");
    const idLabel = document.getElementById("identifierLabel");
    const idInput = document.getElementById("loginIdentifier");

    pills.forEach(pill => {
      pill.addEventListener("click", () => {
        pills.forEach(p => p.classList.remove("active"));
        pill.classList.add("active");
        const role = pill.dataset.role;
        if (role === "STUDENT") {
          idLabel.textContent = "Enrollment Number / Email";
          idInput.placeholder = "e.g. STU2026001";
        } else if (role === "TEACHER") {
          idLabel.textContent = "Teacher Login ID / Email";
          idInput.placeholder = "e.g. TCH101";
        } else {
          idLabel.textContent = "Administrator Identifier";
          idInput.placeholder = "e.g. admin";
        }
      });
    });

    const toggleLoginPw = document.getElementById("toggleLoginPassword");
    if (toggleLoginPw) {
      toggleLoginPw.addEventListener("click", () => {
        const inp = document.getElementById("loginPassword");
        if (inp) {
          inp.type = inp.type === "password" ? "text" : "password";
        }
      });
    }

    document.getElementById("loginForm").addEventListener("submit", async (e) => {
      e.preventDefault();
      const errBox = document.getElementById("loginError");
      const submitBtn = document.getElementById("loginSubmitBtn");
      errBox.style.display = "none";
      submitBtn.disabled = true;
      submitBtn.innerHTML = `<span class="spinner"></span> Verifying Credentials...`;

      try {
        const identifier = idInput.value.trim();
        const password = document.getElementById("loginPassword").value.trim();

        const res = await API.post("/auth/login", { identifier, password });
        API.setToken(res.token);
        API.setCurrentUser(res.user);
        this.user = res.user;

        // Redirect check
        const pendingRedirect = sessionStorage.getItem("quizify_redirect_after_login");
        if (pendingRedirect) {
          sessionStorage.removeItem("quizify_redirect_after_login");
          window.location.hash = pendingRedirect;
        } else {
          this.navigate("dashboard");
        }
      } catch (err) {
        errBox.textContent = err.message;
        errBox.style.display = "block";
      } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = "Sign In to Platform";
      }
    });
  },

  handleLogout() {
    API.clearSession();
    this.user = null;
    this.navigate("login");
  },

  // ----------------------------------------------------
  // DASHBOARD VIEW
  // ----------------------------------------------------
  async renderDashboardView() {
    const container = document.getElementById("pageContent");
    const r = this.user.role;

    if (r === "ADMIN") {
      try {
        const res = await API.get("/admin/stats");
        const c = res.counts;
        container.innerHTML = `
          <div class="grid grid-4" style="margin-bottom:28px;">
            <div class="card">
              <div class="card-subtitle">Active Faculty</div>
              <div style="font-size:2rem; font-weight:800; color:var(--primary);">${c.teachers}</div>
            </div>
            <div class="card">
              <div class="card-subtitle">Enrolled Students</div>
              <div style="font-size:2rem; font-weight:800; color:var(--primary);">${c.students}</div>
            </div>
            <div class="card">
              <div class="card-subtitle">Active Quizzes</div>
              <div style="font-size:2rem; font-weight:800; color:var(--warning);">${c.active_quizzes}</div>
            </div>
            <div class="card">
              <div class="card-subtitle">Attendance Sessions</div>
              <div style="font-size:2rem; font-weight:800; color:var(--success);">${c.attendance_sessions}</div>
            </div>
          </div>

          <div class="grid grid-2">
            <div class="card">
              <div class="card-header">
                <div>
                  <div class="card-title">Recent Audit Trails</div>
                  <div class="card-subtitle">Cryptographic security activity log</div>
                </div>
                <button class="btn btn-secondary" onclick="App.navigate('admin-audit')">View All</button>
              </div>
              <div class="table-responsive">
                <table class="table">
                  <thead>
                    <tr><th>Action</th><th>Actor</th><th>Time</th></tr>
                  </thead>
                  <tbody>
                    ${res.recent_logs.map(l => `
                      <tr>
                        <td><span class="badge badge-primary">${l.action}</span></td>
                        <td>${l.actor_name || 'System'}</td>
                        <td style="font-size:0.8rem; color:var(--text-muted);">${l.created_at}</td>
                      </tr>
                    `).join('')}
                  </tbody>
                </table>
              </div>
            </div>

            <div class="card">
              <div class="card-header">
                <div class="card-title">Quick Administrative Actions</div>
              </div>
              <div style="display:flex; flex-direction:column; gap:12px;">
                <button class="btn btn-secondary" onclick="App.navigate('admin-teachers')">👨‍🏫 Register Faculty & Assign Batches</button>
                <button class="btn btn-secondary" onclick="App.navigate('admin-students')">🎓 Enroll Student & Allocate Division</button>
                <button class="btn btn-secondary" onclick="App.navigate('admin-timetable')">📅 Schedule Lecture in Timetable</button>
                <button class="btn btn-secondary" onclick="App.navigate('admin-attendance')">📋 Review Attendance Corrections</button>
              </div>
            </div>
          </div>
        `;
      } catch (err) {
        container.innerHTML = `<div class="card"><p style="color:var(--danger);">${err.message}</p></div>`;
      }
    } else if (r === "TEACHER") {
      try {
        const tt = await API.get("/attendance/timetable/today");
        container.innerHTML = `
          <div class="card" style="margin-bottom:24px;">
            <div class="card-header">
              <div>
                <h3 class="card-title">Today's Schedule (${tt.day})</h3>
                <div class="card-subtitle">Automatic synchronized schedule for your assigned courses</div>
              </div>
              <button class="btn btn-secondary" onclick="App.openProxyAttendanceModal()">+ Proxy Attendance</button>
            </div>
            <div class="table-responsive">
              <table class="table">
                <thead>
                  <tr><th>Time</th><th>Subject</th><th>Type</th><th>Division & Batch</th><th>Room</th><th>Action</th></tr>
                </thead>
                <tbody>
                  ${tt.entries.length === 0 ? `<tr><td colspan="6" style="text-align:center; color:var(--text-muted);">No scheduled lectures for today.</td></tr>` : 
                    tt.entries.map(e => `
                      <tr>
                        <td><strong>${e.start_time} – ${e.end_time}</strong></td>
                        <td>${e.subject_name} (${e.subject_code})</td>
                        <td><span class="badge ${e.session_type === 'THEORY' ? 'badge-primary' : 'badge-warning'}">${e.session_type}</span></td>
                        <td>Div ${e.division_name} ${e.batch_name ? `(Batch ${e.batch_name})` : '(All Batches)'}</td>
                        <td>${e.room}</td>
                        <td>
                          <button class="btn btn-primary" style="padding:6px 12px; font-size:0.8rem;" onclick="App.startAttendanceFromTimetable(${e.id})">
                            Start Attendance
                          </button>
                        </td>
                      </tr>
                    `).join('')
                  }
                </tbody>
              </table>
            </div>
          </div>

          <div class="grid grid-2">
            <div class="card">
              <div class="card-header">
                <div class="card-title">Examination Engine</div>
              </div>
              <p style="color:var(--text-secondary); margin-bottom:18px;">
                Generate customized academic quizzes with exact MCQ, Numerical, and Subjective question distributions using real AI models.
              </p>
              <button class="btn btn-primary" onclick="App.navigate('create-quiz')">✨ Launch AI Quiz Generator</button>
            </div>

            <div class="card">
              <div class="card-header">
                <div class="card-title">Live Attendance Sessions</div>
              </div>
              <p style="color:var(--text-secondary); margin-bottom:18px;">
                Display full-screen rotating QR codes with authoritatively controlled countdown timers.
              </p>
              <button class="btn btn-secondary" onclick="App.navigate('attendance')">Open Attendance HUD</button>
            </div>
          </div>
        `;
      } catch (err) {
        container.innerHTML = `<div class="card"><p style="color:var(--danger);">${err.message}</p></div>`;
      }
    } else if (r === "STUDENT") {
      try {
        const tt = await API.get("/attendance/timetable/today");
        const overall = await API.get("/attendance/student/overall");
        const ovSum = overall.data.overall_summary;

        container.innerHTML = `
          <div class="grid grid-3" style="margin-bottom:24px;">
            <div class="card">
              <div class="card-subtitle">Overall Attendance</div>
              <div style="font-size:2.2rem; font-weight:800; color:var(--primary);">${ovSum.percentage}%</div>
              <div style="font-size:0.8rem; color:var(--text-muted);">${ovSum.present} Present / ${ovSum.total} Total Lectures</div>
            </div>
            <div class="card">
              <div class="card-subtitle">Theory Ratio</div>
              <div style="font-size:1.8rem; font-weight:700;">${overall.data.theory_summary.percentage}%</div>
              <div style="font-size:0.8rem; color:var(--text-muted);">${overall.data.theory_summary.present}/${overall.data.theory_summary.total} Attended</div>
            </div>
            <div class="card">
              <div class="card-subtitle">Practical / Lab Ratio</div>
              <div style="font-size:1.8rem; font-weight:700;">${overall.data.practical_summary.percentage}%</div>
              <div style="font-size:0.8rem; color:var(--text-muted);">${overall.data.practical_summary.present}/${overall.data.practical_summary.total} Attended</div>
            </div>
          </div>

          <div class="card" style="margin-bottom:24px;">
            <div class="card-header">
              <div class="card-title">Today's Lectures (${tt.day})</div>
              <button class="btn btn-primary" onclick="App.openCameraScannerModal()">📷 Scan Attendance QR</button>
            </div>
            <div class="table-responsive">
              <table class="table">
                <thead>
                  <tr><th>Time</th><th>Subject</th><th>Faculty</th><th>Room</th><th>Status</th><th>Action</th></tr>
                </thead>
                <tbody>
                  ${tt.entries.length === 0 ? `<tr><td colspan="6" style="text-align:center; color:var(--text-muted);">No classes scheduled today.</td></tr>` :
                    tt.entries.map(e => `
                      <tr>
                        <td><strong>${e.start_time} – ${e.end_time}</strong></td>
                        <td>${e.subject_name} (${e.subject_code})</td>
                        <td>${e.teacher_name}</td>
                        <td>${e.room}</td>
                        <td>
                          ${e.student_attendance_status === 'PRESENT' ? `<span class="badge badge-success">✓ PRESENT</span>` :
                            (e.is_session_active ? `<span class="badge badge-warning">SESSION ACTIVE</span>` : `<span class="badge badge-neutral">NOT MARKED</span>`)}
                        </td>
                        <td>
                          ${e.student_attendance_status === 'PRESENT' ? `<span style="font-size:0.8rem; color:var(--success);">Recorded</span>` :
                            `<button class="btn btn-primary" style="padding:6px 12px; font-size:0.8rem;" onclick="App.openCameraScannerModal()">Mark Now</button>`}
                        </td>
                      </tr>
                    `).join('')
                  }
                </tbody>
              </table>
            </div>
          </div>

          <div class="card">
            <div class="card-header">
              <div class="card-title">Scheduled Academic Examinations</div>
              <button class="btn btn-secondary" onclick="App.navigate('quizzes')">View All</button>
            </div>
            <p style="color:var(--text-secondary); margin-bottom:14px;">
              Access active quizzes via Google Lens QR scan or enter your exam code. Server enforces division, batch, and attendance prerequisite checks.
            </p>
            <div style="display:flex; gap:12px; max-width:400px;">
              <input type="text" class="form-input" id="dashQuizCode" placeholder="Enter Quiz Code (e.g. QZ-2026-CEP1)">
              <button class="btn btn-primary" onclick="App.verifyQuizCode(document.getElementById('dashQuizCode').value)">Enter</button>
            </div>
          </div>
        `;
      } catch (err) {
        container.innerHTML = `<div class="card"><p style="color:var(--danger);">${err.message}</p></div>`;
      }
    }
  },

  // ----------------------------------------------------
  // ROTATING QR ATTENDANCE VIEW (Teacher Display)
  // ----------------------------------------------------
  async renderAttendanceView() {
    const container = document.getElementById("pageContent");

    if (this.user.role === "STUDENT") {
      // Student Attendance Self-Mark Interface
      container.innerHTML = `
        <div class="card" style="max-width:540px; margin:0 auto;">
          <div class="card-header">
            <div>
              <div class="card-title">Mark Classroom Attendance</div>
              <div class="card-subtitle">Scan teacher's active rotating QR or enter 6-digit code</div>
            </div>
          </div>

          <div style="display:flex; flex-direction:column; gap:16px;">
            <button class="btn btn-primary" style="padding:16px;" onclick="App.openCameraScannerModal()">
              📷 Open In-Browser Camera Scanner
            </button>

            <div style="text-align:center; color:var(--text-muted); font-size:0.85rem;">— OR ENTER SESSION CODE —</div>

            <div class="form-group">
              <label class="form-label">Attendance Session ID</label>
              <input type="number" class="form-input" id="markSessionId" placeholder="e.g. 1">
            </div>

            <div class="form-group">
              <label class="form-label">Active 6-Digit Backup Code</label>
              <input type="text" class="form-input" id="markBackupCode" placeholder="e.g. 482910" maxlength="6" style="font-family:var(--font-mono); font-size:1.2rem; letter-spacing:0.15em;">
            </div>

            <div id="markAttError" style="color:var(--danger); font-size:0.85rem; display:none;"></div>
            <div id="markAttSuccess" style="display:none;" class="badge badge-success">✓ Attendance Successfully Recorded!</div>

            <button class="btn btn-secondary" onclick="App.submitAttendanceCode()">Submit Backup Code</button>
          </div>
        </div>
      `;
      return;
    }

    // Teacher Attendance Display
    container.innerHTML = `
      <div class="card" style="margin-bottom:24px;">
        <div class="card-header">
          <div>
            <div class="card-title">Start New Attendance Session</div>
            <div class="card-subtitle">Configure rotating QR parameters and validity intervals</div>
          </div>
        </div>
        <form id="startAttForm" class="grid grid-3">
          <div class="form-group">
            <label class="form-label">Select Subject</label>
            <select class="form-select" id="attSubjectSelect" required></select>
          </div>
          <div class="form-group">
            <label class="form-label">Select Division</label>
            <select class="form-select" id="attDivisionSelect" required></select>
          </div>
          <div class="form-group">
            <label class="form-label">Batch (Optional for Theory)</label>
            <select class="form-select" id="attBatchSelect">
              <option value="">All Division Batches</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Session Type</label>
            <select class="form-select" id="attSessionType">
              <option value="THEORY">Theory Lecture</option>
              <option value="PRACTICAL">Practical / Lab</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">QR Validity Interval</label>
            <select class="form-select" id="attQrInterval">
              <option value="15">15 Seconds</option>
              <option value="30" selected>30 Seconds</option>
              <option value="45">45 Seconds</option>
              <option value="60">60 Seconds</option>
              <option value="120">2 Minutes</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Max Rotations</label>
            <select class="form-select" id="attMaxRotations">
              <option value="3">3 Rotations</option>
              <option value="5" selected>5 Rotations</option>
              <option value="10">10 Rotations</option>
              <option value="20">20 Rotations</option>
            </select>
          </div>
          <div style="grid-column: 1 / -1;">
            <button type="submit" class="btn btn-primary" style="padding:12px 24px;">🚀 Launch Rotating QR Session</button>
          </div>
        </form>
      </div>

      <div id="liveAttendanceDisplay"></div>
    `;

    this.populateAcademicDropdowns("attSubjectSelect", "attDivisionSelect", "attBatchSelect");

    document.getElementById("startAttForm").addEventListener("submit", async (e) => {
      e.preventDefault();
      const subject_id = document.getElementById("attSubjectSelect").value;
      const division_id = document.getElementById("attDivisionSelect").value;
      const batch_id = document.getElementById("attBatchSelect").value || null;
      const session_type = document.getElementById("attSessionType").value;
      const qr_interval_seconds = parseInt(document.getElementById("attQrInterval").value);
      const max_qr_rotations = parseInt(document.getElementById("attMaxRotations").value);

      try {
        const res = await API.post("/attendance/session/start", {
          subject_id, division_id, batch_id, session_type, qr_interval_seconds, max_qr_rotations
        });
        this.renderLiveTeacherQrScreen(res.data);
      } catch (err) {
        alert(err.message);
      }
    });
  },

  async startAttendanceFromTimetable(timetableId) {
    try {
      const res = await API.post("/attendance/session/start", { timetable_id: timetableId });
      this.navigate("attendance");
      setTimeout(() => this.renderLiveTeacherQrScreen(res.data), 100);
    } catch (err) {
      alert("Error starting attendance: " + err.message);
    }
  },

  renderLiveTeacherQrScreen(sessionData) {
    const disp = document.getElementById("liveAttendanceDisplay");
    if (!disp) return;

    disp.innerHTML = `
      <div class="card qr-display-container">
        <div style="display:flex; justify-content:space-between; width:100%; margin-bottom:16px;">
          <div>
            <h2 style="color:var(--primary);">Session #${sessionData.session_id} Active</h2>
            <div style="color:var(--text-muted); font-size:0.85rem;">Display on Projector or Screen for Classroom</div>
          </div>
          <div style="display:flex; gap:10px;">
            <button class="btn btn-secondary" onclick="App.manuallyRotateQr(${sessionData.session_id})">Rotate QR Now</button>
            <button class="btn btn-danger" onclick="App.endAttendanceSession(${sessionData.session_id})">End Session</button>
          </div>
        </div>

        <div class="qr-box">
          <img id="activeQrImage" src="${sessionData.qr_image}" alt="Attendance QR">
        </div>

        <div style="display:flex; align-items:center; gap:20px; flex-wrap:wrap; justify-content:center;">
          <div>
            <span style="font-size:0.85rem; color:var(--text-muted);">CURRENT GENERATION</span>
            <div style="font-size:1.6rem; font-weight:800;" id="qrGenCounter">#${sessionData.generation} of ${sessionData.max_rotations}</div>
          </div>
          <div>
            <span style="font-size:0.85rem; color:var(--text-muted);">EXPIRES IN</span>
            <div style="font-size:1.6rem; font-weight:800; color:var(--warning);" id="qrSecCounter">${sessionData.expires_in_seconds}s</div>
          </div>
          <div>
            <span style="font-size:0.85rem; color:var(--text-muted);">ACTIVE BACKUP CODE</span>
            <div class="backup-code-pill" id="qrBackupCodePill">${sessionData.backup_code}</div>
          </div>
        </div>

        <div style="margin-top:20px; font-size:0.85rem; color:var(--text-secondary); word-break:break-all;">
          Direct Scannable URL: <a href="${sessionData.qr_url}" target="_blank" id="qrDirectUrl">${sessionData.qr_url}</a>
        </div>

        <div style="width:100%; margin-top:32px; text-align:left;">
          <div class="card-header">
            <div class="card-title">Real-Time Present Students (<span id="presentCount">0</span>)</div>
          </div>
          <div class="table-responsive">
            <table class="table">
              <thead><tr><th>Enrollment</th><th>Name</th><th>Batch</th><th>Marked At</th><th>Method</th></tr></thead>
              <tbody id="presentStudentsTbody"></tbody>
            </table>
          </div>
        </div>
      </div>
    `;

    // Local countdown timer
    let remainingSec = sessionData.expires_in_seconds;
    clearInterval(this.liveAttendanceInterval);

    this.liveAttendanceInterval = setInterval(async () => {
      remainingSec--;
      const secEl = document.getElementById("qrSecCounter");
      if (secEl) secEl.textContent = `${Math.max(0, remainingSec)}s`;

      if (remainingSec <= 0) {
        // Trigger auto rotation on backend
        await this.manuallyRotateQr(sessionData.session_id);
      }

      // Fetch live present students poll every 3 seconds
      if (remainingSec % 3 === 0) {
        this.pollLiveAttendance(sessionData.session_id);
      }
    }, 1000);
  },

  async manuallyRotateQr(sessionId) {
    try {
      const res = await API.post(`/attendance/session/${sessionId}/rotate`);
      if (res.data && res.data.session_status === "COMPLETED") {
        clearInterval(this.liveAttendanceInterval);
        alert("Maximum rotations reached. Session closed.");
        this.navigate("dashboard");
        return;
      }
      const d = res.data;
      document.getElementById("activeQrImage").src = d.qr_image;
      document.getElementById("qrGenCounter").textContent = `#${d.generation} of ${d.max_rotations}`;
      document.getElementById("qrBackupCodePill").textContent = d.backup_code;
      document.getElementById("qrDirectUrl").textContent = d.qr_url;
      document.getElementById("qrDirectUrl").href = d.qr_url;
      document.getElementById("qrSecCounter").textContent = `${d.expires_in_seconds}s`;
    } catch (err) {
      console.warn("Rotation status:", err.message);
    }
  },

  async endAttendanceSession(sessionId) {
    if (!confirm("Are you sure you want to end this attendance session? All active QRs will be invalidated immediately.")) return;
    clearInterval(this.liveAttendanceInterval);
    await API.post(`/attendance/session/${sessionId}/end`);
    alert("Attendance session completed.");
    this.navigate("dashboard");
  },

  async pollLiveAttendance(sessionId) {
    try {
      const res = await API.get(`/attendance/session/${sessionId}/live`);
      document.getElementById("presentCount").textContent = `${res.present_count} / ${res.total_eligible}`;
      const tbody = document.getElementById("presentStudentsTbody");
      if (tbody) {
        tbody.innerHTML = res.present_students.map(s => `
          <tr>
            <td><strong>${s.enrollment_no}</strong></td>
            <td>${s.full_name}</td>
            <td>${s.batch_name}</td>
            <td>${s.marked_at}</td>
            <td><span class="badge badge-primary">${s.verification_method}</span></td>
          </tr>
        `).join('');
      }
    } catch (e) {
      console.warn("Live poll err:", e);
    }
  },

  async handleDirectAttendanceMark(token) {
    try {
      const res = await API.post("/attendance/mark", { token });
      alert(`✓ Attendance Confirmed for ${res.data.subject_name} (${res.data.session_type})`);
      this.navigate("dashboard");
    } catch (err) {
      alert("Attendance Verification Failed: " + err.message);
      this.navigate("dashboard");
    }
  },

  async submitAttendanceCode() {
    const sId = document.getElementById("markSessionId").value;
    const bCode = document.getElementById("markBackupCode").value.trim();
    const errBox = document.getElementById("markAttError");
    const succBox = document.getElementById("markAttSuccess");
    errBox.style.display = "none";
    succBox.style.display = "none";

    if (!sId || !bCode) {
      errBox.textContent = "Please enter both Session ID and the 6-digit Code.";
      errBox.style.display = "block";
      return;
    }

    try {
      const res = await API.post("/attendance/mark", { session_id: parseInt(sId), backup_code: bCode });
      succBox.textContent = `✓ Attendance Marked as PRESENT for ${res.data.subject_name}!`;
      succBox.style.display = "inline-flex";
      setTimeout(() => this.navigate("dashboard"), 1500);
    } catch (err) {
      errBox.textContent = err.message;
      errBox.style.display = "block";
    }
  },

  // ----------------------------------------------------
  // STUDENT ATTENDANCE ROSTERS (Overall & Datewise)
  // ----------------------------------------------------
  async renderStudentOverallView() {
    const container = document.getElementById("pageContent");
    try {
      const res = await API.get("/attendance/student/overall");
      const d = res.data;

      container.innerHTML = `
        <div class="card" style="margin-bottom:24px;">
          <div class="card-header">
            <div>
              <div class="card-title">Subjectwise Attendance Calculation</div>
              <div class="card-subtitle">Exact raw mathematical calculations: (Present / Total) &times; 100</div>
            </div>
          </div>
          <div class="table-responsive">
            <table class="table">
              <thead>
                <tr>
                  <th>Subject Code</th>
                  <th>Subject Name</th>
                  <th>Theory Attended</th>
                  <th>Theory %</th>
                  <th>Practical Attended</th>
                  <th>Practical %</th>
                  <th>Overall Attended</th>
                  <th>Overall %</th>
                </tr>
              </thead>
              <tbody>
                ${d.subjects.map(s => `
                  <tr>
                    <td><strong>${s.subject_code}</strong></td>
                    <td>${s.subject_name}</td>
                    <td>${s.theory.present} / ${s.theory.total}</td>
                    <td><span class="badge ${s.theory.percentage >= 75 ? 'badge-success' : 'badge-danger'}">${s.theory.percentage}%</span></td>
                    <td>${s.practical.present} / ${s.practical.total}</td>
                    <td><span class="badge ${s.practical.percentage >= 75 ? 'badge-success' : 'badge-danger'}">${s.practical.percentage}%</span></td>
                    <td>${s.overall.present} / ${s.overall.total}</td>
                    <td><strong style="color:var(--primary);">${s.overall.percentage}%</strong></td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>
      `;
    } catch (err) {
      container.innerHTML = `<div class="card"><p style="color:var(--danger);">${err.message}</p></div>`;
    }
  },

  async renderStudentDatewiseView() {
    const container = document.getElementById("pageContent");
    const today = new Date().toISOString().split("T")[0];
    try {
      const res = await API.get("/attendance/student/datewise", { date: today });
      container.innerHTML = `
        <div class="card" style="margin-bottom:24px;">
          <div class="card-header">
            <div>
              <div class="card-title">Datewise Attendance Activity</div>
              <div class="card-subtitle">Individual lecture statuses for selected date</div>
            </div>
            <input type="date" class="form-input" id="datewisePicker" value="${today}" style="max-width:180px;">
          </div>
          <div class="table-responsive">
            <table class="table">
              <thead>
                <tr><th>Time</th><th>Subject</th><th>Type</th><th>Faculty</th><th>Room</th><th>Status</th></tr>
              </thead>
              <tbody id="datewiseTbody">
                ${res.sessions.map(s => `
                  <tr>
                    <td>${s.scheduled_start || ''} – ${s.scheduled_end || ''}</td>
                    <td>${s.subject_name} (${s.subject_code})</td>
                    <td><span class="badge badge-primary">${s.session_type}</span></td>
                    <td>${s.teacher_name}</td>
                    <td>${s.room}</td>
                    <td>
                      <span class="badge ${s.attendance_status === 'PRESENT' ? 'badge-success' : (s.attendance_status === 'ABSENT' ? 'badge-danger' : 'badge-neutral')}">
                        ${s.attendance_status}
                      </span>
                    </td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>
      `;

      document.getElementById("datewisePicker").addEventListener("change", async (e) => {
        const r2 = await API.get("/attendance/student/datewise", { date: e.target.value });
        const tbody = document.getElementById("datewiseTbody");
        tbody.innerHTML = r2.sessions.map(s => `
          <tr>
            <td>${s.scheduled_start || ''} – ${s.scheduled_end || ''}</td>
            <td>${s.subject_name} (${s.subject_code})</td>
            <td><span class="badge badge-primary">${s.session_type}</span></td>
            <td>${s.teacher_name}</td>
            <td>${s.room}</td>
            <td>
              <span class="badge ${s.attendance_status === 'PRESENT' ? 'badge-success' : (s.attendance_status === 'ABSENT' ? 'badge-danger' : 'badge-neutral')}">
                ${s.attendance_status}
              </span>
            </td>
          </tr>
        `).join('');
      });
    } catch (err) {
      container.innerHTML = `<div class="card"><p style="color:var(--danger);">${err.message}</p></div>`;
    }
  },

  // ----------------------------------------------------
  // QUIZ ENGINE: CREATION, QUESTION EDITOR & JOINING
  // ----------------------------------------------------
  async renderQuizzesListView() {
    const container = document.getElementById("pageContent");
    try {
      const res = await API.get("/quiz/list");
      container.innerHTML = `
        <div class="card">
          <div class="card-header">
            <div>
              <div class="card-title">Institutional Examinations</div>
              <div class="card-subtitle">Scheduled examinations with cryptographic join QR links</div>
            </div>
            ${this.user.role !== 'STUDENT' ? `<button class="btn btn-primary" onclick="App.navigate('create-quiz')">+ Create New Examination</button>` : ''}
          </div>
          <div class="table-responsive">
            <table class="table">
              <thead>
                <tr>
                  <th>Code</th>
                  <th>Title</th>
                  <th>Subject</th>
                  <th>Duration</th>
                  <th>Timing Window</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                ${res.quizzes.length === 0 ? `<tr><td colspan="7" style="text-align:center; color:var(--text-muted);">No quizzes available.</td></tr>` :
                  res.quizzes.map(q => `
                    <tr>
                      <td><span class="badge badge-primary">${q.code}</span></td>
                      <td><strong>${q.title}</strong></td>
                      <td>${q.subject_name}</td>
                      <td>${q.duration_minutes} Mins</td>
                      <td style="font-size:0.8rem; color:var(--text-muted);">${q.start_time} to ${q.end_time}</td>
                      <td><span class="badge ${q.status === 'ACTIVE' ? 'badge-success' : 'badge-neutral'}">${q.status}</span></td>
                      <td>
                        <div style="display:flex; gap:8px;">
                          ${this.user.role === 'STUDENT' ? `
                            <button class="btn btn-primary" style="padding:4px 10px; font-size:0.8rem;" onclick="App.verifyQuizCode('${q.code}')">
                              ${q.attempt_status ? (q.attempt_status === 'IN_PROGRESS' ? 'Resume' : 'View Result') : 'Join'}
                            </button>
                          ` : `
                            <button class="btn btn-secondary" style="padding:4px 10px; font-size:0.8rem;" onclick="App.showQuizQrModal(${q.id})">QR Join</button>
                            <button class="btn btn-secondary" style="padding:4px 10px; font-size:0.8rem;" onclick="App.showExportReportModal(${q.id})">Reports</button>
                          `}
                        </div>
                      </td>
                    </tr>
                  `).join('')
                }
              </tbody>
            </table>
          </div>
        </div>
      `;
    } catch (err) {
      container.innerHTML = `<div class="card"><p style="color:var(--danger);">${err.message}</p></div>`;
    }
  },

  async renderCreateQuizView() {
    const container = document.getElementById("pageContent");
    container.innerHTML = `
      <div class="card" style="margin-bottom:24px;">
        <div class="card-header">
          <div>
            <div class="card-title">Create Examination with AI Question Synthesizer</div>
            <div class="card-subtitle">Specify exact distributions for MCQ, Numerical, and Subjective questions</div>
          </div>
        </div>

        <form id="aiQuizForm">
          <div class="grid grid-3">
            <div class="form-group">
              <label class="form-label">Quiz Title</label>
              <input type="text" class="form-input" id="qTitle" placeholder="e.g. Unit 2 Database Transactions Quiz" required>
            </div>
            <div class="form-group">
              <label class="form-label">Subject</label>
              <select class="form-select" id="qSubject" required></select>
            </div>
            <div class="form-group">
              <label class="form-label">Division</label>
              <select class="form-select" id="qDivision" required></select>
            </div>
          </div>

          <div class="grid grid-2" style="margin-top:12px;">
            <div class="form-group">
              <label class="form-label">Topic / Unit</label>
              <input type="text" class="form-input" id="qTopic" placeholder="e.g. Concurrency Control, Deadlocks & ACID Properties" required>
            </div>
            <div class="form-group">
              <label class="form-label">Pedagogical Instructions (Optional)</label>
              <input type="text" class="form-input" id="qInstructions" placeholder="e.g. Include real-world system engineering examples">
            </div>
          </div>

          <div style="background:var(--bg-surface); padding:18px; border-radius:var(--radius-md); border:1px solid var(--border-card); margin:18px 0;">
            <div style="font-weight:700; margin-bottom:12px; color:var(--primary);">Question Counts & Distributions (Strict Count Validation)</div>
            
            <div class="grid grid-4" style="margin-bottom:14px;">
              <div class="form-group">
                <label class="form-label">Total Questions</label>
                <input type="number" class="form-input" id="qTotal" value="10" min="1" max="50">
              </div>
              <div class="form-group">
                <label class="form-label">MCQ Count</label>
                <input type="number" class="form-input" id="qMcqCount" value="5" min="0">
              </div>
              <div class="form-group">
                <label class="form-label">Numerical Count</label>
                <input type="number" class="form-input" id="qNumCount" value="3" min="0">
              </div>
              <div class="form-group">
                <label class="form-label">Answer Type (Subjective)</label>
                <input type="number" class="form-input" id="qAnsCount" value="2" min="0">
              </div>
            </div>

            <div class="grid grid-3">
              <div class="form-group">
                <label class="form-label">Easy Questions</label>
                <input type="number" class="form-input" id="qEasyCount" value="3" min="0">
              </div>
              <div class="form-group">
                <label class="form-label">Medium Questions</label>
                <input type="number" class="form-input" id="qMedCount" value="4" min="0">
              </div>
              <div class="form-group">
                <label class="form-label">Hard Questions</label>
                <input type="number" class="form-input" id="qHardCount" value="3" min="0">
              </div>
            </div>
          </div>

          <div class="grid grid-4">
            <div class="form-group">
              <label class="form-label">Duration (Minutes)</label>
              <input type="number" class="form-input" id="qDuration" value="30" min="5">
            </div>
            <div class="form-group">
              <label class="form-label">Start Date & Time</label>
              <input type="datetime-local" class="form-input" id="qStartTime" required>
            </div>
            <div class="form-group">
              <label class="form-label">End Date & Time</label>
              <input type="datetime-local" class="form-input" id="qEndTime" required>
            </div>
            <div class="form-group">
              <label class="form-label">Result Release Time</label>
              <input type="datetime-local" class="form-input" id="qReleaseTime" required>
            </div>
          </div>

          <div class="grid grid-2" style="margin-top:12px;">
            <div class="form-group">
              <label class="form-label">Attendance Prerequisite Requirement</label>
              <select class="form-select" id="qAttReq">
                <option value="NONE">No Attendance Prerequisite</option>
                <option value="LINKED_SESSION">Require Present in Linked Lecture</option>
                <option value="PERCENTAGE_THRESHOLD">Require Minimum 75% Attendance</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Tab-Switch Violation Limit</label>
              <input type="number" class="form-input" id="qMaxSwitches" value="3" min="1" max="10">
            </div>
          </div>

          <div style="margin-top:18px; display:flex; gap:12px;">
            <button type="button" class="btn btn-primary" id="generateAiQuestionsBtn">
              ✨ Synthesize Questions with AI
            </button>
            <label class="btn btn-secondary" style="cursor:pointer;">
              📎 Upload Notes/Syllabus File (PDF/DOCX)
              <input type="file" id="quizMaterialUpload" accept=".pdf,.docx,.txt" style="display:none;">
            </label>
          </div>
        </form>
      </div>

      <div id="questionEditorContainer" style="display:none;">
        <div class="card">
          <div class="card-header">
            <div>
              <div class="card-title">Question Editor & Final Review</div>
              <div class="card-subtitle">Review, edit, add, or delete AI synthesized questions before final scheduling</div>
            </div>
            <button class="btn btn-success" id="finalizeQuizBtn">✓ Finalize & Schedule Quiz</button>
          </div>
          <div id="questionsEditorList"></div>
        </div>
      </div>
    `;

    this.populateAcademicDropdowns("qSubject", "qDivision");

    // Default datetimes
    const now = new Date();
    const startStr = new Date(now.getTime() - 5 * 60000).toISOString().slice(0, 16);
    const endStr = new Date(now.getTime() + 2 * 86400000).toISOString().slice(0, 16);
    const relStr = new Date(now.getTime() + 2 * 86400000 + 3600000).toISOString().slice(0, 16);
    document.getElementById("qStartTime").value = startStr;
    document.getElementById("qEndTime").value = endStr;
    document.getElementById("qReleaseTime").value = relStr;

    // AI Generation Trigger
    document.getElementById("generateAiQuestionsBtn").addEventListener("click", () => this.handleAiGeneration());

    // File upload
    document.getElementById("quizMaterialUpload").addEventListener("change", async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const formData = new FormData();
      formData.append("file", file);
      try {
        const res = await API.postForm("/quiz/upload-material", formData);
        alert(`Document processed: ${res.category}. Extracted text will guide AI question synthesis.`);
        this.uploadedReferenceText = res.extracted_text;
      } catch (err) {
        alert("Upload error: " + err.message);
      }
    });

    document.getElementById("finalizeQuizBtn").addEventListener("click", () => this.finalizeAndSaveQuiz());
  },

  async handleAiGeneration() {
    const btn = document.getElementById("generateAiQuestionsBtn");
    const subjSelect = document.getElementById("qSubject");
    const subjectName = subjSelect.options[subjSelect.selectedIndex]?.text || "Computer Science";
    const topic = document.getElementById("qTopic").value.trim();

    const total_q = parseInt(document.getElementById("qTotal").value);
    const mcq_cnt = parseInt(document.getElementById("qMcqCount").value);
    const num_cnt = parseInt(document.getElementById("qNumCount").value);
    const ans_cnt = parseInt(document.getElementById("qAnsCount").value);

    const easy_cnt = parseInt(document.getElementById("qEasyCount").value);
    const med_cnt = parseInt(document.getElementById("qMedCount").value);
    const hard_cnt = parseInt(document.getElementById("qHardCount").value);

    // Frontend validation before API
    if (mcq_cnt + num_cnt + ans_cnt !== total_q) {
      alert(`Question type counts (${mcq_cnt} + ${num_cnt} + ${ans_cnt} = ${mcq_cnt+num_cnt+ans_cnt}) must equal total questions (${total_q}).`);
      return;
    }

    if (easy_cnt + med_cnt + hard_cnt !== total_q) {
      alert(`Difficulty counts (${easy_cnt} + ${med_cnt} + ${hard_cnt} = ${easy_cnt+med_cnt+hard_cnt}) must equal total questions (${total_q}).`);
      return;
    }

    btn.disabled = true;
    btn.innerHTML = `<span class="spinner"></span> AI is synthesizing structured questions...`;

    try {
      const res = await API.post("/quiz/generate", {
        subject: subjectName,
        topic: topic || "Core Examination Unit",
        instructions: document.getElementById("qInstructions").value.trim(),
        total_questions: total_q,
        mcq_count: mcq_cnt,
        numerical_count: num_cnt,
        answer_count: ans_cnt,
        easy_count: easy_cnt,
        medium_count: med_cnt,
        hard_count: hard_cnt,
        reference_text: this.uploadedReferenceText || null
      });

      this.currentEditingQuestions = res.data.questions;
      this.renderQuestionEditorList();
    } catch (err) {
      alert("AI Generation failed: " + err.message);
    } finally {
      btn.disabled = false;
      btn.textContent = "✨ Synthesize Questions with AI";
    }
  },

  renderQuestionEditorList() {
    const box = document.getElementById("questionEditorContainer");
    const list = document.getElementById("questionsEditorList");
    box.style.display = "block";

    list.innerHTML = this.currentEditingQuestions.map((q, idx) => `
      <div class="card" style="margin-bottom:16px; border-left:4px solid var(--primary);" id="qEditCard_${idx}">
        <div style="display:flex; justify-content:space-between; margin-bottom:10px;">
          <div>
            <span class="badge badge-primary">Q${idx + 1} &bull; ${q.type}</span>
            <span class="badge badge-neutral">${q.difficulty}</span>
          </div>
          <button class="btn btn-danger" style="padding:2px 8px; font-size:0.75rem;" onclick="App.deleteQuestionFromEditor(${idx})">Delete</button>
        </div>

        <div class="form-group">
          <label class="form-label">Question Text</label>
          <textarea class="form-textarea" style="min-height:60px;" onchange="App.currentEditingQuestions[${idx}].question = this.value">${q.question}</textarea>
        </div>

        ${q.type === 'MCQ' ? `
          <div class="grid grid-2" style="margin-bottom:10px;">
            ${(q.options || []).map((opt, optIdx) => `
              <div class="form-group">
                <label class="form-label">Option ${String.fromCharCode(65 + optIdx)}</label>
                <input type="text" class="form-input" value="${opt}" onchange="App.currentEditingQuestions[${idx}].options[${optIdx}] = this.value">
              </div>
            `).join('')}
          </div>
          <div class="form-group">
            <label class="form-label">Correct Option Text</label>
            <input type="text" class="form-input" value="${q.correct_answer}" onchange="App.currentEditingQuestions[${idx}].correct_answer = this.value">
          </div>
        ` : (q.type === 'NUMERICAL' ? `
          <div class="grid grid-2">
            <div class="form-group">
              <label class="form-label">Final Correct Numerical Answer</label>
              <input type="text" class="form-input" value="${q.correct_answer}" onchange="App.currentEditingQuestions[${idx}].correct_answer = this.value">
            </div>
            <div class="form-group">
              <label class="form-label">Allowed Tolerance (&plusmn;)</label>
              <input type="number" step="0.01" class="form-input" value="${q.numerical_tolerance || 0.05}" onchange="App.currentEditingQuestions[${idx}].numerical_tolerance = parseFloat(this.value)">
            </div>
          </div>
        ` : `
          <div class="form-group">
            <label class="form-label">Expected Answer / Grading Rubric</label>
            <textarea class="form-textarea" style="min-height:60px;" onchange="App.currentEditingQuestions[${idx}].rubric_text = this.value">${q.rubric_text || q.correct_answer}</textarea>
          </div>
        `)}

        <div class="grid grid-2">
          <div class="form-group">
            <label class="form-label">Pedagogical Explanation</label>
            <input type="text" class="form-input" value="${q.explanation || ''}" onchange="App.currentEditingQuestions[${idx}].explanation = this.value">
          </div>
          <div class="form-group">
            <label class="form-label">Marks</label>
            <input type="number" step="0.5" class="form-input" value="${q.marks || 1.0}" onchange="App.currentEditingQuestions[${idx}].marks = parseFloat(this.value)">
          </div>
        </div>
      </div>
    `).join('');

    box.scrollIntoView({ behavior: "smooth" });
  },

  deleteQuestionFromEditor(index) {
    this.currentEditingQuestions.splice(index, 1);
    this.renderQuestionEditorList();
  },

  async finalizeAndSaveQuiz() {
    if (!this.currentEditingQuestions || this.currentEditingQuestions.length === 0) {
      alert("Please generate questions first.");
      return;
    }

    const payload = {
      title: document.getElementById("qTitle").value.trim(),
      subject_id: parseInt(document.getElementById("qSubject").value),
      division_id: parseInt(document.getElementById("qDivision").value),
      topic: document.getElementById("qTopic").value.trim(),
      instructions: document.getElementById("qInstructions").value.trim(),
      duration_minutes: parseInt(document.getElementById("qDuration").value),
      start_time: document.getElementById("qStartTime").value.replace("T", " ") + ":00",
      end_time: document.getElementById("qEndTime").value.replace("T", " ") + ":00",
      result_release_time: document.getElementById("qReleaseTime").value.replace("T", " ") + ":00",
      attendance_requirement_type: document.getElementById("qAttReq").value,
      max_tab_switches: parseInt(document.getElementById("qMaxSwitches").value),
      questions: this.currentEditingQuestions
    };

    try {
      const res = await API.post("/quiz/create", payload);
      alert(`✓ Quiz Successfully Created!\nCode: ${res.code}\nJoin URL: ${res.join_url}`);
      this.navigate("quizzes");
    } catch (err) {
      alert("Error saving quiz: " + err.message);
    }
  },

  async showQuizQrModal(quizId) {
    try {
      const res = await API.get(`/quiz/${quizId}/qr`);
      const modal = document.createElement("div");
      modal.className = "modal-backdrop";
      modal.innerHTML = `
        <div class="modal-content" style="text-align:center; max-width:440px;">
          <h3 style="color:var(--primary); margin-bottom:4px;">QUIZ JOIN QR</h3>
          <p style="color:var(--text-secondary); font-size:0.85rem; margin-bottom:18px;">${res.title} &bull; ${res.code}</p>
          <div class="qr-box" style="margin-bottom:16px;">
            <img src="${res.qr_image}" alt="Quiz Join QR">
          </div>
          <div style="font-size:0.82rem; color:var(--text-muted); word-break:break-all; margin-bottom:18px;">
            ${res.join_url}
          </div>
          <div style="display:flex; gap:10px; justify-content:center;">
            <button class="btn btn-secondary" onclick="navigator.clipboard.writeText('${res.join_url}'); alert('Join URL copied!');">Copy Link</button>
            <button class="btn btn-primary" onclick="this.closest('.modal-backdrop').remove()">Close</button>
          </div>
        </div>
      `;
      document.body.appendChild(modal);
    } catch (err) {
      alert(err.message);
    }
  },

  async showExportReportModal(quizId) {
    const modal = document.createElement("div");
    modal.className = "modal-backdrop";
    modal.innerHTML = `
      <div class="modal-content" style="max-width:460px;">
        <h3 style="margin-bottom:12px;">Export Examination Report</h3>
        <p style="color:var(--text-secondary); font-size:0.85rem; margin-bottom:20px;">Download official institutional results roster in chosen format.</p>
        <div style="display:flex; flex-direction:column; gap:10px;">
          <a class="btn btn-secondary" href="/api/reports/quiz/${quizId}?format=pdf" target="_blank">📄 Download PDF Document</a>
          <a class="btn btn-secondary" href="/api/reports/quiz/${quizId}?format=docx" target="_blank">📝 Download Microsoft Word (.docx)</a>
          <a class="btn btn-secondary" href="/api/reports/quiz/${quizId}?format=excel" target="_blank">📊 Download Microsoft Excel (.xlsx)</a>
          <a class="btn btn-secondary" href="/api/reports/quiz/${quizId}?format=csv" target="_blank">📋 Download CSV Format</a>
        </div>
        <div style="margin-top:20px; text-align:right;">
          <button class="btn btn-secondary" onclick="this.closest('.modal-backdrop').remove()">Cancel</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
  },

  // ----------------------------------------------------
  // PROCTORED EXAMINATION TAKING & HUD
  // ----------------------------------------------------
  async handleDirectQuizJoin(token) {
    await this.verifyQuizCode(token);
  },

  async verifyQuizCode(identifier) {
    if (!identifier) return;
    try {
      const res = await API.post("/quiz/verify-eligibility", { identifier: identifier.trim() });
      if (res.eligible) {
        if (confirm(`Eligible for ${res.quiz.title} (${res.quiz.duration_minutes} Mins).\nReady to start examination?`)) {
          this.startProctoredQuiz(res.quiz.id);
        }
      }
    } catch (err) {
      alert("Eligibility Check Failed:\n" + err.message);
    }
  },

  async startProctoredQuiz(quizId) {
    try {
      const res = await API.post(`/quiz/${quizId}/start`);
      this.examState = res.data;
      this.examState.status = "IN_PROGRESS";
      this.currentQuestionIdx = 0;
      this.navigate("quiz-hud", { attempt_id: res.data.attempt_id });
    } catch (err) {
      alert("Failed to start quiz: " + err.message);
    }
  },

  renderQuizHudView(attemptId) {
    if (!this.examState) {
      this.navigate("quizzes");
      return;
    }

    const container = document.getElementById("pageContent");
    const es = this.examState;
    const questions = es.questions;

    container.innerHTML = `
      <div class="quiz-hud-header">
        <div>
          <h3 style="color:var(--text-primary); font-size:1.1rem;">${es.quiz_title}</h3>
          <div style="font-size:0.8rem; color:var(--text-muted);">${es.subject_name} &bull; Anti-Cheating Monitored</div>
        </div>
        <div class="hud-timer-badge" id="examTimerBadge">
          ⏱️ <span id="examTimerText">00:00</span>
        </div>
      </div>

      <div id="violationWarningArea"></div>

      <div class="grid grid-3" style="margin-top:20px;">
        <div style="grid-column: 1 / 3;">
          <div class="card" id="activeQuestionCard"></div>
          <div style="display:flex; justify-content:space-between; margin-top:16px;">
            <button class="btn btn-secondary" id="prevQBtn" onclick="App.prevExamQuestion()">← Previous</button>
            <button class="btn btn-primary" id="nextQBtn" onclick="App.nextExamQuestion()">Next →</button>
          </div>
        </div>

        <div class="card" style="height:fit-content;">
          <div class="card-header">
            <div class="card-title">Questions Navigator</div>
          </div>
          <div class="q-matrix">
            ${questions.map((q, i) => `
              <div class="q-bubble ${i === 0 ? 'current' : ''} ${es.saved_answers[q.id] ? 'answered' : ''}" id="qBubble_${i}" onclick="App.jumpToQuestion(${i})">
                ${i + 1}
              </div>
            `).join('')}
          </div>
          <button class="btn btn-danger" style="width:100%; margin-top:24px;" onclick="App.submitExamAttempt()">
            Submit Examination
          </button>
        </div>
      </div>
    `;

    this.renderActiveQuestion();
    this.startExamCountdown(es.remaining_seconds);
  },

  renderActiveQuestion() {
    const card = document.getElementById("activeQuestionCard");
    const es = this.examState;
    const q = es.questions[this.currentQuestionIdx];
    const savedAns = es.saved_answers[q.id] || "";

    card.innerHTML = `
      <div style="display:flex; justify-content:space-between; margin-bottom:12px;">
        <span class="badge badge-primary">Question ${this.currentQuestionIdx + 1} of ${es.questions.length}</span>
        <span class="badge badge-neutral">${q.marks} Marks &bull; ${q.type}</span>
      </div>

      <h3 style="font-size:1.15rem; margin-bottom:20px; line-height:1.5;">${q.question}</h3>

      ${q.type === 'MCQ' ? `
        <div class="options-group">
          ${(q.options || []).map((opt, optIdx) => `
            <div class="option-card ${savedAns === opt ? 'selected' : ''}" onclick="App.selectMcqOption(${q.id}, '${opt.replace(/'/g, "\\'")}')">
              <div class="option-indicator">${String.fromCharCode(65 + optIdx)}</div>
              <div>${opt}</div>
            </div>
          `).join('')}
        </div>
      ` : (q.type === 'NUMERICAL' ? `
        <div class="form-group">
          <label class="form-label">Enter Final Numerical Value</label>
          <input type="number" step="any" class="form-input" value="${savedAns}" placeholder="e.g. 24.5" onchange="App.saveCurrentAnswer(${q.id}, this.value)" style="font-size:1.2rem; font-family:var(--font-mono); max-width:300px;">
          <div style="font-size:0.75rem; color:var(--text-muted); margin-top:4px;">Server will verify against authorized precision tolerance.</div>
        </div>
      ` : `
        <div class="form-group">
          <label class="form-label">Write Comprehensive Answer</label>
          <textarea class="form-textarea" placeholder="Type your academic response here..." onchange="App.saveCurrentAnswer(${q.id}, this.value)">${savedAns}</textarea>
        </div>
      `)}
    `;

    document.querySelectorAll(".q-bubble").forEach((b, idx) => {
      b.classList.toggle("current", idx === this.currentQuestionIdx);
    });
  },

  selectMcqOption(questionId, selectedText) {
    this.examState.saved_answers[questionId] = selectedText;
    document.getElementById(`qBubble_${this.currentQuestionIdx}`)?.classList.add("answered");
    this.renderActiveQuestion();
    API.post(`/quiz/attempt/${this.examState.attempt_id}/save-answer`, { question_id: questionId, answer: selectedText });
  },

  saveCurrentAnswer(questionId, answerText) {
    this.examState.saved_answers[questionId] = answerText;
    if (answerText.trim()) {
      document.getElementById(`qBubble_${this.currentQuestionIdx}`)?.classList.add("answered");
    }
    API.post(`/quiz/attempt/${this.examState.attempt_id}/save-answer`, { question_id: questionId, answer: answerText });
  },

  nextExamQuestion() {
    if (this.currentQuestionIdx < this.examState.questions.length - 1) {
      this.currentQuestionIdx++;
      this.renderActiveQuestion();
    }
  },

  prevExamQuestion() {
    if (this.currentQuestionIdx > 0) {
      this.currentQuestionIdx--;
      this.renderActiveQuestion();
    }
  },

  jumpToQuestion(idx) {
    this.currentQuestionIdx = idx;
    this.renderActiveQuestion();
  },

  startExamCountdown(seconds) {
    let remaining = seconds;
    clearInterval(this.examTimerInterval);

    const updateTimerDisplay = () => {
      const mins = Math.floor(remaining / 60);
      const secs = remaining % 60;
      const timerText = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
      const timerEl = document.getElementById("examTimerText");
      const badge = document.getElementById("examTimerBadge");

      if (timerEl) timerEl.textContent = timerText;
      if (badge) {
        if (remaining <= 120) {
          badge.className = "hud-timer-badge danger";
        } else if (remaining <= 300) {
          badge.className = "hud-timer-badge warning";
        }
      }
    };

    updateTimerDisplay();

    this.examTimerInterval = setInterval(async () => {
      remaining--;
      updateTimerDisplay();

      if (remaining <= 0) {
        clearInterval(this.examTimerInterval);
        alert("Authoritative examination time has expired. Your attempt is being auto-submitted.");
        await this.submitExamAttempt(true);
      }
    }, 1000);
  },

  async reportExamViolation(type) {
    if (!this.examState) return;
    try {
      const res = await API.post(`/quiz/attempt/${this.examState.attempt_id}/violation`, { type, duration_seconds: 1 });
      const warnArea = document.getElementById("violationWarningArea");
      if (warnArea) {
        warnArea.innerHTML = `
          <div class="violation-banner">
            ⚠️ <strong>Proctoring Notice:</strong> Window switch detected (${res.violations_count} / ${this.examState.max_tab_switches} violations). Exceeding limit triggers automatic disqualification.
          </div>
        `;
      }
      if (res.auto_submitted) {
        clearInterval(this.examTimerInterval);
        alert("Examination violation threshold exceeded. Attempt automatically submitted.");
        this.examState = null;
        this.navigate("quizzes");
      }
    } catch (e) {
      console.warn("Violation report error:", e);
    }
  },

  async submitExamAttempt(isAuto = false) {
    if (!isAuto && !confirm("Are you ready to finalize and submit your examination? You cannot edit answers after submission.")) return;
    clearInterval(this.examTimerInterval);
    try {
      const res = await API.post(`/quiz/attempt/${this.examState.attempt_id}/submit`);
      alert("Examination attempt successfully submitted!");
      const attId = this.examState.attempt_id;
      this.examState = null;
      this.navigate("quiz-result", { attempt_id: attId });
    } catch (err) {
      alert("Submission error: " + err.message);
    }
  },

  async renderQuizResultView(attemptId) {
    const container = document.getElementById("pageContent");
    try {
      const res = await API.get(`/quiz/attempt/${attemptId}/result`);
      const att = res.attempt;

      if (!res.published) {
        container.innerHTML = `
          <div class="card" style="text-align:center; max-width:540px; margin:40px auto; padding:40px 24px;">
            <div style="font-size:3rem; margin-bottom:12px;">🔒</div>
            <h2 style="margin-bottom:8px;">Results Scheduled for Publication</h2>
            <p style="color:var(--text-secondary); margin-bottom:20px;">${res.message}</p>
            <button class="btn btn-primary" onclick="App.navigate('dashboard')">Return to Dashboard</button>
          </div>
        `;
        return;
      }

      container.innerHTML = `
        <div class="card" style="margin-bottom:24px;">
          <div class="card-header">
            <div>
              <div class="card-title">${att.quiz_title} — Official Result</div>
              <div class="card-subtitle">${att.student_name} (${att.enrollment_no}) &bull; ${att.subject_name}</div>
            </div>
            <div style="text-align:right;">
              <span class="badge ${att.percentage >= 70 ? 'badge-success' : 'badge-warning'}">${att.classification}</span>
            </div>
          </div>

          <div class="grid grid-3" style="margin:20px 0;">
            <div style="background:var(--bg-surface); padding:16px; border-radius:var(--radius-md); text-align:center;">
              <div style="font-size:0.8rem; color:var(--text-muted);">SCORE ACHIEVED</div>
              <div style="font-size:2rem; font-weight:800; color:var(--primary);">${att.score} / ${att.total_marks}</div>
            </div>
            <div style="background:var(--bg-surface); padding:16px; border-radius:var(--radius-md); text-align:center;">
              <div style="font-size:0.8rem; color:var(--text-muted);">PERCENTAGE</div>
              <div style="font-size:2rem; font-weight:800;">${att.percentage}%</div>
            </div>
            <div style="background:var(--bg-surface); padding:16px; border-radius:var(--radius-md); text-align:center;">
              <div style="font-size:0.8rem; color:var(--text-muted);">TIME SPENT</div>
              <div style="font-size:2rem; font-weight:800;">${Math.round(att.time_spent_seconds / 60)} Mins</div>
            </div>
          </div>

          <h3 style="margin:24px 0 14px;">Detailed Question Analysis</h3>
          <div style="display:flex; flex-direction:column; gap:16px;">
            ${res.questions.map(q => `
              <div style="background:var(--bg-surface); border:1px solid var(--border-card); border-radius:var(--radius-md); padding:18px;">
                <div style="display:flex; justify-content:space-between; margin-bottom:8px;">
                  <span class="badge badge-primary">Q${q.order} &bull; ${q.type}</span>
                  <span class="badge ${q.marks_awarded > 0 ? 'badge-success' : 'badge-danger'}">${q.marks_awarded} / ${q.max_marks} Marks</span>
                </div>
                <div style="font-weight:600; margin-bottom:12px;">${q.question}</div>
                <div style="font-size:0.88rem; margin-bottom:6px;"><strong>Your Answer:</strong> ${q.student_answer || '<em style="color:var(--text-muted);">No answer provided</em>'}</div>
                <div style="font-size:0.88rem; color:var(--success); margin-bottom:6px;"><strong>Expected Answer:</strong> ${q.correct_answer}</div>
                ${q.explanation ? `<div style="font-size:0.82rem; color:var(--text-secondary); background:var(--bg-card); padding:8px 12px; border-radius:var(--radius-sm); margin-top:8px;">💡 <em>${q.explanation}</em></div>` : ''}
                ${q.teacher_feedback ? `<div style="font-size:0.82rem; color:var(--primary); background:var(--primary-glow-subtle); padding:8px 12px; border-radius:var(--radius-sm); margin-top:8px;">👨‍🏫 Faculty Feedback: ${q.teacher_feedback}</div>` : ''}
              </div>
            `).join('')}
          </div>
        </div>
      `;
    } catch (err) {
      container.innerHTML = `<div class="card"><p style="color:var(--danger);">${err.message}</p></div>`;
    }
  },

  // ----------------------------------------------------
  // AI DOUBT SOLVER & TUTOR VIEW
  // ----------------------------------------------------
  async renderAiDoubtView() {
    const container = document.getElementById("pageContent");
    try {
      const convRes = await API.get("/ai/doubt/conversations");
      const convs = convRes.conversations;
      const activeConvId = convs.length > 0 ? convs[0].id : null;

      container.innerHTML = `
        <div class="chat-container">
          <div class="card-header" style="background:var(--bg-surface); padding:16px 20px; border-bottom:1px solid var(--border-card); margin-bottom:0;">
            <div>
              <div class="card-title">🤖 Academic AI Doubt Tutor</div>
              <div class="card-subtitle">Confidential, personalized topic explanations and derivation support</div>
            </div>
            <button class="btn btn-secondary" onclick="App.createNewDoubtConversation()">+ New Topic</button>
          </div>

          <div class="chat-messages" id="chatMessages"></div>

          <div class="chat-input-bar">
            <input type="text" class="form-input" id="chatInputText" placeholder="Ask any mathematical derivation, concept doubt, or quiz question...">
            <button class="btn btn-primary" id="chatSendBtn" onclick="App.sendDoubtMessage(${activeConvId})">Send</button>
          </div>
        </div>
      `;

      if (activeConvId) {
        this.loadConversationMessages(activeConvId);
      } else {
        document.getElementById("chatMessages").innerHTML = `
          <div style="text-align:center; color:var(--text-muted); padding:40px;">
            Ask your first academic question below. Your conversation is completely private.
          </div>
        `;
      }

      document.getElementById("chatInputText").addEventListener("keypress", (e) => {
        if (e.key === "Enter") App.sendDoubtMessage(activeConvId);
      });
    } catch (err) {
      container.innerHTML = `<div class="card"><p style="color:var(--danger);">${err.message}</p></div>`;
    }
  },

  async loadConversationMessages(convId) {
    try {
      const res = await API.get(`/ai/doubt/conversation/${convId}/messages`);
      const msgBox = document.getElementById("chatMessages");
      msgBox.innerHTML = res.messages.map(m => `
        <div class="chat-bubble ${m.role}">
          ${m.content.replace(/\n/g, '<br>')}
        </div>
      `).join('');
      msgBox.scrollTop = msgBox.scrollHeight;
    } catch (e) {
      console.warn("Messages err:", e);
    }
  },

  async sendDoubtMessage(convId) {
    const input = document.getElementById("chatInputText");
    const sendBtn = document.getElementById("chatSendBtn");
    const text = input.value.trim();
    if (!text) return;

    input.value = "";
    sendBtn.disabled = true;

    const msgBox = document.getElementById("chatMessages");
    msgBox.innerHTML += `<div class="chat-bubble user">${text}</div>`;
    msgBox.scrollTop = msgBox.scrollHeight;

    try {
      const res = await API.post("/ai/doubt/ask", { conversation_id: convId, message: text });
      msgBox.innerHTML += `<div class="chat-bubble assistant">${res.data.content.replace(/\n/g, '<br>')}</div>`;
      msgBox.scrollTop = msgBox.scrollHeight;
    } catch (err) {
      msgBox.innerHTML += `<div class="chat-bubble assistant" style="color:var(--danger);">Error: ${err.message}</div>`;
    } finally {
      sendBtn.disabled = false;
    }
  },

  async createNewDoubtConversation() {
    const title = prompt("Enter topic title for this AI discussion:");
    if (!title) return;
    try {
      await API.post("/ai/doubt/new", { title });
      this.renderAiDoubtView();
    } catch (e) {
      alert(e.message);
    }
  },

  // ----------------------------------------------------
  // ADMIN MANAGEMENT VIEWS
  // ----------------------------------------------------
  async renderAdminTeachersView() {
    const container = document.getElementById("pageContent");
    try {
      const res = await API.get("/admin/teachers");
      container.innerHTML = `
        <div class="card">
          <div class="card-header">
            <div>
              <div class="card-title">Academic Faculty Directory</div>
              <div class="card-subtitle">Manage professors, credentials, and course/batch teaching assignments</div>
            </div>
            <button class="btn btn-primary" onclick="App.openAddTeacherModal()">+ Register Faculty</button>
          </div>
          <div class="table-responsive">
            <table class="table">
              <thead><tr><th>Code</th><th>Name</th><th>Email</th><th>Department</th><th>Assignments</th><th>Action</th></tr></thead>
              <tbody>
                ${res.teachers.map(t => `
                  <tr>
                    <td><span class="badge badge-primary">${t.employee_code}</span></td>
                    <td><strong>${t.full_name}</strong></td>
                    <td>${t.email}</td>
                    <td>${t.department}</td>
                    <td><span class="badge badge-neutral">${t.assignments_count} Assigned</span></td>
                    <td>
                      <button class="btn btn-secondary" style="padding:4px 10px; font-size:0.8rem;" onclick="App.manageAssignmentsModal(${t.id}, '${t.full_name}')">
                        Assign Batches
                      </button>
                    </td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>
      `;
    } catch (err) {
      container.innerHTML = `<div class="card"><p style="color:var(--danger);">${err.message}</p></div>`;
    }
  },

  async renderAdminStudentsView() {
    const container = document.getElementById("pageContent");
    try {
      const res = await API.get("/admin/students");
      container.innerHTML = `
        <div class="card">
          <div class="card-header">
            <div>
              <div class="card-title">Enrolled Students Roster</div>
              <div class="card-subtitle">Institutional student registry with division and batch assignments</div>
            </div>
            ${this.user.role === 'ADMIN' ? `<button class="btn btn-primary" onclick="App.openAddStudentModal()">+ Enroll Student</button>` : ''}
          </div>
          <div class="table-responsive">
            <table class="table">
              <thead><tr><th>Enrollment</th><th>Name</th><th>Branch</th><th>Semester</th><th>Division</th><th>Batch</th><th>Status</th></tr></thead>
              <tbody>
                ${res.students.map(s => `
                  <tr>
                    <td><strong>${s.enrollment_no}</strong></td>
                    <td>${s.full_name}</td>
                    <td>${s.branch}</td>
                    <td>Sem ${s.semester}</td>
                    <td><span class="badge badge-primary">Div ${s.division_name}</span></td>
                    <td><span class="badge badge-neutral">Batch ${s.batch_name}</span></td>
                    <td><span class="badge ${s.is_active ? 'badge-success' : 'badge-danger'}">${s.is_active ? 'Active' : 'Inactive'}</span></td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>
      `;
    } catch (err) {
      container.innerHTML = `<div class="card"><p style="color:var(--danger);">${err.message}</p></div>`;
    }
  },

  async renderAdminTimetableView() {
    const container = document.getElementById("pageContent");
    try {
      const res = await API.get("/admin/timetable");
      container.innerHTML = `
        <div class="card">
          <div class="card-header">
            <div>
              <div class="card-title">Institutional Timetable</div>
              <div class="card-subtitle">Master schedule coordinating faculty lectures and rotating QR attendance</div>
            </div>
            <button class="btn btn-primary" onclick="App.openAddTimetableModal()">+ Schedule Class</button>
          </div>
          <div class="table-responsive">
            <table class="table">
              <thead><tr><th>Day</th><th>Time</th><th>Subject</th><th>Type</th><th>Faculty</th><th>Division & Batch</th><th>Room</th><th>Action</th></tr></thead>
              <tbody>
                ${res.timetable.map(t => `
                  <tr>
                    <td><strong>${t.day_of_week}</strong></td>
                    <td>${t.start_time} – ${t.end_time}</td>
                    <td>${t.subject_name} (${t.subject_code})</td>
                    <td><span class="badge ${t.session_type === 'THEORY' ? 'badge-primary' : 'badge-warning'}">${t.session_type}</span></td>
                    <td>${t.teacher_name}</td>
                    <td>Div ${t.division_name} ${t.batch_name ? `(${t.batch_name})` : ''}</td>
                    <td>${t.room}</td>
                    <td>
                      <button class="btn btn-danger" style="padding:4px 8px; font-size:0.75rem;" onclick="App.deleteTimetableEntry(${t.id})">Delete</button>
                    </td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>
      `;
    } catch (err) {
      container.innerHTML = `<div class="card"><p style="color:var(--danger);">${err.message}</p></div>`;
    }
  },

  async renderAdminAttendanceView() {
    const container = document.getElementById("pageContent");
    try {
      const res = await API.get("/attendance/corrections");
      container.innerHTML = `
        <div class="card">
          <div class="card-header">
            <div>
              <div class="card-title">Attendance Correction Requests</div>
              <div class="card-subtitle">Faculty requested modifications with mandatory administrative audit approval</div>
            </div>
          </div>
          <div class="table-responsive">
            <table class="table">
              <thead><tr><th>Date</th><th>Student</th><th>Subject</th><th>Faculty</th><th>Requested Change</th><th>Reason</th><th>Status</th><th>Action</th></tr></thead>
              <tbody>
                ${res.corrections.length === 0 ? `<tr><td colspan="8" style="text-align:center; color:var(--text-muted);">No pending corrections.</td></tr>` :
                  res.corrections.map(c => `
                    <tr>
                      <td>${c.date}</td>
                      <td>${c.student_name} (${c.enrollment_no})</td>
                      <td>${c.subject_code}</td>
                      <td>${c.teacher_name}</td>
                      <td>${c.previous_status} → <strong>${c.requested_status}</strong></td>
                      <td>${c.reason}</td>
                      <td><span class="badge ${c.status === 'PENDING' ? 'badge-warning' : (c.status === 'APPROVED' ? 'badge-success' : 'badge-danger')}">${c.status}</span></td>
                      <td>
                        ${c.status === 'PENDING' ? `
                          <div style="display:flex; gap:6px;">
                            <button class="btn btn-success" style="padding:2px 8px; font-size:0.75rem;" onclick="App.reviewCorrection(${c.id}, 'APPROVE')">Approve</button>
                            <button class="btn btn-danger" style="padding:2px 8px; font-size:0.75rem;" onclick="App.reviewCorrection(${c.id}, 'REJECT')">Reject</button>
                          </div>
                        ` : `<span style="font-size:0.75rem; color:var(--text-muted);">${c.status}</span>`}
                      </td>
                    </tr>
                  `).join('')
                }
              </tbody>
            </table>
          </div>
        </div>
      `;
    } catch (err) {
      container.innerHTML = `<div class="card"><p style="color:var(--danger);">${err.message}</p></div>`;
    }
  },

  async renderAdminAuditView() {
    const container = document.getElementById("pageContent");
    try {
      const res = await API.get("/admin/audit-logs");
      container.innerHTML = `
        <div class="card">
          <div class="card-header">
            <div>
              <div class="card-title">Cryptographic Security Audit Trail</div>
              <div class="card-subtitle">Full immutable log of administrative and academic operations</div>
            </div>
          </div>
          <div class="table-responsive">
            <table class="table">
              <thead><tr><th>Timestamp</th><th>Action</th><th>Target</th><th>Actor</th><th>IP Address</th><th>Details</th></tr></thead>
              <tbody>
                ${res.logs.map(l => `
                  <tr>
                    <td style="font-size:0.8rem; color:var(--text-muted); white-space:nowrap;">${l.created_at}</td>
                    <td><span class="badge badge-primary">${l.action}</span></td>
                    <td>${l.target_type} #${l.target_id || ''}</td>
                    <td><strong>${l.actor_name || 'System'}</strong></td>
                    <td><code>${l.ip_address || '127.0.0.1'}</code></td>
                    <td style="font-size:0.75rem; color:var(--text-secondary); max-width:240px; overflow:hidden; text-overflow:ellipsis;">
                      ${l.details_json || '{}'}
                    </td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>
      `;
    } catch (err) {
      container.innerHTML = `<div class="card"><p style="color:var(--danger);">${err.message}</p></div>`;
    }
  },

  // ----------------------------------------------------
  // SETTINGS & APPEARANCE VIEW
  // ----------------------------------------------------
  renderSettingsView() {
    const container = document.getElementById("pageContent");
    const currentTheme = document.documentElement.getAttribute("data-theme") || "dark";
    const currentHue = localStorage.getItem("quizify_primary_hue") || "199";

    container.innerHTML = `
      <div class="grid grid-2">
        <div class="card">
          <div class="card-header">
            <div>
              <div class="card-title">Appearance & Accent Customizer</div>
              <div class="card-subtitle">Theme changes preserve exact layouts and component spacing</div>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Theme Mode</label>
            <div style="display:flex; gap:12px; margin-top:6px;">
              <button class="btn ${currentTheme === 'dark' ? 'btn-primary' : 'btn-secondary'}" onclick="ThemeManager.setTheme('dark'); App.renderSettingsView();">🌙 Dark Mode</button>
              <button class="btn ${currentTheme === 'light' ? 'btn-primary' : 'btn-secondary'}" onclick="ThemeManager.setTheme('light'); App.renderSettingsView();">☀️ Light Mode</button>
            </div>
          </div>

          <div class="form-group" style="margin-top:20px;">
            <label class="form-label">Preset Accent Colors</label>
            <div class="accent-palette-grid">
              ${ThemeManager.PRESETS.map(p => `
                <div class="accent-circle ${String(p.hue) === String(currentHue) ? 'active' : ''}"
                     style="background:${p.hex};"
                     title="${p.name}"
                     onclick="ThemeManager.setAccentHue(${p.hue}); App.renderSettingsView();">
                </div>
              `).join('')}
            </div>
          </div>

          <div class="form-group" style="margin-top:20px;">
            <label class="form-label">Custom Hex Color</label>
            <div style="display:flex; gap:12px; align-items:center;">
              <input type="color" id="customColorPicker" value="#0284c7" style="width:44px; height:44px; border:none; cursor:pointer; background:none;">
              <span style="font-size:0.85rem; color:var(--text-muted);">Pick any color; system computes dynamic HSL tokens</span>
            </div>
          </div>
        </div>

        <div class="card">
          <div class="card-header">
            <div>
              <div class="card-title">Change Password</div>
              <div class="card-subtitle">Update your account authentication credentials</div>
            </div>
          </div>
          <form id="changePwForm">
            <div class="form-group">
              <label class="form-label">Current Password</label>
              <input type="password" class="form-input" id="currPw" required>
            </div>
            <div class="form-group">
              <label class="form-label">New Password (Minimum 6 characters)</label>
              <input type="password" class="form-input" id="newPw" required minlength="6">
            </div>
            <button type="submit" class="btn btn-primary" style="margin-top:8px;">Update Password</button>
          </form>
        </div>
      </div>
    `;

    document.getElementById("customColorPicker").addEventListener("input", (e) => {
      ThemeManager.setAccentHex(e.target.value);
    });

    document.getElementById("changePwForm").addEventListener("submit", async (e) => {
      e.preventDefault();
      try {
        await API.post("/auth/change-password", {
          current_password: document.getElementById("currPw").value,
          new_password: document.getElementById("newPw").value
        });
        alert("Password successfully updated!");
        document.getElementById("changePwForm").reset();
      } catch (err) {
        alert(err.message);
      }
    });
  },

  // ----------------------------------------------------
  // CAMERA SCANNER MODAL & HELPERS
  // ----------------------------------------------------
  openCameraScannerModal() {
    const modal = document.createElement("div");
    modal.className = "modal-backdrop";
    modal.id = "cameraModal";
    modal.innerHTML = `
      <div class="modal-content" style="max-width:480px; text-align:center;">
        <h3 style="color:var(--primary); margin-bottom:4px;">Classroom QR Scanner</h3>
        <p style="color:var(--text-secondary); font-size:0.85rem; margin-bottom:16px;">Point camera at teacher's rotating QR code</p>
        
        <div class="camera-scanner-wrapper">
          <video id="scannerVideo" playsinline></video>
          <div class="scan-reticle"></div>
        </div>

        <div id="scanFeedback" style="font-size:0.85rem; color:var(--text-muted); margin-bottom:16px;">
          Initializing camera feed...
        </div>

        <button class="btn btn-secondary" onclick="QRScanner.stopCamera(); document.getElementById('cameraModal').remove();">Cancel</button>
      </div>
    `;
    document.body.appendChild(modal);

    const videoEl = document.getElementById("scannerVideo");
    QRScanner.startCamera(
      videoEl,
      (scannedVal) => {
        document.getElementById("cameraModal")?.remove();
        const parsed = QRScanner.extractTokenFromScannedUrl(scannedVal);
        if (parsed.type === "ATTENDANCE") {
          App.handleDirectAttendanceMark(parsed.token);
        } else if (parsed.type === "QUIZ") {
          App.handleDirectQuizJoin(parsed.token);
        } else {
          // Attempt raw mark
          App.handleDirectAttendanceMark(parsed.token);
        }
      },
      (err) => {
        document.getElementById("scanFeedback").textContent = err;
      }
    );
  },

  async populateAcademicDropdowns(subjId, divId, batchId = null) {
    try {
      const res = await API.get("/admin/academic-entities");
      const subjEl = document.getElementById(subjId);
      const divEl = document.getElementById(divId);
      if (subjEl) {
        subjEl.innerHTML = res.subjects.map(s => `<option value="${s.id}">${s.code} - ${s.name}</option>`).join('');
      }
      if (divEl) {
        divEl.innerHTML = res.divisions.map(d => `<option value="${d.id}">Div ${d.name} (${d.branch} Sem ${d.semester})</option>`).join('');
      }
      if (batchId) {
        const batchEl = document.getElementById(batchId);
        if (batchEl) {
          batchEl.innerHTML = `<option value="">All Division Batches</option>` + res.batches.map(b => `<option value="${b.id}">Batch ${b.name}</option>`).join('');
        }
      }
    } catch (e) {
      console.warn("Dropdown load err:", e);
    }
  }
};

window.App = App;
document.addEventListener("DOMContentLoaded", () => App.init());
