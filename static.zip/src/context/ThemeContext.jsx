import React, { createContext, useContext, useState, useEffect } from 'react';

const ThemeContext = createContext();

export const ACCENT_PRESETS = [
  { name: 'Indigo Aura', color: '#4f46e5' },
  { name: 'Cyan Neon', color: '#06b6d4' },
  { name: 'Emerald Peak', color: '#10b981' },
  { name: 'Amber Sunset', color: '#f59e0b' },
  { name: 'Rose Quantum', color: '#f43f5e' },
  { name: 'Purple Cosmic', color: '#8b5cf6' }
];

export function ThemeProvider({ children }) {
  const [theme, setTheme] = useState(() => localStorage.getItem('learnique_theme') || localStorage.getItem('quizify_theme') || 'dark');
  const [accentColor, setAccentColor] = useState(() => localStorage.getItem('learnique_accent') || localStorage.getItem('quizify_accent') || '#4f46e5');

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('learnique_theme', theme);
    localStorage.setItem('quizify_theme', theme);
  }, [theme]);

  useEffect(() => {
    // Dynamically update CSS variables
    document.documentElement.style.setProperty('--accent-primary', accentColor);
    document.documentElement.style.setProperty('--accent-hover', adjustBrightness(accentColor, -15));
    document.documentElement.style.setProperty('--accent-glow', hexToRgba(accentColor, 0.35));
    document.documentElement.style.setProperty('--accent-light', hexToRgba(accentColor, 0.12));
    document.documentElement.style.setProperty('--accent-border', hexToRgba(accentColor, 0.3));
    localStorage.setItem('learnique_accent', accentColor);
    localStorage.setItem('quizify_accent', accentColor);
  }, [accentColor]);

  function toggleTheme() {
    setTheme(prev => prev === 'dark' ? 'light' : 'dark');
  }

  return (
    <ThemeContext.Provider value={{ theme, setTheme, toggleTheme, accentColor, setAccentColor }}>
      {children}
    </ThemeContext.Provider>
  );
}

export const useTheme = () => useContext(ThemeContext);

// Utility functions for dynamic color calculation
function hexToRgba(hex, alpha) {
  let c = hex.replace('#', '');
  if (c.length === 3) c = c.split('').map(x => x + x).join('');
  const num = parseInt(c, 16);
  const r = (num >> 16) & 255;
  const g = (num >> 8) & 255;
  const b = num & 255;
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

function adjustBrightness(hex, percent) {
  let c = hex.replace('#', '');
  if (c.length === 3) c = c.split('').map(x => x + x).join('');
  let num = parseInt(c, 16);
  let r = Math.min(255, Math.max(0, ((num >> 16) & 255) + percent));
  let g = Math.min(255, Math.max(0, ((num >> 8) & 255) + percent));
  let b = Math.min(255, Math.max(0, (num & 255) + percent));
  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}
