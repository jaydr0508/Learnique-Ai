import os
import sys
from datetime import datetime, timedelta
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from backend.database.db import init_db, query_one, execute_query, get_db
from backend.auth.security import hash_password, generate_secure_token
from backend.utils.audit import log_audit

def seed_database(force: bool = False):
    init_db()
    
    # Check if admin already exists
    existing_admin = query_one("SELECT id FROM users WHERE role = 'ADMIN' LIMIT 1")
    if existing_admin and not force:
        print("[SEED] Database already contains an administrator. Skipping seeding.")
        return

    admin_login_id = os.getenv("INITIAL_ADMIN_ID", "admin")
    admin_password = os.getenv("INITIAL_ADMIN_PASSWORD", "Admin@Quizify2026")
    admin_email = os.getenv("INITIAL_ADMIN_EMAIL", "admin@quizify.edu")

    with get_db() as conn:
        cursor = conn.cursor()
        if force:
            print("[SEED] Resetting existing database tables...")
            cursor.execute("PRAGMA foreign_keys = OFF;")
            tables = [
                "quiz_answers", "quiz_attempts", "quiz_questions", "quizzes",
                "attendance_records", "qr_generations", "attendance_corrections", "attendance_sessions",
                "timetables", "teacher_assignments", "subjects", "students", "teachers",
                "batches", "divisions", "password_resets", "ai_doubt_messages",
                "ai_doubt_conversations", "audit_logs", "users"
            ]
            for t in tables:
                cursor.execute(f"DELETE FROM {t};")
            cursor.execute("PRAGMA foreign_keys = ON;")

        print("[SEED] Creating initial Administrator account...")
        cursor.execute(
            """
            INSERT INTO users (login_id, email, password_hash, role, full_name, phone, is_active)
            VALUES (?, ?, ?, 'ADMIN', ?, ?, 1)
            """,
            (admin_login_id, admin_email, hash_password(admin_password), "System Administrator", "+91 9876543210")
        )
        admin_user_id = cursor.lastrowid

        print("[SEED] Seeding Academic Divisions & Batches...")
        # Division A1 (Sem 4 CS)
        cursor.execute("INSERT INTO divisions (name, semester, branch) VALUES ('A1', 4, 'Computer Science')")
        div_a1_id = cursor.lastrowid
        cursor.execute("INSERT INTO batches (division_id, name) VALUES (?, 'B1')", (div_a1_id,))
        batch_a1_b1 = cursor.lastrowid
        cursor.execute("INSERT INTO batches (division_id, name) VALUES (?, 'B2')", (div_a1_id,))
        batch_a1_b2 = cursor.lastrowid
        cursor.execute("INSERT INTO batches (division_id, name) VALUES (?, 'B3')", (div_a1_id,))
        batch_a1_b3 = cursor.lastrowid

        # Division A2 (Sem 4 CS)
        cursor.execute("INSERT INTO divisions (name, semester, branch) VALUES ('A2', 4, 'Computer Science')")
        div_a2_id = cursor.lastrowid
        cursor.execute("INSERT INTO batches (division_id, name) VALUES (?, 'B1')", (div_a2_id,))
        batch_a2_b1 = cursor.lastrowid
        cursor.execute("INSERT INTO batches (division_id, name) VALUES (?, 'B2')", (div_a2_id,))
        batch_a2_b2 = cursor.lastrowid
        cursor.execute("INSERT INTO batches (division_id, name) VALUES (?, 'B3')", (div_a2_id,))
        batch_a2_b3 = cursor.lastrowid

        # Division H1 (Sem 4 IT)
        cursor.execute("INSERT INTO divisions (name, semester, branch) VALUES ('H1', 4, 'Information Technology')")
        div_h1_id = cursor.lastrowid
        cursor.execute("INSERT INTO batches (division_id, name) VALUES (?, 'B1')", (div_h1_id,))
        batch_h1_b1 = cursor.lastrowid
        cursor.execute("INSERT INTO batches (division_id, name) VALUES (?, 'B2')", (div_h1_id,))
        batch_h1_b2 = cursor.lastrowid

        print("[SEED] Seeding Academic Subjects...")
        subjects_data = [
            ("CS401", "Data Structures & Algorithms", 4, "Computer Science", 1, 1),
            ("CEP402", "Comprehensive English Proficiency", 4, "Humanities", 1, 1),
            ("CS403", "Database Management Systems", 4, "Computer Science", 1, 1),
            ("CS404", "Operating Systems", 4, "Computer Science", 1, 1)
        ]
        subject_map = {}
        for code, name, sem, dept, has_th, has_pr in subjects_data:
            cursor.execute(
                "INSERT INTO subjects (code, name, semester, department, has_theory, has_practical) VALUES (?, ?, ?, ?, ?, ?)",
                (code, name, sem, dept, has_th, has_pr)
            )
            subject_map[code] = cursor.lastrowid

        print("[SEED] Seeding Teachers...")
        # Teacher 1: Prof. Rajesh Sharma
        cursor.execute(
            """
            INSERT INTO users (login_id, email, password_hash, role, full_name, phone, is_active)
            VALUES ('TCH101', 'sharma@university.edu', ?, 'TEACHER', 'Prof. Rajesh Sharma', '+91 9811122233', 1)
            """,
            (hash_password("Teacher@123"),)
        )
        t1_user_id = cursor.lastrowid
        cursor.execute(
            "INSERT INTO teachers (user_id, employee_code, department, designation) VALUES (?, 'EMP-CS-101', 'Computer Science', 'Associate Professor')",
            (t1_user_id,)
        )
        teacher_sharma_id = cursor.lastrowid

        # Teacher 2: Dr. Priya Patel
        cursor.execute(
            """
            INSERT INTO users (login_id, email, password_hash, role, full_name, phone, is_active)
            VALUES ('TCH102', 'priya@university.edu', ?, 'TEACHER', 'Dr. Priya Patel', '+91 9822233344', 1)
            """,
            (hash_password("Teacher@123"),)
        )
        t2_user_id = cursor.lastrowid
        cursor.execute(
            "INSERT INTO teachers (user_id, employee_code, department, designation) VALUES (?, 'EMP-HUM-102', 'Humanities', 'Assistant Professor')",
            (t2_user_id,)
        )
        teacher_priya_id = cursor.lastrowid

        print("[SEED] Assigning Subjects & Divisions to Teachers...")
        # Prof. Sharma -> CS401 (Div A1: B1, B2, B3) & CS403 (Div A1: all batches)
        cursor.execute("INSERT INTO teacher_assignments (teacher_id, subject_id, division_id, batch_id) VALUES (?, ?, ?, ?)", (teacher_sharma_id, subject_map["CS401"], div_a1_id, batch_a1_b1))
        cursor.execute("INSERT INTO teacher_assignments (teacher_id, subject_id, division_id, batch_id) VALUES (?, ?, ?, ?)", (teacher_sharma_id, subject_map["CS401"], div_a1_id, batch_a1_b2))
        cursor.execute("INSERT INTO teacher_assignments (teacher_id, subject_id, division_id, batch_id) VALUES (?, ?, ?, ?)", (teacher_sharma_id, subject_map["CS401"], div_a1_id, batch_a1_b3))
        cursor.execute("INSERT INTO teacher_assignments (teacher_id, subject_id, division_id, batch_id) VALUES (?, ?, ?, NULL)", (teacher_sharma_id, subject_map["CS403"], div_a1_id))

        # Dr. Priya -> CEP402 (Div A1: all batches; Div A2: B1, B2) & CS404
        cursor.execute("INSERT INTO teacher_assignments (teacher_id, subject_id, division_id, batch_id) VALUES (?, ?, ?, NULL)", (teacher_priya_id, subject_map["CEP402"], div_a1_id))
        cursor.execute("INSERT INTO teacher_assignments (teacher_id, subject_id, division_id, batch_id) VALUES (?, ?, ?, ?)", (teacher_priya_id, subject_map["CEP402"], div_a2_id, batch_a2_b1))
        cursor.execute("INSERT INTO teacher_assignments (teacher_id, subject_id, division_id, batch_id) VALUES (?, ?, ?, ?)", (teacher_priya_id, subject_map["CEP402"], div_a2_id, batch_a2_b2))
        cursor.execute("INSERT INTO teacher_assignments (teacher_id, subject_id, division_id, batch_id) VALUES (?, ?, ?, NULL)", (teacher_priya_id, subject_map["CS404"], div_a1_id))

        print("[SEED] Seeding Students...")
        students_raw = [
            ("STU2026001", "rahul@student.university.edu", "Rahul Sharma", "Male", "2004-05-14", div_a1_id, batch_a1_b1),
            ("STU2026002", "ananya@student.university.edu", "Ananya Iyer", "Female", "2004-09-22", div_a1_id, batch_a1_b1),
            ("STU2026003", "vikram@student.university.edu", "Vikram Singh", "Male", "2004-01-30", div_a1_id, batch_a1_b2),
            ("STU2026004", "sneha@student.university.edu", "Sneha Reddy", "Female", "2004-11-12", div_a1_id, batch_a1_b3),
            ("STU2026005", "aditya@student.university.edu", "Aditya Verma", "Male", "2004-03-18", div_a2_id, batch_a2_b1)
        ]
        student_records = []
        for enr, email, name, gender, dob, div_id, b_id in students_raw:
            cursor.execute(
                """
                INSERT INTO users (login_id, email, password_hash, role, full_name, phone, is_active)
                VALUES (?, ?, ?, 'STUDENT', ?, '+91 9988776655', 1)
                """,
                (enr, email, hash_password("Student@123"), name)
            )
            u_id = cursor.lastrowid
            cursor.execute(
                """
                INSERT INTO students (user_id, enrollment_no, branch, semester, gender, dob, division_id, batch_id)
                VALUES (?, ?, 'Computer Science', 4, ?, ?, ?, ?)
                """,
                (u_id, enr, gender, dob, div_id, b_id)
            )
            student_records.append((cursor.lastrowid, enr, name, div_id, b_id))

        rahul_student_id = student_records[0][0]

        print("[SEED] Seeding Timetable Entries...")
        # Today's day name (Monday-Sunday)
        days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
        for d in days:
            # 10:00 - 10:50 CEP402 Theory EA-511 (Dr. Priya)
            cursor.execute(
                """
                INSERT INTO timetables (academic_year, semester, day_of_week, start_time, end_time, teacher_id, subject_id, session_type, division_id, batch_id, room, building)
                VALUES ('2026-2027', 4, ?, '10:00', '10:50', ?, ?, 'THEORY', ?, NULL, 'EA-511', 'Main Academic Complex')
                """,
                (d, teacher_priya_id, subject_map["CEP402"], div_a1_id)
            )
            # 11:00 - 12:40 CS401 Practical Lab-302 (Prof. Sharma, Batch B1)
            cursor.execute(
                """
                INSERT INTO timetables (academic_year, semester, day_of_week, start_time, end_time, teacher_id, subject_id, session_type, division_id, batch_id, room, building)
                VALUES ('2026-2027', 4, ?, '11:00', '12:40', ?, ?, 'PRACTICAL', ?, ?, 'Lab-302', 'Computer Science Wing')
                """,
                (d, teacher_sharma_id, subject_map["CS401"], div_a1_id, batch_a1_b1)
            )
            # 14:00 - 14:50 CS403 Theory EA-511 (Prof. Sharma)
            cursor.execute(
                """
                INSERT INTO timetables (academic_year, semester, day_of_week, start_time, end_time, teacher_id, subject_id, session_type, division_id, batch_id, room, building)
                VALUES ('2026-2027', 4, ?, '14:00', '14:50', ?, ?, 'THEORY', ?, NULL, 'EA-511', 'Main Academic Complex')
                """,
                (d, teacher_sharma_id, subject_map["CS403"], div_a1_id)
            )

        print("[SEED] Seeding Historical Attendance Records for Exact Calculations...")
        # As per specification:
        # CEP402 Theory: Total = 9, Present = 5, Absent = 4 (55.56%)
        # CEP402 Practical: Total = 4, Present = 3, Absent = 1 (75.00%)
        # Overall: Total = 13, Present = 8, Absent = 5 (61.54%)!
        
        base_date = datetime.now() - timedelta(days=20)
        # 9 Theory Sessions
        theory_session_ids = []
        for i in range(9):
            s_date = (base_date + timedelta(days=i)).strftime("%Y-%m-%d")
            cursor.execute(
                """
                INSERT INTO attendance_sessions (
                    teacher_id, attendance_type, subject_id, division_id, batch_id, semester, session_type,
                    room, date, scheduled_start, scheduled_end, status
                ) VALUES (?, 'REGULAR', ?, ?, NULL, 4, 'THEORY', 'EA-511', ?, '10:00', '10:50', 'COMPLETED')
                """,
                (teacher_priya_id, subject_map["CEP402"], div_a1_id, s_date)
            )
            theory_session_ids.append(cursor.lastrowid)

        # 4 Practical Sessions
        practical_session_ids = []
        for i in range(4):
            s_date = (base_date + timedelta(days=i*2)).strftime("%Y-%m-%d")
            cursor.execute(
                """
                INSERT INTO attendance_sessions (
                    teacher_id, attendance_type, subject_id, division_id, batch_id, semester, session_type,
                    room, date, scheduled_start, scheduled_end, status
                ) VALUES (?, 'REGULAR', ?, ?, ?, 4, 'PRACTICAL', 'Lab-302', ?, '11:00', '12:40', 'COMPLETED')
                """,
                (teacher_priya_id, subject_map["CEP402"], div_a1_id, batch_a1_b1, s_date)
            )
            practical_session_ids.append(cursor.lastrowid)

        # Mark Rahul Sharma: 5 present in theory (first 5), 4 absent (last 4)
        for idx, sess_id in enumerate(theory_session_ids):
            status = 'PRESENT' if idx < 5 else 'ABSENT'
            cursor.execute(
                "INSERT INTO attendance_records (session_id, student_id, status, verification_method) VALUES (?, ?, ?, 'QR')",
                (sess_id, rahul_student_id, status)
            )

        # Mark Rahul Sharma: 3 present in practical (first 3), 1 absent (last 1)
        for idx, sess_id in enumerate(practical_session_ids):
            status = 'PRESENT' if idx < 3 else 'ABSENT'
            cursor.execute(
                "INSERT INTO attendance_records (session_id, student_id, status, verification_method) VALUES (?, ?, ?, 'QR')",
                (sess_id, rahul_student_id, status)
            )

        print("[SEED] Seeding Sample Production Quiz with MCQ, Numerical & Answer Type...")
        now = datetime.now()
        quiz_start = (now - timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S")
        quiz_end = (now + timedelta(days=2)).strftime("%Y-%m-%d %H:%M:%S")
        quiz_release = (now + timedelta(days=2, hours=1)).strftime("%Y-%m-%d %H:%M:%S")
        join_tok = generate_secure_token(16)

        cursor.execute(
            """
            INSERT INTO quizzes (
                code, join_token, title, teacher_id, subject_id, division_id, batch_id,
                topic, instructions, duration_minutes, start_time, end_time, result_release_time,
                total_marks, passing_marks, max_tab_switches, attendance_requirement_type,
                linked_attendance_session_id, min_attendance_percentage, status
            ) VALUES (
                'QZ-2026-CEP1', ?, 'CEP Unit 1 - Syntax & Analysis Quiz', ?, ?, ?, NULL,
                'Formal Grammar & Logical Analysis', 'Solve all questions within the allocated time. Tab switching is strictly monitored.',
                25, ?, ?, ?, 10.0, 4.0, 3, 'LINKED_SESSION', ?, 0, 'ACTIVE'
            )
            """,
            (join_tok, teacher_priya_id, subject_map["CEP402"], div_a1_id, quiz_start, quiz_end, quiz_release, theory_session_ids[0])
        )
        sample_quiz_id = cursor.lastrowid

        # Questions for Sample Quiz:
        # Question 1: MCQ (Easy, 2 marks)
        cursor.execute(
            """
            INSERT INTO quiz_questions (quiz_id, question_order, question_type, question_text, options_json, correct_answer, explanation, difficulty, marks)
            VALUES (?, 1, 'MCQ', 'Identify the passive voice construction of: \"The team analyzed the critical dataset yesterday.\"',
            '[\"The critical dataset was analyzed by the team yesterday.\", \"The critical dataset had analyzed by the team.\", \"Yesterday the team has analyzed the dataset.\", \"The dataset is being analyzed by the team.\"]',
            'The critical dataset was analyzed by the team yesterday.',
            'Passive voice in simple past takes was/were + past participle (was analyzed).', 'EASY', 2.0)
            """,
            (sample_quiz_id,)
        )

        # Question 2: Numerical (Medium, 3 marks)
        cursor.execute(
            """
            INSERT INTO quiz_questions (quiz_id, question_order, question_type, question_text, options_json, correct_answer, explanation, difficulty, marks, numerical_tolerance)
            VALUES (?, 2, 'NUMERICAL', 'A text passage contains 480 words and 24 complex sentences. Calculate the average words per sentence with high precision.',
            NULL, '20.0', 'Total words (480) divided by total sentences (24) equals exactly 20.0.', 'MEDIUM', 3.0, 0.05)
            """,
            (sample_quiz_id,)
        )

        # Question 3: Answer Type (Hard, 5 marks)
        cursor.execute(
            """
            INSERT INTO quiz_questions (quiz_id, question_order, question_type, question_text, options_json, correct_answer, explanation, difficulty, marks, rubric_text)
            VALUES (?, 3, 'ANSWER_TYPE', 'Explain the difference between coherence and cohesion in technical academic writing with two concrete examples.',
            NULL, 'Cohesion refers to grammatical and lexical links at the sentence level, while coherence refers to the overall semantic clarity and logical flow of ideas throughout the document.',
            'Coherence = macroscopic idea connectivity; Cohesion = microscopic syntactic glue.', 'HARD', 5.0,
            '3 marks for distinguishing definitions; 2 marks for relevant technical examples.')
            """,
            (sample_quiz_id,)
        )

        # Audit initial seed directly in same cursor transaction
        cursor.execute(
            """
            INSERT INTO audit_logs (actor_user_id, actor_name, action, target_type, target_id, details_json, ip_address, created_at)
            VALUES (?, 'System Administrator', 'DATABASE_SEEDED', 'SYSTEM', 'DATABASE', '{\"status\": \"SUCCESS\"}', '127.0.0.1', datetime('now'))
            """,
            (admin_user_id,)
        )

    print("[SEED] Successfully seeded complete Quizify database!")
    print(f"[SEED] Initial Administrator: {admin_login_id} (Password: [configured via environment])")
    print("[SEED] Seeded Teachers: TCH101, TCH102")
    print("[SEED] Seeded Students: STU2026001 through STU2026005")

if __name__ == "__main__":
    force_flag = "--force" in sys.argv
    seed_database(force=force_flag)
