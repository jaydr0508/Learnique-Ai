// IN-BROWSER CAMERA QR SCANNER & URL DECODER
const QRScanner = {
  stream: null,
  videoElement: null,
  animFrameId: null,
  barcodeDetector: null,

  async init() {
    if ('BarcodeDetector' in window) {
      try {
        const formats = await BarcodeDetector.getSupportedFormats();
        if (formats.includes('qr_code')) {
          this.barcodeDetector = new BarcodeDetector({ formats: ['qr_code'] });
        }
      } catch (e) {
        console.warn('BarcodeDetector initialization skipped:', e);
      }
    }
  },

  async startCamera(videoElement, onScanSuccess, onScanError) {
    this.videoElement = videoElement;
    await this.init();

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      if (onScanError) onScanError("Camera access not supported on this browser.");
      return;
    }

    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment", width: { ideal: 640 }, height: { ideal: 480 } }
      });
      videoElement.srcObject = this.stream;
      await videoElement.play();

      this.scanLoop(onScanSuccess);
    } catch (err) {
      console.error("Camera permission denied or unavailable:", err);
      if (onScanError) onScanError("Camera permission was denied or device has no camera.");
    }
  },

  scanLoop(onScanSuccess) {
    if (!this.stream || !this.videoElement) return;

    if (this.barcodeDetector && this.videoElement.readyState === this.videoElement.HAVE_ENOUGH_DATA) {
      this.barcodeDetector.detect(this.videoElement)
        .then(barcodes => {
          if (barcodes.length > 0) {
            const rawValue = barcodes[0].rawValue;
            this.stopCamera();
            if (onScanSuccess) onScanSuccess(rawValue);
          } else {
            this.animFrameId = requestAnimationFrame(() => this.scanLoop(onScanSuccess));
          }
        })
        .catch(() => {
          this.animFrameId = requestAnimationFrame(() => this.scanLoop(onScanSuccess));
        });
    } else {
      this.animFrameId = requestAnimationFrame(() => this.scanLoop(onScanSuccess));
    }
  },

  stopCamera() {
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = null;
    }
    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop());
      this.stream = null;
    }
  },

  extractTokenFromScannedUrl(scannedUrl) {
    // Check for Quizify attendance or quiz URLs
    // e.g. http://192.168.1.15:5000/join/attendance/<token>
    // e.g. http://domain.com/join/quiz/<token>
    try {
      if (scannedUrl.includes("/join/attendance/")) {
        const parts = scannedUrl.split("/join/attendance/");
        return { type: "ATTENDANCE", token: parts[1].split("?")[0].trim() };
      }
      if (scannedUrl.includes("/join/quiz/")) {
        const parts = scannedUrl.split("/join/quiz/");
        return { type: "QUIZ", token: parts[1].split("?")[0].trim() };
      }
      // Direct token string
      if (scannedUrl.length > 10 && !scannedUrl.includes(" ")) {
        return { type: "UNKNOWN", token: scannedUrl.trim() };
      }
    } catch (e) {
      console.warn("URL parse error:", e);
    }
    return { type: "RAW", token: scannedUrl };
  }
};
