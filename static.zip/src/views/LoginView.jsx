import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { Lock, User, ArrowRight, ShieldCheck, KeyRound, AlertCircle, Moon, Sun, Palette, ArrowLeft, Eye, EyeOff } from 'lucide-react';
import ColorPickerModal from '../components/ColorPickerModal';
import { useNotifications } from '../context/NotificationContext';

export default function LoginView({ onBackToHome, onLoginSuccess }) {
  const { login } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const { notify } = useNotifications();

  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Forgot password modal state
  const [forgotModalOpen, setForgotModalOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotStatus, setForgotStatus] = useState(null);
  const [forgotLoading, setForgotLoading] = useState(false);

  // Reset password modal state (from reset token link)
  const [resetTokenInput, setResetTokenInput] = useState('');
  const [newPasswordInput, setNewPasswordInput] = useState('');
  const [showResetPassword, setShowResetPassword] = useState(false);
  const [resetSuccessMsg, setResetSuccessMsg] = useState('');

  // Theme modal
  const [colorPickerOpen, setColorPickerOpen] = useState(false);

  async function handleLogin(e) {
    e.preventDefault();
    if (!identifier.trim() || !password) {
      setError('Please enter your identifier and password.');
      return;
    }
    setError('');
    setLoading(true);

    try {
      const loggedUser = await login(identifier.trim(), password);
      notify(`Welcome back, ${loggedUser?.name || 'Administrator'}!`, 'success');
      if (onLoginSuccess) {
        onLoginSuccess(loggedUser);
      }
    } catch (err) {
      setError(err.message || 'Invalid login credentials.');
    } finally {
      setLoading(false);
    }
  }

  async function handleForgotPassword(e) {
    e.preventDefault();
    if (!forgotEmail.trim()) return;
    setForgotLoading(true);
    setForgotStatus(null);
    setResetSuccessMsg('');

    try {
      const res = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: forgotEmail.trim() })
      });
      const data = await res.json();
      setForgotStatus({
        success: true,
        message: data.message,
        devToken: data.devToken
      });
      if (data.devToken) {
        setResetTokenInput(data.devToken);
      }
    } catch (err) {
      setForgotStatus({ success: false, message: 'Failed to process request.' });
    } finally {
      setForgotLoading(false);
    }
  }

  async function handleResetPassword(e) {
    e.preventDefault();
    if (!resetTokenInput.trim() || !newPasswordInput || newPasswordInput.length < 8) {
      notify('Valid token and minimum 8-character password required.', 'warning');
      return;
    }
    try {
      const res = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token: resetTokenInput.trim(),
          newPassword: newPasswordInput
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setResetSuccessMsg(data.message || 'Password successfully updated! You can now log in.');
      setForgotStatus(null);
      setResetTokenInput('');
      setNewPasswordInput('');
      notify('Password successfully reset! You can now log in.', 'success');
    } catch (err) {
      notify(err.message, 'error');
    }
  }

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '24px',
      position: 'relative'
    }}>
      {/* Top Left: Back to Home */}
      {onBackToHome && (
        <div style={{ position: 'absolute', top: '24px', left: '24px' }}>
          <button
            onClick={onBackToHome}
            className="btn-secondary"
            style={{ padding: '8px 14px', borderRadius: '10px', fontSize: '0.85rem', display: 'flex', alignItems: 'center', gap: '6px' }}
          >
            <ArrowLeft size={16} /> Back to Home
          </button>
        </div>
      )}

      {/* Top Controls: Theme & Color */}
      <div style={{ position: 'absolute', top: '24px', right: '24px', display: 'flex', gap: '10px' }}>
        <button
          onClick={() => setColorPickerOpen(true)}
          className="btn-secondary"
          title="Customize Theme Color"
          style={{ padding: '8px 12px', borderRadius: '10px' }}
        >
          <Palette size={18} style={{ color: 'var(--accent-primary)' }} />
        </button>
        <button
          onClick={toggleTheme}
          className="btn-secondary"
          title="Toggle Light/Dark Mode"
          style={{ padding: '8px 12px', borderRadius: '10px' }}
        >
          {theme === 'dark' ? <Sun size={18} style={{ color: '#f59e0b' }} /> : <Moon size={18} style={{ color: '#6366f1' }} />}
        </button>
      </div>

      {/* Main Glassmorphic Login Card */}
      <div className="glass-panel animate-fade-in" style={{
        width: '460px',
        maxWidth: '100%',
        padding: '44px 38px',
        borderRadius: '24px',
        position: 'relative',
        boxShadow: '0 20px 50px rgba(0, 0, 0, 0.4), var(--shadow-glow)'
      }}>
        {/* Header with logo */}
        <div style={{ textAlign: 'center', marginBottom: '32px' }}>
          <div style={{
            width: '58px',
            height: '58px',
            margin: '0 auto 16px',
            borderRadius: '18px',
            background: 'linear-gradient(135deg, var(--accent-primary), var(--accent-hover))',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: '0 8px 24px var(--accent-glow)'
          }}>
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 2L2 7l10 5 10-5-10-5z" />
              <path d="M2 17l10 5 10-5" />
              <path d="M2 12l10 5 10-5" />
            </svg>
          </div>
          <h1 style={{ fontSize: '1.85rem', fontWeight: '800', letterSpacing: '-0.03em', marginBottom: '6px' }}>
            Learnique AI
          </h1>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.875rem' }}>
            Academic Examination & Attendance Portal
          </p>
        </div>

        {/* Error Alert */}
        {error && (
          <div style={{
            background: 'rgba(239, 68, 68, 0.12)',
            border: '1px solid rgba(239, 68, 68, 0.3)',
            borderRadius: '10px',
            padding: '12px 14px',
            display: 'flex',
            alignItems: 'center',
            gap: '10px',
            color: '#ef4444',
            fontSize: '0.85rem',
            marginBottom: '20px'
          }}>
            <AlertCircle size={18} style={{ flexShrink: 0 }} />
            <span>{error}</span>
          </div>
        )}

        {/* Single Unified Login Form */}
        <form onSubmit={handleLogin} style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          <div>
            <label style={{ fontSize: '0.825rem', fontWeight: '600', color: 'var(--text-secondary)', display: 'block', marginBottom: '8px' }}>
              Account Identifier
            </label>
            <div style={{ position: 'relative' }}>
              <input
                type="text"
                className="input-field"
                placeholder="Login ID"
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                autoComplete="off"
                required
                style={{ paddingLeft: '42px', fontSize: '0.9rem' }}
              />
              <User size={18} style={{ position: 'absolute', left: '14px', top: '13px', color: 'var(--text-muted)' }} />
            </div>
          </div>

          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
              <label style={{ fontSize: '0.825rem', fontWeight: '600', color: 'var(--text-secondary)' }}>
                Password
              </label>
              <button
                type="button"
                onClick={() => setForgotModalOpen(true)}
                style={{
                  background: 'none',
                  border: 'none',
                  color: 'var(--accent-primary)',
                  fontSize: '0.785rem',
                  fontWeight: '600',
                  cursor: 'pointer'
                }}
              >
                Forgot Password?
              </button>
            </div>
            <div style={{ position: 'relative' }}>
              <input
                type={showPassword ? 'text' : 'password'}
                className="input-field"
                placeholder="Enter password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="off"
                required
                style={{ paddingLeft: '42px', paddingRight: '42px', fontSize: '0.9rem' }}
              />
              <Lock size={18} style={{ position: 'absolute', left: '14px', top: '13px', color: 'var(--text-muted)' }} />
              <button
                type="button"
                onClick={() => setShowPassword(prev => !prev)}
                aria-label={showPassword ? 'Hide password' : 'Show password'}
                title={showPassword ? 'Hide password' : 'Show password'}
                style={{
                  position: 'absolute',
                  right: '12px',
                  top: '50%',
                  transform: 'translateY(-50%)',
                  background: 'none',
                  border: 'none',
                  cursor: 'pointer',
                  color: showPassword ? 'var(--accent-primary)' : 'var(--text-muted)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  padding: '4px',
                  borderRadius: '6px',
                  transition: 'color 0.15s ease'
                }}
              >
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            className="btn-primary"
            disabled={loading}
            style={{ width: '100%', padding: '13px', marginTop: '6px', fontSize: '0.95rem' }}
          >
            {loading ? (
              <span>Authenticating...</span>
            ) : (
              <>
                <span>Sign In to Learnique AI</span>
                <ArrowRight size={18} />
              </>
            )}
          </button>
        </form>

        <div style={{
          marginTop: '26px',
          paddingTop: '18px',
          borderTop: '1px solid var(--border-subtle)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '8px',
          color: 'var(--text-muted)',
          fontSize: '0.75rem'
        }}>
          <ShieldCheck size={16} style={{ color: 'var(--success)' }} />
          <span>Automated Role Detection (Admin • Faculty • Student)</span>
        </div>
      </div>

      {/* Forgot / Reset Password Modal */}
      {forgotModalOpen && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100vw',
          height: '100vh',
          background: 'rgba(0, 0, 0, 0.7)',
          backdropFilter: 'blur(8px)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 9999
        }}>
          <div className="glass-panel" style={{ width: '440px', maxWidth: '90%', padding: '30px', borderRadius: '22px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '16px' }}>
              <KeyRound size={22} style={{ color: 'var(--accent-primary)' }} />
              <h3 style={{ fontSize: '1.25rem', fontWeight: '700' }}>Password Recovery</h3>
            </div>

            {resetSuccessMsg ? (
              <div style={{
                background: 'rgba(16, 185, 129, 0.15)',
                border: '1px solid rgba(16, 185, 129, 0.3)',
                color: '#10b981',
                padding: '16px',
                borderRadius: '12px',
                marginBottom: '18px',
                fontSize: '0.875rem'
              }}>
                <div>{resetSuccessMsg}</div>
                <button
                  type="button"
                  onClick={() => { setForgotModalOpen(false); setResetSuccessMsg(''); }}
                  className="btn-primary"
                  style={{ width: '100%', marginTop: '14px', padding: '10px' }}
                >
                  Return to Login
                </button>
              </div>
            ) : (
              <>
                <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem', marginBottom: '18px' }}>
                  Enter your registered institutional email address. If an account matches, a secure one-time reset token will be issued.
                </p>

                {forgotStatus && (
                  <div style={{
                    background: forgotStatus.success ? 'rgba(16, 185, 129, 0.12)' : 'rgba(239, 68, 68, 0.12)',
                    border: `1px solid ${forgotStatus.success ? 'rgba(16, 185, 129, 0.3)' : 'rgba(239, 68, 68, 0.3)'}`,
                    color: forgotStatus.success ? '#10b981' : '#ef4444',
                    padding: '12px',
                    borderRadius: '10px',
                    fontSize: '0.825rem',
                    marginBottom: '16px'
                  }}>
                    <div>{forgotStatus.message}</div>
                    {forgotStatus.devToken && (
                      <div style={{ marginTop: '8px', fontFamily: 'var(--font-mono)', fontSize: '0.75rem', wordBreak: 'break-all' }}>
                        <strong>Generated Token:</strong> {forgotStatus.devToken}
                      </div>
                    )}
                  </div>
                )}

                <form onSubmit={handleForgotPassword} style={{ display: 'flex', flexDirection: 'column', gap: '12px', marginBottom: '18px' }}>
                  <input
                    type="email"
                    className="input-field"
                    placeholder="Enter registered email"
                    value={forgotEmail}
                    onChange={(e) => setForgotEmail(e.target.value)}
                    required
                  />
                  <button type="submit" className="btn-primary" disabled={forgotLoading}>
                    {forgotLoading ? 'Generating Reset Token...' : 'Generate Reset Token'}
                  </button>
                </form>

                {/* Direct Password Reset Form using Token */}
                <div style={{ paddingTop: '16px', borderTop: '1px solid var(--border-subtle)' }}>
                  <h4 style={{ fontSize: '0.85rem', fontWeight: '700', marginBottom: '10px', color: 'var(--text-secondary)' }}>
                    Already have a token? Set New Password:
                  </h4>
                  <form onSubmit={handleResetPassword} style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                    <input
                      type="text"
                      className="input-field"
                      placeholder="Paste reset token here"
                      value={resetTokenInput}
                      onChange={(e) => setResetTokenInput(e.target.value)}
                      required
                    />
                    <div style={{ position: 'relative' }}>
                      <input
                        type={showResetPassword ? 'text' : 'password'}
                        className="input-field"
                        placeholder="Enter new password (min 8 chars)"
                        value={newPasswordInput}
                        onChange={(e) => setNewPasswordInput(e.target.value)}
                        required
                        style={{ paddingRight: '42px' }}
                      />
                      <button
                        type="button"
                        onClick={() => setShowResetPassword(prev => !prev)}
                        aria-label={showResetPassword ? 'Hide password' : 'Show password'}
                        title={showResetPassword ? 'Hide password' : 'Show password'}
                        style={{
                          position: 'absolute',
                          right: '12px',
                          top: '50%',
                          transform: 'translateY(-50%)',
                          background: 'none',
                          border: 'none',
                          cursor: 'pointer',
                          color: showResetPassword ? 'var(--accent-primary)' : 'var(--text-muted)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          padding: '4px',
                          borderRadius: '6px'
                        }}
                      >
                        {showResetPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                      </button>
                    </div>
                    <button type="submit" className="btn-secondary" style={{ padding: '9px' }}>
                      Update Password Now
                    </button>
                  </form>
                </div>

                <div style={{ marginTop: '16px', textAlign: 'right' }}>
                  <button type="button" className="btn-secondary" onClick={() => setForgotModalOpen(false)}>
                    Close
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      <ColorPickerModal isOpen={colorPickerOpen} onClose={() => setColorPickerOpen(false)} />
    </div>
  );
}
