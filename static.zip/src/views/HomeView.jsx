import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNotifications } from '../context/NotificationContext';
import { 
  Calendar, Video, PlusCircle, Activity, Bell, Award, 
  ArrowRight, Users, Sparkles, MapPin, Clock, ShieldCheck, 
  ChevronRight, Play, CheckCircle2, Copy, Search, LogIn, ExternalLink
} from 'lucide-react';

export default function HomeView({ onNavigate, onOpenSchedule, onRegisterEvent, onViewEventDetail, onJoinMeetingWithCode }) {
  const { user, token } = useAuth();
  const { notify } = useNotifications();

  const [overview, setOverview] = useState(null);
  const [loading, setLoading] = useState(true);
  const [meetingCodeInput, setMeetingCodeInput] = useState('');
  const [startingInstant, setStartingInstant] = useState(false);

  useEffect(() => {
    fetchOverview();
  }, [token]);

  const fetchOverview = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/home/overview', {
        headers: token ? { Authorization: `Bearer ${token}` } : {}
      });
      const data = await res.json();
      setOverview(data);
    } catch (err) {
      console.error('Error fetching home overview:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleStartInstantMeeting = async () => {
    try {
      setStartingInstant(true);
      const res = await fetch('/api/meetings/instant', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify({
          title: `${user?.name || 'Instant'} Live Collaboration Room`
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to start meeting');

      notify(`Instant meeting created: ${data.meeting.code}`, 'success');
      if (onJoinMeetingWithCode) {
        onJoinMeetingWithCode(data.meeting.code);
      }
    } catch (err) {
      notify(err.message, 'danger');
    } finally {
      setStartingInstant(false);
    }
  };

  const handleJoinByCodeSubmit = (e) => {
    e.preventDefault();
    const clean = meetingCodeInput.trim().toLowerCase();
    if (!clean) {
      notify('Please enter a meeting code', 'warning');
      return;
    }
    if (onJoinMeetingWithCode) {
      onJoinMeetingWithCode(clean);
    }
  };

  return (
    <div style={{ maxWidth: '1280px', margin: '0 auto', padding: '10px 20px 60px 20px', display: 'flex', flexDirection: 'column', gap: '48px' }}>
      {/* =========================================================================
          HERO SECTION
          ========================================================================= */}
      <section style={{
        position: 'relative',
        borderRadius: '24px',
        padding: '56px 40px',
        background: 'linear-gradient(135deg, rgba(79, 70, 229, 0.12) 0%, rgba(6, 182, 212, 0.08) 100%)',
        border: '1px solid var(--border-glass)',
        overflow: 'hidden',
        boxShadow: 'var(--shadow-card)'
      }}>
        {/* Subtle decorative glow orb */}
        <div style={{
          position: 'absolute',
          top: '-80px',
          right: '-80px',
          width: '320px',
          height: '320px',
          borderRadius: '50%',
          background: 'radial-gradient(circle, var(--accent-glow) 0%, transparent 70%)',
          pointerEvents: 'none'
        }} />

        <div style={{ maxWidth: '780px', position: 'relative', zIndex: 2 }}>
          {/* Tagline pill */}
          <div style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '8px',
            padding: '6px 14px',
            borderRadius: '20px',
            background: 'var(--accent-light)',
            border: '1px solid var(--accent-border)',
            fontSize: '0.82rem',
            fontWeight: '700',
            color: 'var(--accent-primary)',
            marginBottom: '20px'
          }}>
            <Sparkles size={14} /> The Central Collaboration & Academic Hub
          </div>

          <h1 style={{
            fontSize: 'clamp(2.2rem, 4.5vw, 3.4rem)',
            fontWeight: '800',
            lineHeight: 1.15,
            letterSpacing: '-0.03em',
            marginBottom: '18px',
            color: 'var(--text-primary)'
          }}>
            Everything You Need to Learn, Connect, and Organize.
          </h1>

          <p style={{
            fontSize: '1.15rem',
            color: 'var(--text-secondary)',
            lineHeight: 1.6,
            marginBottom: '32px'
          }}>
            Discover upcoming events, organize activities, join virtual classrooms, and collaborate with your community from one central platform.
          </p>

          {/* Hero CTAs */}
          <div className="hero-buttons-group" style={{ display: 'flex', flexWrap: 'wrap', gap: '14px', alignItems: 'center' }}>
            <button
              onClick={() => onNavigate('events')}
              className="btn-primary"
              style={{
                padding: '13px 26px',
                borderRadius: '12px',
                fontSize: '0.98rem',
                fontWeight: '700',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '8px'
              }}
            >
              <Calendar size={18} /> Explore Events
            </button>

            <button
              onClick={handleStartInstantMeeting}
              disabled={startingInstant}
              className="btn-secondary"
              style={{
                padding: '13px 24px',
                borderRadius: '12px',
                fontSize: '0.98rem',
                fontWeight: '600',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '8px',
                background: 'var(--bg-secondary)',
                border: '1px solid var(--border-glass)'
              }}
            >
              <Video size={18} style={{ color: '#06b6d4' }} /> 
              {startingInstant ? 'Launching...' : 'Start a Meeting'}
            </button>

            {user?.role !== 'STUDENT' && (
              <button
                onClick={() => {
                  if (!user) {
                    onNavigate('login');
                  } else if (onOpenSchedule) {
                    onOpenSchedule();
                  }
                }}
                className="btn-secondary"
                style={{
                  padding: '13px 22px',
                  borderRadius: '12px',
                  fontSize: '0.98rem',
                  fontWeight: '600',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '8px'
                }}
              >
                <PlusCircle size={18} style={{ color: 'var(--accent-primary)' }} /> Schedule a Meeting
              </button>
            )}
          </div>

          {/* Quick Join With Code Bar */}
          <div style={{ marginTop: '28px', paddingTop: '22px', borderTop: '1px solid var(--border-subtle)', display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: '12px' }}>
            <span style={{ fontSize: '0.85rem', fontWeight: '600', color: 'var(--text-muted)' }}>
              Have a meeting code?
            </span>
            <form onSubmit={handleJoinByCodeSubmit} style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
              <input
                type="text"
                placeholder="e.g. quiz-cs401-algo"
                value={meetingCodeInput}
                onChange={e => setMeetingCodeInput(e.target.value)}
                style={{
                  padding: '9px 14px',
                  borderRadius: '10px',
                  background: 'var(--bg-secondary)',
                  border: '1px solid var(--border-glass)',
                  color: 'var(--text-primary)',
                  fontSize: '0.85rem',
                  fontFamily: 'var(--font-mono)',
                  minWidth: '200px'
                }}
              />
              <button
                type="submit"
                className="btn-primary"
                style={{ padding: '9px 16px', borderRadius: '10px', fontSize: '0.85rem' }}
              >
                Join
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* =========================================================================
          DYNAMIC USER DASHBOARD STRIP (If Logged In)
          ========================================================================= */}
      {user && overview?.user_personalized && (
        <section style={{
          padding: '20px 24px',
          borderRadius: '18px',
          background: 'var(--bg-secondary)',
          border: '1px solid var(--border-glass)',
          display: 'flex',
          flexWrap: 'wrap',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: '20px'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
            <div style={{
              width: '46px',
              height: '46px',
              borderRadius: '14px',
              background: 'linear-gradient(135deg, var(--accent-primary), #06b6d4)',
              color: '#ffffff',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontWeight: '800',
              fontSize: '1.2rem'
            }}>
              {user.name[0].toUpperCase()}
            </div>
            <div>
              <div style={{ fontSize: '1.1rem', fontWeight: '700' }}>
                Welcome back, {user.name}!
              </div>
              <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                {user.role === 'ADMIN' ? 'Administrator' : user.role === 'TEACHER' ? 'Faculty Instructor' : 'Enrolled Student'} • {user.email}
              </div>
            </div>
          </div>

          <div style={{ display: 'flex', gap: '20px', flexWrap: 'wrap' }}>
            <div 
              onClick={() => onNavigate('my-activities')}
              style={{ cursor: 'pointer', textAlign: 'center', padding: '6px 14px', borderRadius: '10px', background: 'var(--bg-surface)' }}
            >
              <div style={{ fontSize: '1.2rem', fontWeight: '800', color: 'var(--accent-primary)' }}>
                {overview.user_personalized.my_registered_count}
              </div>
              <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>My Registrations</div>
            </div>

            {user.role !== 'STUDENT' && (
              <div 
                onClick={() => onNavigate('my-activities')}
                style={{ cursor: 'pointer', textAlign: 'center', padding: '6px 14px', borderRadius: '10px', background: 'var(--bg-surface)' }}
              >
                <div style={{ fontSize: '1.2rem', fontWeight: '800', color: '#06b6d4' }}>
                  {overview.user_personalized.my_hosted_count}
                </div>
                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>Events Hosted</div>
              </div>
            )}

            <button
              onClick={() => onNavigate('dashboard')}
              className="btn-primary"
              style={{ padding: '8px 16px', borderRadius: '10px', fontSize: '0.85rem', gap: '6px' }}
            >
              Open Academic Dashboard <ArrowRight size={14} />
            </button>
          </div>
        </section>
      )}

      {/* =========================================================================
          INTERACTIVE FEATURE CARDS
          ========================================================================= */}
      <section>
        <div style={{ marginBottom: '20px' }}>
          <h2 style={{ fontSize: '1.6rem', fontWeight: '800', color: 'var(--text-primary)' }}>
            Explore Platform Features
          </h2>
          <p style={{ fontSize: '0.9rem', color: 'var(--text-muted)' }}>
            Direct access to all major collaborative tools and academic systems
          </p>
        </div>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
          gap: '20px'
        }}>
          {/* Card 1: Event Management */}
          <div className="glass-panel" style={{
            padding: '26px',
            borderRadius: '20px',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between',
            background: 'var(--bg-secondary)',
            border: '1px solid var(--border-glass)',
            transition: 'transform 0.2s ease, box-shadow 0.2s ease'
          }}>
            <div>
              <div style={{
                width: '46px',
                height: '46px',
                borderRadius: '12px',
                background: 'rgba(79, 70, 229, 0.12)',
                color: 'var(--accent-primary)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: '16px'
              }}>
                <Calendar size={22} />
              </div>
              <h3 style={{ fontSize: '1.2rem', marginBottom: '8px' }}>Event Management</h3>
              <p style={{ fontSize: '0.88rem', color: 'var(--text-secondary)', lineHeight: 1.5, marginBottom: '20px' }}>
                Discover events, explore their details, register for participation, and access payment information.
              </p>
            </div>
            <button
              onClick={() => onNavigate('events')}
              className="btn-primary"
              style={{ width: '100%', padding: '11px', borderRadius: '10px', fontSize: '0.9rem', gap: '6px' }}
            >
              Explore Events <ArrowRight size={16} />
            </button>
          </div>

          {/* Card 2: Host an Event */}
          {user?.role !== 'STUDENT' && (
            <div className="glass-panel" style={{
              padding: '26px',
              borderRadius: '20px',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
              background: 'var(--bg-secondary)',
              border: '1px solid var(--border-glass)'
            }}>
              <div>
                <div style={{
                  width: '46px',
                  height: '46px',
                  borderRadius: '12px',
                  background: 'rgba(16, 185, 129, 0.12)',
                  color: 'var(--success)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginBottom: '16px'
                }}>
                  <PlusCircle size={22} />
                </div>
                <h3 style={{ fontSize: '1.2rem', marginBottom: '8px' }}>Host an Event</h3>
                <p style={{ fontSize: '0.88rem', color: 'var(--text-secondary)', lineHeight: 1.5, marginBottom: '20px' }}>
                  Create, publish, and manage your own events with descriptions, schedules, registration links, and payment information.
                </p>
              </div>
              <button
                onClick={() => onNavigate('host-event')}
                className="btn-secondary"
                style={{ width: '100%', padding: '11px', borderRadius: '10px', fontSize: '0.9rem', gap: '6px' }}
              >
                Host an Event <ArrowRight size={16} />
              </button>
            </div>
          )}

          {/* Card 3: Online Meetings */}
          <div className="glass-panel" style={{
            padding: '26px',
            borderRadius: '20px',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between',
            background: 'var(--bg-secondary)',
            border: '1px solid var(--border-glass)'
          }}>
            <div>
              <div style={{
                width: '46px',
                height: '46px',
                borderRadius: '12px',
                background: 'rgba(6, 182, 212, 0.12)',
                color: '#06b6d4',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: '16px'
              }}>
                <Video size={22} />
              </div>
              <h3 style={{ fontSize: '1.2rem', marginBottom: '8px' }}>Online Meetings</h3>
              <p style={{ fontSize: '0.88rem', color: 'var(--text-secondary)', lineHeight: 1.5, marginBottom: '20px' }}>
                Start or join live video meetings for classes, discussions, presentations, and collaborative sessions.
              </p>
            </div>
            <button
              onClick={() => onNavigate('meetings')}
              className="btn-primary"
              style={{ width: '100%', padding: '11px', borderRadius: '10px', fontSize: '0.9rem', gap: '6px' }}
            >
              Open Meetings <ArrowRight size={16} />
            </button>
          </div>

          {/* Card 4: Scheduled Meetings */}
          {user?.role !== 'STUDENT' && (
            <div className="glass-panel" style={{
              padding: '26px',
              borderRadius: '20px',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
              background: 'var(--bg-secondary)',
              border: '1px solid var(--border-glass)'
            }}>
              <div>
                <div style={{
                  width: '46px',
                  height: '46px',
                  borderRadius: '12px',
                  background: 'rgba(245, 158, 11, 0.12)',
                  color: 'var(--warning)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginBottom: '16px'
                }}>
                  <Clock size={22} />
                </div>
                <h3 style={{ fontSize: '1.2rem', marginBottom: '8px' }}>Scheduled Meetings</h3>
                <p style={{ fontSize: '0.88rem', color: 'var(--text-secondary)', lineHeight: 1.5, marginBottom: '20px' }}>
                  Schedule upcoming classes or meetings, invite participants, and manage meeting details.
                </p>
              </div>
              <button
                onClick={() => {
                  if (!user) onNavigate('login');
                  else if (onOpenSchedule) onOpenSchedule();
                }}
                className="btn-secondary"
                style={{ width: '100%', padding: '11px', borderRadius: '10px', fontSize: '0.9rem', gap: '6px' }}
              >
                Schedule Now <ArrowRight size={16} />
              </button>
            </div>
          )}

          {/* Card 5: Notifications */}
          <div className="glass-panel" style={{
            padding: '26px',
            borderRadius: '20px',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between',
            background: 'var(--bg-secondary)',
            border: '1px solid var(--border-glass)'
          }}>
            <div>
              <div style={{
                width: '46px',
                height: '46px',
                borderRadius: '12px',
                background: 'rgba(239, 68, 68, 0.12)',
                color: 'var(--danger)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: '16px'
              }}>
                <Bell size={22} />
              </div>
              <h3 style={{ fontSize: '1.2rem', marginBottom: '8px' }}>Notifications</h3>
              <p style={{ fontSize: '0.88rem', color: 'var(--text-secondary)', lineHeight: 1.5, marginBottom: '20px' }}>
                Stay updated about events, meeting invitations, registration confirmations, and important announcements.
              </p>
            </div>
            <button
              onClick={() => {
                if (!user) onNavigate('login');
                else notify('Check the notification bell in the top navigation bar!', 'info');
              }}
              className="btn-secondary"
              style={{ width: '100%', padding: '11px', borderRadius: '10px', fontSize: '0.9rem', gap: '6px' }}
            >
              View Notifications <ArrowRight size={16} />
            </button>
          </div>

          {/* Card 6: My Activities */}
          <div className="glass-panel" style={{
            padding: '26px',
            borderRadius: '20px',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between',
            background: 'var(--bg-secondary)',
            border: '1px solid var(--border-glass)'
          }}>
            <div>
              <div style={{
                width: '46px',
                height: '46px',
                borderRadius: '12px',
                background: 'rgba(147, 51, 234, 0.12)',
                color: '#9333ea',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: '16px'
              }}>
                <Activity size={22} />
              </div>
              <h3 style={{ fontSize: '1.2rem', marginBottom: '8px' }}>My Activities</h3>
              <p style={{ fontSize: '0.88rem', color: 'var(--text-secondary)', lineHeight: 1.5, marginBottom: '20px' }}>
                View your registered events, upcoming meetings, hosted events, and recent activities.
              </p>
            </div>
            <button
              onClick={() => {
                if (!user) onNavigate('login');
                else onNavigate('my-activities');
              }}
              className="btn-secondary"
              style={{ width: '100%', padding: '11px', borderRadius: '10px', fontSize: '0.9rem', gap: '6px' }}
            >
              View Activities <ArrowRight size={16} />
            </button>
          </div>
        </div>
      </section>

      {/* =========================================================================
          UPCOMING EVENTS PREVIEW
          ========================================================================= */}
      <section>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '20px', flexWrap: 'wrap', gap: '10px' }}>
          <div>
            <h2 style={{ fontSize: '1.6rem', fontWeight: '800', color: 'var(--text-primary)' }}>
              Upcoming Featured Events
            </h2>
            <p style={{ fontSize: '0.9rem', color: 'var(--text-muted)' }}>
              Symposiums, academic workshops, hackathons, and certified masterclasses
            </p>
          </div>
          <button
            onClick={() => onNavigate('events')}
            className="btn-secondary"
            style={{ padding: '8px 16px', borderRadius: '10px', fontSize: '0.85rem', gap: '6px' }}
          >
            View All Events <ChevronRight size={16} />
          </button>
        </div>

        {loading ? (
          <div style={{ padding: '40px', textAlign: 'center', color: 'var(--text-muted)' }}>
            Loading events...
          </div>
        ) : !overview?.upcoming_events || overview.upcoming_events.length === 0 ? (
          <div style={{ padding: '40px', textAlign: 'center', background: 'var(--bg-secondary)', borderRadius: '16px', border: '1px solid var(--border-glass)' }}>
            <Calendar size={36} style={{ color: 'var(--text-muted)', marginBottom: '10px' }} />
            <h4>No published events found</h4>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginTop: '4px' }}>
              Be the first to host an academic workshop or conference!
            </p>
          </div>
        ) : (
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(340px, 1fr))',
            gap: '24px'
          }}>
            {overview.upcoming_events.map(ev => {
              const isFree = ev.min_price === 0;
              return (
                <div
                  key={ev.id}
                  className="glass-panel"
                  style={{
                    borderRadius: '20px',
                    overflow: 'hidden',
                    background: 'var(--bg-secondary)',
                    border: '1px solid var(--border-glass)',
                    display: 'flex',
                    flexDirection: 'column',
                    boxShadow: 'var(--shadow-card)',
                    transition: 'transform 0.2s ease'
                  }}
                >
                  {/* Banner image with overlay badges */}
                  <div style={{ height: '170px', position: 'relative', overflow: 'hidden' }}>
                    <img 
                      src={ev.banner_url || "https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=800&q=80"}
                      alt={ev.title}
                      style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                    />
                    <div style={{ position: 'absolute', top: '12px', left: '12px', display: 'flex', gap: '6px' }}>
                      <span className="badge" style={{ background: 'rgba(0, 0, 0, 0.7)', color: '#ffffff', backdropFilter: 'blur(4px)' }}>
                        {ev.category}
                      </span>
                    </div>
                    <div style={{ position: 'absolute', top: '12px', right: '12px' }}>
                      <span className="badge" style={{
                        background: isFree ? 'rgba(16, 185, 129, 0.85)' : 'rgba(79, 70, 229, 0.9)',
                        color: '#ffffff',
                        fontWeight: '700'
                      }}>
                        {isFree ? 'FREE' : `From ₹${ev.min_price}`}
                      </span>
                    </div>
                  </div>

                  {/* Body */}
                  <div style={{ padding: '20px', flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '12px', fontSize: '0.78rem', color: 'var(--text-muted)', marginBottom: '8px' }}>
                        <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                          <Calendar size={13} style={{ color: 'var(--accent-primary)' }} />
                          {new Date(ev.event_date).toLocaleDateString([], { month: 'short', day: 'numeric' })} • {ev.start_time}
                        </span>
                        <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                          <MapPin size={13} style={{ color: '#06b6d4' }} />
                          {ev.venue_type}
                        </span>
                      </div>

                      <h3 style={{ fontSize: '1.1rem', fontWeight: '700', marginBottom: '8px', lineHeight: 1.3 }}>
                        {ev.title}
                      </h3>

                      <p style={{
                        fontSize: '0.84rem',
                        color: 'var(--text-secondary)',
                        lineHeight: 1.45,
                        display: '-webkit-box',
                        WebkitLineClamp: 2,
                        WebkitBoxOrient: 'vertical',
                        overflow: 'hidden',
                        marginBottom: '16px'
                      }}>
                        {ev.short_description || ev.description}
                      </p>
                    </div>

                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingBottom: '14px', borderBottom: '1px solid var(--border-subtle)', marginBottom: '14px', fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                        <span>Organizer: <strong style={{ color: 'var(--text-primary)' }}>{ev.organizer_name}</strong></span>
                        <span>{ev.reg_count || 0}/{ev.max_capacity} registered</span>
                      </div>

                      <div style={{ display: 'flex', gap: '10px' }}>
                        <button
                          onClick={() => onViewEventDetail && onViewEventDetail(ev.id)}
                          className="btn-secondary"
                          style={{ flex: 1, padding: '9px', fontSize: '0.84rem', borderRadius: '10px' }}
                        >
                          View Details
                        </button>
                        <button
                          onClick={() => onRegisterEvent && onRegisterEvent(ev)}
                          className="btn-primary"
                          style={{ flex: 1, padding: '9px', fontSize: '0.84rem', borderRadius: '10px' }}
                        >
                          Register Now
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* =========================================================================
          MEETING PREVIEW & DEDICATED CONFERENCING HUB
          ========================================================================= */}
      <section style={{
        padding: '36px',
        borderRadius: '24px',
        background: 'var(--bg-secondary)',
        border: '1px solid var(--border-glass)',
        boxShadow: 'var(--shadow-card)'
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '16px', marginBottom: '28px' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px' }}>
              <span className="badge" style={{ background: 'rgba(6, 182, 212, 0.15)', color: '#06b6d4', border: '1px solid rgba(6, 182, 212, 0.3)' }}>
                <Video size={12} /> Live Conferencing
              </span>
            </div>
            <h2 style={{ fontSize: '1.6rem', fontWeight: '800', color: 'var(--text-primary)' }}>
              Live Virtual Classrooms & Online Meetings
            </h2>
            <p style={{ fontSize: '0.88rem', color: 'var(--text-muted)', marginTop: '4px' }}>
              Instant peer-to-peer HD video, crystal clear audio, low-latency screen sharing & real-time room chat
            </p>
          </div>

          <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
            <button
              onClick={handleStartInstantMeeting}
              disabled={startingInstant}
              className="btn-primary"
              style={{ padding: '10px 18px', borderRadius: '10px', fontSize: '0.88rem', gap: '6px' }}
            >
              <Video size={16} /> Start Instant Meeting
            </button>
            {user?.role !== 'STUDENT' && (
              <button
                onClick={() => {
                  if (!user) onNavigate('login');
                  else if (onOpenSchedule) onOpenSchedule();
                }}
                className="btn-secondary"
                style={{ padding: '10px 18px', borderRadius: '10px', fontSize: '0.88rem', gap: '6px' }}
              >
                <Calendar size={16} /> Schedule a Meeting
              </button>
            )}
          </div>
        </div>

        {/* Live and Upcoming Meetings Listing */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {!overview?.meetings || overview.meetings.length === 0 ? (
            <div style={{ padding: '24px', textAlign: 'center', color: 'var(--text-muted)' }}>
              No meetings currently scheduled. Click 'Start Instant Meeting' to initiate one immediately.
            </div>
          ) : (
            overview.meetings.map(m => {
              const isLive = m.status === 'LIVE';
              return (
                <div
                  key={m.id}
                  style={{
                    padding: '16px 20px',
                    borderRadius: '14px',
                    background: 'var(--bg-surface)',
                    border: isLive ? '1px solid rgba(16, 185, 129, 0.4)' : '1px solid var(--border-subtle)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    flexWrap: 'wrap',
                    gap: '14px'
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
                    <div style={{
                      width: '40px',
                      height: '40px',
                      borderRadius: '12px',
                      background: isLive ? 'rgba(16, 185, 129, 0.15)' : 'var(--accent-light)',
                      color: isLive ? 'var(--success)' : 'var(--accent-primary)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center'
                    }}>
                      <Video size={20} />
                    </div>
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <h4 style={{ fontSize: '1rem', margin: 0 }}>{m.title}</h4>
                        {isLive && (
                          <span className="badge badge-present" style={{ fontSize: '0.68rem', padding: '2px 8px' }}>
                            ● LIVE NOW
                          </span>
                        )}
                      </div>
                      <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginTop: '2px' }}>
                        Host: {m.host_name} • Code: <strong style={{ fontFamily: 'var(--font-mono)' }}>{m.code}</strong> • {m.scheduled_date ? `${m.scheduled_date} at ${m.scheduled_start_time}` : 'Instant Session'}
                      </div>
                    </div>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    {isLive && m.active_count > 0 && (
                      <span style={{ fontSize: '0.78rem', color: 'var(--success)', display: 'flex', alignItems: 'center', gap: '4px' }}>
                        <Users size={14} /> {m.active_count} in room
                      </span>
                    )}
                    <button
                      onClick={() => onJoinMeetingWithCode && onJoinMeetingWithCode(m.code)}
                      className="btn-primary"
                      style={{
                        padding: '8px 18px',
                        borderRadius: '10px',
                        fontSize: '0.85rem',
                        background: isLive ? 'linear-gradient(135deg, var(--success), #059669)' : 'var(--accent-primary)'
                      }}
                    >
                      {isLive ? 'Join Meeting' : 'Open Lobby'}
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </section>

      {/* =========================================================================
          PLATFORM STATS COUNTER STRIP
          ========================================================================= */}
      <section style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
        gap: '16px',
        textAlign: 'center'
      }}>
        <div style={{ padding: '20px', borderRadius: '16px', background: 'var(--bg-secondary)', border: '1px solid var(--border-glass)' }}>
          <div style={{ fontSize: '2rem', fontWeight: '800', color: 'var(--accent-primary)' }}>
            {overview?.stats?.published_events || 3}+
          </div>
          <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)', marginTop: '4px' }}>Active Events</div>
        </div>

        <div style={{ padding: '20px', borderRadius: '16px', background: 'var(--bg-secondary)', border: '1px solid var(--border-glass)' }}>
          <div style={{ fontSize: '2rem', fontWeight: '800', color: '#06b6d4' }}>
            {overview?.stats?.live_meetings || 1}+
          </div>
          <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)', marginTop: '4px' }}>Live Meetings & Rooms</div>
        </div>

        <div style={{ padding: '20px', borderRadius: '16px', background: 'var(--bg-secondary)', border: '1px solid var(--border-glass)' }}>
          <div style={{ fontSize: '2rem', fontWeight: '800', color: 'var(--success)' }}>
            {overview?.stats?.total_registrations || 100}+
          </div>
          <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)', marginTop: '4px' }}>Verified Registrations</div>
        </div>

        <div style={{ padding: '20px', borderRadius: '16px', background: 'var(--bg-secondary)', border: '1px solid var(--border-glass)' }}>
          <div style={{ fontSize: '2rem', fontWeight: '800', color: 'var(--warning)' }}>
            {overview?.stats?.active_users || 13}+
          </div>
          <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)', marginTop: '4px' }}>Academic Scholars & Faculty</div>
        </div>
      </section>
    </div>
  );
}
