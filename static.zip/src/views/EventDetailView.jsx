import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNotifications } from '../context/NotificationContext';
import { 
  Calendar, Clock, MapPin, Share2, Check, ArrowLeft, 
  ShieldCheck, AlertCircle, Ticket, Mail, Phone, ExternalLink, Megaphone 
} from 'lucide-react';

export default function EventDetailView({ eventId, onBack, onRegisterEvent, onViewReceipt }) {
  const { user } = useAuth();
  const { notify } = useNotifications();

  const [event, setEvent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [copiedLink, setCopiedLink] = useState(false);

  useEffect(() => {
    if (eventId) fetchEventDetail();
  }, [eventId]);

  const fetchEventDetail = async () => {
    try {
      setLoading(true);
      const res = await fetch(`/api/events/${eventId}`);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to fetch event');
      setEvent(data.event);
    } catch (err) {
      notify(err.message, 'danger');
    } finally {
      setLoading(false);
    }
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    notify('Event shareable link copied to clipboard!', 'info');
    setTimeout(() => setCopiedLink(false), 2500);
  };

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '100px 20px', color: 'var(--text-muted)' }}>
        Loading event details...
      </div>
    );
  }

  if (!event) {
    return (
      <div style={{ textAlign: 'center', padding: '80px 20px' }}>
        <h3>Event Not Found</h3>
        <button onClick={onBack} className="btn-secondary" style={{ marginTop: '14px' }}>
          Back to Events
        </button>
      </div>
    );
  }

  const isFree = event.tickets?.some(t => t.price === 0);
  const minPrice = event.tickets && event.tickets.length > 0 
    ? Math.min(...event.tickets.map(t => t.price)) 
    : 0;

  return (
    <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '10px 20px 80px 20px', display: 'flex', flexDirection: 'column', gap: '30px' }}>
      {/* Back button and share bar */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <button
          onClick={onBack}
          className="btn-secondary"
          style={{ padding: '8px 14px', borderRadius: '10px', fontSize: '0.85rem', gap: '6px' }}
        >
          <ArrowLeft size={16} /> Back to Catalog
        </button>

        <button
          onClick={handleCopyLink}
          className="btn-secondary"
          style={{ padding: '8px 16px', borderRadius: '10px', fontSize: '0.85rem', gap: '6px' }}
        >
          {copiedLink ? <Check size={16} style={{ color: 'var(--success)' }} /> : <Share2 size={16} />}
          {copiedLink ? 'Link Copied!' : 'Share Event'}
        </button>
      </div>

      {/* Hero Banner */}
      <div style={{
        position: 'relative',
        borderRadius: '24px',
        overflow: 'hidden',
        height: '340px',
        border: '1px solid var(--border-glass)',
        boxShadow: 'var(--shadow-card)'
      }}>
        <img
          src={event.banner_url || "https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=1200&q=80"}
          alt={event.title}
          style={{ width: '100%', height: '100%', objectFit: 'cover' }}
        />
        <div style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'linear-gradient(to top, rgba(7, 9, 14, 0.95) 0%, rgba(7, 9, 14, 0.3) 60%, transparent 100%)',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'flex-end',
          padding: '36px'
        }}>
          <div style={{ display: 'flex', gap: '8px', marginBottom: '12px' }}>
            <span className="badge" style={{ background: 'var(--accent-primary)', color: '#ffffff' }}>
              {event.category}
            </span>
            <span className="badge" style={{ background: 'rgba(255, 255, 255, 0.15)', color: '#ffffff', backdropFilter: 'blur(4px)' }}>
              {event.venue_type}
            </span>
            {event.is_registered && (
              <span className="badge badge-present" style={{ display: 'inline-flex', alignItems: 'center', gap: '4px' }}>
                <Check size={12} /> You are registered
              </span>
            )}
          </div>

          <h1 style={{ fontSize: 'clamp(1.8rem, 3.5vw, 2.6rem)', color: '#ffffff', fontWeight: '800', lineHeight: 1.2 }}>
            {event.title}
          </h1>
        </div>
      </div>

      {/* Main Grid: Details Column + Action Card Column */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '30px', alignItems: 'start' }}>
        {/* Left: Detailed Information */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '26px' }}>
          {/* Quick Info Strip */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
            gap: '14px',
            padding: '20px',
            borderRadius: '16px',
            background: 'var(--bg-secondary)',
            border: '1px solid var(--border-glass)'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <div style={{ width: '38px', height: '38px', borderRadius: '10px', background: 'var(--accent-light)', color: 'var(--accent-primary)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Calendar size={18} />
              </div>
              <div>
                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>Date</div>
                <div style={{ fontSize: '0.88rem', fontWeight: '700' }}>
                  {new Date(event.event_date).toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })}
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <div style={{ width: '38px', height: '38px', borderRadius: '10px', background: 'rgba(245, 158, 11, 0.15)', color: 'var(--warning)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Clock size={18} />
              </div>
              <div>
                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>Time</div>
                <div style={{ fontSize: '0.88rem', fontWeight: '700' }}>
                  {event.start_time} - {event.end_time}
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <div style={{ width: '38px', height: '38px', borderRadius: '10px', background: 'rgba(6, 182, 212, 0.15)', color: '#06b6d4', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <MapPin size={18} />
              </div>
              <div>
                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>Venue</div>
                <div style={{ fontSize: '0.88rem', fontWeight: '700' }}>
                  {event.venue_type === 'ONLINE' ? 'Virtual Classroom' : (event.venue_address || 'Main Campus')}
                </div>
              </div>
            </div>
          </div>

          {/* Announcements Feed (if any) */}
          {event.announcements && event.announcements.length > 0 && (
            <div style={{
              padding: '20px',
              borderRadius: '16px',
              background: 'rgba(245, 158, 11, 0.08)',
              border: '1px solid rgba(245, 158, 11, 0.3)'
            }}>
              <h3 style={{ fontSize: '1rem', color: 'var(--warning)', display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px' }}>
                <Megaphone size={18} /> Organizer Announcements
              </h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                {event.announcements.map(ann => (
                  <div key={ann.id} style={{ padding: '12px', borderRadius: '10px', background: 'var(--bg-secondary)' }}>
                    <div style={{ fontWeight: '700', fontSize: '0.9rem' }}>{ann.title}</div>
                    <div style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', marginTop: '4px' }}>{ann.content}</div>
                    <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: '6px' }}>
                      By {ann.author_name || 'Organizer'} • {new Date(ann.created_at).toLocaleDateString()}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Full Description */}
          <div style={{
            padding: '28px',
            borderRadius: '20px',
            background: 'var(--bg-secondary)',
            border: '1px solid var(--border-glass)'
          }}>
            <h3 style={{ fontSize: '1.25rem', marginBottom: '14px', fontWeight: '700' }}>
              About This Event
            </h3>
            <div style={{ fontSize: '0.95rem', color: 'var(--text-secondary)', lineHeight: 1.7, whiteSpace: 'pre-line' }}>
              {event.description || event.short_description}
            </div>
          </div>

          {/* Rules & Requirements */}
          {event.rules_and_requirements && (
            <div style={{
              padding: '24px',
              borderRadius: '20px',
              background: 'var(--bg-secondary)',
              border: '1px solid var(--border-glass)'
            }}>
              <h4 style={{ fontSize: '1.1rem', marginBottom: '10px' }}>Rules & Guidelines</h4>
              <p style={{ fontSize: '0.88rem', color: 'var(--text-secondary)', lineHeight: 1.6 }}>
                {event.rules_and_requirements}
              </p>
            </div>
          )}

          {/* Cancellation & Policies */}
          <div style={{
            padding: '20px',
            borderRadius: '16px',
            background: 'var(--bg-tertiary)',
            border: '1px solid var(--border-subtle)',
            fontSize: '0.8rem',
            color: 'var(--text-muted)',
            lineHeight: 1.5
          }}>
            <div><strong>Cancellation Policy:</strong> {event.cancellation_policy || 'Full refund available up to 24h prior.'}</div>
            <div style={{ marginTop: '6px' }}><strong>Terms:</strong> {event.terms_and_conditions || 'Standard academic event rules apply.'}</div>
          </div>
        </div>

        {/* Right: Registration & Ticket Selector Card */}
        <div style={{
          position: 'sticky',
          top: '90px',
          padding: '28px',
          borderRadius: '20px',
          background: 'var(--bg-secondary)',
          border: '1px solid var(--border-glass)',
          boxShadow: 'var(--shadow-card)',
          display: 'flex',
          flexDirection: 'column',
          gap: '20px'
        }}>
          <div>
            <div style={{ fontSize: '0.75rem', textTransform: 'uppercase', color: 'var(--text-muted)', fontWeight: '700' }}>
              Registration & Passes
            </div>
            <div style={{ fontSize: '1.8rem', fontWeight: '800', color: minPrice === 0 ? 'var(--success)' : 'var(--accent-primary)', marginTop: '4px' }}>
              {minPrice === 0 ? 'Free Admission' : `From ₹${minPrice}.00`}
            </div>
            <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
              {event.current_registrations || 0} / {event.max_capacity} registered
            </div>
          </div>

          {/* Tickets Breakdown */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            <label style={{ fontSize: '0.8rem', fontWeight: '700', color: 'var(--text-secondary)' }}>
              Available Passes:
            </label>
            {(event.tickets || []).map(t => (
              <div 
                key={t.id}
                style={{
                  padding: '12px 14px',
                  borderRadius: '12px',
                  background: 'var(--bg-surface)',
                  border: '1px solid var(--border-subtle)',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center'
                }}
              >
                <div>
                  <div style={{ fontWeight: '600', fontSize: '0.88rem' }}>{t.name}</div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{t.description || 'Verified access'}</div>
                </div>
                <div style={{ fontWeight: '700', fontSize: '0.95rem', color: t.price === 0 ? 'var(--success)' : 'var(--accent-primary)' }}>
                  {t.price === 0 ? 'FREE' : `₹${t.price}`}
                </div>
              </div>
            ))}
          </div>

          {/* Registration Trigger */}
          {event.is_registered ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              <div style={{
                padding: '14px',
                borderRadius: '12px',
                background: 'rgba(16, 185, 129, 0.15)',
                border: '1px solid var(--success)',
                color: 'var(--success)',
                fontSize: '0.85rem',
                fontWeight: '600',
                display: 'flex',
                alignItems: 'center',
                gap: '8px'
              }}>
                <Check size={18} /> You are registered for this event!
              </div>

              <button
                onClick={() => {
                  if (onViewReceipt && event.user_registration) {
                    onViewReceipt({
                      ...event.user_registration,
                      event_title: event.title,
                      event_date: event.event_date,
                      start_time: event.start_time,
                      organizer_name: event.organizer_name
                    });
                  }
                }}
                className="btn-primary"
                style={{ width: '100%', padding: '12px', fontSize: '0.9rem' }}
              >
                View / Download My Receipt
              </button>
            </div>
          ) : (
            <button
              onClick={() => onRegisterEvent && onRegisterEvent(event)}
              className="btn-primary"
              style={{
                width: '100%',
                padding: '14px',
                borderRadius: '12px',
                fontSize: '1rem',
                fontWeight: '700'
              }}
            >
              Register for Event
            </button>
          )}

          {/* Organizer Card */}
          <div style={{
            padding: '16px',
            borderRadius: '14px',
            background: 'var(--bg-surface)',
            border: '1px solid var(--border-subtle)',
            marginTop: '10px'
          }}>
            <div style={{ fontSize: '0.72rem', textTransform: 'uppercase', color: 'var(--text-muted)', fontWeight: '700' }}>
              Event Organizer
            </div>
            <div style={{ fontWeight: '700', fontSize: '0.95rem', marginTop: '4px' }}>
              {event.organizer_name}
            </div>
            {event.contact_email && (
              <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', display: 'flex', alignItems: 'center', gap: '6px', marginTop: '6px' }}>
                <Mail size={13} /> {event.contact_email}
              </div>
            )}
            {event.contact_phone && (
              <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', display: 'flex', alignItems: 'center', gap: '6px', marginTop: '4px' }}>
                <Phone size={13} /> {event.contact_phone}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
