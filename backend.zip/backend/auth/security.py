import time
import os
import secrets
import hashlib
from typing import Optional, Dict, Any
from werkzeug.security import generate_password_hash, check_password_hash
import jwt
from backend.config import config

JWT_SECRET = config.SECRET_KEY
JWT_ALGORITHM = "HS256"

def hash_password(password: str) -> str:
    """Securely hash a password with Werkzeug's modern scrypt/pbkdf2 algorithm."""
    return generate_password_hash(password)

def verify_password(password: str, password_hash: str) -> bool:
    """Verify password against its hash."""
    return check_password_hash(password_hash, password)

def generate_jwt_token(payload: Dict[str, Any], expires_in_hours: int = 24) -> str:
    """Generate a signed JWT token containing user identity and role."""
    data = payload.copy()
    data["iat"] = int(time.time())
    data["exp"] = int(time.time()) + (expires_in_hours * 3600)
    return jwt.encode(data, JWT_SECRET, algorithm=JWT_ALGORITHM)

def decode_jwt_token(token: str) -> Optional[Dict[str, Any]]:
    """Decode and validate a signed JWT token."""
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
    except (jwt.ExpiredSignatureError, jwt.InvalidTokenError):
        return None

def generate_secure_token(length: int = 32) -> str:
    """Generate a cryptographically secure URL-safe token."""
    return secrets.token_urlsafe(length)

def hash_token(token: str) -> str:
    """Hash a token using SHA-256 for secure storage."""
    return hashlib.sha256(token.encode("utf-8")).hexdigest()

def generate_backup_code(digits: int = 6) -> str:
    """Generate a random 6-digit numeric backup code for attendance."""
    min_val = 10 ** (digits - 1)
    max_val = (10 ** digits) - 1
    return str(secrets.randbelow(max_val - min_val + 1) + min_val)
