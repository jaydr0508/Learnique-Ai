import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
from backend.config import config

def send_password_reset_email(to_email: str, recipient_name: str, reset_url: str) -> bool:
    """Send a password reset email via SMTP, or log to dev_emails.log in development mode."""
    subject = "Quizify - Secure Password Reset Request"
    
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <style>
        body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #0b0f19; color: #f3f4f6; margin: 0; padding: 20px; }}
        .card {{ max-width: 560px; margin: 0 auto; background: #111827; border: 1px solid #1f2937; border-radius: 12px; padding: 32px; box-shadow: 0 10px 25px rgba(0,0,0,0.5); }}
        .header {{ text-align: center; margin-bottom: 24px; }}
        .brand {{ font-size: 26px; font-weight: 800; color: #38bdf8; letter-spacing: -0.5px; }}
        .button {{ display: inline-block; padding: 14px 28px; background: linear-gradient(135deg, #0284c7, #0369a1); color: #ffffff !important; text-decoration: none; border-radius: 8px; font-weight: 600; margin: 24px 0; }}
        .footer {{ font-size: 12px; color: #6b7280; text-align: center; margin-top: 32px; border-top: 1px solid #1f2937; padding-top: 16px; }}
        .notice {{ background: #1e293b; padding: 12px 16px; border-left: 4px solid #38bdf8; border-radius: 4px; font-size: 13px; color: #cbd5e1; }}
      </style>
    </head>
    <body>
      <div class="card">
        <div class="header">
          <div class="brand">QUIZIFY ACADEMIC</div>
          <p style="color: #9ca3af; margin-top: 4px;">Institutional Access Recovery</p>
        </div>
        <p>Hello <strong>{recipient_name}</strong>,</p>
        <p>A password reset request was received for your academic account. Click the button below to establish a new password.</p>
        <div style="text-align: center;">
          <a href="{reset_url}" class="button" target="_blank">Reset My Password</a>
        </div>
        <div class="notice">
          <strong>Security Notice:</strong> This single-use link is valid for {config.RESET_TOKEN_EXPIRATION_MINUTES} minutes. If you did not initiate this request, your account remains secure and no action is necessary.
        </div>
        <div class="footer">
          Quizify Autonomous Academic Platform &bull; Server Security Protocol<br>
          Direct link: <span style="word-break: break-all; color: #38bdf8;">{reset_url}</span>
        </div>
      </div>
    </body>
    </html>
    """

    # If SMTP is configured, attempt to send via real SMTP
    if config.SMTP_HOST and config.SMTP_USERNAME and config.SMTP_PASSWORD:
        try:
            msg = MIMEMultipart("alternative")
            msg["Subject"] = subject
            msg["From"] = config.SMTP_FROM
            msg["To"] = to_email
            msg.attach(MIMEText(html_content, "html"))

            with smtplib.SMTP(config.SMTP_HOST, config.SMTP_PORT, timeout=10) as server:
                if config.SMTP_USE_TLS:
                    server.starttls()
                server.login(config.SMTP_USERNAME, config.SMTP_PASSWORD)
                server.sendmail(config.SMTP_FROM, [to_email], msg.as_string())
            print(f"[EMAIL] Password reset email successfully delivered to {to_email}")
            return True
        except Exception as e:
            print(f"[EMAIL ERROR] SMTP delivery failed: {e}. Falling back to dev log mode.")

    # Development mode logging (console + dev_emails.log)
    log_entry = (
        f"================================================================================\n"
        f"TIMESTAMP: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        f"RECIPIENT: {to_email} ({recipient_name})\n"
        f"SUBJECT:   {subject}\n"
        f"RESET URL: {reset_url}\n"
        f"================================================================================\n"
    )
    print(f"\n[DEV EMAIL NOTIFICATION]\nPassword Reset Link for {to_email}:\n--> {reset_url}\n")
    try:
        with open(config.DEV_EMAIL_LOG, "a", encoding="utf-8") as f:
            f.write(log_entry)
    except Exception as e:
        print(f"[DEV EMAIL LOG ERROR] Could not write to log file: {e}")

    return True
