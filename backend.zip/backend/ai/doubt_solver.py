from typing import List, Dict, Any, Optional
from backend.database.db import query_one, query_all, execute_query, get_db
from backend.ai.provider import get_ai_provider

def get_or_create_conversation(user_id: int, subject_id: Optional[int] = None, title: Optional[str] = None) -> int:
    """Get latest conversation or initialize a new private thread for the authenticated user."""
    conv = query_one(
        "SELECT id FROM ai_doubt_conversations WHERE user_id = ? ORDER BY id DESC LIMIT 1",
        (user_id,)
    )
    if conv and not title:
        return conv["id"]

    subject_name = "General Academic"
    if subject_id:
        sub = query_one("SELECT name FROM subjects WHERE id = ?", (subject_id,))
        if sub:
            subject_name = sub["name"]

    conv_title = title or f"{subject_name} Academic Inquiries"
    conv_id = execute_query(
        "INSERT INTO ai_doubt_conversations (user_id, subject_id, title) VALUES (?, ?, ?)",
        (user_id, subject_id, conv_title)
    )
    return conv_id

def send_doubt_message(user_id: int, conversation_id: int, user_message: str) -> Dict[str, Any]:
    """
    Append user message to conversation history, invoke active AI provider,
    store AI assistant response, and return the answer.
    Enforces privacy: conversation must belong to user_id.
    """
    conv = query_one("SELECT * FROM ai_doubt_conversations WHERE id = ? AND user_id = ?", (conversation_id, user_id))
    if not conv:
        raise PermissionError("Access denied: You cannot access or reply to another user's private AI conversation.")

    subject_name = "Engineering & Science"
    if conv["subject_id"]:
        sub = query_one("SELECT name, code FROM subjects WHERE id = ?", (conv["subject_id"],))
        if sub:
            subject_name = f"{sub['name']} ({sub['code']})"

    # Save user message
    user_msg_id = execute_query(
        "INSERT INTO ai_doubt_messages (conversation_id, role, content) VALUES (?, 'user', ?)",
        (conversation_id, user_message)
    )

    # Fetch recent history (up to last 10 messages)
    history_rows = query_all(
        "SELECT role, content FROM ai_doubt_messages WHERE conversation_id = ? ORDER BY id ASC LIMIT 12",
        (conversation_id,)
    )
    history = [{"role": r["role"], "content": r["content"]} for r in history_rows]

    provider = get_ai_provider()
    try:
        assistant_reply = provider.answer_academic_doubt(subject_name, history)
    except Exception as e:
        print(f"[AI DOUBT ERROR] Provider error: {e}. Utilizing fallback.")
        from backend.ai.provider import SmartOfflineAcademicProvider
        fallback = SmartOfflineAcademicProvider()
        assistant_reply = fallback.answer_academic_doubt(subject_name, history)

    # Save assistant message
    asst_msg_id = execute_query(
        "INSERT INTO ai_doubt_messages (conversation_id, role, content) VALUES (?, 'assistant', ?)",
        (conversation_id, assistant_reply)
    )

    return {
        "conversation_id": conversation_id,
        "user_message_id": user_msg_id,
        "assistant_message_id": asst_msg_id,
        "role": "assistant",
        "content": assistant_reply
    }

def get_user_conversations(user_id: int) -> List[Dict[str, Any]]:
    """Retrieve private conversations list for current user."""
    return query_all(
        """
        SELECT c.*, s.name as subject_name, s.code as subject_code,
               (SELECT content FROM ai_doubt_messages m WHERE m.conversation_id = c.id ORDER BY m.id DESC LIMIT 1) as last_message,
               (SELECT created_at FROM ai_doubt_messages m WHERE m.conversation_id = c.id ORDER BY m.id DESC LIMIT 1) as last_message_at
        FROM ai_doubt_conversations c
        LEFT JOIN subjects s ON c.subject_id = s.id
        WHERE c.user_id = ?
        ORDER BY c.id DESC
        """,
        (user_id,)
    )

def get_conversation_messages(user_id: int, conversation_id: int) -> List[Dict[str, Any]]:
    """Retrieve full chronological message thread for a private user conversation."""
    conv = query_one("SELECT id FROM ai_doubt_conversations WHERE id = ? AND user_id = ?", (conversation_id, user_id))
    if not conv:
        raise PermissionError("Access denied: You cannot view another user's conversation.")

    return query_all(
        "SELECT id, role, content, created_at FROM ai_doubt_messages WHERE conversation_id = ? ORDER BY id ASC",
        (conversation_id,)
    )
