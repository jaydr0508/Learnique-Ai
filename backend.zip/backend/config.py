import os
import socket
from pathlib import Path
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")

def get_lan_ip() -> str:
    """Auto-detect the primary local area network IP of the machine."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(0.5)
        # Doesn't need to be reachable, just initiates routing lookup
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"

class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "quizify-secure-secret-key-default-32-chars")
    DB_PATH = Path(os.getenv("DATABASE_PATH", str(BASE_DIR / "backend" / "database" / "quizify.db"))).resolve()
    
    # Network and Base URL
    HOST = os.getenv("HOST", "0.0.0.0")
    PORT = int(os.getenv("PORT", "5000"))
    LAN_IP = get_lan_ip()
    
    # APP_BASE_URL is critical for QR URLs (Google Lens, phone camera)
    APP_BASE_URL = os.getenv("APP_BASE_URL", f"http://{LAN_IP}:{PORT}").rstrip("/")
    if "localhost" in APP_BASE_URL or "127.0.0.1" in APP_BASE_URL:
        # Provide LAN alternative for mobile devices
        LAN_BASE_URL = f"http://{LAN_IP}:{PORT}"
    else:
        LAN_BASE_URL = APP_BASE_URL

    # AI Configuration
    AI_PROVIDER = os.getenv("AI_PROVIDER", "smart_offline")
    GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
    OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
    OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.2")
    
    # SMTP / Email Configuration
    SMTP_HOST = os.getenv("SMTP_HOST", "")
    SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
    SMTP_USERNAME = os.getenv("SMTP_USERNAME", "")
    SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
    SMTP_FROM = os.getenv("SMTP_FROM", "quizify-noreply@university.edu")
    SMTP_USE_TLS = os.getenv("SMTP_USE_TLS", "true").lower() in ("true", "1", "yes")
    DEV_EMAIL_MODE = os.getenv("DEV_EMAIL_MODE", "true").lower() in ("true", "1", "yes")
    DEV_EMAIL_LOG = BASE_DIR / "dev_emails.log"
    
    # Security parameters
    JWT_EXPIRATION_HOURS = 24
    RESET_TOKEN_EXPIRATION_MINUTES = 30
    DEFAULT_QR_VALIDITY_SECONDS = 30
    DEFAULT_QR_MAX_ROTATIONS = 5

config = Config()
