import sqlite3
import os
from contextlib import contextmanager
from pathlib import Path
from backend.config import config

DB_PATH = Path(config.DB_PATH)
SCHEMA_PATH = Path(__file__).resolve().parent / "schema.sql"

def get_db_connection():
    """Create a SQLite connection with foreign keys and WAL mode enabled, returning dict rows."""
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH), timeout=30.0, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute("PRAGMA journal_mode = WAL;")
    return conn

@contextmanager
def get_db():
    """Context manager for SQLite database transactions."""
    conn = get_db_connection()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

def query_all(query: str, params: tuple = ()) -> list[dict]:
    """Execute a query and return all results as a list of dictionaries."""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute(query, params)
        rows = cursor.fetchall()
        return [dict(row) for row in rows]

def query_one(query: str, params: tuple = ()) -> dict | None:
    """Execute a query and return a single row as a dictionary or None."""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute(query, params)
        row = cursor.fetchone()
        return dict(row) if row else None

def execute_query(query: str, params: tuple = ()) -> int:
    """Execute an INSERT/UPDATE/DELETE query and return the lastrowid or rowcount."""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute(query, params)
        return cursor.lastrowid or cursor.rowcount

def execute_script(script: str):
    """Execute a multi-statement SQL script."""
    with get_db() as conn:
        conn.executescript(script)

def init_db():
    """Initialize tables from schema.sql if not existing."""
    if not SCHEMA_PATH.exists():
        raise FileNotFoundError(f"Schema file not found at {SCHEMA_PATH}")
    with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
        schema_sql = f.read()
    execute_script(schema_sql)
