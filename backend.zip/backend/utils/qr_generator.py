import io
import base64
import qrcode
from qrcode.image.styledpil import StyledPilImage
from qrcode.image.styles.moduledrawers import RoundedModuleDrawer
from qrcode.image.styles.colormasks import SolidFillColorMask

def generate_qr_data_url(url: str, fill_color: tuple = (2, 132, 199), back_color: tuple = (255, 255, 255)) -> str:
    """
    Generate a high-contrast, scannable QR code PNG encoding a genuine HTTP/HTTPS URL.
    Returns a data URL string suitable for direct browser rendering: data:image/png;base64,...
    """
    qr = qrcode.QRCode(
        version=None, # Auto-size based on URL length
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=10,
        border=3,
    )
    qr.add_data(url)
    qr.make(fit=True)

    # Use standard crisp PIL image
    img = qr.make_image(fill_color="black", back_color="white")
    buffer = io.BytesIO()
    img.save(buffer, format="PNG")
    b64 = base64.b64encode(buffer.getvalue()).decode("utf-8")
    return f"data:image/png;base64,{b64}"

def get_qr_png_bytes(url: str) -> bytes:
    """Return raw PNG bytes for file downloads or PDF embeds."""
    qr = qrcode.QRCode(
        version=None,
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=10,
        border=3,
    )
    qr.add_data(url)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    buffer = io.BytesIO()
    img.save(buffer, format="PNG")
    return buffer.getvalue()
