import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  Clock,
  AlertTriangle,
  CheckCircle,
  ChevronLeft,
  ChevronRight,
  Send,
  ShieldAlert,
  HelpCircle
} from 'lucide-react';
import { useNotification } from '../context/NotificationContext';

export default function LiveQuizTakingView({ quizData, onFinished }) {
  const { token } = useAuth();
  const { notify } = useNotification();
  const { quiz, attempt, questions, savedAnswers } = quizData;

  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState(savedAnswers || {});
  const [tabViolations, setTabViolations] = useState(attempt.tab_switch_count || 0);
  const [violationAlert, setViolationAlert] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [submittedResult, setSubmittedResult] = useState(null);
  const [showSubmitModal, setShowSubmitModal] = useState(false);

  const isSubmittingRef = useRef(false);
  const blurTimestampRef = useRef(null);

  // Authoritative server timer countdown with fallback
  const [remainingSeconds, setRemainingSeconds] = useState(() => {
    let exp = attempt?.server_expires_at ? new Date(attempt.server_expires_at).getTime() : NaN;
    if (isNaN(exp) || exp <= Date.now()) {
      const durMins = Number(quiz?.duration_minutes) || 30;
      exp = Date.now() + durMins * 60 * 1000;
    }
    return Math.max(10, Math.floor((exp - Date.now()) / 1000));
  });

  // Timer Tick
  useEffect(() => {
    const timer = setInterval(() => {
      setRemainingSeconds(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          handleAutoSubmit('TIME_EXPIRED');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Tab / Window Switch Monitoring (Master Build Prompt Section 24)
  useEffect(() => {
    function handleVisibilityChange() {
      if (isSubmittingRef.current || showSubmitModal) return;
      if (document.hidden) {
        blurTimestampRef.current = Date.now();
      } else {
        if (blurTimestampRef.current) {
          const durationSec = Math.round((Date.now() - blurTimestampRef.current) / 1000);
          blurTimestampRef.current = null;
          reportViolation(durationSec);
        }
      }
    }

    function handleWindowBlur() {
      if (isSubmittingRef.current || showSubmitModal) return;
      if (!blurTimestampRef.current) {
        blurTimestampRef.current = Date.now();
      }
    }

    function handleWindowFocus() {
      if (isSubmittingRef.current || showSubmitModal) return;
      if (blurTimestampRef.current) {
        const durationSec = Math.round((Date.now() - blurTimestampRef.current) / 1000);
        blurTimestampRef.current = null;
        reportViolation(durationSec);
      }
    }

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('blur', handleWindowBlur);
    window.addEventListener('focus', handleWindowFocus);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('blur', handleWindowBlur);
      window.removeEventListener('focus', handleWindowFocus);
    };
  }, [attempt.id, showSubmitModal]);

  async function reportViolation(durationSec) {
    if (isSubmittingRef.current) return;
    try {
      const res = await fetch(`/api/quizzes/attempts/${attempt.id}/violation`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ duration_seconds: durationSec })
      });
      const data = await res.json();
      if (data.autoSubmitted) {
        isSubmittingRef.current = true;
        setViolationAlert({
          autoSubmitted: true,
          message: data.reason || 'Maximum allowed tab switches exceeded. Examination auto-submitted due to proctoring violation.'
        });
        setSubmittedResult(data.attempt || {
          status: 'AUTO_SUBMITTED_VIOLATION',
          tab_switch_count: data.violationsCount || attempt.tab_switch_count,
          total_score: data.attempt?.total_score || 0
        });
      } else {
        setTabViolations(data.violationsCount);
        setViolationAlert({
          autoSubmitted: false,
          message: `Warning: Window/Tab switch detected (${data.violationsCount}/${data.maxAllowed}). Further violations will terminate and auto-submit your attempt!`
        });
      }
    } catch (e) {
      console.error('Failed to report violation', e);
    }
  }

  async function saveAnswer(qId, val) {
    setAnswers(prev => ({ ...prev, [qId]: val }));
    try {
      await fetch(`/api/quizzes/attempts/${attempt.id}/answer`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ question_id: qId, answer: val })
      });
    } catch (e) {
      console.error('Failed to save answer', e);
    }
  }

  function handleOpenSubmitModal() {
    setShowSubmitModal(true);
  }

  async function executeSubmit() {
    isSubmittingRef.current = true;
    setSubmitting(true);
    try {
      const res = await fetch(`/api/quizzes/attempts/${attempt.id}/submit`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ answers })
      });
      const data = await res.json();
      setShowSubmitModal(false);
      if (data.attempt) {
        setSubmittedResult(data.attempt);
      } else {
        setSubmittedResult({
          status: 'SUBMITTED',
          total_score: data.score,
          percentage: data.percentage,
          tab_switch_count: tabViolations
        });
      }
    } catch (e) {
      notify('Failed to submit: ' + e.message, 'error');
      isSubmittingRef.current = false;
      setSubmitting(false);
    }
  }

  async function handleAutoSubmit(reason) {
    isSubmittingRef.current = true;
    try {
      const res = await fetch(`/api/quizzes/attempts/${attempt.id}/submit`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ answers })
      });
      const data = await res.json();
      if (data.attempt) {
        setSubmittedResult(data.attempt);
      } else {
        setSubmittedResult({
          status: 'TIME_EXPIRED',
          total_score: data.score || 0,
          percentage: data.percentage || 0,
          tab_switch_count: tabViolations
        });
      }
    } catch (e) {}
  }

  // Format Time Remaining (MM:SS)
  const formatTime = (secs) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  if (submittedResult) {
    return (
      <div style={{
        maxWidth: '680px',
        margin: '60px auto',
        padding: '40px',
        textAlign: 'center'
      }} className="glass-panel animate-fade-in">
        <CheckCircle size={56} style={{ color: 'var(--success)', margin: '0 auto 20px' }} />
        <h2 style={{ fontSize: '1.75rem', fontWeight: '800', marginBottom: '8px' }}>
          Examination Attempt Recorded
        </h2>
        <p style={{ color: 'var(--text-secondary)', marginBottom: '24px', fontSize: '0.95rem' }}>
          Your answers have been securely evaluated and archived on the server.
        </p>

        <div style={{
          padding: '20px',
          background: 'var(--bg-tertiary)',
          borderRadius: '16px',
          marginBottom: '28px',
          display: 'grid',
          gridTemplateColumns: 'repeat(3, 1fr)',
          gap: '12px'
        }}>
          <div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Status</div>
            <div style={{ fontWeight: '700', color: 'var(--accent-primary)', marginTop: '4px' }}>
              {submittedResult.status}
            </div>
          </div>
          <div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Tab Violations</div>
            <div style={{ fontWeight: '700', color: submittedResult.tab_switch_count > 0 ? 'var(--warning)' : 'var(--success)', marginTop: '4px' }}>
              {submittedResult.tab_switch_count} Recorded
            </div>
          </div>
          <div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Questions Answered</div>
            <div style={{ fontWeight: '700', color: 'var(--text-primary)', marginTop: '4px' }}>
              {Object.keys(answers).length} / {questions.length}
            </div>
          </div>
        </div>

        <button onClick={onFinished} className="btn-primary" style={{ padding: '12px 28px' }}>
          Return to Student Dashboard
        </button>
      </div>
    );
  }

  const currentQ = questions[currentIndex] || questions[0];

  return (
    <div style={{ maxWidth: '1000px', margin: '20px auto', padding: '0 20px' }}>
      {/* Top Examination HUD */}
      <div className="glass-panel" style={{
        padding: '16px 24px',
        borderRadius: '16px',
        marginBottom: '20px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between'
      }}>
        <div>
          <h2 style={{ fontSize: '1.25rem', fontWeight: '800' }}>{quiz.title}</h2>
          <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
            {quiz.subject_name} ({quiz.subject_code}) • {questions.length} Questions • Max Marks: {quiz.total_marks}
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
          {/* Violations Warning Counter */}
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            padding: '8px 14px',
            borderRadius: '10px',
            background: tabViolations > 0 ? 'rgba(239, 68, 68, 0.12)' : 'var(--bg-tertiary)',
            color: tabViolations > 0 ? 'var(--danger)' : 'var(--text-muted)',
            border: tabViolations > 0 ? '1px solid rgba(239, 68, 68, 0.3)' : '1px solid var(--border-glass)',
            fontSize: '0.825rem',
            fontWeight: '600'
          }}>
            <ShieldAlert size={16} />
            <span>Violations: {tabViolations}/{quiz.max_tab_switches}</span>
          </div>

          {/* Authoritative Server Countdown */}
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '10px',
            padding: '8px 16px',
            borderRadius: '12px',
            background: remainingSeconds < 300 ? 'rgba(239, 68, 68, 0.15)' : 'var(--accent-light)',
            color: remainingSeconds < 300 ? '#ef4444' : 'var(--accent-primary)',
            border: `1px solid ${remainingSeconds < 300 ? 'rgba(239, 68, 68, 0.3)' : 'var(--accent-border)'}`,
            fontWeight: '700',
            fontSize: '1.1rem',
            fontFamily: 'var(--font-mono)'
          }}>
            <Clock size={18} />
            <span>{formatTime(remainingSeconds)}</span>
          </div>

          <button
            onClick={handleOpenSubmitModal}
            disabled={submitting}
            className="btn-primary"
            style={{ padding: '10px 20px', background: 'linear-gradient(135deg, #10b981, #059669)' }}
          >
            <Send size={16} />
            <span>Submit Quiz</span>
          </button>
        </div>
      </div>

      {/* Tab Switch Warning Modal / Banner */}
      {violationAlert && (
        <div className="tab-switch-warning animate-fade-in">
          <AlertTriangle size={24} style={{ color: 'var(--danger)', flexShrink: 0 }} />
          <div style={{ flex: 1, fontSize: '0.875rem', fontWeight: '500', color: 'var(--text-primary)' }}>
            {violationAlert.message}
          </div>
          <button 
            onClick={() => setViolationAlert(null)}
            className="btn-secondary"
            style={{ padding: '4px 10px', fontSize: '0.75rem' }}
          >
            Acknowledge
          </button>
        </div>
      )}

      {/* Main Examination Viewport */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 280px', gap: '20px' }}>
        {/* Left: Current Question Card */}
        <div className="glass-panel" style={{ padding: '30px', borderRadius: '20px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
            <span className="badge badge-active" style={{ fontSize: '0.85rem', padding: '6px 14px' }}>
              Question {currentIndex + 1} of {questions.length}
            </span>
            <div style={{ display: 'flex', gap: '8px' }}>
              <span className="badge" style={{ background: 'var(--bg-tertiary)', color: 'var(--text-secondary)' }}>
                {currentQ.type}
              </span>
              <span className="badge" style={{ background: 'var(--bg-tertiary)', color: 'var(--text-secondary)' }}>
                {currentQ.marks} Marks
              </span>
            </div>
          </div>

          <p style={{ fontSize: '1.15rem', fontWeight: '600', lineHeight: 1.6, marginBottom: '24px' }}>
            {currentQ.question}
          </p>

          {/* MCQ Options */}
          {currentQ.type === 'MCQ' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              {(currentQ.options || []).map((opt, oIdx) => {
                const isSelected = answers[currentQ.id] === opt;
                return (
                  <button
                    key={oIdx}
                    type="button"
                    onClick={() => saveAnswer(currentQ.id, opt)}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '14px',
                      padding: '14px 18px',
                      borderRadius: '12px',
                      border: isSelected ? '2px solid var(--accent-primary)' : '1px solid var(--border-glass)',
                      background: isSelected ? 'var(--accent-light)' : 'var(--bg-secondary)',
                      color: 'var(--text-primary)',
                      cursor: 'pointer',
                      textAlign: 'left',
                      fontSize: '0.95rem',
                      fontWeight: isSelected ? '600' : '400',
                      transition: 'all 0.15s'
                    }}
                  >
                    <div style={{
                      width: '24px',
                      height: '24px',
                      borderRadius: '50%',
                      border: isSelected ? '6px solid var(--accent-primary)' : '2px solid var(--text-muted)',
                      background: 'var(--bg-primary)',
                      flexShrink: 0
                    }} />
                    <span>{opt}</span>
                  </button>
                );
              })}
            </div>
          )}

          {/* Numerical Input */}
          {currentQ.type === 'NUMERICAL' && (
            <div>
              <label style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', display: 'block', marginBottom: '8px' }}>
                Enter Numerical Answer (Integer or Decimal)
              </label>
              <input
                type="text"
                className="input-field"
                placeholder="e.g. 42 or 3.1415"
                value={answers[currentQ.id] || ''}
                onChange={e => saveAnswer(currentQ.id, e.target.value)}
                style={{ fontSize: '1.1rem', fontFamily: 'var(--font-mono)' }}
              />
            </div>
          )}

          {/* Subjective Input */}
          {currentQ.type === 'SUBJECTIVE' && (
            <div>
              <label style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', display: 'block', marginBottom: '8px' }}>
                Write your analytical explanation below (will be evaluated by instructor)
              </label>
              <textarea
                className="input-field"
                rows="6"
                placeholder="Type your academic solution here..."
                value={answers[currentQ.id] || ''}
                onChange={e => saveAnswer(currentQ.id, e.target.value)}
              />
            </div>
          )}

          {/* Navigation Controls */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '30px' }}>
            <button
              onClick={() => setCurrentIndex(prev => Math.max(0, prev - 1))}
              disabled={currentIndex === 0}
              className="btn-secondary"
            >
              <ChevronLeft size={18} /> Previous
            </button>
            {currentIndex < questions.length - 1 ? (
              <button
                onClick={() => setCurrentIndex(prev => Math.min(questions.length - 1, prev + 1))}
                className="btn-primary"
              >
                Next <ChevronRight size={18} />
              </button>
            ) : (
              <button
                onClick={handleOpenSubmitModal}
                className="btn-primary"
                style={{ background: 'linear-gradient(135deg, #10b981, #059669)' }}
              >
                <Send size={16} /> Review & Submit
              </button>
            )}
          </div>
        </div>

        {/* Right: Question Palette Navigator */}
        <div className="glass-panel" style={{ padding: '20px', borderRadius: '20px', height: 'fit-content' }}>
          <h4 style={{ fontSize: '0.9rem', fontWeight: '700', marginBottom: '14px' }}>Question Palette</h4>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '8px' }}>
            {questions.map((q, idx) => {
              const isAnswered = answers[q.id] !== undefined && answers[q.id] !== '';
              const isCurrent = idx === currentIndex;
              return (
                <button
                  key={idx}
                  onClick={() => setCurrentIndex(idx)}
                  style={{
                    height: '42px',
                    borderRadius: '10px',
                    border: isCurrent ? '2px solid var(--accent-primary)' : '1px solid var(--border-glass)',
                    background: isAnswered ? 'rgba(16, 185, 129, 0.2)' : 'var(--bg-tertiary)',
                    color: isAnswered ? '#10b981' : 'var(--text-primary)',
                    fontWeight: '700',
                    fontSize: '0.85rem',
                    cursor: 'pointer'
                  }}
                >
                  {idx + 1}
                </button>
              );
            })}
          </div>

          <div style={{ marginTop: '20px', paddingTop: '16px', borderTop: '1px solid var(--border-subtle)', fontSize: '0.75rem', color: 'var(--text-muted)', display: 'flex', flexDirection: 'column', gap: '6px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span style={{ width: '10px', height: '10px', borderRadius: '50%', background: '#10b981' }} />
              <span>Answered ({Object.keys(answers).length})</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span style={{ width: '10px', height: '10px', borderRadius: '50%', background: 'var(--text-muted)' }} />
              <span>Unanswered ({questions.length - Object.keys(answers).length})</span>
            </div>
          </div>
        </div>
      </div>

      {/* In-Page Web Submission Confirmation Modal (Prevents Chrome window blur / violation trigger) */}
      {showSubmitModal && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100vw',
          height: '100vh',
          background: 'rgba(0, 0, 0, 0.75)',
          backdropFilter: 'blur(8px)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 99999
        }}>
          <div className="glass-panel animate-fade-in" style={{
            width: '480px',
            maxWidth: '92%',
            padding: '32px',
            borderRadius: '24px',
            textAlign: 'center',
            border: '1px solid var(--border-glass)',
            boxShadow: '0 20px 50px rgba(0,0,0,0.5)'
          }}>
            <div style={{
              width: '56px',
              height: '56px',
              borderRadius: '50%',
              background: 'rgba(16, 185, 129, 0.15)',
              color: 'var(--success)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto 16px'
            }}>
              <CheckCircle size={32} />
            </div>
            <h3 style={{ fontSize: '1.35rem', fontWeight: '800', marginBottom: '8px' }}>
              Finalize Examination Attempt?
            </h3>
            <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', marginBottom: '20px', lineHeight: 1.5 }}>
              You have answered <strong>{Object.keys(answers).length}</strong> of <strong>{questions.length}</strong> questions.
              Once confirmed, your responses will be submitted and evaluated by the server.
            </p>

            <div style={{
              padding: '14px',
              background: 'var(--bg-tertiary)',
              borderRadius: '12px',
              marginBottom: '24px',
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              gap: '12px',
              fontSize: '0.85rem'
            }}>
              <div>
                <div style={{ color: 'var(--text-muted)' }}>Time Remaining</div>
                <div style={{ fontWeight: '700', color: 'var(--accent-primary)', marginTop: '2px' }}>{formatTime(remainingSeconds)}</div>
              </div>
              <div>
                <div style={{ color: 'var(--text-muted)' }}>Tab Violations</div>
                <div style={{ fontWeight: '700', color: tabViolations > 0 ? 'var(--danger)' : 'var(--success)', marginTop: '2px' }}>
                  {tabViolations} / {quiz.max_tab_switches}
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', gap: '12px', justifyContent: 'center' }}>
              <button
                type="button"
                onClick={() => setShowSubmitModal(false)}
                disabled={submitting}
                className="btn-secondary"
                style={{ flex: 1, padding: '12px' }}
              >
                Continue Answering
              </button>
              <button
                type="button"
                onClick={executeSubmit}
                disabled={submitting}
                className="btn-primary"
                style={{ flex: 1, padding: '12px', background: 'linear-gradient(135deg, #10b981, #059669)' }}
              >
                {submitting ? 'Submitting...' : 'Yes, Finalize & Submit'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
