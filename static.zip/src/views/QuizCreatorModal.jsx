import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  X,
  Sparkles,
  FileUp,
  Plus,
  Trash2,
  Calendar,
  Clock,
  CheckCircle,
  AlertCircle,
  Layers,
  HelpCircle,
  FileText
} from 'lucide-react';

export default function QuizCreatorModal({
  isOpen,
  onClose,
  onCreated,
  subjects = [],
  divisions = [],
  batches = [],
  initialTab = 'INFO',
  initialSubjectId = ''
}) {
  const { token, user } = useAuth();

  const [activeTab, setActiveTab] = useState(initialTab || 'INFO'); // 'INFO', 'AI_GEN', 'FILE_UPLOAD', 'QUESTIONS'

  // Quiz Parameters
  const [title, setTitle] = useState('');
  const [subjectId, setSubjectId] = useState(initialSubjectId ? String(initialSubjectId) : '');
  const [divisionId, setDivisionId] = useState('');
  const [batchId, setBatchId] = useState('');

  React.useEffect(() => {
    if (isOpen) {
      if (initialTab) setActiveTab(initialTab);
      if (initialSubjectId) setSubjectId(String(initialSubjectId));
    }
  }, [isOpen, initialTab, initialSubjectId]);
  const [topic, setTopic] = useState('');
  const [durationMinutes, setDurationMinutes] = useState(30);
  const [startTime, setStartTime] = useState(() => {
    const d = new Date();
    d.setMinutes(d.getMinutes() + 2);
    return d.toISOString().slice(0, 16);
  });
  const [endTime, setEndTime] = useState(() => {
    const d = new Date();
    d.setHours(d.getHours() + 2);
    return d.toISOString().slice(0, 16);
  });
  const [resultReleaseTime, setResultReleaseTime] = useState(() => {
    const d = new Date();
    d.setHours(d.getHours() + 3);
    return d.toISOString().slice(0, 16);
  });
  const [maxTabSwitches, setMaxTabSwitches] = useState(3);
  const [attendanceReqType, setAttendanceReqType] = useState('NONE'); // 'NONE', 'LINKED_SESSION', 'PERCENTAGE_THRESHOLD'
  const [reqPercentage, setReqPercentage] = useState(75);

  // Questions List
  const [questions, setQuestions] = useState([]);

  // AI Generation State
  const [aiTopic, setAiTopic] = useState('');
  const [aiNumQ, setAiNumQ] = useState(5);
  const [aiEasy, setAiEasy] = useState(2);
  const [aiMed, setAiMed] = useState(2);
  const [aiHard, setAiHard] = useState(1);
  const [aiMcqCount, setAiMcqCount] = useState(3);
  const [aiNumCount, setAiNumCount] = useState(1);
  const [aiAnsCount, setAiAnsCount] = useState(1);
  const [aiInstructions, setAiInstructions] = useState('');
  const [aiLoading, setAiLoading] = useState(false);

  function autoBalanceCounts(total) {
    const t = Math.max(1, Number(total) || 5);
    setAiNumQ(t);
    const e = Math.max(1, Math.floor(t * 0.4));
    const m = Math.max(1, Math.floor(t * 0.4));
    const h = Math.max(0, t - e - m);
    setAiEasy(e);
    setAiMed(m);
    setAiHard(h);

    const mcq = Math.max(1, Math.floor(t * 0.6));
    const num = Math.max(0, Math.floor(t * 0.2));
    const ans = Math.max(0, t - mcq - num);
    setAiMcqCount(mcq);
    setAiNumCount(num);
    setAiAnsCount(ans);
  }

  // File Upload State
  const [uploadFile, setUploadFile] = useState(null);
  const [fileNumQ, setFileNumQ] = useState(5);
  const [fileLoading, setFileLoading] = useState(false);
  const [fileScanning, setFileScanning] = useState(false);

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  // Safe Arrays
  const safeSubjects = Array.isArray(subjects) ? subjects : [];
  const safeDivisions = Array.isArray(divisions) ? divisions : [];
  const safeBatches = Array.isArray(batches) ? batches : [];

  // Filter batches under selected division
  const filteredBatches = safeBatches.filter(b => !divisionId || String(b.division_id) === String(divisionId));

  async function handleAIGenerate(e) {
    e.preventDefault();
    if (!aiTopic.trim()) {
      setError('Please provide a topic for AI generation.');
      return;
    }

    const totalQ = Number(aiNumQ);
    const easy = Number(aiEasy);
    const med = Number(aiMed);
    const hard = Number(aiHard);
    const mcq = Number(aiMcqCount);
    const num = Number(aiNumCount);
    const ans = Number(aiAnsCount);

    if (easy + med + hard !== totalQ) {
      setError(`Difficulty count mismatch: Easy (${easy}) + Medium (${med}) + Hard (${hard}) = ${easy + med + hard}, but Total is ${totalQ}.`);
      return;
    }
    if (mcq + num + ans !== totalQ) {
      setError(`Question type count mismatch: MCQ (${mcq}) + Numerical (${num}) + Answer Type (${ans}) = ${mcq + num + ans}, but Total is ${totalQ}.`);
      return;
    }

    setError('');
    setAiLoading(true);

    try {
      const res = await fetch('/api/quizzes/generate-ai', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          topic: aiTopic.trim(),
          subject_id: subjectId,
          difficultyDist: { easy, medium: med, hard },
          questionTypes: ['MCQ', 'NUMERICAL', 'SUBJECTIVE'],
          numQuestions: totalQ,
          mcqCount: mcq,
          numCount: num,
          ansCount: ans,
          customInstructions: aiInstructions
        })
      });

      const text = await res.text();
      let data = {};
      try {
        data = JSON.parse(text);
      } catch (jsonErr) {
        throw new Error(`Server returned error (${res.status}): ${text.slice(0, 100)}`);
      }
      if (!res.ok) throw new Error(data.error || 'AI question generation failed');

      const incoming = (data.questions || []).map((q, i) => ({
        order_index: questions.length + i + 1,
        type: q.type || q.question_type || 'MCQ',
        question: q.question || '',
        options: (q.type || q.question_type) === 'MCQ' ? (Array.isArray(q.options) && q.options.length ? q.options : ['Option A', 'Option B', 'Option C', 'Option D']) : null,
        correct_answer: q.correct_answer || (q.options ? q.options[0] : ''),
        explanation: q.explanation || '',
        difficulty: q.difficulty || 'MEDIUM',
        marks: Number(q.marks) > 0 ? Number(q.marks) : 1.0,
        numerical_tolerance: q.numerical_tolerance != null ? Number(q.numerical_tolerance) : ((q.type || q.question_type) === 'NUMERICAL' ? 0.05 : 0),
        numerical_exact_required: q.numerical_exact_required ? 1 : 0,
        decimal_places_required: q.decimal_places_required != null ? Number(q.decimal_places_required) : -1
      }));

      setQuestions(prev => [...prev, ...incoming]);
      setActiveTab('QUESTIONS');
    } catch (err) {
      setError(err.message);
    } finally {
      setAiLoading(false);
    }
  }

  async function handleFileUpload(e) {
    e.preventDefault();
    if (!uploadFile) {
      setError('Please select a PDF or DOCX file to extract questions.');
      return;
    }
    setError('');
    setFileLoading(true);
    setFileScanning(true);

    try {
      const formData = new FormData();
      formData.append('file', uploadFile);
      formData.append('subject_id', subjectId);
      formData.append('numQuestions', fileNumQ);

      const res = await fetch('/api/quizzes/generate-file', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
        body: formData
      });

      const text = await res.text();
      let data = {};
      try {
        data = JSON.parse(text);
      } catch (jsonErr) {
        throw new Error(`Server returned error (${res.status}): ${text.slice(0, 100)}`);
      }
      if (!res.ok) throw new Error(data.error || 'File question parsing failed');

      const incoming = (data.questions || []).map((q, i) => ({
        order_index: questions.length + i + 1,
        type: q.type || q.question_type || 'MCQ',
        question: q.question || '',
        options: (q.type || q.question_type) === 'MCQ' ? (Array.isArray(q.options) && q.options.length ? q.options : ['Option A', 'Option B', 'Option C', 'Option D']) : null,
        correct_answer: q.correct_answer || (q.options ? q.options[0] : ''),
        explanation: q.explanation || '',
        difficulty: q.difficulty || 'MEDIUM',
        marks: Number(q.marks) > 0 ? Number(q.marks) : 1.0,
        numerical_tolerance: q.numerical_tolerance != null ? Number(q.numerical_tolerance) : ((q.type || q.question_type) === 'NUMERICAL' ? 0.05 : 0),
        numerical_exact_required: q.numerical_exact_required ? 1 : 0,
        decimal_places_required: q.decimal_places_required != null ? Number(q.decimal_places_required) : -1
      }));

      setQuestions(prev => [...prev, ...incoming]);
      setActiveTab('QUESTIONS');
    } catch (err) {
      setError(err.message);
    } finally {
      setFileLoading(false);
      setFileScanning(false);
    }
  }

  function handleAddManualQuestion() {
    const newQ = {
      order_index: questions.length + 1,
      type: 'MCQ',
      question: 'New Question Prompt',
      options: ['Option 1', 'Option 2', 'Option 3', 'Option 4'],
      correct_answer: 'Option 1',
      explanation: 'Explanation for correct choice.',
      difficulty: 'MEDIUM',
      marks: 1.0,
      numerical_tolerance: 0,
      numerical_exact_required: 0,
      decimal_places_required: -1
    };
    setQuestions(prev => [...prev, newQ]);
  }

  function handleUpdateQuestion(index, field, value) {
    setQuestions(prev => {
      const copy = [...prev];
      copy[index] = { ...copy[index], [field]: value };
      return copy;
    });
  }

  function handleRemoveQuestion(index) {
    setQuestions(prev => prev.filter((_, i) => i !== index));
  }

  async function handleFinalSchedule(e) {
    if (e && e.preventDefault) e.preventDefault();
    if (!title.trim() || !subjectId || !divisionId) {
      setError('Please complete title, subject, and division assignments.');
      setActiveTab('INFO');
      return;
    }
    if (questions.length === 0) {
      setError('Please add or generate at least one question before scheduling.');
      setActiveTab('QUESTIONS');
      return;
    }

    const cleanedQuestions = questions.map((q, idx) => ({
      order_index: idx + 1,
      type: q.type || 'MCQ',
      question: (q.question || '').trim(),
      options: q.type === 'MCQ' ? (Array.isArray(q.options) ? q.options : []) : null,
      correct_answer: String(q.correct_answer ?? '').trim(),
      explanation: String(q.explanation ?? '').trim(),
      difficulty: q.difficulty || 'MEDIUM',
      marks: Number(q.marks) > 0 ? Number(q.marks) : 1.0,
      numerical_tolerance: q.type === 'NUMERICAL' ? (q.numerical_tolerance != null && Number(q.numerical_tolerance) >= 0 ? Number(q.numerical_tolerance) : 0.05) : 0,
      numerical_exact_required: q.numerical_exact_required ? 1 : 0,
      decimal_places_required: q.decimal_places_required != null ? Number(q.decimal_places_required) : -1
    }));

    if (cleanedQuestions.some(q => !q.question)) {
      setError('All questions must have valid question text before scheduling.');
      setActiveTab('QUESTIONS');
      return;
    }

    setError('');
    setSubmitting(true);

    try {
      const res = await fetch('/api/quizzes', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          title: title.trim(),
          subject_id: Number(subjectId),
          division_id: Number(divisionId),
          batch_id: batchId ? Number(batchId) : null,
          topic: topic.trim(),
          duration_minutes: Number(durationMinutes),
          start_time: startTime,
          end_time: endTime,
          result_release_time: resultReleaseTime,
          max_tab_switches: Number(maxTabSwitches),
          attendance_requirement_type: attendanceReqType,
          required_attendance_percentage: Number(reqPercentage),
          questions: cleanedQuestions
        })
      });

      const text = await res.text();
      let data = {};
      try {
        data = JSON.parse(text);
      } catch (jsonErr) {
        throw new Error(`Server returned error (${res.status}): ${text.slice(0, 120)}`);
      }

      if (!res.ok) throw new Error(data.error || 'Failed to schedule quiz');

      if (onCreated) onCreated(data.quiz);
      onClose();
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      width: '100vw',
      height: '100vh',
      background: 'rgba(0, 0, 0, 0.75)',
      backdropFilter: 'blur(10px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 9999
    }}>
      <div className="glass-panel" style={{
        width: '920px',
        maxWidth: '95%',
        maxHeight: '90vh',
        display: 'flex',
        flexDirection: 'column',
        borderRadius: '24px',
        overflow: 'hidden'
      }}>
        {/* Modal Header */}
        <div style={{
          padding: '20px 28px',
          borderBottom: '1px solid var(--border-subtle)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          background: 'var(--bg-secondary)'
        }}>
          <div>
            <h2 style={{ fontSize: '1.35rem', fontWeight: '800' }}>Schedule Examination / Quiz</h2>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>
              Authoritative server timer • AI question generation • Attendance eligibility integration
            </p>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
            <X size={22} />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div style={{
          display: 'flex',
          gap: '8px',
          padding: '12px 28px',
          background: 'var(--bg-tertiary)',
          borderBottom: '1px solid var(--border-glass)'
        }}>
          {[
            { id: 'INFO', label: '1. Basic Configuration', icon: Layers },
            { id: 'AI_GEN', label: '2. AI Generator', icon: Sparkles },
            { id: 'FILE_UPLOAD', label: '3. Upload PDF / DOCX', icon: FileUp },
            { id: 'QUESTIONS', label: `4. Review Questions (${questions.length})`, icon: HelpCircle }
          ].map(t => {
            const Icon = t.icon;
            const isA = activeTab === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setActiveTab(t.id)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  padding: '8px 16px',
                  borderRadius: '10px',
                  border: isA ? '1px solid var(--accent-border)' : '1px solid transparent',
                  background: isA ? 'var(--accent-light)' : 'transparent',
                  color: isA ? 'var(--accent-primary)' : 'var(--text-secondary)',
                  fontWeight: isA ? '600' : '500',
                  fontSize: '0.825rem',
                  cursor: 'pointer'
                }}
              >
                <Icon size={16} />
                <span>{t.label}</span>
              </button>
            );
          })}
        </div>

        {/* Content Body */}
        <div style={{ padding: '24px 28px', overflowY: 'auto', flex: 1 }}>
          {error && (
            <div style={{
              background: 'rgba(239, 68, 68, 0.12)',
              border: '1px solid rgba(239, 68, 68, 0.3)',
              color: '#ef4444',
              padding: '12px 16px',
              borderRadius: '10px',
              marginBottom: '20px',
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
              fontSize: '0.85rem'
            }}>
              <AlertCircle size={18} />
              <span>{error}</span>
            </div>
          )}

          {/* TAB 1: BASIC INFO */}
          {activeTab === 'INFO' && (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '18px' }}>
              <div style={{ gridColumn: 'span 2' }}>
                <label style={{ fontSize: '0.825rem', fontWeight: '600', color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>
                  Quiz Title *
                </label>
                <input
                  type="text"
                  className="input-field"
                  placeholder="e.g. Mid-Term Assessment: Trees & Graph Traversal"
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  required
                />
              </div>

              <div>
                <label style={{ fontSize: '0.825rem', fontWeight: '600', color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>
                  Subject *
                </label>
                <select className="input-field" value={subjectId} onChange={e => setSubjectId(e.target.value)} required>
                  <option value="">-- Select Subject --</option>
                  {safeSubjects.map(s => (
                    <option key={s.id} value={s.id}>{s.name} ({s.code})</option>
                  ))}
                </select>
              </div>

              <div>
                <label style={{ fontSize: '0.825rem', fontWeight: '600', color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>
                  Division *
                </label>
                <select className="input-field" value={divisionId} onChange={e => { setDivisionId(e.target.value); setBatchId(''); }} required>
                  <option value="">-- Select Division --</option>
                  {safeDivisions.map(d => (
                    <option key={d.id} value={d.id}>Division {d.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label style={{ fontSize: '0.825rem', fontWeight: '600', color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>
                  Target Batch (Optional)
                </label>
                <select className="input-field" value={batchId} onChange={e => setBatchId(e.target.value)}>
                  <option value="">All Batches in Division</option>
                  {filteredBatches.map(b => (
                    <option key={b.id} value={b.id}>Batch {b.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label style={{ fontSize: '0.825rem', fontWeight: '600', color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>
                  Topic Description
                </label>
                <input
                  type="text"
                  className="input-field"
                  placeholder="e.g. Binary Search Trees & AVL Rotations"
                  value={topic}
                  onChange={e => setTopic(e.target.value)}
                />
              </div>

              <div>
                <label style={{ fontSize: '0.825rem', fontWeight: '600', color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>
                  Duration (Minutes) *
                </label>
                <input
                  type="number"
                  className="input-field"
                  value={durationMinutes}
                  onChange={e => setDurationMinutes(e.target.value)}
                  min="5"
                  max="180"
                  required
                />
              </div>

              <div>
                <label style={{ fontSize: '0.825rem', fontWeight: '600', color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>
                  Max Tab Switches Allowed
                </label>
                <input
                  type="number"
                  className="input-field"
                  value={maxTabSwitches}
                  onChange={e => setMaxTabSwitches(e.target.value)}
                  min="1"
                  max="10"
                />
              </div>

              <div>
                <label style={{ fontSize: '0.825rem', fontWeight: '600', color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>
                  Start Window *
                </label>
                <input
                  type="datetime-local"
                  className="input-field"
                  value={startTime}
                  onChange={e => setStartTime(e.target.value)}
                  required
                />
              </div>

              <div>
                <label style={{ fontSize: '0.825rem', fontWeight: '600', color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>
                  Submission Closes At *
                </label>
                <input
                  type="datetime-local"
                  className="input-field"
                  value={endTime}
                  onChange={e => setEndTime(e.target.value)}
                  required
                />
              </div>

              <div>
                <label style={{ fontSize: '0.825rem', fontWeight: '600', color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>
                  Result Release Timing *
                </label>
                <input
                  type="datetime-local"
                  className="input-field"
                  value={resultReleaseTime}
                  onChange={e => setResultReleaseTime(e.target.value)}
                  required
                />
              </div>

              <div>
                <label style={{ fontSize: '0.825rem', fontWeight: '600', color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>
                  Attendance Requirement Policy
                </label>
                <select className="input-field" value={attendanceReqType} onChange={e => setAttendanceReqType(e.target.value)}>
                  <option value="NONE">No Attendance Requirement</option>
                  <option value="PERCENTAGE_THRESHOLD">Require Minimum Attendance %</option>
                </select>
              </div>

              {attendanceReqType === 'PERCENTAGE_THRESHOLD' && (
                <div style={{ gridColumn: 'span 2' }}>
                  <label style={{ fontSize: '0.825rem', fontWeight: '600', color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>
                    Mandatory Attendance Threshold: {reqPercentage}%
                  </label>
                  <input
                    type="range"
                    min="50"
                    max="90"
                    value={reqPercentage}
                    onChange={e => setReqPercentage(e.target.value)}
                    style={{ width: '100%' }}
                  />
                </div>
              )}
            </div>
          )}

          {/* TAB 2: AI QUESTION GENERATION */}
          {activeTab === 'AI_GEN' && (
            <form onSubmit={handleAIGenerate} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div style={{
                background: 'var(--accent-light)',
                border: '1px solid var(--accent-border)',
                padding: '14px 18px',
                borderRadius: '12px',
                display: 'flex',
                alignItems: 'center',
                gap: '12px'
              }}>
                <Sparkles size={24} style={{ color: 'var(--accent-primary)', flexShrink: 0 }} />
                <div style={{ fontSize: '0.85rem' }}>
                  <strong>Curriculum AI Engine:</strong> Automatically produces pedagogically sound MCQs, numerical tolerance questions, and rubrics. Questions will be added directly to your editable question list for review.
                </div>
              </div>

              <div>
                <label style={{ fontSize: '0.825rem', fontWeight: '600', color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>
                  Topic or Syllabus Unit *
                </label>
                <input
                  type="text"
                  className="input-field"
                  placeholder="e.g. Asymptotic Complexity and Recurrence Relations (Master Theorem)"
                  value={aiTopic}
                  onChange={e => setAiTopic(e.target.value)}
                  required
                />
              </div>

              {/* DIFFICULTY DISTRIBUTION */}
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                  <label style={{ fontSize: '0.825rem', fontWeight: '600', color: 'var(--text-secondary)' }}>
                    Difficulty Distribution (Easy + Medium + Hard = Total)
                  </label>
                  <button
                    type="button"
                    onClick={() => autoBalanceCounts(aiNumQ)}
                    style={{ background: 'none', border: 'none', color: 'var(--accent-primary)', fontSize: '0.75rem', fontWeight: '600', cursor: 'pointer' }}
                  >
                    ⚡ Auto-Balance
                  </button>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '14px' }}>
                  <div>
                    <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>
                      Total Questions
                    </label>
                    <input
                      type="number"
                      className="input-field"
                      value={aiNumQ}
                      onChange={e => autoBalanceCounts(e.target.value)}
                      min="1"
                      max="20"
                    />
                  </div>
                  <div>
                    <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>
                      Easy
                    </label>
                    <input
                      type="number"
                      className="input-field"
                      value={aiEasy}
                      onChange={e => setAiEasy(e.target.value)}
                      min="0"
                    />
                  </div>
                  <div>
                    <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>
                      Medium
                    </label>
                    <input
                      type="number"
                      className="input-field"
                      value={aiMed}
                      onChange={e => setAiMed(e.target.value)}
                      min="0"
                    />
                  </div>
                  <div>
                    <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>
                      Hard
                    </label>
                    <input
                      type="number"
                      className="input-field"
                      value={aiHard}
                      onChange={e => setAiHard(e.target.value)}
                      min="0"
                    />
                  </div>
                </div>
              </div>

              {/* QUESTION TYPE DISTRIBUTION */}
              <div>
                <label style={{ fontSize: '0.825rem', fontWeight: '600', color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>
                  Question Type Breakdown (MCQ + Numerical + Answer Type = Total)
                </label>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '14px' }}>
                  <div>
                    <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>
                      Multiple Choice (MCQ)
                    </label>
                    <input
                      type="number"
                      className="input-field"
                      value={aiMcqCount}
                      onChange={e => setAiMcqCount(e.target.value)}
                      min="0"
                    />
                  </div>
                  <div>
                    <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>
                      Numerical Questions
                    </label>
                    <input
                      type="number"
                      className="input-field"
                      value={aiNumCount}
                      onChange={e => setAiNumCount(e.target.value)}
                      min="0"
                    />
                  </div>
                  <div>
                    <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>
                      Answer Type (Subjective)
                    </label>
                    <input
                      type="number"
                      className="input-field"
                      value={aiAnsCount}
                      onChange={e => setAiAnsCount(e.target.value)}
                      min="0"
                    />
                  </div>
                </div>
              </div>

              {/* LIVE VALIDATION BADGE */}
              {(() => {
                const totalQ = Number(aiNumQ);
                const diffSum = Number(aiEasy) + Number(aiMed) + Number(aiHard);
                const typeSum = Number(aiMcqCount) + Number(aiNumCount) + Number(aiAnsCount);
                const isDiffOk = diffSum === totalQ;
                const isTypeOk = typeSum === totalQ;
                const allOk = isDiffOk && isTypeOk;

                return (
                  <div style={{
                    padding: '10px 14px',
                    borderRadius: '10px',
                    fontSize: '0.8rem',
                    background: allOk ? 'rgba(34, 197, 94, 0.12)' : 'rgba(239, 68, 68, 0.12)',
                    border: `1px solid ${allOk ? 'rgba(34, 197, 94, 0.3)' : 'rgba(239, 68, 68, 0.3)'}`,
                    color: allOk ? '#4ade80' : '#f87171',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between'
                  }}>
                    <span>
                      {allOk
                        ? `✓ Counts Valid: Difficulty sum (${diffSum}/${totalQ}) & Type sum (${typeSum}/${totalQ}) match!`
                        : `⚠️ Mismatch: Difficulty (${diffSum}/${totalQ}) ${isDiffOk ? '✓' : '✗'} & Type (${typeSum}/${totalQ}) ${isTypeOk ? '✓' : '✗'}`}
                    </span>
                    {!allOk && (
                      <button
                        type="button"
                        onClick={() => autoBalanceCounts(aiNumQ)}
                        style={{ background: 'none', border: 'none', color: 'var(--accent-primary)', fontWeight: '700', cursor: 'pointer', textDecoration: 'underline' }}
                      >
                        Fix Now
                      </button>
                    )}
                  </div>
                );
              })()}

              <div>
                <label style={{ fontSize: '0.825rem', fontWeight: '600', color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>
                  Specific Guidelines / Instructions
                </label>
                <textarea
                  className="input-field"
                  rows="3"
                  placeholder="e.g. Include at least two numerical calculations on log bounds and focus on worst-case bounds."
                  value={aiInstructions}
                  onChange={e => setAiInstructions(e.target.value)}
                />
              </div>

              <button type="submit" className="btn-primary" disabled={aiLoading} style={{ alignSelf: 'flex-start', padding: '12px 24px' }}>
                {aiLoading ? (
                  <>
                    <Sparkles className="animate-spin" size={18} />
                    <span>Synthesizing Academic Questions...</span>
                  </>
                ) : (
                  <>
                    <Sparkles size={18} />
                    <span>Generate Structured Questions</span>
                  </>
                )}
              </button>
            </form>
          )}

          {/* TAB 3: FILE UPLOAD */}
          {activeTab === 'FILE_UPLOAD' && (
            <form onSubmit={handleFileUpload} style={{ display: 'flex', flexDirection: 'column', gap: '18px' }}>
              <div style={{
                border: '2px dashed var(--border-hover)',
                borderRadius: '16px',
                padding: '36px 20px',
                textAlign: 'center',
                position: 'relative',
                overflow: 'hidden',
                background: 'var(--bg-tertiary)'
              }}>
                {fileScanning && (
                  <div style={{
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    width: '100%',
                    height: '3px',
                    background: 'linear-gradient(90deg, transparent, var(--accent-primary), transparent)',
                    boxShadow: '0 0 15px var(--accent-primary)',
                    animation: 'scanningLine 1.5s infinite linear'
                  }} />
                )}

                <FileText size={42} style={{ color: 'var(--accent-primary)', margin: '0 auto 12px' }} />
                <h4 style={{ fontSize: '1.05rem', fontWeight: '700', marginBottom: '6px' }}>
                  {uploadFile ? uploadFile.name : 'Upload Lecture Material or Question Paper'}
                </h4>
                <p style={{ color: 'var(--text-muted)', fontSize: '0.825rem', marginBottom: '16px' }}>
                  Supports PDF, DOCX, and TXT files. AI classifies reference material vs existing question papers automatically.
                </p>

                <input
                  type="file"
                  id="quizDocInput"
                  accept=".pdf,.docx,.txt"
                  onChange={e => setUploadFile(e.target.files[0] || null)}
                  style={{ display: 'none' }}
                />
                <label htmlFor="quizDocInput" className="btn-secondary" style={{ cursor: 'pointer', display: 'inline-flex' }}>
                  <FileUp size={16} />
                  <span>{uploadFile ? 'Replace Selected File' : 'Choose Document File'}</span>
                </label>
              </div>

              <div>
                <label style={{ fontSize: '0.825rem', fontWeight: '600', color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>
                  Target Questions to Extract/Synthesize
                </label>
                <input
                  type="number"
                  className="input-field"
                  value={fileNumQ}
                  onChange={e => setFileNumQ(e.target.value)}
                  min="1"
                  max="20"
                />
              </div>

              <button type="submit" className="btn-primary" disabled={fileLoading || !uploadFile} style={{ alignSelf: 'flex-start', padding: '12px 24px' }}>
                {fileLoading ? 'Scanning & Parsing Document...' : 'Extract & Generate Questions'}
              </button>
            </form>
          )}

          {/* TAB 4: REVIEW & EDIT QUESTIONS */}
          {activeTab === 'QUESTIONS' && (
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
                <div>
                  <h3 style={{ fontSize: '1.1rem', fontWeight: '700' }}>Editable Question Review</h3>
                  <p style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>
                    Review, adjust options, modify tolerance, change marks, or add manual questions before scheduling.
                  </p>
                </div>
                <button type="button" onClick={handleAddManualQuestion} className="btn-secondary" style={{ padding: '8px 14px', fontSize: '0.825rem' }}>
                  <Plus size={16} /> Add Question
                </button>
              </div>

              {questions.length === 0 ? (
                <div style={{
                  padding: '40px',
                  textAlign: 'center',
                  background: 'var(--bg-tertiary)',
                  borderRadius: '16px',
                  color: 'var(--text-muted)',
                  fontSize: '0.875rem'
                }}>
                  No questions added yet. Use the <strong>AI Generator</strong>, upload a <strong>PDF/DOCX</strong>, or click <strong>Add Question</strong>.
                </div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                  {questions.map((q, idx) => (
                    <div key={idx} className="glass-panel" style={{ padding: '18px 20px', borderRadius: '16px' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '12px' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                          <span className="badge badge-active">Q{idx + 1}</span>
                          <select
                            className="input-field"
                            style={{ width: '130px', padding: '6px 10px', fontSize: '0.8rem' }}
                            value={q.type}
                            onChange={e => handleUpdateQuestion(idx, 'type', e.target.value)}
                          >
                            <option value="MCQ">MCQ</option>
                            <option value="NUMERICAL">Numerical</option>
                            <option value="SUBJECTIVE">Subjective</option>
                          </select>
                          <select
                            className="input-field"
                            style={{ width: '110px', padding: '6px 10px', fontSize: '0.8rem' }}
                            value={q.difficulty}
                            onChange={e => handleUpdateQuestion(idx, 'difficulty', e.target.value)}
                          >
                            <option value="EASY">Easy</option>
                            <option value="MEDIUM">Medium</option>
                            <option value="HARD">Hard</option>
                          </select>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                            <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Marks:</span>
                            <input
                              type="number"
                              className="input-field"
                              style={{ width: '65px', padding: '6px 10px', fontSize: '0.8rem' }}
                              value={q.marks}
                              onChange={e => handleUpdateQuestion(idx, 'marks', Number(e.target.value))}
                              min="0.5"
                              step="0.5"
                            />
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleRemoveQuestion(idx)}
                          style={{ background: 'none', border: 'none', color: 'var(--danger)', cursor: 'pointer', padding: '4px' }}
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>

                      {/* Question text */}
                      <textarea
                        className="input-field"
                        rows="2"
                        value={q.question}
                        onChange={e => handleUpdateQuestion(idx, 'question', e.target.value)}
                        style={{ marginBottom: '12px' }}
                      />

                      {/* MCQ Options */}
                      {q.type === 'MCQ' && (
                        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '10px', marginBottom: '12px' }}>
                          {(Array.isArray(q.options) ? q.options : (typeof q.options === 'string' ? JSON.parse(q.options || '[]') : [])).map((opt, optIdx) => (
                            <div key={optIdx} style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                              <input
                                type="radio"
                                name={`correct-${idx}`}
                                checked={q.correct_answer === opt}
                                onChange={() => handleUpdateQuestion(idx, 'correct_answer', opt)}
                              />
                              <input
                                type="text"
                                className="input-field"
                                value={opt}
                                onChange={e => {
                                  const currentOpts = Array.isArray(q.options) ? [...q.options] : JSON.parse(q.options || '[]');
                                  currentOpts[optIdx] = e.target.value;
                                  handleUpdateQuestion(idx, 'options', currentOpts);
                                }}
                                style={{ fontSize: '0.85rem', padding: '8px 12px' }}
                              />
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Numerical Settings */}
                      {q.type === 'NUMERICAL' && (
                        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px', marginBottom: '12px' }}>
                          <div>
                            <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Correct Answer Value</label>
                            <input
                              type="text"
                              className="input-field"
                              value={q.correct_answer}
                              onChange={e => handleUpdateQuestion(idx, 'correct_answer', e.target.value)}
                            />
                          </div>
                          <div>
                            <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Tolerance (±)</label>
                            <input
                              type="number"
                              className="input-field"
                              value={q.numerical_tolerance || 0}
                              onChange={e => handleUpdateQuestion(idx, 'numerical_tolerance', Number(e.target.value))}
                              step="0.01"
                            />
                          </div>
                          <div>
                            <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Required Decimal Places</label>
                            <input
                              type="number"
                              className="input-field"
                              value={q.decimal_places_required ?? -1}
                              onChange={e => handleUpdateQuestion(idx, 'decimal_places_required', Number(e.target.value))}
                            />
                          </div>
                        </div>
                      )}

                      {/* Subjective Model Rubric */}
                      {q.type === 'SUBJECTIVE' && (
                        <div style={{ marginBottom: '12px' }}>
                          <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Model Answer / Marking Rubric</label>
                          <textarea
                            className="input-field"
                            rows="2"
                            value={q.correct_answer}
                            onChange={e => handleUpdateQuestion(idx, 'correct_answer', e.target.value)}
                          />
                        </div>
                      )}

                      {/* Explanation */}
                      <div>
                        <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Detailed Explanation (Visible after results release)</label>
                        <input
                          type="text"
                          className="input-field"
                          value={q.explanation || ''}
                          onChange={e => handleUpdateQuestion(idx, 'explanation', e.target.value)}
                          style={{ fontSize: '0.825rem' }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div style={{
          padding: '16px 28px',
          borderTop: '1px solid var(--border-subtle)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          background: 'var(--bg-secondary)'
        }}>
          <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
            Total Marks: <strong>{questions.reduce((sum, q) => sum + (Number(q.marks) || 1), 0)}</strong> | Questions: <strong>{questions.length}</strong>
          </div>
          <div style={{ display: 'flex', gap: '12px' }}>
            <button type="button" onClick={onClose} className="btn-secondary">
              Cancel
            </button>
            <button
              type="button"
              onClick={handleFinalSchedule}
              disabled={submitting || questions.length === 0}
              className="btn-primary"
            >
              {submitting ? 'Scheduling Examination...' : 'Approve & Schedule Quiz'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
