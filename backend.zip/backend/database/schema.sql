-- QUIZIFY ACADEMIC PLATFORM RELATIONAL SCHEMA
PRAGMA foreign_keys = ON;

-- Core Users Table
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  identifier TEXT UNIQUE NOT NULL, -- Admin ID, Teacher Login ID, or Student Enrollment Number
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('ADMIN', 'TEACHER', 'STUDENT')),
  name TEXT NOT NULL,
  phone TEXT,
  avatar_url TEXT,
  is_active INTEGER DEFAULT 1 CHECK(is_active IN (0, 1)),
  reset_token_hash TEXT,
  reset_token_expires_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Academic Hierarchy
CREATE TABLE IF NOT EXISTS courses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS semesters (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  number INTEGER NOT NULL,
  academic_year TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(course_id, number, academic_year)
);

CREATE TABLE IF NOT EXISTS divisions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  semester_id INTEGER NOT NULL REFERENCES semesters(id) ON DELETE CASCADE,
  name TEXT NOT NULL, -- e.g. A1, A2, H1
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(semester_id, name)
);

CREATE TABLE IF NOT EXISTS batches (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  division_id INTEGER NOT NULL REFERENCES divisions(id) ON DELETE CASCADE,
  name TEXT NOT NULL, -- e.g. B1, B2 (under A1)
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(division_id, name)
);

CREATE TABLE IF NOT EXISTS subjects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  semester_id INTEGER NOT NULL REFERENCES semesters(id) ON DELETE CASCADE,
  code TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  type TEXT NOT NULL CHECK(type IN ('THEORY', 'PRACTICAL', 'BOTH')) DEFAULT 'BOTH',
  branch TEXT DEFAULT 'Computer Science & Engineering',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Teacher Academic Assignments (Division and optional Batch under Division)
CREATE TABLE IF NOT EXISTS teacher_assignments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  teacher_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
  division_id INTEGER NOT NULL REFERENCES divisions(id) ON DELETE CASCADE,
  batch_id INTEGER REFERENCES batches(id) ON DELETE CASCADE, -- NULL means entire division
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(teacher_id, subject_id, division_id, batch_id)
);

-- Student Profile
CREATE TABLE IF NOT EXISTS student_profiles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  enrollment_number TEXT UNIQUE NOT NULL,
  branch TEXT NOT NULL,
  semester_id INTEGER NOT NULL REFERENCES semesters(id) ON DELETE RESTRICT,
  division_id INTEGER NOT NULL REFERENCES divisions(id) ON DELETE RESTRICT,
  batch_id INTEGER NOT NULL REFERENCES batches(id) ON DELETE RESTRICT,
  gender TEXT,
  date_of_birth DATE,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Timetable Entries
CREATE TABLE IF NOT EXISTS timetable_entries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  academic_year TEXT NOT NULL,
  semester_id INTEGER NOT NULL REFERENCES semesters(id) ON DELETE CASCADE,
  day_of_week INTEGER NOT NULL CHECK(day_of_week BETWEEN 1 AND 7), -- 1=Monday ... 7=Sunday
  start_time TEXT NOT NULL, -- 'HH:MM'
  end_time TEXT NOT NULL,   -- 'HH:MM'
  teacher_id INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE RESTRICT,
  session_type TEXT NOT NULL CHECK(session_type IN ('THEORY', 'PRACTICAL')),
  division_id INTEGER NOT NULL REFERENCES divisions(id) ON DELETE RESTRICT,
  batch_id INTEGER REFERENCES batches(id) ON DELETE RESTRICT, -- NULL = all batches in division
  room TEXT NOT NULL,
  building TEXT,
  attendance_required INTEGER DEFAULT 1,
  is_proxy INTEGER DEFAULT 0,
  specific_date TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Attendance Sessions
CREATE TABLE IF NOT EXISTS attendance_sessions (
  id TEXT PRIMARY KEY, -- UUID
  timetable_entry_id INTEGER REFERENCES timetable_entries(id) ON DELETE SET NULL,
  teacher_id INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  proxy_teacher_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  attendance_type TEXT NOT NULL CHECK(attendance_type IN ('REGULAR', 'PROXY')) DEFAULT 'REGULAR',
  subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE RESTRICT,
  division_id INTEGER NOT NULL REFERENCES divisions(id) ON DELETE RESTRICT,
  batch_ids TEXT NOT NULL, -- JSON array of batch IDs: "[1, 2]" or "[1]"
  session_type TEXT NOT NULL CHECK(session_type IN ('THEORY', 'PRACTICAL')),
  room TEXT NOT NULL,
  session_date DATE NOT NULL,
  scheduled_start TEXT,
  scheduled_end TEXT,
  actual_start DATETIME,
  actual_end DATETIME,
  attendance_status TEXT NOT NULL CHECK(attendance_status IN ('DRAFT', 'SCHEDULED', 'ACTIVE', 'EXPIRED', 'COMPLETED', 'LOCKED', 'CANCELLED')) DEFAULT 'ACTIVE',
  qr_interval_seconds INTEGER DEFAULT 30,
  max_qr_rotations INTEGER DEFAULT 5,
  current_qr_generation INTEGER DEFAULT 1,
  current_qr_expires_at DATETIME,
  network_verification_mode TEXT CHECK(network_verification_mode IN ('OFF', 'OPTIONAL', 'REQUIRED')) DEFAULT 'OFF',
  location_verification_mode TEXT CHECK(location_verification_mode IN ('OFF', 'OPTIONAL', 'REQUIRED')) DEFAULT 'OFF',
  allowed_latitude REAL,
  allowed_longitude REAL,
  allowed_radius_meters REAL DEFAULT 100,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- QR Generations (Server-side rotation state)
CREATE TABLE IF NOT EXISTS qr_generations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  attendance_session_id TEXT NOT NULL REFERENCES attendance_sessions(id) ON DELETE CASCADE,
  generation_number INTEGER NOT NULL,
  token_hash TEXT NOT NULL,
  code_hash TEXT NOT NULL,
  valid_from DATETIME NOT NULL,
  valid_until DATETIME NOT NULL,
  invalidated_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(attendance_session_id, generation_number)
);

-- Attendance Records (Source of truth for calculations)
CREATE TABLE IF NOT EXISTS attendance_records (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  attendance_session_id TEXT NOT NULL REFERENCES attendance_sessions(id) ON DELETE CASCADE,
  student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status TEXT NOT NULL CHECK(status IN ('PRESENT', 'ABSENT', 'LEAVE')) DEFAULT 'PRESENT',
  marked_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  verification_method TEXT CHECK(verification_method IN ('QR_SCAN', 'BACKUP_CODE', 'MANUAL_PROXY', 'CORRECTION', 'DEFAULT_ABSENT')) DEFAULT 'QR_SCAN',
  verification_result TEXT CHECK(verification_result IN ('PASSED', 'FAILED', 'NOT_APPLICABLE')) DEFAULT 'PASSED',
  ip_address TEXT,
  user_agent TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(attendance_session_id, student_id)
);

-- Attendance Corrections Workflow
CREATE TABLE IF NOT EXISTS attendance_corrections (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  attendance_session_id TEXT NOT NULL REFERENCES attendance_sessions(id) ON DELETE CASCADE,
  student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  requested_by_teacher_id INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  previous_status TEXT NOT NULL,
  requested_status TEXT NOT NULL CHECK(requested_status IN ('PRESENT', 'ABSENT', 'LEAVE')),
  reason TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('PENDING', 'APPROVED', 'REJECTED')) DEFAULT 'PENDING',
  reviewed_by_admin_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  reviewed_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Quizzes
CREATE TABLE IF NOT EXISTS quizzes (
  id TEXT PRIMARY KEY, -- UUID
  creator_id INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  title TEXT NOT NULL,
  subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE RESTRICT,
  division_id INTEGER NOT NULL REFERENCES divisions(id) ON DELETE RESTRICT,
  batch_id INTEGER REFERENCES batches(id) ON DELETE SET NULL, -- NULL = all batches in division
  topic TEXT,
  access_code TEXT UNIQUE NOT NULL,
  duration_minutes INTEGER NOT NULL,
  start_time DATETIME NOT NULL,
  end_time DATETIME NOT NULL,
  result_release_time DATETIME NOT NULL,
  max_tab_switches INTEGER DEFAULT 3,
  attendance_requirement_type TEXT CHECK(attendance_requirement_type IN ('NONE', 'LINKED_SESSION', 'PERCENTAGE_THRESHOLD')) DEFAULT 'NONE',
  linked_attendance_session_id TEXT REFERENCES attendance_sessions(id) ON DELETE SET NULL,
  required_attendance_percentage REAL DEFAULT 0,
  status TEXT CHECK(status IN ('DRAFT', 'SCHEDULED', 'ACTIVE', 'CLOSED', 'CANCELLED')) DEFAULT 'SCHEDULED',
  total_marks REAL DEFAULT 0,
  pass_percentage REAL DEFAULT 40,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Quiz Questions
CREATE TABLE IF NOT EXISTS quiz_questions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  quiz_id TEXT NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE,
  order_index INTEGER NOT NULL,
  type TEXT NOT NULL CHECK(type IN ('MCQ', 'NUMERICAL', 'SUBJECTIVE')),
  question TEXT NOT NULL,
  options TEXT, -- JSON array of string options for MCQ
  correct_answer TEXT, -- Exact answer or correct option or model rubric
  explanation TEXT,
  difficulty TEXT CHECK(difficulty IN ('EASY', 'MEDIUM', 'HARD')) DEFAULT 'MEDIUM',
  marks REAL DEFAULT 1.0,
  numerical_tolerance REAL DEFAULT 0,
  numerical_exact_required INTEGER DEFAULT 0,
  decimal_places_required INTEGER DEFAULT -1
);

-- Quiz Attempts (Strict server timer and violation recording)
CREATE TABLE IF NOT EXISTS quiz_attempts (
  id TEXT PRIMARY KEY, -- UUID
  quiz_id TEXT NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE,
  student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  attempt_number INTEGER DEFAULT 1,
  is_official INTEGER DEFAULT 1,
  start_time DATETIME NOT NULL,
  server_expires_at DATETIME NOT NULL,
  submit_time DATETIME,
  status TEXT NOT NULL CHECK(status IN ('IN_PROGRESS', 'SUBMITTED', 'AUTO_SUBMITTED_TIME', 'AUTO_SUBMITTED_VIOLATION', 'DISQUALIFIED')) DEFAULT 'IN_PROGRESS',
  total_score REAL DEFAULT 0,
  percentage REAL DEFAULT 0,
  performance_level TEXT CHECK(performance_level IN ('Needs Improvement', 'Developing', 'Proficient', 'Advanced')),
  tab_switch_count INTEGER DEFAULT 0,
  tab_switch_duration_seconds INTEGER DEFAULT 0,
  auto_submit_reason TEXT,
  teacher_evaluated INTEGER DEFAULT 0,
  evaluated_at DATETIME,
  evaluated_by_teacher_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(quiz_id, student_id, attempt_number)
);

-- Student Answers per Question
CREATE TABLE IF NOT EXISTS quiz_attempt_answers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  attempt_id TEXT NOT NULL REFERENCES quiz_attempts(id) ON DELETE CASCADE,
  question_id INTEGER NOT NULL REFERENCES quiz_questions(id) ON DELETE CASCADE,
  student_answer TEXT,
  is_correct INTEGER,
  awarded_marks REAL DEFAULT 0,
  teacher_feedback TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(attempt_id, question_id)
);

-- Tab / Window Switch Violations
CREATE TABLE IF NOT EXISTS quiz_violations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  attempt_id TEXT NOT NULL REFERENCES quiz_attempts(id) ON DELETE CASCADE,
  violation_number INTEGER NOT NULL,
  violation_type TEXT DEFAULT 'TAB_SWITCH',
  duration_seconds REAL DEFAULT 0,
  timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- AI Doubt Solver Conversations (Private per student/teacher)
CREATE TABLE IF NOT EXISTS ai_doubt_threads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role TEXT NOT NULL,
  subject TEXT,
  topic TEXT,
  title TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS ai_doubt_messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  thread_id INTEGER NOT NULL REFERENCES ai_doubt_threads(id) ON DELETE CASCADE,
  sender TEXT NOT NULL CHECK(sender IN ('USER', 'AI')),
  content TEXT NOT NULL,
  timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Platform Audit Logs
CREATE TABLE IF NOT EXISTS audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  actor_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  actor_role TEXT NOT NULL,
  action TEXT NOT NULL,
  target_type TEXT,
  target_id TEXT,
  details TEXT, -- JSON string
  ip_address TEXT,
  timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Performance Indexes
CREATE INDEX IF NOT EXISTS idx_users_identifier ON users(identifier);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_teacher_assignments ON teacher_assignments(teacher_id, subject_id, division_id);
CREATE INDEX IF NOT EXISTS idx_student_profiles ON student_profiles(division_id, batch_id, semester_id);
CREATE INDEX IF NOT EXISTS idx_attendance_sessions ON attendance_sessions(session_date, division_id, subject_id);
CREATE INDEX IF NOT EXISTS idx_attendance_records ON attendance_records(attendance_session_id, student_id);
CREATE INDEX IF NOT EXISTS idx_quizzes_access_code ON quizzes(access_code);
CREATE INDEX IF NOT EXISTS idx_quiz_attempts ON quiz_attempts(quiz_id, student_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_actor ON audit_logs(actor_id, timestamp);
