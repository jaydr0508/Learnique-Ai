import React from 'react';
import { useAuth } from '../context/AuthContext';
import {
  LayoutDashboard,
  Users,
  GraduationCap,
  BookOpen,
  Layers,
  Calendar,
  QrCode,
  HelpCircle,
  Award,
  ShieldAlert,
  Settings,
  User,
  Sparkles,
  ClipboardCheck,
  FileText
} from 'lucide-react';

export default function Sidebar({ activeTab, setActiveTab }) {
  const { user } = useAuth();

  const adminNav = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'semester_system', label: 'Semester System', icon: Layers },
    { id: 'teachers', label: 'Faculty Management', icon: Users },
    { id: 'students', label: 'Student Directory', icon: GraduationCap },
    { id: 'structure', label: 'Subjects & Divisions', icon: BookOpen },
    { id: 'timetable', label: 'Master Timetable', icon: Calendar },
    { id: 'attendance_sessions', label: 'Attendance Audit', icon: QrCode },
    { id: 'corrections', label: 'Correction Requests', icon: ClipboardCheck },
    { id: 'quizzes', label: 'All Examinations', icon: Award },
    { id: 'reports', label: 'Academic Reports', icon: FileText },
    { id: 'audit_logs', label: 'Security Audit Logs', icon: ShieldAlert },
    { id: 'settings', label: 'System Settings', icon: Settings },
  ];

  const teacherNav = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'semester_system', label: 'Assigned Semesters', icon: Layers },
    { id: 'timetable', label: "Today's Schedule", icon: Calendar },
    { id: 'attendance', label: 'Start Attendance', icon: QrCode },
    { id: 'students', label: 'My Students', icon: GraduationCap },
    { id: 'quizzes', label: 'Quiz Management', icon: Award },
    { id: 'reports', label: 'Results & Reports', icon: FileText },
    { id: 'ai_assistant', label: 'AI Teaching Assistant', icon: Sparkles },
    { id: 'profile', label: 'Faculty Profile', icon: User },
    { id: 'settings', label: 'Preferences', icon: Settings },
  ];

  const studentNav = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'mark_attendance', label: 'Scan Attendance', icon: QrCode },
    { id: 'attendance_view', label: 'My Attendance', icon: ClipboardCheck },
    { id: 'timetable', label: 'My Schedule', icon: Calendar },
    { id: 'quizzes', label: 'Live & Upcoming Quizzes', icon: Award },
    { id: 'reports', label: 'My Results', icon: FileText },
    { id: 'ai_doubt', label: 'AI Doubt Solver', icon: Sparkles },
    { id: 'profile', label: 'Academic Profile', icon: User },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  let items = studentNav;
  if (user?.role === 'ADMIN') items = adminNav;
  else if (user?.role === 'TEACHER') items = teacherNav;

  return (
    <aside className="glass-panel" style={{
      width: '260px',
      margin: '0 0 20px 20px',
      padding: '20px 14px',
      borderRadius: '16px',
      display: 'flex',
      flexDirection: 'column',
      gap: '6px',
      height: 'calc(100vh - 120px)',
      position: 'sticky',
      top: '90px'
    }}>
      <div style={{
        padding: '0 12px 14px 12px',
        borderBottom: '1px solid var(--border-subtle)',
        marginBottom: '6px'
      }}>
        <div style={{ fontSize: '0.75rem', fontWeight: '700', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>
          Navigation Portal
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', overflowY: 'auto', flex: 1, paddingRight: '4px' }}>
        {items.map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '12px',
                width: '100%',
                padding: '11px 14px',
                borderRadius: '12px',
                border: 'none',
                background: isActive ? 'var(--accent-light)' : 'transparent',
                color: isActive ? 'var(--accent-primary)' : 'var(--text-secondary)',
                fontWeight: isActive ? '600' : '500',
                fontSize: '0.885rem',
                cursor: 'pointer',
                textAlign: 'left',
                transition: 'all var(--transition-fast)',
                borderLeft: isActive ? '3px solid var(--accent-primary)' : '3px solid transparent'
              }}
            >
              <Icon size={18} style={{ color: isActive ? 'var(--accent-primary)' : 'inherit' }} />
              <span style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>

      <div style={{
        paddingTop: '12px',
        borderTop: '1px solid var(--border-subtle)',
        fontSize: '0.725rem',
        color: 'var(--text-muted)',
        textAlign: 'center'
      }}>
        Learnique AI Academic Engine v2.0
      </div>
    </aside>
  );
}
