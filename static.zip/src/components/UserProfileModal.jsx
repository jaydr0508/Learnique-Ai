import React from 'react';
import { useAuth } from '../context/AuthContext';
import { User, Mail, Shield, BookOpen, GraduationCap, Phone, Calendar, LogOut, X, Settings } from 'lucide-react';

export default function UserProfileModal({ isOpen, onClose, onNavigate }) {
  const { user, logout } = useAuth();

  if (!isOpen) return null;

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: 'rgba(0, 0, 0, 0.6)',
      backdropFilter: 'blur(4px)',
      zIndex: 1000,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '20px'
    }} onClick={onClose}>
      <div 
        onClick={e => e.stopPropagation()}
        className="glass-panel"
        style={{
          width: '100%',
          maxWidth: '460px',
          borderRadius: '20px',
          background: 'var(--bg-secondary)',
          border: '1px solid var(--border-glass)',
          boxShadow: 'var(--shadow-card)',
          overflow: 'hidden'
        }}
      >
        {/* Cover / Avatar Header */}
        <div style={{
          height: '110px',
          background: 'linear-gradient(135deg, var(--accent-primary), #06b6d4)',
          position: 'relative',
          padding: '16px'
        }}>
          <button 
            onClick={onClose}
            style={{
              position: 'absolute',
              top: '12px',
              right: '12px',
              background: 'rgba(0, 0, 0, 0.4)',
              border: 'none',
              borderRadius: '50%',
              width: '32px',
              height: '32px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#ffffff',
              cursor: 'pointer'
            }}
          >
            <X size={16} />
          </button>
        </div>

        {/* Profile Card Body */}
        <div style={{ padding: '0 24px 24px 24px', position: 'relative' }}>
          {/* Avatar */}
          <div style={{
            width: '74px',
            height: '74px',
            borderRadius: '50%',
            background: 'var(--bg-secondary)',
            border: '4px solid var(--bg-secondary)',
            marginTop: '-37px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '1.8rem',
            fontWeight: '800',
            color: 'var(--accent-primary)',
            boxShadow: '0 4px 14px rgba(0,0,0,0.2)'
          }}>
            {user?.name ? user.name[0].toUpperCase() : 'U'}
          </div>

          <div style={{ marginTop: '12px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '8px' }}>
              <h3 style={{ fontSize: '1.25rem', margin: 0 }}>{user?.name || 'Guest User'}</h3>
              <span className="badge" style={{
                background: user?.role === 'ADMIN' ? 'rgba(239, 68, 68, 0.15)' : user?.role === 'TEACHER' ? 'rgba(59, 130, 246, 0.15)' : 'rgba(16, 185, 129, 0.15)',
                color: user?.role === 'ADMIN' ? '#ef4444' : user?.role === 'TEACHER' ? '#3b82f6' : '#10b981',
                border: '1px solid currentColor'
              }}>
                {user?.role === 'ADMIN' ? 'System Admin' : user?.role === 'TEACHER' ? 'Faculty Instructor' : 'Student Scholar'}
              </span>
            </div>
            <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', marginTop: '4px' }}>
              ID: {user?.identifier || 'N/A'}
            </div>
          </div>

          {/* Details list */}
          <div style={{ marginTop: '20px', display: 'flex', flexDirection: 'column', gap: '10px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '10px 14px', borderRadius: '10px', background: 'var(--bg-surface)' }}>
              <Mail size={16} style={{ color: 'var(--text-muted)' }} />
              <div>
                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>Email Address</div>
                <div style={{ fontSize: '0.85rem', fontWeight: '500' }}>{user?.email || 'None'}</div>
              </div>
            </div>

            {user?.phone && (
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '10px 14px', borderRadius: '10px', background: 'var(--bg-surface)' }}>
                <Phone size={16} style={{ color: 'var(--text-muted)' }} />
                <div>
                  <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>Contact Number</div>
                  <div style={{ fontSize: '0.85rem', fontWeight: '500' }}>{user.phone}</div>
                </div>
              </div>
            )}

            {user?.student_profile && (
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '10px 14px', borderRadius: '10px', background: 'var(--accent-light)' }}>
                <GraduationCap size={16} style={{ color: 'var(--accent-primary)' }} />
                <div>
                  <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>Academic Enrollment</div>
                  <div style={{ fontSize: '0.85rem', fontWeight: '600' }}>
                    {user.student_profile.branch} (Enrollment: {user.student_profile.enrollment_number})
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Actions */}
          <div style={{ marginTop: '24px', display: 'flex', gap: '10px' }}>
            <button
              onClick={() => {
                onClose();
                onNavigate('settings');
              }}
              className="btn-secondary"
              style={{ flex: 1, padding: '10px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}
            >
              <Settings size={16} /> Preferences
            </button>
            <button
              onClick={() => {
                onClose();
                logout();
              }}
              className="btn-secondary"
              style={{ flex: 1, padding: '10px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', color: 'var(--danger)' }}
            >
              <LogOut size={16} /> Log Out
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
