import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { AlertTriangle, CheckCircle2, Info, XCircle, X } from 'lucide-react';

const NotificationContext = createContext(null);

export function NotificationProvider({ children }) {
  // Modal state for Confirmations & Alerts
  const [modalState, setModalState] = useState(null); // { id, title, message, type, isConfirm, confirmText, cancelText, resolve }
  
  // Toast notifications state
  const [toasts, setToasts] = useState([]);

  const removeToast = useCallback((id) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  const notify = useCallback((message, type = 'info', duration = 4000) => {
    const id = Date.now() + Math.random().toString(36).substring(2, 6);
    setToasts(prev => [...prev, { id, message, type }]);
    if (duration > 0) {
      setTimeout(() => removeToast(id), duration);
    }
  }, [removeToast]);

  const confirm = useCallback(({
    title = 'Confirm Action',
    message,
    confirmText = 'Yes, Proceed',
    cancelText = 'Cancel',
    type = 'warning'
  }) => {
    return new Promise((resolve) => {
      setModalState({
        title,
        message,
        confirmText,
        cancelText,
        type,
        isConfirm: true,
        resolve: (val) => {
          setModalState(null);
          resolve(val);
        }
      });
    });
  }, []);

  const alert = useCallback(({
    title = 'Notification',
    message,
    confirmText = 'Understood',
    type = 'info'
  }) => {
    return new Promise((resolve) => {
      setModalState({
        title,
        message,
        confirmText,
        cancelText: null,
        type,
        isConfirm: false,
        resolve: () => {
          setModalState(null);
          resolve(true);
        }
      });
    });
  }, []);

  // Listen to custom DOM events or window.alert interception
  useEffect(() => {
    const originalAlert = window.alert;
    
    // Override window.alert so no native browser popup ever opens
    window.alert = (msg) => {
      notify(String(msg || ''), 'info', 4500);
    };

    const handleCustomAlert = (e) => {
      if (e.detail?.message) {
        notify(e.detail.message, e.detail.type || 'info', e.detail.duration || 4500);
      }
    };

    window.addEventListener('learnique-notify', handleCustomAlert);
    window.addEventListener('quizify-notify', handleCustomAlert);

    return () => {
      window.alert = originalAlert;
      window.removeEventListener('learnique-notify', handleCustomAlert);
      window.removeEventListener('quizify-notify', handleCustomAlert);
    };
  }, [notify]);

  return (
    <NotificationContext.Provider value={{ confirm, alert, notify }}>
      {children}

      {/* IN-WEB TOAST CONTAINER (Top Right) */}
      <div style={{
        position: 'fixed',
        top: '20px',
        right: '20px',
        zIndex: 100000,
        display: 'flex',
        flexDirection: 'column',
        gap: '10px',
        maxWidth: '420px',
        pointerEvents: 'none'
      }}>
        {toasts.map(t => {
          const isErr = t.type === 'error' || t.type === 'danger';
          const isSucc = t.type === 'success';
          const bg = isErr 
            ? 'rgba(239, 68, 68, 0.95)' 
            : isSucc 
              ? 'rgba(16, 185, 129, 0.95)' 
              : 'rgba(30, 41, 59, 0.95)';
          const Icon = isErr ? XCircle : isSucc ? CheckCircle2 : Info;
          return (
            <div
              key={t.id}
              style={{
                pointerEvents: 'auto',
                background: bg,
                color: '#ffffff',
                padding: '12px 18px',
                borderRadius: '12px',
                boxShadow: '0 10px 25px rgba(0,0,0,0.3)',
                display: 'flex',
                alignItems: 'center',
                gap: '12px',
                fontSize: '0.875rem',
                fontWeight: '500',
                backdropFilter: 'blur(10px)',
                border: '1px solid rgba(255,255,255,0.15)',
                animation: 'fadeIn 0.2s ease-out'
              }}
            >
              <Icon size={18} style={{ flexShrink: 0 }} />
              <div style={{ flex: 1, wordBreak: 'break-word', lineHeight: 1.4 }}>{t.message}</div>
              <button
                onClick={() => removeToast(t.id)}
                style={{
                  background: 'none',
                  border: 'none',
                  color: 'rgba(255,255,255,0.8)',
                  cursor: 'pointer',
                  padding: '2px',
                  display: 'flex',
                  alignItems: 'center'
                }}
              >
                <X size={16} />
              </button>
            </div>
          );
        })}
      </div>

      {/* IN-WEB CONFIRM / ALERT MODAL (Center Viewport) */}
      {modalState && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100vw',
          height: '100vh',
          background: 'rgba(0, 0, 0, 0.72)',
          backdropFilter: 'blur(8px)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 99999
        }}>
          <div className="glass-panel" style={{
            width: '90%',
            maxWidth: '440px',
            padding: '28px',
            borderRadius: '20px',
            boxShadow: '0 20px 40px rgba(0,0,0,0.4)',
            border: '1px solid var(--border-subtle)',
            background: 'var(--bg-primary)',
            color: 'var(--text-primary)',
            animation: 'scaleUp 0.18s ease-out'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '14px', marginBottom: '14px' }}>
              <div style={{
                width: '42px',
                height: '42px',
                borderRadius: '12px',
                background: modalState.type === 'danger' || modalState.type === 'warning'
                  ? 'rgba(239, 68, 68, 0.15)'
                  : modalState.type === 'success'
                    ? 'rgba(16, 185, 129, 0.15)'
                    : 'rgba(99, 102, 241, 0.15)',
                color: modalState.type === 'danger' || modalState.type === 'warning'
                  ? 'var(--danger)'
                  : modalState.type === 'success'
                    ? 'var(--success)'
                    : 'var(--accent-primary)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexShrink: 0
              }}>
                {modalState.type === 'danger' || modalState.type === 'warning' ? (
                  <AlertTriangle size={22} />
                ) : modalState.type === 'success' ? (
                  <CheckCircle2 size={22} />
                ) : (
                  <Info size={22} />
                )}
              </div>
              <h3 style={{ fontSize: '1.15rem', fontWeight: '700', margin: 0 }}>
                {modalState.title}
              </h3>
            </div>

            <p style={{
              color: 'var(--text-muted)',
              fontSize: '0.9rem',
              lineHeight: 1.5,
              marginBottom: '24px'
            }}>
              {modalState.message}
            </p>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
              {modalState.isConfirm && (
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={() => modalState.resolve(false)}
                  style={{ padding: '9px 18px', fontSize: '0.875rem' }}
                >
                  {modalState.cancelText || 'No, Cancel'}
                </button>
              )}
              <button
                type="button"
                className={modalState.type === 'danger' ? 'btn-danger' : 'btn-primary'}
                onClick={() => modalState.resolve(true)}
                style={{
                  padding: '9px 20px',
                  fontSize: '0.875rem',
                  background: modalState.type === 'danger' ? '#ef4444' : undefined,
                  color: '#ffffff'
                }}
              >
                {modalState.confirmText || 'Yes, Confirm'}
              </button>
            </div>
          </div>
        </div>
      )}
    </NotificationContext.Provider>
  );
}

export function useNotification() {
  const context = useContext(NotificationContext);
  if (!context) {
    return {
      confirm: async ({ message }) => window.confirm ? window.confirm(message) : true,
      alert: async ({ message }) => console.log(message),
      notify: (message, type) => console.log(type, message)
    };
  }
  return context;
}

export const useNotifications = useNotification;
