/**
 * Utility to sanitize and format AI responses and questions
 * Strips unwanted markdown hashtags, LaTeX dollar signs, and raw formatting symbols
 */
export function formatAIResponse(text) {
  if (!text || typeof text !== 'string') return text || '';

  let clean = text;

  // 1. Remove markdown header hashtags (e.g. "### Heading" -> "Heading", "# Heading" -> "Heading")
  clean = clean.replace(/^[ \t]*#+\s*/gm, '');
  clean = clean.replace(/#+\s*/g, '');

  // 2. Remove LaTeX math delimiters ($$expr$$ -> expr, $expr$ -> expr)
  clean = clean.replace(/\$\$(.*?)\$\$/gs, '$1');
  clean = clean.replace(/\$([^$\n]+)\$/g, '$1');
  clean = clean.replace(/\$/g, '');

  // 3. Convert LaTeX symbols
  clean = clean.replace(/\\times\b/g, '×');
  clean = clean.replace(/\\leq\b/g, '≤');
  clean = clean.replace(/\\geq\b/g, '≥');
  clean = clean.replace(/\\neq\b/g, '≠');
  clean = clean.replace(/\\pm\b/g, '±');
  clean = clean.replace(/\\cdot\b/g, '·');
  clean = clean.replace(/\\approx\b/g, '≈');
  clean = clean.replace(/\\infty\b/g, '∞');
  clean = clean.replace(/\\rightarrow\b/g, '→');
  clean = clean.replace(/\\Delta\b/g, 'Δ');
  clean = clean.replace(/\\theta\b/g, 'θ');
  clean = clean.replace(/\\alpha\b/g, 'α');
  clean = clean.replace(/\\beta\b/g, 'β');
  clean = clean.replace(/\\pi\b/g, 'π');
  clean = clean.replace(/\\frac\{([^}]+)\}\{([^}]+)\}/g, '$1/$2');
  clean = clean.replace(/\\sqrt\{([^}]+)\}/g, 'sqrt($1)');
  clean = clean.replace(/\\(text|mathrm|mathbf)\{([^}]+)\}/g, '$2');
  clean = clean.replace(/\\[a-zA-Z]+/g, '');

  // 4. Strip raw bold markers
  clean = clean.replace(/\*\*([^*]+)\*\*/g, '$1');
  clean = clean.replace(/__([^_]+)__/g, '$1');

  return clean.trim();
}
