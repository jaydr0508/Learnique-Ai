// QUIZIFY THEME & ACCENT COLOR ENGINE
const ThemeManager = {
  PRESETS: [
    { name: "Cyan (Default)", hue: 199, hex: "#0284c7" },
    { name: "Electric Purple", hue: 265, hex: "#8b5cf6" },
    { name: "Emerald Forest", hue: 158, hex: "#10b981" },
    { name: "Sunset Amber", hue: 38, hex: "#f59e0b" },
    { name: "Crimson Rose", hue: 345, hex: "#f43f5e" },
    { name: "Royal Cobalt", hue: 220, hex: "#3b82f6" }
  ],

  init() {
    const savedTheme = localStorage.getItem("quizify_theme") || "dark";
    const savedHue = localStorage.getItem("quizify_primary_hue") || "199";

    this.setTheme(savedTheme, false);
    this.setAccentHue(savedHue, false);
  },

  setTheme(mode, persist = true) {
    document.documentElement.setAttribute("data-theme", mode);
    if (persist) {
      localStorage.setItem("quizify_theme", mode);
    }
  },

  toggleTheme() {
    const current = document.documentElement.getAttribute("data-theme") || "dark";
    const next = current === "dark" ? "light" : "dark";
    this.setTheme(next);
    return next;
  },

  setAccentHue(hue, persist = true) {
    document.documentElement.style.setProperty("--primary-hue", hue);
    if (persist) {
      localStorage.setItem("quizify_primary_hue", hue);
    }
  },

  setAccentHex(hexColor) {
    // Convert hex to HSL Hue
    const hue = this.hexToHue(hexColor);
    this.setAccentHue(hue);
  },

  hexToHue(hex) {
    let c = hex.replace("#", "");
    if (c.length === 3) c = c.split("").map(x => x + x).join("");
    const r = parseInt(c.substring(0, 2), 16) / 255;
    const g = parseInt(c.substring(2, 4), 16) / 255;
    const b = parseInt(c.substring(4, 6), 16) / 255;

    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    let h = 0;
    if (max !== min) {
      const d = max - min;
      switch (max) {
        case r: h = (g - b) / d + (g < b ? 6 : 0); break;
        case g: h = (b - r) / d + 2; break;
        case b: h = (r - g) / d + 4; break;
      }
      h /= 6;
    }
    return Math.round(h * 360);
  }
};

ThemeManager.init();
