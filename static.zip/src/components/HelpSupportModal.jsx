import React, { useState } from 'react';
import { HelpCircle, X, Calendar, Video, Award, QrCode, Shield, Sparkles, ChevronDown, ChevronRight, Mail, BookOpen } from 'lucide-react';

export default function HelpSupportModal({ isOpen, onClose }) {
  const [activeFaq, setActiveFaq] = useState(null);

  if (!isOpen) return null;

  const faqs = [
    {
      q: "How do I host an academic event or workshop?",
      a: "Click 'Host an Event' from the top navigation bar or the home page action card. Fill in the event title, category, date/time, venue details (physical auditorium or virtual meeting link), set ticket pricing (or free admission), and click 'Publish Event'. It instantly appears on the central events catalog."
    },
    {
      q: "How does the Live Video Meeting room work?",
      a: "Our meeting room is an original WebRTC video conferencing system. You can start an instant meeting with one click, or join any meeting using a code like 'quiz-xxx-yyy'. The room supports HD camera, microphone, screen sharing, real-time in-meeting chat, hand raising, and active speaker spotlight layout."
    },
    {
      q: "Can non-registered users join meetings or browse events?",
      a: "Yes! Guest participants can browse all public symposiums and workshops, view full event agendas, and enter live meeting rooms with their display name without having to sign up."
    },
    {
      q: "How do event payments and receipts work?",
      a: "For free tickets, registration is instantaneous and generates a verified registration pass. For paid tickets, you can securely complete checkout with order verification. Every completed registration automatically generates an official receipt with a unique receipt number (e.g. RCPT-2026-XXXX) which can be viewed, printed, or downloaded."
    },
    {
      q: "Where do I access the academic quizzes and attendance scanner?",
      a: "Click 'Dashboard' in the top navbar. If you are a Student, you can scan rotating attendance QR codes and take live proctored quizzes. If you are Faculty or Admin, you can launch attendance sessions and create AI-powered examination questions."
    }
  ];

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: 'rgba(0, 0, 0, 0.65)',
      backdropFilter: 'blur(5px)',
      zIndex: 1000,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '20px'
    }} onClick={onClose}>
      <div 
        onClick={e => e.stopPropagation()}
        className="glass-panel"
        style={{
          width: '100%',
          maxWidth: '680px',
          maxHeight: '90vh',
          borderRadius: '20px',
          display: 'flex',
          flexDirection: 'column',
          background: 'var(--bg-secondary)',
          border: '1px solid var(--border-glass)',
          boxShadow: 'var(--shadow-card)',
          overflow: 'hidden'
        }}
      >
        {/* Header */}
        <div style={{
          padding: '20px 24px',
          borderBottom: '1px solid var(--border-subtle)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          background: 'var(--bg-tertiary)'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div style={{
              width: '40px',
              height: '40px',
              borderRadius: '12px',
              background: 'linear-gradient(135deg, var(--accent-primary), var(--accent-hover))',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#ffffff'
            }}>
              <HelpCircle size={22} />
            </div>
            <div>
              <h3 style={{ fontSize: '1.2rem', margin: 0 }}>Help & Knowledge Center</h3>
              <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', margin: 0 }}>
                Comprehensive guides for Events, Meetings & Academic Workspace
              </p>
            </div>
          </div>
          <button onClick={onClose} className="btn-secondary" style={{ padding: '8px', borderRadius: '10px' }}>
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '24px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
          {/* Quick Pillars */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '12px' }}>
            <div style={{ padding: '14px', borderRadius: '12px', background: 'var(--bg-surface)', border: '1px solid var(--border-subtle)' }}>
              <Calendar size={20} style={{ color: 'var(--accent-primary)', marginBottom: '8px' }} />
              <div style={{ fontWeight: '600', fontSize: '0.9rem' }}>Event Hosting</div>
              <div style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', marginTop: '4px' }}>
                Create conferences, manage tickets, and track registrations.
              </div>
            </div>
            <div style={{ padding: '14px', borderRadius: '12px', background: 'var(--bg-surface)', border: '1px solid var(--border-subtle)' }}>
              <Video size={20} style={{ color: '#06b6d4', marginBottom: '8px' }} />
              <div style={{ fontWeight: '600', fontSize: '0.9rem' }}>Live Meetings</div>
              <div style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', marginTop: '4px' }}>
                Join HD virtual classrooms with screen share & real-time chat.
              </div>
            </div>
            <div style={{ padding: '14px', borderRadius: '12px', background: 'var(--bg-surface)', border: '1px solid var(--border-subtle)' }}>
              <Award size={20} style={{ color: 'var(--warning)', marginBottom: '8px' }} />
              <div style={{ fontWeight: '600', fontSize: '0.9rem' }}>Academic Quizzes</div>
              <div style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', marginTop: '4px' }}>
                Take timed examinations with AI question generation.
              </div>
            </div>
          </div>

          {/* FAQs Accordion */}
          <div>
            <h4 style={{ fontSize: '1rem', marginBottom: '12px', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <BookOpen size={16} style={{ color: 'var(--accent-primary)' }} /> Frequently Asked Questions
            </h4>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {faqs.map((faq, i) => {
                const isOpenFaq = activeFaq === i;
                return (
                  <div 
                    key={i}
                    style={{
                      borderRadius: '10px',
                      background: 'var(--bg-tertiary)',
                      border: '1px solid var(--border-glass)',
                      overflow: 'hidden'
                    }}
                  >
                    <button
                      onClick={() => setActiveFaq(isOpenFaq ? null : i)}
                      style={{
                        width: '100%',
                        padding: '14px 16px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        background: 'transparent',
                        border: 'none',
                        color: 'var(--text-primary)',
                        fontWeight: '600',
                        fontSize: '0.88rem',
                        cursor: 'pointer',
                        textAlign: 'left'
                      }}
                    >
                      <span>{faq.q}</span>
                      {isOpenFaq ? <ChevronDown size={18} style={{ color: 'var(--accent-primary)' }} /> : <ChevronRight size={18} />}
                    </button>
                    {isOpenFaq && (
                      <div style={{
                        padding: '0 16px 14px 16px',
                        fontSize: '0.82rem',
                        color: 'var(--text-secondary)',
                        lineHeight: 1.5,
                        borderTop: '1px solid var(--border-subtle)',
                        paddingTop: '10px'
                      }}>
                        {faq.a}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Contact Support */}
          <div style={{
            padding: '16px 20px',
            borderRadius: '12px',
            background: 'var(--accent-light)',
            border: '1px solid var(--accent-border)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between'
          }}>
            <div>
              <div style={{ fontWeight: '600', fontSize: '0.9rem', color: 'var(--text-primary)' }}>
                Need personalized technical assistance?
              </div>
              <div style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', marginTop: '2px' }}>
                Academic IT Helpdesk: support@learnique.edu | Mon-Sat 9AM-6PM IST
              </div>
            </div>
            <a 
              href="mailto:support@learnique.edu"
              className="btn-primary"
              style={{ padding: '8px 14px', fontSize: '0.82rem', textDecoration: 'none', display: 'flex', alignItems: 'center', gap: '6px' }}
            >
              <Mail size={14} /> Contact Desk
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
