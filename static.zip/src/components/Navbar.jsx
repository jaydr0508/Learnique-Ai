import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { 
  Moon, Sun, Palette, LogOut, User, Shield, GraduationCap, 
  BookOpen, Bell, Calendar, Video, PlusCircle, HelpCircle, 
  Menu, X, Home, LayoutDashboard, Activity, Sparkles, ChevronRight
} from 'lucide-react';
import ColorPickerModal from './ColorPickerModal';
import NotificationDrawer from './NotificationDrawer';
import HelpSupportModal from './HelpSupportModal';
import UserProfileModal from './UserProfileModal';

export default function Navbar({ currentView, onNavigate, onOpenSchedule }) {
  const { user, token, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();

  const [colorPickerOpen, setColorPickerOpen] = useState(false);
  const [notifDrawerOpen, setNotifDrawerOpen] = useState(false);
  const [helpModalOpen, setHelpModalOpen] = useState(false);
  const [profileModalOpen, setProfileModalOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [unreadNotifs, setUnreadNotifs] = useState(0);

  // Poll for notifications unread count
  useEffect(() => {
    let isMounted = true;
    const fetchUnread = async () => {
      if (!token) return;
      try {
        const res = await fetch('/api/notifications', {
          headers: { Authorization: `Bearer ${token}` }
        });
        const data = await res.json();
        if (isMounted) setUnreadNotifs(data.unread_count || 0);
      } catch (e) {}
    };

    fetchUnread();
    const interval = setInterval(fetchUnread, 15000);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, [token]);

  function getRoleBadge() {
    if (!user) return null;
    if (user.role === 'ADMIN') {
      return (
        <span className="badge" style={{ background: 'rgba(239, 68, 68, 0.15)', color: '#ef4444', border: '1px solid rgba(239, 68, 68, 0.3)' }}>
          <Shield size={12} /> Admin
        </span>
      );
    }
    if (user.role === 'TEACHER') {
      return (
        <span className="badge" style={{ background: 'rgba(59, 130, 246, 0.15)', color: '#3b82f6', border: '1px solid rgba(59, 130, 246, 0.3)' }}>
          <BookOpen size={12} /> Faculty
        </span>
      );
    }
    return (
      <span className="badge badge-present">
        <GraduationCap size={12} /> Student
      </span>
    );
  }

  const navLinks = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, authOnly: true },
    { id: 'events', label: 'Events', icon: Calendar },
    { id: 'host-event', label: 'Host an Event', icon: PlusCircle, teacherOrAdmin: true },
    { id: 'meetings', label: 'Online Meetings', icon: Video },
    { id: 'schedule', label: 'Schedule a Meeting', icon: Calendar, isAction: true, teacherOrAdmin: true },
    { id: 'my-activities', label: 'My Activities', icon: Activity, authOnly: true },
  ];

  const isTeacherOrAdmin = user && (user.role === 'ADMIN' || user.role === 'TEACHER');

  const visibleNavLinks = navLinks.filter(link => {
    if (link.teacherOrAdmin && !isTeacherOrAdmin) return false;
    if (user?.role === 'STUDENT' && (link.id === 'host-event' || link.id === 'schedule')) return false;
    return true;
  });

  const handleNavClick = (link) => {
    setMobileMenuOpen(false);
    if (link.isAction) {
      if (user?.role === 'STUDENT') return;
      if (onOpenSchedule) onOpenSchedule();
      return;
    }
    if (link.authOnly && !user) {
      if (onNavigate) onNavigate('login');
      return;
    }
    if (link.id === 'host-event' && (!user || (user.role !== 'ADMIN' && user.role !== 'TEACHER'))) {
      if (onNavigate) onNavigate(user ? 'events' : 'login');
      return;
    }
    if (onNavigate) onNavigate(link.id);
  };

  return (
    <>
      <header className="glass-panel" style={{
        margin: '14px 20px',
        padding: '10px 20px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        borderRadius: '16px',
        position: 'sticky',
        top: '14px',
        zIndex: 100,
        gap: '12px'
      }}>
        {/* Brand / Logo */}
        <div 
          onClick={() => onNavigate && onNavigate('home')}
          style={{ display: 'flex', alignItems: 'center', gap: '12px', cursor: 'pointer', flexShrink: 0 }}
        >
          <div style={{
            width: '40px',
            height: '40px',
            borderRadius: '12px',
            background: 'linear-gradient(135deg, var(--accent-primary), var(--accent-hover))',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: '0 4px 14px var(--accent-glow)'
          }}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 2L2 7l10 5 10-5-10-5z" />
              <path d="M2 17l10 5 10-5" />
              <path d="M2 12l10 5 10-5" />
            </svg>
          </div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span style={{ fontSize: '1.25rem', fontWeight: '800', letterSpacing: '-0.02em', background: 'linear-gradient(135deg, var(--text-primary), var(--accent-primary))', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
                Learnique AI
              </span>
              {getRoleBadge()}
            </div>
            <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>
              Events, Meetings & Academic Platform
            </div>
          </div>
        </div>

        {/* Center Desktop Navigation Hub */}
        <nav className="desktop-nav" style={{
          display: 'flex',
          alignItems: 'center',
          gap: '4px',
          background: 'var(--bg-tertiary)',
          padding: '4px 6px',
          borderRadius: '12px',
          border: '1px solid var(--border-glass)',
          flexWrap: 'nowrap'
        }}>
          {visibleNavLinks.map(link => {
            const Icon = link.icon;
            const isActive = currentView === link.id;
            return (
              <button
                key={link.id}
                onClick={() => handleNavClick(link)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  padding: '7px 12px',
                  borderRadius: '9px',
                  border: 'none',
                  background: isActive ? 'var(--accent-light)' : 'transparent',
                  color: isActive ? 'var(--accent-primary)' : 'var(--text-secondary)',
                  fontWeight: isActive ? '700' : '500',
                  fontSize: '0.825rem',
                  cursor: 'pointer',
                  transition: 'all var(--transition-fast)',
                  whiteSpace: 'nowrap'
                }}
              >
                <Icon size={14} style={{ color: isActive ? 'var(--accent-primary)' : 'inherit' }} />
                <span>{link.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Right Tools & User Info */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexShrink: 0 }}>
          {/* Notifications Bell */}
          <button 
            onClick={() => setNotifDrawerOpen(true)}
            title="Notifications"
            className="btn-secondary"
            style={{ padding: '8px 10px', borderRadius: '10px', position: 'relative' }}
          >
            <Bell size={17} style={{ color: unreadNotifs > 0 ? 'var(--accent-primary)' : 'var(--text-secondary)' }} />
            {unreadNotifs > 0 && (
              <span style={{
                position: 'absolute',
                top: '-3px',
                right: '-3px',
                background: 'var(--danger)',
                color: '#ffffff',
                fontSize: '0.65rem',
                fontWeight: '800',
                padding: '1px 5px',
                borderRadius: '10px',
                lineHeight: 1.2
              }}>
                {unreadNotifs}
              </span>
            )}
          </button>

          {/* Help & Support */}
          <button 
            onClick={() => setHelpModalOpen(true)}
            title="Help & Support Guide"
            className="btn-secondary"
            style={{ padding: '8px 10px', borderRadius: '10px' }}
          >
            <HelpCircle size={17} style={{ color: 'var(--text-secondary)' }} />
          </button>

          {/* Theme Color Picker */}
          <button 
            onClick={() => setColorPickerOpen(true)}
            title="Theme Palette"
            className="btn-secondary"
            style={{ padding: '8px 10px', borderRadius: '10px' }}
          >
            <Palette size={17} style={{ color: 'var(--accent-primary)' }} />
          </button>

          {/* Dark / Light Toggle */}
          <button 
            onClick={toggleTheme}
            title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            className="btn-secondary"
            style={{ padding: '8px 10px', borderRadius: '10px' }}
          >
            {theme === 'dark' ? <Sun size={17} style={{ color: '#f59e0b' }} /> : <Moon size={17} style={{ color: '#6366f1' }} />}
          </button>

          {/* User Profile Pill or Login Button */}
          {user ? (
            <div 
              onClick={() => setProfileModalOpen(true)}
              title="Click to view profile"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                padding: '4px 10px',
                borderRadius: '10px',
                background: 'var(--bg-tertiary)',
                border: '1px solid var(--border-glass)',
                cursor: 'pointer'
              }}
            >
              <div style={{
                width: '28px',
                height: '28px',
                borderRadius: '50%',
                background: 'var(--accent-light)',
                color: 'var(--accent-primary)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontWeight: '700',
                fontSize: '0.8rem'
              }}>
                {user?.name ? user.name[0].toUpperCase() : 'U'}
              </div>
              <div style={{ textAlign: 'left', lineHeight: 1.1 }} className="user-name-text">
                <div style={{ fontSize: '0.8rem', fontWeight: '600' }}>
                  {user.name.split(' ')[0]}
                </div>
              </div>
            </div>
          ) : (
            <button
              onClick={() => onNavigate && onNavigate('login')}
              className="btn-primary"
              style={{ padding: '7px 14px', borderRadius: '10px', fontSize: '0.825rem', fontWeight: '600' }}
            >
              Sign In
            </button>
          )}

          {/* Mobile Menu Hamburger */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="btn-secondary mobile-menu-btn"
            style={{ padding: '8px', borderRadius: '10px' }}
          >
            {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </header>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div style={{
          position: 'fixed',
          top: '76px',
          left: '20px',
          right: '20px',
          zIndex: 99,
          background: 'var(--bg-secondary)',
          border: '1px solid var(--border-glass)',
          borderRadius: '16px',
          padding: '16px',
          boxShadow: 'var(--shadow-card)',
          display: 'flex',
          flexDirection: 'column',
          gap: '6px'
        }}>
          {visibleNavLinks.map(link => {
            const Icon = link.icon;
            const isActive = currentView === link.id;
            return (
              <button
                key={link.id}
                onClick={() => handleNavClick(link)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  padding: '12px 14px',
                  borderRadius: '10px',
                  border: 'none',
                  background: isActive ? 'var(--accent-light)' : 'transparent',
                  color: isActive ? 'var(--accent-primary)' : 'var(--text-primary)',
                  fontWeight: isActive ? '700' : '500',
                  fontSize: '0.9rem',
                  cursor: 'pointer'
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <Icon size={18} style={{ color: isActive ? 'var(--accent-primary)' : 'inherit' }} />
                  <span>{link.label}</span>
                </div>
                <ChevronRight size={16} style={{ color: 'var(--text-muted)' }} />
              </button>
            );
          })}
        </div>
      )}

      {/* Modals & Drawers */}
      <ColorPickerModal isOpen={colorPickerOpen} onClose={() => setColorPickerOpen(false)} />
      <NotificationDrawer 
        isOpen={notifDrawerOpen} 
        onClose={() => setNotifDrawerOpen(false)} 
        onNavigate={path => onNavigate && onNavigate(path)} 
      />
      <HelpSupportModal isOpen={helpModalOpen} onClose={() => setHelpModalOpen(false)} />
      <UserProfileModal 
        isOpen={profileModalOpen} 
        onClose={() => setProfileModalOpen(false)} 
        onNavigate={path => onNavigate && onNavigate(path)} 
      />
    </>
  );
}
