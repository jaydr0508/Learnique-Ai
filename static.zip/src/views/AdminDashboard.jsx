import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNotification } from '../context/NotificationContext';
import {
  Users,
  GraduationCap,
  Layers,
  Calendar,
  ClipboardCheck,
  ShieldAlert,
  Plus,
  KeyRound,
  Check,
  X,
  FileDown,
  FileText,
  Search,
  Eye,
  Trash2,
  Edit,
  Award,
  BookOpen,
  Clock,
  QrCode,
  ChevronRight
} from 'lucide-react';
import SemesterHierarchyView from './SemesterHierarchyView';
import QuizCreatorModal from './QuizCreatorModal';

export default function AdminDashboard({ activeTab, setActiveTab }) {
  const { token } = useAuth();
  const { confirm: confirmModal, notify } = useNotification();

  const [loading, setLoading] = useState(true);
  const [overview, setOverview] = useState(null);
  const [teachers, setTeachers] = useState([]);
  const [students, setStudents] = useState([]);
  const [structure, setStructure] = useState({ courses: [], semesters: [], divisions: [], batches: [], subjects: [] });
  const [timetable, setTimetable] = useState([]);
  const [corrections, setCorrections] = useState([]);
  const [auditLogs, setAuditLogs] = useState([]);
  const [allQuizzes, setAllQuizzes] = useState([]);

  // Quiz Modal State for Semester System
  const [isQuizModalOpen, setIsQuizModalOpen] = useState(false);
  const [quizModalSubjectId, setQuizModalSubjectId] = useState('');

  // Teacher Dossier Modal State
  const [selectedTeacherId, setSelectedTeacherId] = useState(null);
  const [teacherDossier, setTeacherDossier] = useState(null);
  const [teacherDossierTab, setTeacherDossierTab] = useState('INFO');
  const [editTeacherForm, setEditTeacherForm] = useState(null);

  // Student Hierarchy Drill-down Filter State
  const [selCourse, setSelCourse] = useState('');
  const [selSem, setSelSem] = useState('');
  const [selDiv, setSelDiv] = useState('');
  const [selBatch, setSelBatch] = useState('');
  const [studentSearch, setStudentSearch] = useState('');

  // Student Dossier Modal State
  const [selectedStudentId, setSelectedStudentId] = useState(null);
  const [studentDossier, setStudentDossier] = useState(null);
  const [editStudentForm, setEditStudentForm] = useState(null);
  const [editingAttemptId, setEditingAttemptId] = useState(null);
  const [overrideScoreInput, setOverrideScoreInput] = useState('');

  // Creation Modals
  const [isAddTeacherOpen, setIsAddTeacherOpen] = useState(false);
  const [teacherForm, setTeacherForm] = useState({ identifier: '', name: '', email: '', phone: '', password: '' });
  const [teacherAssignmentModal, setTeacherAssignmentModal] = useState(null);
  const [assignForm, setAssignForm] = useState({ subject_id: '', division_id: '', batch_id: '' });

  const [isAddStudentOpen, setIsAddStudentOpen] = useState(false);
  const [studentForm, setStudentForm] = useState({
    enrollment_number: '',
    name: '',
    email: '',
    phone: '',
    password: '',
    semester_id: '1',
    division_id: '',
    batch_id: '',
    branch: 'Computer Science & Engineering',
    gender: 'Male'
  });

  const [isAddTimetableOpen, setIsAddTimetableOpen] = useState(false);
  const [ttForm, setTtForm] = useState({
    academic_year: '2025-2026',
    semester_id: '1',
    day_of_week: '1',
    start_time: '10:00',
    end_time: '10:50',
    teacher_id: '',
    subject_id: '',
    session_type: 'THEORY',
    division_id: '',
    batch_id: '',
    room: 'EA-511',
    building: 'Engineering Block A'
  });

  // Timetable Drill-down: Branch > Semester > Monday to Friday > Subjects = Timing
  const [ttBranch, setTtBranch] = useState('Computer Science & Engineering');
  const [ttSemester, setTtSemester] = useState(5);
  const [ttDay, setTtDay] = useState(() => {
    const today = new Date().getDay();
    return (today >= 1 && today <= 5) ? today : 1;
  });
  const [ttViewMode, setTtViewMode] = useState('cards'); // 'cards' (day schedule) or 'table' (full week)

  const availableBranches = React.useMemo(() => {
    const set = new Set();
    (structure.subjects || []).forEach(s => { if (s.branch) set.add(s.branch); });
    (timetable || []).forEach(t => { if (t.branch) set.add(t.branch); });
    if (set.size === 0) {
      set.add('Computer Science & Engineering');
      set.add('Information Technology');
      set.add('Electronics & Communication');
    }
    return Array.from(set);
  }, [structure.subjects, timetable]);

  const availableSemesters = React.useMemo(() => {
    const sems = (structure.semesters || []).map(s => Number(s.number)).sort((a, b) => a - b);
    return sems.length > 0 ? sems : [1, 2, 3, 4, 5, 6, 7, 8];
  }, [structure.semesters]);

  useEffect(() => {
    if (availableBranches.length > 0 && !availableBranches.includes(ttBranch)) {
      setTtBranch(availableBranches[0]);
    }
  }, [availableBranches]);

  useEffect(() => {
    if (timetable && timetable.length > 0) {
      const branchEntries = timetable.filter(t => t.branch === ttBranch);
      const semHasEntries = branchEntries.some(t => Number(t.semester_number || t.semester_id) === Number(ttSemester));
      if (!semHasEntries && branchEntries.length > 0) {
        setTtSemester(Number(branchEntries[0].semester_number || branchEntries[0].semester_id));
      }
    }
  }, [ttBranch, timetable]);

  // Structure Creation Forms
  const [newDivName, setNewDivName] = useState('');
  const [newDivSem, setNewDivSem] = useState('1');
  const [newBatchName, setNewBatchName] = useState('');
  const [newBatchDiv, setNewBatchDiv] = useState('');
  const [newSubCode, setNewSubCode] = useState('');
  const [newSubName, setNewSubName] = useState('');
  const [newSubType, setNewSubType] = useState('BOTH');
  const [newSubSemester, setNewSubSemester] = useState('5');

  useEffect(() => {
    loadAllAdminData();
  }, [token]);

  async function parseSafeJson(res, defaultMsg = 'Operation failed') {
    let data;
    try {
      data = await res.json();
    } catch {
      throw new Error(`Server returned non-JSON response (${res.status} ${res.statusText})`);
    }
    if (!res.ok) throw new Error(data?.error || defaultMsg);
    return data;
  }

  async function loadAllAdminData() {
    setLoading(true);
    try {
      const [ovRes, tRes, sRes, strRes, ttRes, corRes, alRes, qRes] = await Promise.all([
        fetch('/api/admin/overview', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/admin/teachers', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/admin/students', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/admin/structure', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/admin/timetable', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/admin/corrections', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/admin/audit-logs', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/admin/quizzes', { headers: { Authorization: `Bearer ${token}` } })
      ]);

      const safe = async (r) => {
        try { return await r.json(); } catch { return {}; }
      };

      const [ov, t, s, str, tt, cor, al, q] = await Promise.all([
        safe(ovRes), safe(tRes), safe(sRes), safe(strRes), safe(ttRes), safe(corRes), safe(alRes), safe(qRes)
      ]);

      setOverview(ov);
      setTeachers(t.teachers || []);
      setStudents(s.students || []);
      setStructure(str);
      setTimetable(tt.timetable || []);
      setCorrections(cor.corrections || []);
      setAuditLogs(al.logs || []);
      setAllQuizzes(q.quizzes || []);
    } catch (e) {
      console.error('Failed to load admin data', e);
    } finally {
      setLoading(false);
    }
  }

  // Open Teacher Dossier
  async function openTeacherDossier(tId) {
    setSelectedTeacherId(tId);
    setTeacherDossierTab('INFO');
    try {
      const res = await fetch(`/api/admin/teachers/${tId}/details`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await parseSafeJson(res, 'Failed to load teacher dossier');
      setTeacherDossier(data);
      setEditTeacherForm({ ...data.teacher, password: '' });
    } catch (e) {
      notify(e.message, 'error');
    }
  }

  async function handleSaveTeacherEdit(e) {
    e.preventDefault();
    try {
      const res = await fetch(`/api/admin/teachers/${selectedTeacherId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(editTeacherForm)
      });
      await parseSafeJson(res, 'Failed to update teacher');

      notify('Teacher updated successfully.', 'success');
      openTeacherDossier(selectedTeacherId);
      loadAllAdminData();
    } catch (err) {
      notify(err.message, 'error');
    }
  }

  async function handleDeleteTeacher(tId) {
    const ok = await confirmModal({
      title: 'Delete Faculty Account',
      message: 'Are you sure you want to permanently delete this teacher account?',
      type: 'danger',
      confirmText: 'Yes, Delete'
    });
    if (!ok) return;

    try {
      const res = await fetch(`/api/admin/teachers/${tId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      await parseSafeJson(res, 'Failed to delete teacher');

      notify('Teacher account deleted.', 'info');
      setSelectedTeacherId(null);
      setTeacherDossier(null);
      loadAllAdminData();
    } catch (err) {
      notify(err.message, 'error');
    }
  }

  async function handleAssignSubjectToTeacher(e) {
    e.preventDefault();
    if (!assignForm.subject_id || !assignForm.division_id) {
      notify('Please select both a Subject and a Division.', 'warning');
      return;
    }
    try {
      const res = await fetch(`/api/admin/teachers/${selectedTeacherId}/assignments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(assignForm)
      });
      await parseSafeJson(res, 'Failed to assign subject');
      notify('Subject successfully assigned to teacher.', 'success');
      setAssignForm({ subject_id: '', division_id: '', batch_id: '' });
      openTeacherDossier(selectedTeacherId);
      loadAllAdminData();
    } catch (err) {
      notify(err.message, 'error');
    }
  }

  async function handleRemoveTeacherAssignment(assignmentId) {
    const ok = await confirmModal({
      title: 'Remove Course Assignment',
      message: 'Are you sure you want to unassign this course from the teacher?',
      type: 'warning',
      confirmText: 'Yes, Unassign'
    });
    if (!ok) return;

    try {
      const res = await fetch(`/api/admin/teachers/${selectedTeacherId}/assignments/${assignmentId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      await parseSafeJson(res, 'Failed to remove assignment');
      notify('Course assignment removed.', 'info');
      openTeacherDossier(selectedTeacherId);
      loadAllAdminData();
    } catch (err) {
      notify(err.message, 'error');
    }
  }

  // Open Student Dossier
  async function openStudentDossier(sId) {
    setSelectedStudentId(sId);
    try {
      const res = await fetch(`/api/admin/students/${sId}/details`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await parseSafeJson(res, 'Failed to load student dossier');
      setStudentDossier(data);
      setEditStudentForm({ ...data.student, password: '' });
    } catch (e) {
      notify(e.message, 'error');
    }
  }

  async function handleSaveStudentEdit(e) {
    e.preventDefault();
    try {
      const res = await fetch(`/api/admin/students/${selectedStudentId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(editStudentForm)
      });
      await parseSafeJson(res, 'Failed to update student');

      notify('Student updated successfully.', 'success');
      openStudentDossier(selectedStudentId);
      loadAllAdminData();
    } catch (err) {
      notify(err.message, 'error');
    }
  }

  async function handleDeleteStudent(sId) {
    const ok = await confirmModal({
      title: 'Delete Student Account',
      message: 'Are you sure you want to delete this student account?',
      type: 'danger',
      confirmText: 'Yes, Delete'
    });
    if (!ok) return;

    try {
      const res = await fetch(`/api/admin/students/${sId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      notify('Student account deleted.', 'info');
      setSelectedStudentId(null);
      setStudentDossier(null);
      loadAllAdminData();
    } catch (err) {
      notify(err.message, 'error');
    }
  }

  async function handleOverrideMarks(attemptId) {
    if (!overrideScoreInput) return;
    try {
      const res = await fetch(`/api/admin/attempts/${attemptId}/override-marks`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          total_score: Number(overrideScoreInput),
          teacher_evaluated: 1
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      notify('Marks updated successfully.', 'success');
      setEditingAttemptId(null);
      setOverrideScoreInput('');
      openStudentDossier(selectedStudentId);
    } catch (err) {
      notify(err.message, 'error');
    }
  }

  // Filtered Students in Hierarchical Drill-Down
  const filteredStudents = students.filter(s => {
    if (selDiv && String(s.division_id) !== String(selDiv)) return false;
    if (selBatch && String(s.batch_id) !== String(selBatch)) return false;
    if (studentSearch) {
      const term = studentSearch.toLowerCase();
      return s.name.toLowerCase().includes(term) || s.enrollment_number.toLowerCase().includes(term) || s.email.toLowerCase().includes(term);
    }
    return true;
  });

  // Structure Actions
  async function handleAddDivision(e) {
    e.preventDefault();
    if (!newDivName.trim()) return;
    try {
      const res = await fetch('/api/admin/divisions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ semester_id: Number(newDivSem), name: newDivName.trim() })
      });
      await parseSafeJson(res, 'Failed to add division');
      setNewDivName('');
      notify('Division added successfully.', 'success');
      loadAllAdminData();
    } catch (e) {
      notify(e.message, 'error');
    }
  }

  async function handleDeleteDivision(id) {
    const ok = await confirmModal({
      title: 'Delete Academic Division',
      message: 'Are you sure you want to delete this division?',
      type: 'danger',
      confirmText: 'Yes, Delete'
    });
    if (!ok) return;

    try {
      await fetch(`/api/admin/divisions/${id}`, { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } });
      notify('Division deleted.', 'info');
      loadAllAdminData();
    } catch (e) {
      notify(e.message, 'error');
    }
  }

  async function handleAddBatch(e) {
    e.preventDefault();
    if (!newBatchName.trim() || !newBatchDiv) return;
    try {
      const res = await fetch('/api/admin/batches', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ division_id: Number(newBatchDiv), name: newBatchName.trim() })
      });
      await parseSafeJson(res, 'Failed to add batch');
      setNewBatchName('');
      notify('Batch added successfully.', 'success');
      loadAllAdminData();
    } catch (e) {
      notify(e.message, 'error');
    }
  }

  async function handleDeleteBatch(id) {
    const ok = await confirmModal({
      title: 'Delete Batch',
      message: 'Are you sure you want to delete this batch?',
      type: 'danger',
      confirmText: 'Yes, Delete'
    });
    if (!ok) return;

    try {
      await fetch(`/api/admin/batches/${id}`, { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } });
      notify('Batch deleted.', 'info');
      loadAllAdminData();
    } catch (e) {
      notify(e.message, 'error');
    }
  }

  async function handleAddSubject(e) {
    e.preventDefault();
    if (!newSubCode.trim() || !newSubName.trim()) return;
    try {
      const res = await fetch('/api/admin/subjects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          semester: Number(newSubSemester || 5),
          code: newSubCode.trim(),
          name: newSubName.trim(),
          type: newSubType
        })
      });
      await parseSafeJson(res, 'Failed to create subject');
      setNewSubCode('');
      setNewSubName('');
      notify(`Subject created successfully for Semester ${newSubSemester}!`, 'success');
      loadAllAdminData();
    } catch (e) {
      notify(e.message, 'error');
    }
  }

  async function handleDeleteSubject(id) {
    const ok = await confirmModal({
      title: 'Delete Curriculum Subject',
      message: 'Are you sure you want to delete this subject?',
      type: 'danger',
      confirmText: 'Yes, Delete'
    });
    if (!ok) return;

    try {
      await fetch(`/api/admin/subjects/${id}`, { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } });
      notify('Subject deleted.', 'info');
      loadAllAdminData();
    } catch (e) {
      notify(e.message, 'error');
    }
  }

  async function handleDeleteQuiz(quizId, quizTitle) {
    const ok = await confirmModal({
      title: 'Delete Examination',
      message: `Are you sure you want to permanently delete quiz "${quizTitle}"? All student attempts and records will be deleted.`,
      type: 'danger',
      confirmText: 'Yes, Delete'
    });
    if (!ok) return;

    try {
      const res = await fetch(`/api/quizzes/${quizId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      await parseSafeJson(res, 'Failed to delete quiz');
      notify('Quiz deleted successfully.', 'info');
      loadAllAdminData();
    } catch (err) {
      notify(err.message, 'error');
    }
  }

  async function handleCreateTeacher(e) {
    e.preventDefault();
    try {
      const res = await fetch('/api/admin/teachers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(teacherForm)
      });
      await parseSafeJson(res, 'Failed to create teacher');

      notify('Teacher account created successfully.', 'success');
      setIsAddTeacherOpen(false);
      setTeacherForm({ identifier: '', name: '', email: '', phone: '', password: '' });
      loadAllAdminData();
    } catch (err) {
      notify(err.message, 'error');
    }
  }

  async function handleCreateStudent(e) {
    e.preventDefault();
    try {
      const res = await fetch('/api/admin/students', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          ...studentForm,
          semester_id: Number(studentForm.semester_id || 1),
          division_id: Number(studentForm.division_id),
          batch_id: Number(studentForm.batch_id)
        })
      });
      await parseSafeJson(res, 'Failed to enroll student');

      notify('Student enrolled successfully.', 'success');
      setIsAddStudentOpen(false);
      setStudentForm({
        enrollment_number: '',
        name: '',
        email: '',
        phone: '',
        password: '',
        semester_id: '1',
        division_id: '',
        batch_id: '',
        branch: 'Computer Science & Engineering',
        gender: 'Male'
      });
      loadAllAdminData();
    } catch (err) {
      notify(err.message, 'error');
    }
  }

  async function handleCreateTimetable(e) {
    e.preventDefault();
    try {
      const res = await fetch('/api/admin/timetable', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          ...ttForm,
          semester_id: Number(ttForm.semester_id),
          day_of_week: Number(ttForm.day_of_week),
          teacher_id: Number(ttForm.teacher_id),
          subject_id: Number(ttForm.subject_id),
          division_id: Number(ttForm.division_id),
          batch_id: ttForm.batch_id ? Number(ttForm.batch_id) : null
        })
      });
      await parseSafeJson(res, 'Failed to add timetable schedule');

      notify('Timetable schedule added successfully.', 'success');
      setIsAddTimetableOpen(false);
      loadAllAdminData();
    } catch (err) {
      notify(err.message, 'error');
    }
  }

  async function handleDeleteTimetable(entryId) {
    const ok = await confirmModal('Are you sure you want to delete this timetable schedule slot?');
    if (!ok) return;
    try {
      const res = await fetch(`/api/admin/timetable/${entryId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      await parseSafeJson(res, 'Failed to delete timetable entry');
      notify('Timetable slot removed successfully.', 'success');
      loadAllAdminData();
    } catch (err) {
      notify(err.message, 'error');
    }
  }

  async function handleReviewCorrection(correctionId, action) {
    try {
      const res = await fetch(`/api/admin/corrections/${correctionId}/review`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ action })
      });
      await parseSafeJson(res, 'Failed to review correction');
      notify(`Correction request ${action.toLowerCase()}ed.`, 'info');
      loadAllAdminData();
    } catch (err) {
      notify(err.message, 'error');
    }
  }

  if (loading) {
    return <div style={{ textAlign: 'center', padding: '60px', color: 'var(--text-muted)' }}>Loading Administrator Console...</div>;
  }

  const stats = overview?.stats;

  return (
    <div style={{ padding: '0 24px 40px 24px', maxWidth: '1320px', margin: '0 auto' }}>
      {/* OVERVIEW STATS ROW */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px', marginBottom: '28px' }}>
        <div className="glass-panel" style={{ padding: '20px', borderRadius: '16px' }}>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: '600' }}>Active Faculty</div>
          <div style={{ fontSize: '2rem', fontWeight: '800', color: 'var(--accent-primary)', marginTop: '4px' }}>{stats?.totalTeachers ?? 0}</div>
        </div>
        <div className="glass-panel" style={{ padding: '20px', borderRadius: '16px' }}>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: '600' }}>Enrolled Students</div>
          <div style={{ fontSize: '2rem', fontWeight: '800', color: '#10b981', marginTop: '4px' }}>{stats?.totalStudents ?? 0}</div>
        </div>
        <div className="glass-panel" style={{ padding: '20px', borderRadius: '16px' }}>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: '600' }}>Active Quizzes</div>
          <div style={{ fontSize: '2rem', fontWeight: '800', color: '#06b6d4', marginTop: '4px' }}>{allQuizzes.filter(q => q.live_state === 'LIVE').length} Live</div>
        </div>
        <div className="glass-panel" style={{ padding: '20px', borderRadius: '16px' }}>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: '600' }}>Pending Corrections</div>
          <div style={{ fontSize: '2rem', fontWeight: '800', color: stats?.pendingCorrections > 0 ? '#f59e0b' : 'var(--text-muted)', marginTop: '4px' }}>
            {stats?.pendingCorrections ?? 0}
          </div>
        </div>
      </div>

      {/* QUICK BANNER ON DASHBOARD: SEMESTER SYSTEM */}
      {activeTab === 'dashboard' && setActiveTab && (
        <div
          onClick={() => setActiveTab('semester_system')}
          className="glass-panel"
          style={{
            padding: '20px 24px',
            borderRadius: '16px',
            marginBottom: '28px',
            background: 'linear-gradient(135deg, var(--bg-tertiary), var(--accent-light))',
            border: '1px solid var(--accent-primary)',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            cursor: 'pointer',
            transition: 'all 0.2s ease'
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <div style={{
              width: '46px',
              height: '46px',
              borderRadius: '14px',
              background: 'var(--accent-primary)',
              color: '#ffffff',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}>
              <Layers size={24} />
            </div>
            <div>
              <div style={{ fontWeight: '800', fontSize: '1.15rem', color: 'var(--text-primary)' }}>
                Academic Semester System (Semester &gt; Branch &gt; Courses &gt; Lectures / Quizzes)
              </div>
              <div style={{ fontSize: '0.825rem', color: 'var(--text-muted)', marginTop: '2px' }}>
                Complete institutional hierarchy explorer. Drill down into Semesters (1 to 8), Branches, Courses, Timetables, and Examinations.
              </div>
            </div>
          </div>
          <button className="btn-primary" style={{ padding: '9px 18px', fontSize: '0.85rem' }}>
            Explore Semester System
          </button>
        </div>
      )}

      {/* VIEW: SEMESTER SYSTEM HIERARCHY */}
      {activeTab === 'semester_system' && (
        <div style={{ marginBottom: '32px' }}>
          <SemesterHierarchyView
            role="ADMIN"
            divisions={structure.divisions}
            onOpenQuizCreator={(course) => {
              setQuizModalSubjectId(course.id);
              setIsQuizModalOpen(true);
            }}
            onOpenQuizMonitor={(quizId) => {
              window.open(`/api/reports/quiz/${quizId}?format=pdf&token=${token}`, '_blank');
            }}
          />
        </div>
      )}

      {/* VIEW: TEACHERS DIRECTORY WITH CLICK-TO-INSPECT DOSSIER */}
      {(activeTab === 'dashboard' || activeTab === 'teachers') && (
        <div style={{ marginBottom: '32px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
            <div>
              <h3 style={{ fontSize: '1.25rem', fontWeight: '700' }}>Faculty Management & Dossiers</h3>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.825rem' }}>
                Click on any faculty member to inspect and edit their assigned classes, timetable, lectures, and quizzes
              </p>
            </div>
            <button onClick={() => setIsAddTeacherOpen(true)} className="btn-primary">
              <Plus size={18} /> Add Faculty Member
            </button>
          </div>

          <div className="glass-panel" style={{ borderRadius: '18px', overflow: 'hidden' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.875rem' }}>
              <thead>
                <tr style={{ background: 'var(--bg-tertiary)' }}>
                  <th style={{ padding: '14px 20px' }}>Faculty Name</th>
                  <th style={{ padding: '14px 20px' }}>Login ID</th>
                  <th style={{ padding: '14px 20px' }}>Email</th>
                  <th style={{ padding: '14px 20px' }}>Assigned Classes</th>
                  <th style={{ padding: '14px 20px', textAlign: 'right' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {teachers.map(t => (
                  <tr
                    key={t.id}
                    onClick={() => openTeacherDossier(t.id)}
                    style={{ borderBottom: '1px solid var(--border-subtle)', cursor: 'pointer', transition: 'background 0.15s' }}
                    className="hover-row"
                  >
                    <td style={{ padding: '14px 20px', fontWeight: '600' }}>{t.name}</td>
                    <td style={{ padding: '14px 20px', fontFamily: 'var(--font-mono)' }}>{t.identifier}</td>
                    <td style={{ padding: '14px 20px', color: 'var(--text-secondary)' }}>{t.email}</td>
                    <td style={{ padding: '14px 20px' }}>
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                        {t.assignments?.map(a => (
                          <span key={a.assignment_id} className="badge badge-active" style={{ fontSize: '0.725rem' }}>
                            {a.subject_code} (Div {a.division_name}{a.batch_name ? ` • B${a.batch_name}` : ''})
                          </span>
                        ))}
                      </div>
                    </td>
                    <td style={{ padding: '14px 20px', textAlign: 'right' }} onClick={e => e.stopPropagation()}>
                      <div style={{ display: 'inline-flex', gap: '8px' }}>
                        <button
                          onClick={() => openTeacherDossier(t.id)}
                          className="btn-secondary"
                          style={{ padding: '6px 12px', fontSize: '0.78rem' }}
                        >
                          <Eye size={14} /> Full Dossier
                        </button>
                        <button
                          onClick={() => handleDeleteTeacher(t.id)}
                          className="btn-secondary"
                          style={{ padding: '6px 10px', fontSize: '0.78rem', color: 'var(--danger)' }}
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* VIEW: STUDENT DIRECTORY (COURSE > SEMESTER > DIVISION > BATCH DRILL-DOWN) */}
      {(activeTab === 'students') && (
        <div style={{ marginBottom: '32px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
            <div>
              <h3 style={{ fontSize: '1.25rem', fontWeight: '700' }}>Student Academic Directory & Records</h3>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.825rem' }}>
                Filter hierarchy: Course ➔ Semester ➔ Division ➔ Batch. Click any student to view dossier, edit info, or override marks.
              </p>
            </div>
            <button onClick={() => setIsAddStudentOpen(true)} className="btn-primary">
              <Plus size={18} /> Enroll Student
            </button>
          </div>

          {/* Hierarchical Drill-Down Filter Bar */}
          <div className="glass-panel" style={{ padding: '16px 20px', borderRadius: '16px', marginBottom: '18px', display: 'flex', flexWrap: 'wrap', gap: '12px', alignItems: 'center' }}>
            <div style={{ minWidth: '160px' }}>
              <label style={{ fontSize: '0.725rem', color: 'var(--text-muted)', fontWeight: '600', display: 'block', marginBottom: '4px' }}>Division</label>
              <select className="input-field" value={selDiv} onChange={e => { setSelDiv(e.target.value); setSelBatch(''); }} style={{ padding: '8px 12px' }}>
                <option value="">All Divisions</option>
                {structure.divisions.map(d => <option key={d.id} value={d.id}>Division {d.name}</option>)}
              </select>
            </div>

            <div style={{ minWidth: '160px' }}>
              <label style={{ fontSize: '0.725rem', color: 'var(--text-muted)', fontWeight: '600', display: 'block', marginBottom: '4px' }}>Batch</label>
              <select className="input-field" value={selBatch} onChange={e => setSelBatch(e.target.value)} style={{ padding: '8px 12px' }}>
                <option value="">All Batches</option>
                {structure.batches
                  .filter(b => !selDiv || String(b.division_id) === String(selDiv))
                  .map(b => <option key={b.id} value={b.id}>Batch {b.name}</option>)}
              </select>
            </div>

            <div style={{ flex: 1, minWidth: '220px' }}>
              <label style={{ fontSize: '0.725rem', color: 'var(--text-muted)', fontWeight: '600', display: 'block', marginBottom: '4px' }}>Search Student</label>
              <div style={{ position: 'relative' }}>
                <input
                  type="text"
                  className="input-field"
                  placeholder="Filter by name or enrollment number..."
                  value={studentSearch}
                  onChange={e => setStudentSearch(e.target.value)}
                  style={{ padding: '8px 12px 8px 36px' }}
                />
                <Search size={16} style={{ position: 'absolute', left: '12px', top: '10px', color: 'var(--text-muted)' }} />
              </div>
            </div>
          </div>

          <div className="glass-panel" style={{ borderRadius: '18px', overflow: 'hidden' }}>
            <div style={{ padding: '12px 20px', borderBottom: '1px solid var(--border-glass)', fontSize: '0.8rem', color: 'var(--text-muted)' }}>
              Showing <strong>{filteredStudents.length}</strong> student records
            </div>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.875rem' }}>
              <thead>
                <tr style={{ background: 'var(--bg-tertiary)' }}>
                  <th style={{ padding: '14px 20px' }}>Enrollment No</th>
                  <th style={{ padding: '14px 20px' }}>Full Name</th>
                  <th style={{ padding: '14px 20px' }}>Email</th>
                  <th style={{ padding: '14px 20px' }}>Branch</th>
                  <th style={{ padding: '14px 20px' }}>Division</th>
                  <th style={{ padding: '14px 20px' }}>Batch</th>
                  <th style={{ padding: '14px 20px', textAlign: 'right' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredStudents.map(s => (
                  <tr
                    key={s.id}
                    onClick={() => openStudentDossier(s.id)}
                    style={{ borderBottom: '1px solid var(--border-subtle)', cursor: 'pointer' }}
                  >
                    <td style={{ padding: '14px 20px', fontFamily: 'var(--font-mono)', fontWeight: '700', color: 'var(--accent-primary)' }}>
                      {s.enrollment_number}
                    </td>
                    <td style={{ padding: '14px 20px', fontWeight: '600' }}>{s.name}</td>
                    <td style={{ padding: '14px 20px', color: 'var(--text-secondary)' }}>{s.email}</td>
                    <td style={{ padding: '14px 20px' }}>{s.branch}</td>
                    <td style={{ padding: '14px 20px' }}>Div {s.division_name}</td>
                    <td style={{ padding: '14px 20px' }}>Batch {s.batch_name}</td>
                    <td style={{ padding: '14px 20px', textAlign: 'right' }} onClick={e => e.stopPropagation()}>
                      <div style={{ display: 'inline-flex', gap: '8px' }}>
                        <button onClick={() => openStudentDossier(s.id)} className="btn-secondary" style={{ padding: '6px 12px', fontSize: '0.78rem' }}>
                          <Eye size={14} /> View / Edit
                        </button>
                        <button onClick={() => handleDeleteStudent(s.id)} className="btn-secondary" style={{ padding: '6px 10px', fontSize: '0.78rem', color: 'var(--danger)' }}>
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* VIEW: ACADEMIC DIVISIONS & BATCHES MANAGEMENT (Master Build Prompt Section 6) */}
      {(activeTab === 'structure') && (
        <div style={{ marginBottom: '32px' }}>
          <div style={{ marginBottom: '16px' }}>
            <h3 style={{ fontSize: '1.25rem', fontWeight: '700' }}>Divisions, Batches & Subject Hierarchy</h3>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.825rem' }}>
              Create, view, and organize institutional academic divisions and their tied laboratory batches
            </p>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '20px', marginBottom: '24px' }}>
            {/* Divisions & Tied Batches Card */}
            <div className="glass-panel" style={{ padding: '24px', borderRadius: '20px' }}>
              <h4 style={{ fontSize: '1.1rem', fontWeight: '700', marginBottom: '14px' }}>Academic Divisions & Tied Batches</h4>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '14px', marginBottom: '20px' }}>
                {structure.divisions.map(d => {
                  const divBatches = structure.batches.filter(b => b.division_id === d.id);
                  return (
                    <div key={d.id} style={{ padding: '14px 18px', background: 'var(--bg-tertiary)', borderRadius: '14px', border: '1px solid var(--border-glass)' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                        <div style={{ fontWeight: '700', fontSize: '1rem', color: 'var(--text-primary)' }}>
                          Division {d.name}
                        </div>
                        <button onClick={() => handleDeleteDivision(d.id)} style={{ background: 'none', border: 'none', color: 'var(--danger)', cursor: 'pointer' }}>
                          <Trash2 size={16} />
                        </button>
                      </div>

                      <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginBottom: '8px' }}>
                        Tied Laboratory Batches:
                      </div>
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                        {divBatches.length === 0 ? (
                          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>No batches created under Division {d.name}</span>
                        ) : (
                          divBatches.map(b => (
                            <span key={b.id} className="badge badge-active" style={{ fontSize: '0.75rem' }}>
                              Batch {b.name}
                              <button onClick={() => handleDeleteBatch(b.id)} style={{ background: 'none', border: 'none', color: 'inherit', marginLeft: '6px', cursor: 'pointer' }}>
                                ×
                              </button>
                            </span>
                          ))
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Add Division Form */}
              <form onSubmit={handleAddDivision} style={{ display: 'flex', gap: '8px', marginBottom: '14px' }}>
                <input
                  type="text"
                  className="input-field"
                  placeholder="New Division Name (e.g. H1)"
                  value={newDivName}
                  onChange={e => setNewDivName(e.target.value)}
                  required
                />
                <button type="submit" className="btn-primary" style={{ whiteSpace: 'nowrap' }}>
                  <Plus size={16} /> Add Division
                </button>
              </form>

              {/* Add Batch Form */}
              <form onSubmit={handleAddBatch} style={{ display: 'flex', gap: '8px' }}>
                <select className="input-field" value={newBatchDiv} onChange={e => setNewBatchDiv(e.target.value)} required>
                  <option value="">-- Under Division --</option>
                  {structure.divisions.map(d => <option key={d.id} value={d.id}>Division {d.name}</option>)}
                </select>
                <input
                  type="text"
                  className="input-field"
                  placeholder="Batch (e.g. B1)"
                  value={newBatchName}
                  onChange={e => setNewBatchName(e.target.value)}
                  required
                />
                <button type="submit" className="btn-secondary" style={{ whiteSpace: 'nowrap' }}>
                  <Plus size={16} /> Add Batch
                </button>
              </form>
            </div>

            {/* Subjects Card */}
            <div className="glass-panel" style={{ padding: '24px', borderRadius: '20px' }}>
              <h4 style={{ fontSize: '1.1rem', fontWeight: '700', marginBottom: '14px' }}>Academic Curriculum Subjects</h4>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginBottom: '20px', maxHeight: '280px', overflowY: 'auto' }}>
                {structure.subjects.map(s => (
                  <div key={s.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 14px', background: 'var(--bg-tertiary)', borderRadius: '10px' }}>
                    <div>
                      <div style={{ fontWeight: '600', display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <span>{s.name} ({s.code})</span>
                        <span className="badge badge-scheduled" style={{ fontSize: '0.7rem', padding: '2px 8px' }}>
                          Sem {s.semester_number || s.semester_id || '5'}
                        </span>
                      </div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Type: {s.type}</div>
                    </div>
                    <button onClick={() => handleDeleteSubject(s.id)} style={{ background: 'none', border: 'none', color: 'var(--danger)', cursor: 'pointer' }}>
                      <Trash2 size={15} />
                    </button>
                  </div>
                ))}
              </div>

              {/* Add Subject Form */}
              <form onSubmit={handleAddSubject} style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '8px' }}>
                  <input type="text" className="input-field" placeholder="Code (CS504)" value={newSubCode} onChange={e => setNewSubCode(e.target.value)} required />
                  <input type="text" className="input-field" placeholder="Subject Name" value={newSubName} onChange={e => setNewSubName(e.target.value)} required />
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1.1fr 1.2fr auto', gap: '8px' }}>
                  <select className="input-field" value={newSubSemester} onChange={e => setNewSubSemester(e.target.value)}>
                    <option value="1">Semester 1</option>
                    <option value="2">Semester 2</option>
                    <option value="3">Semester 3</option>
                    <option value="4">Semester 4</option>
                    <option value="5">Semester 5</option>
                    <option value="6">Semester 6</option>
                    <option value="7">Semester 7</option>
                    <option value="8">Semester 8</option>
                  </select>
                  <select className="input-field" value={newSubType} onChange={e => setNewSubType(e.target.value)}>
                    <option value="BOTH">Theory & Practical</option>
                    <option value="THEORY">Theory Only</option>
                    <option value="PRACTICAL">Practical Only</option>
                  </select>
                  <button type="submit" className="btn-primary" style={{ whiteSpace: 'nowrap' }}>
                    <Plus size={16} /> Add Subject
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* VIEW: ALL EXAMINATIONS (LIVE, UPCOMING, COMPLETED) */}
      {(activeTab === 'quizzes') && (
        <div style={{ marginBottom: '32px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
            <div>
              <h3 style={{ fontSize: '1.25rem', fontWeight: '700' }}>Institutional Examination Roster</h3>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.825rem' }}>
                Complete visibility over live, upcoming, and evaluated examinations across all departments
              </p>
            </div>
          </div>

          <div className="glass-panel" style={{ borderRadius: '18px', overflow: 'hidden' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.875rem' }}>
              <thead>
                <tr style={{ background: 'var(--bg-tertiary)' }}>
                  <th style={{ padding: '14px 20px' }}>Access Code</th>
                  <th style={{ padding: '14px 20px' }}>Title & Subject</th>
                  <th style={{ padding: '14px 20px' }}>Faculty Author</th>
                  <th style={{ padding: '14px 20px' }}>Division / Batch</th>
                  <th style={{ padding: '14px 20px' }}>Status</th>
                  <th style={{ padding: '14px 20px' }}>Attempts</th>
                  <th style={{ padding: '14px 20px', textAlign: 'right' }}>Reports</th>
                </tr>
              </thead>
              <tbody>
                {allQuizzes.map(q => (
                  <tr key={q.id} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                    <td style={{ padding: '14px 20px', fontFamily: 'var(--font-mono)', fontWeight: '700', color: 'var(--accent-primary)' }}>
                      {q.access_code}
                    </td>
                    <td style={{ padding: '14px 20px' }}>
                      <div style={{ fontWeight: '600' }}>{q.title}</div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{q.subject_name} ({q.subject_code})</div>
                    </td>
                    <td style={{ padding: '14px 20px' }}>{q.creator_name}</td>
                    <td style={{ padding: '14px 20px' }}>Div {q.division_name} {q.batch_name ? `• Batch ${q.batch_name}` : ''}</td>
                    <td style={{ padding: '14px 20px' }}>
                      <span className={`badge ${q.live_state === 'LIVE' ? 'badge-active' : (q.live_state === 'COMPLETED' ? 'badge-present' : 'badge-leave')}`}>
                        {q.live_state}
                      </span>
                    </td>
                    <td style={{ padding: '14px 20px', fontWeight: '600' }}>{q.attempts_count} Candidates</td>
                    <td style={{ padding: '14px 20px', textAlign: 'right' }}>
                      <div style={{ display: 'inline-flex', gap: '6px' }}>
                        <a
                          href={`/api/reports/quiz/${q.id}?format=pdf&token=${token}`}
                          download
                          className="btn-secondary"
                          style={{ padding: '6px 10px', fontSize: '0.78rem', textDecoration: 'none' }}
                        >
                          <FileDown size={14} /> PDF
                        </a>
                        <a
                          href={`/api/reports/quiz/${q.id}?format=excel&token=${token}`}
                          download
                          className="btn-secondary"
                          style={{ padding: '6px 10px', fontSize: '0.78rem', textDecoration: 'none' }}
                        >
                          <FileText size={14} /> Excel
                        </a>
                        <button
                          onClick={() => handleDeleteQuiz(q.id, q.title)}
                          className="btn-secondary"
                          style={{ padding: '6px 10px', fontSize: '0.78rem', color: 'var(--danger)' }}
                          title="Delete Quiz"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* VIEW: MASTER TIMETABLE */}
      {(activeTab === 'timetable') && (
        <div style={{ marginBottom: '32px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
          {/* HEADER & CONTROLS */}
          <div className="glass-panel" style={{ padding: '22px 28px', borderRadius: '20px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px' }}>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--text-muted)', fontSize: '0.825rem', marginBottom: '6px' }}>
                  <span>Academic Timetable</span>
                  <ChevronRight size={14} />
                  <span style={{ color: 'var(--accent-primary)', fontWeight: '600' }}>{ttBranch}</span>
                  <ChevronRight size={14} />
                  <span>Semester {ttSemester}</span>
                  <ChevronRight size={14} />
                  <span style={{ color: 'var(--text-primary)', fontWeight: '700' }}>
                    {[
                      { day: 1, label: 'Monday' },
                      { day: 2, label: 'Tuesday' },
                      { day: 3, label: 'Wednesday' },
                      { day: 4, label: 'Thursday' },
                      { day: 5, label: 'Friday' },
                      { day: 6, label: 'Saturday' }
                    ].find(d => d.day === ttDay)?.label || 'Monday'}
                  </span>
                </div>
                <h3 style={{ fontSize: '1.4rem', fontWeight: '800', display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <Calendar size={24} style={{ color: 'var(--accent-primary)' }} />
                  Master Institutional Timetable
                </h3>
                <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem', marginTop: '4px' }}>
                  Curriculum drill-down: <strong>Branch</strong> &gt; <strong>Semester</strong> &gt; <strong>Monday to Friday</strong> &gt; <strong>Courses & Subjects = Timing</strong>
                </p>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
                <div style={{ display: 'flex', background: 'var(--bg-tertiary)', padding: '3px', borderRadius: '10px' }}>
                  <button
                    type="button"
                    onClick={() => setTtViewMode('cards')}
                    style={{
                      padding: '7px 14px',
                      borderRadius: '8px',
                      border: 'none',
                      fontSize: '0.8rem',
                      fontWeight: '700',
                      cursor: 'pointer',
                      background: ttViewMode === 'cards' ? 'var(--accent-primary)' : 'transparent',
                      color: ttViewMode === 'cards' ? '#ffffff' : 'var(--text-secondary)',
                      transition: 'all 0.15s ease'
                    }}
                  >
                    Day Schedule
                  </button>
                  <button
                    type="button"
                    onClick={() => setTtViewMode('table')}
                    style={{
                      padding: '7px 14px',
                      borderRadius: '8px',
                      border: 'none',
                      fontSize: '0.8rem',
                      fontWeight: '700',
                      cursor: 'pointer',
                      background: ttViewMode === 'table' ? 'var(--accent-primary)' : 'transparent',
                      color: ttViewMode === 'table' ? '#ffffff' : 'var(--text-secondary)',
                      transition: 'all 0.15s ease'
                    }}
                  >
                    Full Week Table
                  </button>
                </div>

                <button
                  onClick={() => {
                    const semObj = structure.semesters?.find(s => Number(s.number) === Number(ttSemester));
                    const subjList = structure.subjects?.filter(s =>
                      (!s.branch || s.branch === ttBranch) &&
                      (!s.semester_number || Number(s.semester_number) === Number(ttSemester))
                    ) || [];
                    setTtForm({
                      ...ttForm,
                      semester_id: semObj ? String(semObj.id) : String(ttSemester),
                      day_of_week: String(ttDay),
                      subject_id: subjList.length > 0 ? String(subjList[0].id) : ''
                    });
                    setIsAddTimetableOpen(true);
                  }}
                  className="btn-primary"
                  style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.85rem', padding: '9px 16px' }}
                >
                  <Plus size={16} /> Add Schedule Slot
                </button>
              </div>
            </div>
          </div>

          {/* STEP 1: BRANCH SELECTOR */}
          <div>
            <div style={{ fontSize: '0.75rem', fontWeight: '700', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: '8px' }}>
              Step 1: Academic Branch
            </div>
            <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
              {availableBranches.map(bName => {
                const isSelected = bName === ttBranch;
                const slotCount = timetable.filter(t => t.branch === bName).length;
                return (
                  <button
                    key={bName}
                    type="button"
                    onClick={() => setTtBranch(bName)}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '10px',
                      padding: '10px 18px',
                      borderRadius: '14px',
                      border: isSelected ? '2px solid var(--accent-primary)' : '1px solid var(--border-subtle)',
                      background: isSelected ? 'var(--accent-primary)' : 'var(--bg-secondary)',
                      color: isSelected ? '#ffffff' : 'var(--text-primary)',
                      fontWeight: isSelected ? '700' : '600',
                      fontSize: '0.875rem',
                      cursor: 'pointer',
                      transition: 'all 0.15s ease'
                    }}
                  >
                    <GraduationCap size={16} />
                    <span>{bName}</span>
                    <span style={{
                      padding: '2px 8px',
                      borderRadius: '20px',
                      fontSize: '0.72rem',
                      background: isSelected ? 'rgba(255,255,255,0.25)' : 'var(--bg-tertiary)',
                      color: isSelected ? '#ffffff' : 'var(--accent-primary)'
                    }}>
                      {slotCount} slots
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* STEP 2: SEMESTER SELECTOR */}
          <div>
            <div style={{ fontSize: '0.75rem', fontWeight: '700', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: '8px' }}>
              Step 2: Academic Semester ({ttBranch})
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))', gap: '10px' }}>
              {availableSemesters.map(semNum => {
                const isSelected = Number(semNum) === Number(ttSemester);
                const count = timetable.filter(t =>
                  (t.branch === ttBranch || (!t.branch && ttBranch === availableBranches[0])) &&
                  Number(t.semester_number || t.semester_id) === Number(semNum)
                ).length;

                return (
                  <button
                    key={semNum}
                    type="button"
                    onClick={() => setTtSemester(semNum)}
                    className="glass-panel"
                    style={{
                      textAlign: 'left',
                      padding: '12px 16px',
                      borderRadius: '14px',
                      border: isSelected ? '2px solid var(--accent-primary)' : '1px solid var(--border-subtle)',
                      background: isSelected ? 'var(--accent-light)' : 'var(--bg-secondary)',
                      cursor: 'pointer',
                      transition: 'all 0.15s ease',
                      boxShadow: isSelected ? '0 0 16px var(--accent-glow)' : 'none'
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span style={{
                        fontSize: '0.95rem',
                        fontWeight: '800',
                        color: isSelected ? 'var(--accent-primary)' : 'var(--text-primary)'
                      }}>
                        Semester {semNum}
                      </span>
                      {isSelected && (
                        <span style={{ width: '7px', height: '7px', borderRadius: '50%', background: 'var(--accent-primary)' }} />
                      )}
                    </div>
                    <div style={{ fontSize: '0.72rem', color: isSelected ? 'var(--accent-primary)' : 'var(--text-muted)', marginTop: '4px', fontWeight: '600' }}>
                      {count} {count === 1 ? 'class' : 'classes'}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* STEP 3: MONDAY TO FRIDAY DAY SELECTOR (JUST LIKE IN STUDENT SECTION) */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px' }}>
            <div>
              <div style={{ fontSize: '0.75rem', fontWeight: '700', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>
                Step 3: Day Schedule (Monday to Friday)
              </div>
              <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginTop: '2px' }}>
                Showing lectures for <strong>{[
                  { day: 1, label: 'Monday' },
                  { day: 2, label: 'Tuesday' },
                  { day: 3, label: 'Wednesday' },
                  { day: 4, label: 'Thursday' },
                  { day: 5, label: 'Friday' },
                  { day: 6, label: 'Saturday' }
                ].find(d => d.day === ttDay)?.label}</strong> in Semester {ttSemester}
              </div>
            </div>

            <div style={{ display: 'flex', gap: '6px', background: 'var(--bg-secondary)', padding: '5px', borderRadius: '14px', border: '1px solid var(--border-subtle)' }}>
              {[
                { day: 1, label: 'Monday', short: 'Mon' },
                { day: 2, label: 'Tuesday', short: 'Tue' },
                { day: 3, label: 'Wednesday', short: 'Wed' },
                { day: 4, label: 'Thursday', short: 'Thu' },
                { day: 5, label: 'Friday', short: 'Fri' },
                { day: 6, label: 'Saturday', short: 'Sat' }
              ].map(d => {
                const isSelected = ttDay === d.day;
                const countForDay = timetable.filter(t =>
                  (t.branch === ttBranch || (!t.branch && ttBranch === availableBranches[0])) &&
                  Number(t.semester_number || t.semester_id) === Number(ttSemester) &&
                  Number(t.day_of_week) === d.day
                ).length;

                return (
                  <button
                    key={d.day}
                    type="button"
                    onClick={() => setTtDay(d.day)}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      padding: '8px 16px',
                      borderRadius: '10px',
                      border: 'none',
                      fontWeight: '700',
                      fontSize: '0.85rem',
                      cursor: 'pointer',
                      background: isSelected ? 'var(--accent-primary)' : 'transparent',
                      color: isSelected ? '#ffffff' : 'var(--text-secondary)',
                      transition: 'all 0.15s ease'
                    }}
                  >
                    <span>{d.short}</span>
                    <span style={{
                      padding: '1px 6px',
                      borderRadius: '10px',
                      fontSize: '0.7rem',
                      background: isSelected ? 'rgba(255,255,255,0.25)' : 'var(--bg-tertiary)',
                      color: isSelected ? '#ffffff' : 'var(--text-muted)'
                    }}>
                      {countForDay}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* STEP 4: COURSES & SUBJECTS = TIMING */}
          {ttViewMode === 'cards' ? (
            (() => {
              const dayEntries = timetable.filter(t =>
                (t.branch === ttBranch || (!t.branch && ttBranch === availableBranches[0])) &&
                Number(t.semester_number || t.semester_id) === Number(ttSemester) &&
                Number(t.day_of_week) === Number(ttDay)
              ).sort((a, b) => (a.start_time || '').localeCompare(b.start_time || ''));

              const dayName = [
                { day: 1, label: 'Monday' },
                { day: 2, label: 'Tuesday' },
                { day: 3, label: 'Wednesday' },
                { day: 4, label: 'Thursday' },
                { day: 5, label: 'Friday' },
                { day: 6, label: 'Saturday' }
              ].find(d => d.day === ttDay)?.label || 'Selected Day';

              if (dayEntries.length === 0) {
                return (
                  <div className="glass-panel" style={{ padding: '48px 24px', textAlign: 'center', borderRadius: '20px' }}>
                    <Calendar size={42} style={{ color: 'var(--text-muted)', margin: '0 auto 12px', opacity: 0.5 }} />
                    <h4 style={{ fontSize: '1.1rem', fontWeight: '800' }}>
                      No Lectures Scheduled for {dayName}
                    </h4>
                    <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem', maxWidth: '440px', margin: '6px auto 18px' }}>
                      No classes are currently scheduled on {dayName} for Semester {ttSemester} in {ttBranch}.
                    </p>
                    <button
                      onClick={() => {
                        const semObj = structure.semesters?.find(s => Number(s.number) === Number(ttSemester));
                        const subjList = structure.subjects?.filter(s =>
                          (!s.branch || s.branch === ttBranch) &&
                          (!s.semester_number || Number(s.semester_number) === Number(ttSemester))
                        ) || [];
                        setTtForm({
                          ...ttForm,
                          semester_id: semObj ? String(semObj.id) : String(ttSemester),
                          day_of_week: String(ttDay),
                          subject_id: subjList.length > 0 ? String(subjList[0].id) : ''
                        });
                        setIsAddTimetableOpen(true);
                      }}
                      className="btn-primary"
                      style={{ fontSize: '0.85rem', padding: '9px 20px' }}
                    >
                      <Plus size={16} /> Schedule Class for {dayName}
                    </button>
                  </div>
                );
              }

              return (
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(340px, 1fr))', gap: '16px' }}>
                  {dayEntries.map(entry => (
                    <div
                      key={entry.id}
                      className="glass-panel"
                      style={{
                        padding: '20px 22px',
                        borderRadius: '18px',
                        display: 'flex',
                        flexDirection: 'column',
                        justifyContent: 'space-between',
                        gap: '14px',
                        minWidth: 0,
                        overflow: 'hidden',
                        wordBreak: 'break-word'
                      }}
                    >
                      <div>
                        {/* Header: Session Type & Room */}
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px', gap: '8px' }}>
                          <div style={{ display: 'flex', gap: '8px', alignItems: 'center', flexWrap: 'wrap' }}>
                            <span className="badge badge-active">{entry.session_type}</span>
                            <span style={{
                              fontSize: '0.75rem',
                              padding: '3px 8px',
                              borderRadius: '6px',
                              background: 'var(--bg-tertiary)',
                              color: 'var(--text-secondary)',
                              fontWeight: '600'
                            }}>
                              Div {entry.division_name} {entry.batch_name ? `• Batch ${entry.batch_name}` : ''}
                            </span>
                          </div>
                          <div style={{
                            padding: '4px 10px',
                            background: 'var(--bg-tertiary)',
                            borderRadius: '8px',
                            fontSize: '0.8rem',
                            fontWeight: '700',
                            color: 'var(--text-primary)'
                          }}>
                            Room {entry.room}
                          </div>
                        </div>

                        {/* Subject Title & Code */}
                        <h4 style={{ fontSize: '1.15rem', fontWeight: '800', marginBottom: '4px', color: 'var(--text-primary)' }}>
                          {entry.subject_name}
                        </h4>
                        <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>
                          {entry.subject_code} • {entry.branch}
                        </div>

                        {/* Instructor */}
                        <div style={{ fontSize: '0.825rem', color: 'var(--text-secondary)', marginTop: '8px' }}>
                          Faculty: <strong style={{ color: 'var(--text-primary)' }}>{entry.teacher_name}</strong>
                          {entry.building && <span style={{ color: 'var(--text-muted)' }}> ({entry.building})</span>}
                        </div>
                      </div>

                      {/* Footer: Prominent Timing & Actions */}
                      <div style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        paddingTop: '12px',
                        borderTop: '1px solid var(--border-subtle)',
                        gap: '8px'
                      }}>
                        <div style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '8px',
                          fontSize: '1rem',
                          fontWeight: '800',
                          color: 'var(--accent-primary)',
                          fontFamily: 'var(--font-mono)'
                        }}>
                          <Clock size={16} />
                          <span>{entry.start_time} - {entry.end_time}</span>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleDeleteTimetable(entry.id)}
                          style={{
                            background: 'none',
                            border: 'none',
                            color: 'var(--danger)',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '4px',
                            fontSize: '0.78rem',
                            padding: '4px 8px',
                            borderRadius: '6px'
                          }}
                          title="Remove timetable slot"
                        >
                          <Trash2 size={14} /> Remove
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              );
            })()
          ) : (
            /* ALL WEEK TABLE VIEW */
            <div className="glass-panel" style={{ borderRadius: '18px', overflow: 'hidden' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.875rem' }}>
                <thead>
                  <tr style={{ background: 'var(--bg-tertiary)' }}>
                    <th style={{ padding: '12px 18px' }}>Day</th>
                    <th style={{ padding: '12px 18px' }}>Timing</th>
                    <th style={{ padding: '12px 18px' }}>Subject</th>
                    <th style={{ padding: '12px 18px' }}>Type</th>
                    <th style={{ padding: '12px 18px' }}>Division / Batch</th>
                    <th style={{ padding: '12px 18px' }}>Room</th>
                    <th style={{ padding: '12px 18px' }}>Faculty</th>
                    <th style={{ padding: '12px 18px', textAlign: 'right' }}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {(() => {
                    const filtered = timetable.filter(t =>
                      (t.branch === ttBranch || (!t.branch && ttBranch === availableBranches[0])) &&
                      Number(t.semester_number || t.semester_id) === Number(ttSemester)
                    ).sort((a, b) => a.day_of_week - b.day_of_week || (a.start_time || '').localeCompare(b.start_time || ''));

                    const dayNames = ['', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

                    if (filtered.length === 0) {
                      return (
                        <tr>
                          <td colSpan="8" style={{ textAlign: 'center', padding: '30px', color: 'var(--text-muted)' }}>
                            No timetable entries found for {ttBranch} - Semester {ttSemester}.
                          </td>
                        </tr>
                      );
                    }

                    return filtered.map(tt => (
                      <tr key={tt.id} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                        <td style={{ padding: '12px 18px', fontWeight: '700', color: 'var(--accent-primary)' }}>
                          {dayNames[tt.day_of_week] || `Day ${tt.day_of_week}`}
                        </td>
                        <td style={{ padding: '12px 18px', fontFamily: 'var(--font-mono)', fontWeight: '600' }}>
                          {tt.start_time} - {tt.end_time}
                        </td>
                        <td style={{ padding: '12px 18px', fontWeight: '600' }}>
                          {tt.subject_name} ({tt.subject_code})
                        </td>
                        <td style={{ padding: '12px 18px' }}>
                          <span className="badge badge-active">{tt.session_type}</span>
                        </td>
                        <td style={{ padding: '12px 18px' }}>
                          Div {tt.division_name} {tt.batch_name ? `• Batch ${tt.batch_name}` : ''}
                        </td>
                        <td style={{ padding: '12px 18px' }}>{tt.room}</td>
                        <td style={{ padding: '12px 18px' }}>{tt.teacher_name}</td>
                        <td style={{ padding: '12px 18px', textAlign: 'right' }}>
                          <button
                            type="button"
                            onClick={() => handleDeleteTimetable(tt.id)}
                            style={{ background: 'none', border: 'none', color: 'var(--danger)', cursor: 'pointer', padding: '4px' }}
                            title="Delete slot"
                          >
                            <Trash2 size={15} />
                          </button>
                        </td>
                      </tr>
                    ));
                  })()}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* VIEW: ATTENDANCE CORRECTIONS */}
      {(activeTab === 'corrections') && (
        <div style={{ marginBottom: '32px' }}>
          <div style={{ marginBottom: '16px' }}>
            <h3 style={{ fontSize: '1.25rem', fontWeight: '700' }}>Attendance Correction Workflow</h3>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.825rem' }}>
              Teachers submit correction requests; administrative approval updates source records with audit logs
            </p>
          </div>

          <div className="glass-panel" style={{ borderRadius: '18px', overflow: 'hidden' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.875rem' }}>
              <thead>
                <tr style={{ background: 'var(--bg-tertiary)' }}>
                  <th style={{ padding: '14px 20px' }}>Student</th>
                  <th style={{ padding: '14px 20px' }}>Session / Subject</th>
                  <th style={{ padding: '14px 20px' }}>Change Requested</th>
                  <th style={{ padding: '14px 20px' }}>Reason</th>
                  <th style={{ padding: '14px 20px' }}>Status</th>
                  <th style={{ padding: '14px 20px', textAlign: 'right' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {corrections.length === 0 ? (
                  <tr>
                    <td colSpan="6" style={{ textAlign: 'center', padding: '30px', color: 'var(--text-muted)' }}>
                      No attendance correction requests submitted.
                    </td>
                  </tr>
                ) : (
                  corrections.map(c => (
                    <tr key={c.id} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                      <td style={{ padding: '14px 20px' }}>
                        <div style={{ fontWeight: '600' }}>{c.student_name}</div>
                        <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{c.enrollment_number}</div>
                      </td>
                      <td style={{ padding: '14px 20px' }}>
                        <div>{c.subject_name} ({c.session_type})</div>
                        <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{c.session_date}</div>
                      </td>
                      <td style={{ padding: '14px 20px' }}>
                        <span style={{ color: 'var(--danger)' }}>{c.previous_status}</span> ➔ <span style={{ color: 'var(--success)', fontWeight: '700' }}>{c.requested_status}</span>
                      </td>
                      <td style={{ padding: '14px 20px', color: 'var(--text-secondary)' }}>{c.reason}</td>
                      <td style={{ padding: '14px 20px' }}>
                        <span className={`badge ${c.status === 'APPROVED' ? 'badge-present' : (c.status === 'REJECTED' ? 'badge-absent' : 'badge-leave')}`}>
                          {c.status}
                        </span>
                      </td>
                      <td style={{ padding: '14px 20px', textAlign: 'right' }}>
                        {c.status === 'PENDING' && (
                          <div style={{ display: 'inline-flex', gap: '8px' }}>
                            <button
                              onClick={() => handleReviewCorrection(c.id, 'APPROVE')}
                              className="btn-primary"
                              style={{ padding: '6px 12px', fontSize: '0.75rem', background: '#10b981' }}
                            >
                              <Check size={14} /> Approve
                            </button>
                            <button
                              onClick={() => handleReviewCorrection(c.id, 'REJECT')}
                              className="btn-secondary"
                              style={{ padding: '6px 12px', fontSize: '0.75rem', color: '#ef4444' }}
                            >
                              <X size={14} /> Reject
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* VIEW: AUDIT LOGS */}
      {(activeTab === 'audit_logs') && (
        <div style={{ marginBottom: '32px' }}>
          <div style={{ marginBottom: '16px' }}>
            <h3 style={{ fontSize: '1.25rem', fontWeight: '700' }}>Platform Security & Compliance Audit Log</h3>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.825rem' }}>
              Immutable record of administrative operations, attendance corrections, and authentication events
            </p>
          </div>

          <div className="glass-panel" style={{ borderRadius: '18px', overflow: 'hidden' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.825rem' }}>
              <thead>
                <tr style={{ background: 'var(--bg-tertiary)' }}>
                  <th style={{ padding: '12px 18px' }}>Timestamp</th>
                  <th style={{ padding: '12px 18px' }}>Actor</th>
                  <th style={{ padding: '12px 18px' }}>Role</th>
                  <th style={{ padding: '12px 18px' }}>Action</th>
                  <th style={{ padding: '12px 18px' }}>Target</th>
                  <th style={{ padding: '12px 18px' }}>Details / Metadata</th>
                </tr>
              </thead>
              <tbody>
                {auditLogs.map(log => (
                  <tr key={log.id} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                    <td style={{ padding: '12px 18px', fontFamily: 'var(--font-mono)', color: 'var(--text-muted)' }}>
                      {new Date(log.timestamp).toLocaleString()}
                    </td>
                    <td style={{ padding: '12px 18px', fontWeight: '600' }}>
                      {log.actor_name || log.actor_identifier || `User #${log.actor_id}`}
                    </td>
                    <td style={{ padding: '12px 18px' }}>
                      <span className="badge badge-active">{log.actor_role}</span>
                    </td>
                    <td style={{ padding: '12px 18px', fontWeight: '700', color: 'var(--text-primary)' }}>
                      {log.action}
                    </td>
                    <td style={{ padding: '12px 18px', color: 'var(--text-secondary)' }}>
                      {log.target_type} ({log.target_id})
                    </td>
                    <td style={{ padding: '12px 18px', fontFamily: 'var(--font-mono)', color: 'var(--text-muted)' }}>
                      {log.details || '-'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TEACHER DETAILED DOSSIER MODAL */}
      {selectedTeacherId && teacherDossier && (
        <div style={{
          position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh',
          background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(8px)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 9999
        }}>
          <div className="glass-panel" style={{ width: '820px', maxWidth: '95%', maxHeight: '88vh', padding: '30px', borderRadius: '24px', overflowY: 'auto' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
              <div>
                <h3 style={{ fontSize: '1.35rem', fontWeight: '800' }}>Faculty Dossier: {teacherDossier.teacher.name}</h3>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>ID: {teacherDossier.teacher.identifier} • {teacherDossier.teacher.email}</div>
              </div>
              <button onClick={() => setSelectedTeacherId(null)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}><X size={22} /></button>
            </div>

            {/* Dossier Tabs */}
            <div style={{ display: 'flex', gap: '8px', marginBottom: '20px', borderBottom: '1px solid var(--border-glass)', paddingBottom: '10px' }}>
              {['INFO', 'ASSIGNMENTS', 'TIMETABLE', 'LECTURES', 'QUIZZES'].map(tab => (
                <button
                  key={tab}
                  onClick={() => setTeacherDossierTab(tab)}
                  className={teacherDossierTab === tab ? 'btn-primary' : 'btn-secondary'}
                  style={{ padding: '7px 14px', fontSize: '0.8rem' }}
                >
                  {tab}
                </button>
              ))}
            </div>

            {teacherDossierTab === 'INFO' && editTeacherForm && (
              <form onSubmit={handleSaveTeacherEdit} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
                  <div>
                    <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>Full Name</label>
                    <input type="text" className="input-field" value={editTeacherForm.name} onChange={e => setEditTeacherForm({ ...editTeacherForm, name: e.target.value })} required />
                  </div>
                  <div>
                    <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>Login ID</label>
                    <input type="text" className="input-field" value={editTeacherForm.identifier} onChange={e => setEditTeacherForm({ ...editTeacherForm, identifier: e.target.value })} required />
                  </div>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
                  <div>
                    <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>Email</label>
                    <input type="email" className="input-field" value={editTeacherForm.email} onChange={e => setEditTeacherForm({ ...editTeacherForm, email: e.target.value })} required />
                  </div>
                  <div>
                    <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>Phone</label>
                    <input type="text" className="input-field" value={editTeacherForm.phone || ''} onChange={e => setEditTeacherForm({ ...editTeacherForm, phone: e.target.value })} />
                  </div>
                </div>
                <div>
                  <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>Change Password (Optional - Leave blank to keep current)</label>
                  <input type="password" className="input-field" placeholder="New Password (min 8 chars)" value={editTeacherForm.password} onChange={e => setEditTeacherForm({ ...editTeacherForm, password: e.target.value })} />
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '10px' }}>
                  <button type="submit" className="btn-primary">Save Changes</button>
                  <button type="button" onClick={() => handleDeleteTeacher(selectedTeacherId)} className="btn-secondary" style={{ color: 'var(--danger)' }}>
                    <Trash2 size={16} /> Delete Faculty Account
                  </button>
                </div>
              </form>
            )}

            {teacherDossierTab === 'ASSIGNMENTS' && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                <div>
                  <h4 style={{ fontSize: '0.95rem', fontWeight: '700', marginBottom: '10px' }}>Current Assigned Courses & Divisions</h4>
                  {(!teacherDossier.assignments || teacherDossier.assignments.length === 0) ? (
                    <div style={{ padding: '16px', background: 'var(--bg-tertiary)', borderRadius: '12px', color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                      No subjects are currently assigned to this faculty member. Use the form below to assign a course.
                    </div>
                  ) : (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                      {teacherDossier.assignments.map(a => (
                        <div key={a.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', background: 'var(--bg-tertiary)', borderRadius: '12px' }}>
                          <div>
                            <div style={{ fontWeight: '700', fontSize: '0.9rem' }}>
                              {a.subject_name} <span style={{ color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', fontSize: '0.8rem' }}>({a.subject_code})</span>
                            </div>
                            <div style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', marginTop: '2px' }}>
                              Division {a.division_name} {a.batch_name ? `• Batch ${a.batch_name}` : '• All Batches in Division'}
                              {a.subject_type ? ` • ${a.subject_type}` : ''}
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleRemoveTeacherAssignment(a.id)}
                            className="btn-secondary"
                            style={{ color: 'var(--danger)', padding: '6px 10px', fontSize: '0.75rem', display: 'flex', alignItems: 'center', gap: '6px' }}
                            title="Unassign Subject"
                          >
                            <Trash2 size={14} /> Remove
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Form to Assign New Subject */}
                <div style={{ padding: '18px', background: 'var(--bg-secondary)', borderRadius: '16px', border: '1px solid var(--border-glass)' }}>
                  <h5 style={{ fontSize: '0.9rem', fontWeight: '700', marginBottom: '12px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <Plus size={16} style={{ color: 'var(--accent-primary)' }} /> Assign Subject / Course to Teacher
                  </h5>
                  <form onSubmit={handleAssignSubjectToTeacher} style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                      <div>
                        <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>Subject *</label>
                        <select
                          className="input-field"
                          value={assignForm.subject_id}
                          onChange={e => setAssignForm({ ...assignForm, subject_id: e.target.value })}
                          required
                        >
                          <option value="">-- Select Subject --</option>
                          {structure.subjects.map(s => (
                            <option key={s.id} value={s.id}>{s.name} ({s.code}) - {s.type}</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>Division *</label>
                        <select
                          className="input-field"
                          value={assignForm.division_id}
                          onChange={e => setAssignForm({ ...assignForm, division_id: e.target.value, batch_id: '' })}
                          required
                        >
                          <option value="">-- Select Division --</option>
                          {structure.divisions.map(d => (
                            <option key={d.id} value={d.id}>Division {d.name}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: '12px', alignItems: 'flex-end' }}>
                      <div>
                        <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>Batch (Optional - For Practical/Lab)</label>
                        <select
                          className="input-field"
                          value={assignForm.batch_id}
                          onChange={e => setAssignForm({ ...assignForm, batch_id: e.target.value })}
                        >
                          <option value="">All Batches (Whole Division)</option>
                          {structure.batches
                            .filter(b => !assignForm.division_id || String(b.division_id) === String(assignForm.division_id))
                            .map(b => (
                              <option key={b.id} value={b.id}>Batch {b.name}</option>
                            ))}
                        </select>
                      </div>

                      <button type="submit" className="btn-primary" style={{ padding: '10px 20px', whiteSpace: 'nowrap' }}>
                        <Plus size={16} /> Assign Course
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}

            {teacherDossierTab === 'TIMETABLE' && (
              <div>
                <h4 style={{ fontSize: '0.95rem', fontWeight: '700', marginBottom: '10px' }}>Scheduled Lectures</h4>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  {teacherDossier.timetable.map(tt => (
                    <div key={tt.id} style={{ padding: '10px 14px', background: 'var(--bg-tertiary)', borderRadius: '10px' }}>
                      <strong>Day {tt.day_of_week} ({tt.start_time} - {tt.end_time})</strong>: {tt.subject_name} ({tt.session_type}) • Room {tt.room}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {teacherDossierTab === 'LECTURES' && (
              <div>
                <h4 style={{ fontSize: '0.95rem', fontWeight: '700', marginBottom: '10px' }}>Attendance Sessions Conducted</h4>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  {teacherDossier.sessions.map(s => (
                    <div key={s.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 14px', background: 'var(--bg-tertiary)', borderRadius: '10px' }}>
                      <div>
                        <strong>{s.session_date}</strong>: {s.subject_name} ({s.session_type}) • Room {s.room}
                      </div>
                      <div style={{ fontWeight: '700', color: 'var(--success)' }}>
                        {s.present_count} Present
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {teacherDossierTab === 'QUIZZES' && (
              <div>
                <h4 style={{ fontSize: '0.95rem', fontWeight: '700', marginBottom: '10px' }}>Quizzes Authored</h4>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  {teacherDossier.quizzes.map(q => (
                    <div key={q.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 14px', background: 'var(--bg-tertiary)', borderRadius: '10px' }}>
                      <div>
                        <strong>{q.title}</strong> ({q.subject_name}) • Code: <code>{q.access_code}</code>
                      </div>
                      <div>{q.attempts_count} Candidates</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* STUDENT DETAILED DOSSIER & MARKS OVERRIDE MODAL */}
      {selectedStudentId && studentDossier && (
        <div style={{
          position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh',
          background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(8px)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 9999
        }}>
          <div className="glass-panel" style={{ width: '850px', maxWidth: '95%', maxHeight: '88vh', padding: '30px', borderRadius: '24px', overflowY: 'auto' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
              <div>
                <h3 style={{ fontSize: '1.35rem', fontWeight: '800' }}>Student Academic Record: {studentDossier.student.name}</h3>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                  Enrollment: <strong>{studentDossier.student.enrollment_number}</strong> • Div {studentDossier.student.division_name}, Batch {studentDossier.student.batch_name}
                </div>
              </div>
              <button onClick={() => setSelectedStudentId(null)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}><X size={22} /></button>
            </div>

            {/* Student Edit Form */}
            <div style={{ padding: '20px', background: 'var(--bg-tertiary)', borderRadius: '16px', marginBottom: '24px' }}>
              <h4 style={{ fontSize: '1rem', fontWeight: '700', marginBottom: '12px' }}>Edit Student Identity & Profile</h4>
              {editStudentForm && (
                <form onSubmit={handleSaveStudentEdit} style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '10px' }}>
                    <div>
                      <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Full Name</label>
                      <input type="text" className="input-field" value={editStudentForm.name} onChange={e => setEditStudentForm({ ...editStudentForm, name: e.target.value })} required />
                    </div>
                    <div>
                      <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Enrollment No</label>
                      <input type="text" className="input-field" value={editStudentForm.enrollment_number} onChange={e => setEditStudentForm({ ...editStudentForm, enrollment_number: e.target.value })} required />
                    </div>
                    <div>
                      <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Email</label>
                      <input type="email" className="input-field" value={editStudentForm.email} onChange={e => setEditStudentForm({ ...editStudentForm, email: e.target.value })} required />
                    </div>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr 1fr 1fr', gap: '10px' }}>
                    <div>
                      <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Branch</label>
                      <input type="text" className="input-field" value={editStudentForm.branch || ''} onChange={e => setEditStudentForm({ ...editStudentForm, branch: e.target.value })} />
                    </div>
                    <div>
                      <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Semester</label>
                      <select className="input-field" value={editStudentForm.semester_id || '1'} onChange={e => setEditStudentForm({ ...editStudentForm, semester_id: e.target.value })}>
                        <option value="1">Semester 1</option>
                        <option value="2">Semester 2</option>
                        <option value="3">Semester 3</option>
                        <option value="4">Semester 4</option>
                        <option value="5">Semester 5</option>
                        <option value="6">Semester 6</option>
                        <option value="7">Semester 7</option>
                        <option value="8">Semester 8</option>
                      </select>
                    </div>
                    <div>
                      <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Division</label>
                      <select className="input-field" value={editStudentForm.division_id} onChange={e => setEditStudentForm({ ...editStudentForm, division_id: e.target.value, batch_id: '' })}>
                        {structure.divisions.map(d => <option key={d.id} value={d.id}>Div {d.name}</option>)}
                      </select>
                    </div>
                    <div>
                      <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Batch</label>
                      <select className="input-field" value={editStudentForm.batch_id} onChange={e => setEditStudentForm({ ...editStudentForm, batch_id: e.target.value })}>
                        {structure.batches.filter(b => String(b.division_id) === String(editStudentForm.division_id)).map(b => <option key={b.id} value={b.id}>Batch {b.name}</option>)}
                      </select>
                    </div>
                  </div>
                  <div>
                    <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Reset Password (Optional)</label>
                    <input type="password" className="input-field" placeholder="Enter new password" value={editStudentForm.password} onChange={e => setEditStudentForm({ ...editStudentForm, password: e.target.value })} />
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '6px' }}>
                    <button type="submit" className="btn-primary" style={{ padding: '8px 18px', fontSize: '0.85rem' }}>Save Changes</button>
                    <button type="button" onClick={() => handleDeleteStudent(selectedStudentId)} className="btn-secondary" style={{ color: 'var(--danger)', padding: '8px 14px', fontSize: '0.85rem' }}>
                      <Trash2 size={15} /> Delete Student
                    </button>
                  </div>
                </form>
              )}
            </div>

            {/* Exam Attempts & Editable Marks */}
            <div style={{ marginBottom: '24px' }}>
              <h4 style={{ fontSize: '1rem', fontWeight: '700', marginBottom: '10px' }}>Examination Performance & Marks Override</h4>
              {studentDossier.attempts.length === 0 ? (
                <div style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>No examinations attempted yet.</div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                  {studentDossier.attempts.map(att => (
                    <div key={att.id} style={{ padding: '12px 16px', background: 'var(--bg-secondary)', borderRadius: '12px', border: '1px solid var(--border-glass)' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <div>
                          <strong>{att.quiz_title}</strong> ({att.subject_name})
                          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                            Status: <span className="badge badge-active">{att.status}</span> • Percentage: {att.percentage}%
                          </div>
                        </div>

                        {editingAttemptId === att.id ? (
                          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                            <input
                              type="number"
                              className="input-field"
                              style={{ width: '90px', padding: '6px 8px' }}
                              value={overrideScoreInput}
                              onChange={e => setOverrideScoreInput(e.target.value)}
                              step="0.5"
                            />
                            <button onClick={() => handleOverrideMarks(att.id)} className="btn-primary" style={{ padding: '6px 12px', fontSize: '0.75rem' }}>
                              Save
                            </button>
                            <button onClick={() => setEditingAttemptId(null)} className="btn-secondary" style={{ padding: '6px 10px', fontSize: '0.75rem' }}>
                              Cancel
                            </button>
                          </div>
                        ) : (
                          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                            <div style={{ fontSize: '1.1rem', fontWeight: '800', color: 'var(--accent-primary)' }}>
                              {att.total_score} / {att.max_marks}
                            </div>
                            <button
                              onClick={() => { setEditingAttemptId(att.id); setOverrideScoreInput(String(att.total_score)); }}
                              className="btn-secondary"
                              style={{ padding: '6px 10px', fontSize: '0.75rem' }}
                            >
                              <Edit size={14} /> Edit Marks
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Attendance Metrics */}
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
                <h4 style={{ fontSize: '1rem', fontWeight: '700' }}>Attendance Metrics (Source of Truth)</h4>
                <div style={{ display: 'flex', gap: '8px' }}>
                  <a href={`/api/reports/attendance?student_id=${selectedStudentId}&format=pdf&token=${token}`} download className="btn-secondary" style={{ padding: '6px 12px', fontSize: '0.75rem', textDecoration: 'none' }}>
                    <FileDown size={14} /> Download PDF Transcript
                  </a>
                </div>
              </div>

              {studentDossier.attendance && (
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px' }}>
                  <div style={{ padding: '14px', background: 'var(--bg-tertiary)', borderRadius: '12px' }}>
                    <div style={{ fontSize: '0.725rem', color: 'var(--text-muted)' }}>Theory</div>
                    <div style={{ fontSize: '1.4rem', fontWeight: '800' }}>{studentDossier.attendance.summary.theory.percentage}%</div>
                    <div style={{ fontSize: '0.725rem', color: 'var(--text-muted)' }}>
                      {studentDossier.attendance.summary.theory.present}/{studentDossier.attendance.summary.theory.total} Present
                    </div>
                  </div>
                  <div style={{ padding: '14px', background: 'var(--bg-tertiary)', borderRadius: '12px' }}>
                    <div style={{ fontSize: '0.725rem', color: 'var(--text-muted)' }}>Practical</div>
                    <div style={{ fontSize: '1.4rem', fontWeight: '800' }}>{studentDossier.attendance.summary.practical.percentage}%</div>
                    <div style={{ fontSize: '0.725rem', color: 'var(--text-muted)' }}>
                      {studentDossier.attendance.summary.practical.present}/{studentDossier.attendance.summary.practical.total} Present
                    </div>
                  </div>
                  <div style={{ padding: '14px', background: 'var(--bg-tertiary)', borderRadius: '12px' }}>
                    <div style={{ fontSize: '0.725rem', color: 'var(--text-muted)' }}>Overall Cumulative</div>
                    <div style={{ fontSize: '1.4rem', fontWeight: '800', color: studentDossier.attendance.summary.overall.percentage >= 75 ? 'var(--success)' : 'var(--danger)' }}>
                      {studentDossier.attendance.summary.overall.percentage}%
                    </div>
                    <div style={{ fontSize: '0.725rem', color: 'var(--text-muted)' }}>
                      {studentDossier.attendance.summary.overall.present}/{studentDossier.attendance.summary.overall.total} Present
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* CREATE TEACHER MODAL */}
      {isAddTeacherOpen && (
        <div style={{
          position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh',
          background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(8px)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 9999
        }}>
          <div className="glass-panel" style={{ width: '460px', padding: '28px', borderRadius: '20px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <h3 style={{ fontSize: '1.2rem', fontWeight: '700' }}>Add Faculty Member</h3>
              <button onClick={() => setIsAddTeacherOpen(false)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}><X size={20} /></button>
            </div>
            <form onSubmit={handleCreateTeacher} style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <input type="text" className="input-field" placeholder="Identifier (e.g. prof.gupta)" value={teacherForm.identifier} onChange={e => setTeacherForm({ ...teacherForm, identifier: e.target.value })} required />
              <input type="text" className="input-field" placeholder="Full Name (e.g. Prof. Arvind Gupta)" value={teacherForm.name} onChange={e => setTeacherForm({ ...teacherForm, name: e.target.value })} required />
              <input type="email" className="input-field" placeholder="Email (gupta@learnique.edu)" value={teacherForm.email} onChange={e => setTeacherForm({ ...teacherForm, email: e.target.value })} required />
              <input type="text" className="input-field" placeholder="Phone (+91 98765 00000)" value={teacherForm.phone} onChange={e => setTeacherForm({ ...teacherForm, phone: e.target.value })} />
              <input type="password" className="input-field" placeholder="Initial Password" value={teacherForm.password} onChange={e => setTeacherForm({ ...teacherForm, password: e.target.value })} required />
              <button type="submit" className="btn-primary" style={{ marginTop: '8px' }}>Create Faculty Profile</button>
            </form>
          </div>
        </div>
      )}

      {/* CREATE STUDENT MODAL */}
      {isAddStudentOpen && (
        <div style={{
          position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh',
          background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(8px)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 9999
        }}>
          <div className="glass-panel" style={{ width: '480px', padding: '28px', borderRadius: '20px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <h3 style={{ fontSize: '1.2rem', fontWeight: '700' }}>Enroll Student</h3>
              <button onClick={() => setIsAddStudentOpen(false)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}><X size={20} /></button>
            </div>
            <form onSubmit={handleCreateStudent} style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <input type="text" className="input-field" placeholder="Enrollment Number (e.g. 2026CSE099)" value={studentForm.enrollment_number} onChange={e => setStudentForm({ ...studentForm, enrollment_number: e.target.value })} required />
              <input type="text" className="input-field" placeholder="Full Name" value={studentForm.name} onChange={e => setStudentForm({ ...studentForm, name: e.target.value })} required />
              <input type="email" className="input-field" placeholder="Email" value={studentForm.email} onChange={e => setStudentForm({ ...studentForm, email: e.target.value })} required />
              <input type="text" className="input-field" placeholder="Branch (e.g. Computer Science)" value={studentForm.branch} onChange={e => setStudentForm({ ...studentForm, branch: e.target.value })} required />
              <input type="password" className="input-field" placeholder="Initial Password" value={studentForm.password} onChange={e => setStudentForm({ ...studentForm, password: e.target.value })} required />
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '10px' }}>
                <div>
                  <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Semester *</label>
                  <select className="input-field" value={studentForm.semester_id} onChange={e => setStudentForm({ ...studentForm, semester_id: e.target.value })} required>
                    <option value="1">Semester 1</option>
                    <option value="2">Semester 2</option>
                    <option value="3">Semester 3</option>
                    <option value="4">Semester 4</option>
                    <option value="5">Semester 5</option>
                    <option value="6">Semester 6</option>
                    <option value="7">Semester 7</option>
                    <option value="8">Semester 8</option>
                  </select>
                </div>
                <div>
                  <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Division *</label>
                  <select className="input-field" value={studentForm.division_id} onChange={e => setStudentForm({ ...studentForm, division_id: e.target.value, batch_id: '' })} required>
                    <option value="">-- Div --</option>
                    {structure.divisions.map(d => <option key={d.id} value={d.id}>Div {d.name}</option>)}
                  </select>
                </div>
                <div>
                  <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Batch *</label>
                  <select className="input-field" value={studentForm.batch_id} onChange={e => setStudentForm({ ...studentForm, batch_id: e.target.value })} required>
                    <option value="">-- Batch --</option>
                    {structure.batches
                      .filter(b => !studentForm.division_id || String(b.division_id) === String(studentForm.division_id))
                      .map(b => <option key={b.id} value={b.id}>Batch {b.name}</option>)}
                  </select>
                </div>
              </div>
              <button type="submit" className="btn-primary" style={{ marginTop: '8px' }}>Enroll Student</button>
            </form>
          </div>
        </div>
      )}

      {/* CREATE TIMETABLE MODAL */}
      {isAddTimetableOpen && (
        <div style={{
          position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh',
          background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(8px)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 9999
        }}>
          <div className="glass-panel" style={{ width: '500px', padding: '28px', borderRadius: '20px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <h3 style={{ fontSize: '1.2rem', fontWeight: '700' }}>Add Timetable Schedule</h3>
              <button onClick={() => setIsAddTimetableOpen(false)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}><X size={20} /></button>
            </div>
            <form onSubmit={handleCreateTimetable} style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                <div>
                  <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Day of Week</label>
                  <select className="input-field" value={ttForm.day_of_week} onChange={e => setTtForm({ ...ttForm, day_of_week: e.target.value })}>
                    <option value="1">Monday</option>
                    <option value="2">Tuesday</option>
                    <option value="3">Wednesday</option>
                    <option value="4">Thursday</option>
                    <option value="5">Friday</option>
                  </select>
                </div>
                <div>
                  <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Session Type</label>
                  <select className="input-field" value={ttForm.session_type} onChange={e => setTtForm({ ...ttForm, session_type: e.target.value })}>
                    <option value="THEORY">Theory</option>
                    <option value="PRACTICAL">Practical</option>
                  </select>
                </div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                <div>
                  <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Start Time</label>
                  <input type="text" className="input-field" value={ttForm.start_time} onChange={e => setTtForm({ ...ttForm, start_time: e.target.value })} placeholder="10:00" required />
                </div>
                <div>
                  <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>End Time</label>
                  <input type="text" className="input-field" value={ttForm.end_time} onChange={e => setTtForm({ ...ttForm, end_time: e.target.value })} placeholder="10:50" required />
                </div>
              </div>
              <div>
                <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Subject</label>
                <select
                  className="input-field"
                  value={ttForm.subject_id}
                  onChange={e => {
                    const sId = e.target.value;
                    const foundSub = structure.subjects.find(s => String(s.id) === String(sId));
                    setTtForm({
                      ...ttForm,
                      subject_id: sId,
                      session_type: foundSub && foundSub.type !== 'BOTH' ? foundSub.type : ttForm.session_type
                    });
                  }}
                  required
                >
                  <option value="">-- Choose Subject --</option>
                  {structure.subjects.map(s => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.code}) {s.branch ? `• ${s.branch}` : ''} - Sem {s.semester_number || s.semester_id}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Faculty</label>
                <select className="input-field" value={ttForm.teacher_id} onChange={e => setTtForm({ ...ttForm, teacher_id: e.target.value })} required>
                  <option value="">-- Choose Faculty --</option>
                  {teachers.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                </select>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                <div>
                  <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Division</label>
                  <select className="input-field" value={ttForm.division_id} onChange={e => setTtForm({ ...ttForm, division_id: e.target.value, batch_id: '' })} required>
                    <option value="">-- Div --</option>
                    {structure.divisions.map(d => <option key={d.id} value={d.id}>Div {d.name}</option>)}
                  </select>
                </div>
                <div>
                  <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Batch</label>
                  <select className="input-field" value={ttForm.batch_id} onChange={e => setTtForm({ ...ttForm, batch_id: e.target.value })}>
                    <option value="">All Batches</option>
                    {structure.batches.filter(b => !ttForm.division_id || String(b.division_id) === String(ttForm.division_id)).map(b => <option key={b.id} value={b.id}>Batch {b.name}</option>)}
                  </select>
                </div>
              </div>
              <div>
                <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Room Number</label>
                <input type="text" className="input-field" value={ttForm.room} onChange={e => setTtForm({ ...ttForm, room: e.target.value })} placeholder="EA-511" required />
              </div>
              <button type="submit" className="btn-primary" style={{ marginTop: '8px' }}>Create Timetable Schedule</button>
            </form>
          </div>
        </div>
      )}

      {/* QUIZ CREATOR MODAL */}
      <QuizCreatorModal
        isOpen={isQuizModalOpen}
        initialSubjectId={quizModalSubjectId}
        onClose={() => {
          setIsQuizModalOpen(false);
          setQuizModalSubjectId('');
        }}
        onCreated={() => loadAllAdminData()}
        subjects={structure.subjects}
        divisions={structure.divisions}
        batches={structure.batches}
      />
    </div>
  );
}
