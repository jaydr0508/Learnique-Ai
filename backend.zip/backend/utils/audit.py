import json
from datetime import datetime
from typing import Optional, Any
from backend.database.db import execute_query

def log_audit(
    action: str,
    target_type: str,
    target_id: Optional[str] = None,
    actor_user_id: Optional[int] = None,
    actor_name: Optional[str] = None,
    details: Optional[dict[str, Any]] = None,
    ip_address: Optional[str] = None
):
    """Record a sensitive administrative or academic action to the audit logs."""
    try:
        details_json = json.dumps(details) if details else None
        execute_query(
            """
            INSERT INTO audit_logs (actor_user_id, actor_name, action, target_type, target_id, details_json, ip_address, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                actor_user_id,
                actor_name or "System",
                action,
                target_type,
                str(target_id) if target_id is not None else None,
                details_json,
                ip_address or "127.0.0.1",
                datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            )
        )
    except Exception as e:
        # Audit logging failure should not crash the main transaction, but log to stderr
        print(f"[AUDIT LOG ERROR] Failed to log audit: {e}")
