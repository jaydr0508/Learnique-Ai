import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  Calendar,
  Clock,
  QrCode,
  Award,
  CheckCircle,
  AlertCircle,
  FileDown,
  Sparkles,
  Camera,
  ChevronDown,
  ChevronRight,
  BookOpen,
  Send,
  Eye,
  KeyRound,
  FileText,
  User,
  Paperclip,
  Copy,
  Check,
  RotateCcw,
  X,
  Image as ImageIcon,
  Download,
  Loader2,
  Presentation,
  ThumbsUp,
  ThumbsDown,
  Lightbulb,
  Compass,
  Code,
  GraduationCap,
  Plus
} from 'lucide-react';
import { Html5QrcodeScanner } from 'html5-qrcode';
import LiveQuizTakingView from './LiveQuizTakingView';
import { useNotification } from '../context/NotificationContext';
import { formatAIResponse } from '../utils/textUtils';

export default function StudentDashboard({ activeTab }) {
  const { token, user } = useAuth();
  const { notify } = useNotification();

  const [loading, setLoading] = useState(true);
  const [dashboardData, setDashboardData] = useState(null);
  const [attendanceStats, setAttendanceStats] = useState(null);

  // Active Live Quiz Attempting State
  const [activeQuizData, setActiveQuizData] = useState(null);

  // Scanner & Code Entry State
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [selectedSessionForAttendance, setSelectedSessionForAttendance] = useState(null);
  const [manualBackupCode, setManualBackupCode] = useState('');
  const [standaloneCode, setStandaloneCode] = useState('');
  const [modalTab, setModalTab] = useState('CODE');
  const [scanMessage, setScanMessage] = useState(null);
  const [scanLoading, setScanLoading] = useState(false);

  // Join Quiz State
  const [quizAccessCode, setQuizAccessCode] = useState('');
  const [joinError, setJoinError] = useState('');
  const [joinLoading, setJoinLoading] = useState(false);

  // Subject Table Accordion
  const [expandedSubject, setExpandedSubject] = useState(null);

  // Results Review State
  const [selectedResult, setSelectedResult] = useState(null);
  const [resultLoading, setResultLoading] = useState(false);

  // Student Profile, Timetable & Results State
  const [profileData, setProfileData] = useState(null);
  const [weeklyTimetable, setWeeklyTimetable] = useState([]);
  const [pastResults, setPastResults] = useState([]);
  const [selectedTimetableDay, setSelectedTimetableDay] = useState(() => {
    const d = new Date().getDay();
    return (d >= 1 && d <= 5) ? d : 1;
  });

  // AI Doubt Solver State
  const [doubtText, setDoubtText] = useState('');
  const [doubtSubject, setDoubtSubject] = useState('General Academic');
  const [doubtTopic, setDoubtTopic] = useState('');
  const [doubtThreadId, setDoubtThreadId] = useState(null);
  const [doubtMessages, setDoubtMessages] = useState([]);
  const [doubtLoading, setDoubtLoading] = useState(false);
  const [doubtAttachment, setDoubtAttachment] = useState(null);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [copiedIndex, setCopiedIndex] = useState(null);
  const [doubtFeedback, setDoubtFeedback] = useState({});
  const doubtFileInputRef = useRef(null);
  const doubtChatEndRef = useRef(null);

  useEffect(() => {
    loadStudentData();
  }, [token]);

  // Restore AI Doubt history when tab becomes active
  useEffect(() => {
    if (activeTab === 'ai_doubt' && doubtMessages.length === 0 && token) {
      fetch('/api/student/ai/history', {
        headers: { Authorization: `Bearer ${token}` }
      })
      .then(res => res.json())
      .then(data => {
        if (data.messages && data.messages.length > 0) {
          setDoubtMessages(data.messages);
          if (data.thread) {
            setDoubtThreadId(data.thread.id);
            if (data.thread.subject) setDoubtSubject(data.thread.subject);
            if (data.thread.topic) setDoubtTopic(data.thread.topic);
          }
        }
      })
      .catch(() => {});
    }
  }, [activeTab, token]);

  // Auto-scroll doubt chat to bottom
  useEffect(() => {
    if (activeTab === 'ai_doubt') {
      doubtChatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [doubtMessages, doubtLoading, activeTab]);

  async function loadStudentData() {
    setLoading(true);
    try {
      const res = await fetch('/api/student/dashboard', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      setDashboardData(data);

      const attRes = await fetch('/api/student/attendance', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const attData = await attRes.json();
      setAttendanceStats(attData);

      // Load Profile
      fetch('/api/student/profile', { headers: { Authorization: `Bearer ${token}` } })
        .then(r => r.json())
        .then(d => { if (d.profile) setProfileData(d.profile); })
        .catch(() => {});

      // Load Weekly Timetable
      fetch('/api/student/timetable', { headers: { Authorization: `Bearer ${token}` } })
        .then(r => r.json())
        .then(d => { if (d.timetable) setWeeklyTimetable(d.timetable); })
        .catch(() => {});

      // Load Quiz Results
      fetch('/api/student/results', { headers: { Authorization: `Bearer ${token}` } })
        .then(r => r.json())
        .then(d => { if (d.results) setPastResults(d.results); })
        .catch(() => {});
    } catch (e) {
      console.error('Failed to load student dashboard', e);
    } finally {
      setLoading(false);
    }
  }

  // Camera QR Scanner Hook
  useEffect(() => {
    let scanner = null;
    if (isScannerOpen && selectedSessionForAttendance) {
      scanner = new Html5QrcodeScanner('qr-reader-container', {
        fps: 10,
        qrbox: { width: 250, height: 250 }
      }, false);

      scanner.render((decodedText) => {
        let cleanToken = decodedText.trim();
        if (cleanToken.includes('/attendance/join/')) {
          cleanToken = cleanToken.split('/attendance/join/')[1].split('?')[0].split('#')[0];
        } else if (cleanToken.includes('/join/attendance/')) {
          cleanToken = cleanToken.split('/join/attendance/')[1].split('?')[0].split('#')[0];
        }

        try {
          const parsed = JSON.parse(decodedText);
          if (parsed.sessionId && parsed.token) {
            handleMarkAttendance({ sessionId: parsed.sessionId, token: parsed.token });
            try { scanner.clear(); } catch (e) {}
            return;
          }
        } catch (e) {}

        handleMarkAttendance({ sessionId: selectedSessionForAttendance.id, token: cleanToken });
        try { scanner.clear(); } catch (e) {}
      }, (err) => {
        // scan progress error, ignore
      });
    }

    return () => {
      if (scanner) {
        try { scanner.clear(); } catch (e) {}
      }
    };
  }, [isScannerOpen, selectedSessionForAttendance]);

  async function handleMarkAttendance({ sessionId, token: rawToken, backupCode }) {
    setScanLoading(true);
    setScanMessage(null);

    try {
      const res = await fetch('/api/attendance/mark', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          sessionId,
          token: rawToken,
          backupCode: backupCode ? backupCode.trim().toUpperCase() : undefined
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Attendance validation failed');

      setScanMessage({
        success: true,
        message: `✓ ATTENDANCE MARKED: ${data.subjectName} (${data.sessionType}) - Status: PRESENT`
      });
      loadStudentData();
      setTimeout(() => {
        setIsScannerOpen(false);
        setManualBackupCode('');
      }, 2500);
    } catch (err) {
      setScanMessage({
        success: false,
        message: err.message
      });
    } finally {
      setScanLoading(false);
    }
  }

  async function handleJoinQuiz(e) {
    e.preventDefault();
    if (!quizAccessCode.trim()) return;

    setJoinError('');
    setJoinLoading(true);

    try {
      const res = await fetch('/api/quizzes/join', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ access_code: quizAccessCode.trim() })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to enter examination');

      setActiveQuizData(data);
    } catch (err) {
      setJoinError(err.message);
    } finally {
      setJoinLoading(false);
    }
  }

  async function loadQuizResult(quizId) {
    setResultLoading(true);
    try {
      const res = await fetch(`/api/quizzes/${quizId}/results`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      setSelectedResult(data);
    } catch (e) {
      notify('Failed to load result', 'error');
    } finally {
      setResultLoading(false);
    }
  }

  const handleAttachmentChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 25 * 1024 * 1024) {
      notify('File size exceeds 25MB limit', 'warning');
      return;
    }

    const isImg = file.type.startsWith('image/');
    const nameLower = file.name.toLowerCase();
    let fileCategory = 'document';
    if (isImg) fileCategory = 'image';
    else if (nameLower.endsWith('.pdf')) fileCategory = 'pdf';
    else if (nameLower.endsWith('.ppt') || nameLower.endsWith('.pptx')) fileCategory = 'presentation';
    else if (nameLower.endsWith('.doc') || nameLower.endsWith('.docx')) fileCategory = 'word';
    else if (nameLower.match(/\.(py|java|c|cpp|js|json|sql|html|css|ts)$/)) fileCategory = 'code';

    const reader = new FileReader();
    reader.onload = () => {
      setDoubtAttachment({
        name: file.name,
        type: file.type || 'application/octet-stream',
        size: file.size < 1024 * 1024 ? (file.size / 1024).toFixed(1) + ' KB' : (file.size / (1024 * 1024)).toFixed(2) + ' MB',
        data: reader.result,
        previewUrl: isImg ? reader.result : null,
        isImage: isImg,
        category: fileCategory
      });
      notify(`Attached: ${file.name} (${fileCategory.toUpperCase()})`, 'info');
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  async function handleSendDoubt(e, forceCreatePdf = false, promptOverride = null) {
    if (e && e.preventDefault) e.preventDefault();
    const activeText = promptOverride || doubtText;
    if (!activeText.trim() && !doubtAttachment) return;

    const userText = activeText.trim() || (doubtAttachment ? `Please analyze and explain the key concepts in attached ${doubtAttachment.name}.` : '');
    const currentAttachment = doubtAttachment;
    const currentTopic = doubtTopic.trim() || 'Core Academic Concept';

    if (!promptOverride) setDoubtText('');
    setDoubtAttachment(null);

    const userMsgObj = {
      sender: 'USER',
      content: userText,
      topic: currentTopic,
      attachment: currentAttachment ? {
        name: currentAttachment.name,
        type: currentAttachment.type,
        previewUrl: currentAttachment.previewUrl,
        size: currentAttachment.size,
        isImage: currentAttachment.isImage,
        category: currentAttachment.category
      } : null
    };

    setDoubtMessages(prev => [...prev, userMsgObj]);
    setDoubtLoading(true);

    try {
      const res = await fetch('/api/student/ai/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          threadId: doubtThreadId,
          message: forceCreatePdf ? `${userText}\n(Please format this explanation systematically as structured study notes to be downloaded as a PDF document.)` : userText,
          subject: doubtSubject,
          topic: currentTopic,
          history: doubtMessages.map(m => ({ sender: m.sender, content: m.content })),
          attachment: currentAttachment ? {
            name: currentAttachment.name,
            type: currentAttachment.type,
            data: currentAttachment.data
          } : null,
          createPdf: forceCreatePdf
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Doubt solver failed');

      setDoubtThreadId(data.threadId);
      setDoubtMessages(prev => [...prev, {
        sender: 'AI',
        content: data.response,
        canCreatePdf: true,
        topic: currentTopic,
        subject: doubtSubject
      }]);

      if (forceCreatePdf) {
        handleDownloadPdf(data.response, doubtSubject, currentTopic || userText);
      }
    } catch (err) {
      notify('Doubt solver failed: ' + err.message, 'error');
    } finally {
      setDoubtLoading(false);
    }
  }

  async function handleDownloadPdf(content, subject = doubtSubject, title = '') {
    try {
      setIsGeneratingPdf(true);
      notify('Generating PDF study notes document...', 'info');

      const res = await fetch('/api/student/ai/pdf', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          title: title ? `Study Notes: ${title.slice(0, 45)}` : `Academic Doubt Notes - ${subject}`,
          subject: subject,
          topic: 'Curriculum Study Sheet',
          content: content,
          student_name: user?.name || profileData?.name || 'Learnique AI Student'
        })
      });

      if (!res.ok) throw new Error('Server PDF generation failed');

      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      const safeSubject = (subject || 'academic').replace(/[^a-zA-Z0-9]/g, '_');
      a.download = `Learnique_AI_Notes_${safeSubject}.pdf`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
      notify('PDF study notes downloaded successfully!', 'success');
    } catch (err) {
      try {
        const printWin = window.open('', '', 'height=750,width=850');
        printWin.document.write(`
          <html>
            <head>
              <title>Learnique AI Study Notes - ${subject}</title>
              <style>
                body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; padding: 40px; color: #1e293b; line-height: 1.6; }
                .header { border-bottom: 2px solid #4f46e5; padding-bottom: 15px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; }
                .brand { font-size: 22px; font-weight: 800; color: #4f46e5; }
                .meta { background: #f1f5f9; padding: 10px 14px; border-radius: 8px; margin-bottom: 20px; font-size: 13px; }
                .content { font-size: 14px; white-space: pre-wrap; line-height: 1.6; }
                .footer { margin-top: 30px; border-top: 1px dashed #cbd5e1; padding-top: 12px; font-size: 11px; color: #64748b; text-align: center; }
              </style>
            </head>
            <body>
              <div class="header">
                <div>
                  <div class="brand">LEARNIQUE AI ACADEMIC PLATFORM</div>
                  <div style="font-size: 12px; color: #64748b;">AI Academic Tutor • Study Notes & Doubt Resolution</div>
                </div>
                <div style="text-align: right; font-size: 12px; color: #64748b;">
                  <div>Student: <b>${user?.name || 'Student'}</b></div>
                  <div>Date: ${new Date().toLocaleDateString()}</div>
                </div>
              </div>
              <div class="meta">
                <b>Subject:</b> ${subject} &nbsp;|&nbsp; <b>Topic:</b> ${title || 'Academic Concept Notes'}
              </div>
              <div class="content">${content.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</div>
              <div class="footer">Generated by Learnique AI Doubt Solver • For Academic Review and Study</div>
            </body>
          </html>
        `);
        printWin.document.close();
        printWin.focus();
        setTimeout(() => {
          printWin.print();
          printWin.close();
        }, 350);
        notify('Opened printable PDF window', 'info');
      } catch (clientErr) {
        notify('Failed to generate PDF: ' + err.message, 'error');
      }
    } finally {
      setIsGeneratingPdf(false);
    }
  }

  async function handleClearDoubtChat() {
    setDoubtMessages([]);
    setDoubtThreadId(null);
    setDoubtAttachment(null);
    try {
      await fetch('/api/student/ai/clear', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      notify('Conversation cleared. Started a fresh doubt session.', 'info');
    } catch (e) {}
  }

  function handleDownloadFullSessionPdf() {
    if (doubtMessages.length === 0) {
      notify('No messages in current doubt session to export', 'warning');
      return;
    }
    const fullText = doubtMessages.map(m => {
      const sender = m.sender === 'USER' ? `STUDENT (${user?.name || 'Student'})` : 'LEARNIQUE AI ACADEMIC TUTOR';
      return `${sender}:\n${m.content}\n----------------------------------------\n`;
    }).join('\n\n');

    handleDownloadPdf(fullText, doubtSubject, `Full Doubt Session - ${doubtSubject}`);
  }

  const handleFeedback = (idx, type) => {
    setDoubtFeedback(prev => ({
      ...prev,
      [idx]: prev[idx] === type ? null : type
    }));
    notify(type === 'up' ? 'Helpful explanation feedback recorded' : 'Feedback noted for future improvements', 'info');
  };

  // If student is actively taking a live quiz, show distraction-free test screen
  if (activeQuizData) {
    return (
      <LiveQuizTakingView
        quizData={activeQuizData}
        onFinished={() => {
          setActiveQuizData(null);
          loadStudentData();
        }}
      />
    );
  }

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '60px', color: 'var(--text-muted)' }}>
        Loading Student Academic Workspace...
      </div>
    );
  }

  const summary = attendanceStats?.summary;

  return (
    <div style={{ padding: '0 24px 40px 24px', maxWidth: '1240px', margin: '0 auto' }}>
      {/* ATTENDANCE SUMMARY STATS CARDS (Separating Theory & Practical strictly from raw counts) */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '18px', marginBottom: '28px' }}>
        <div className="glass-panel" style={{ padding: '22px', borderRadius: '18px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
            <span style={{ fontSize: '0.8rem', fontWeight: '600', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
              Theory Attendance
            </span>
            <span className="badge badge-active">Classroom</span>
          </div>
          <div style={{ fontSize: '2.2rem', fontWeight: '800', color: 'var(--accent-primary)', marginBottom: '6px' }}>
            {summary?.theory?.percentage ?? 0}%
          </div>
          <div style={{ fontSize: '0.825rem', color: 'var(--text-muted)' }}>
            Present: <strong>{summary?.theory?.present ?? 0}</strong> / Total: <strong>{summary?.theory?.total ?? 0}</strong> (Absent: {summary?.theory?.absent ?? 0})
          </div>
        </div>

        <div className="glass-panel" style={{ padding: '22px', borderRadius: '18px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
            <span style={{ fontSize: '0.8rem', fontWeight: '600', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
              Practical Attendance
            </span>
            <span className="badge" style={{ background: 'rgba(6, 182, 212, 0.15)', color: '#06b6d4' }}>Laboratory</span>
          </div>
          <div style={{ fontSize: '2.2rem', fontWeight: '800', color: '#06b6d4', marginBottom: '6px' }}>
            {summary?.practical?.percentage ?? 0}%
          </div>
          <div style={{ fontSize: '0.825rem', color: 'var(--text-muted)' }}>
            Present: <strong>{summary?.practical?.present ?? 0}</strong> / Total: <strong>{summary?.practical?.total ?? 0}</strong> (Absent: {summary?.practical?.absent ?? 0})
          </div>
        </div>

        <div className="glass-panel" style={{ padding: '22px', borderRadius: '18px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
            <span style={{ fontSize: '0.8rem', fontWeight: '600', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
              Overall Cumulative
            </span>
            <span className={`badge ${(summary?.overall?.percentage ?? 0) >= 75 ? 'badge-present' : 'badge-absent'}`}>
              {(summary?.overall?.percentage ?? 0) >= 75 ? 'Eligible' : 'Low Attendance'}
            </span>
          </div>
          <div style={{
            fontSize: '2.2rem',
            fontWeight: '800',
            color: (summary?.overall?.percentage ?? 0) >= 75 ? 'var(--success)' : 'var(--danger)',
            marginBottom: '6px'
          }}>
            {summary?.overall?.percentage ?? 0}%
          </div>
          <div style={{ fontSize: '0.825rem', color: 'var(--text-muted)' }}>
            Present: <strong>{summary?.overall?.present ?? 0}</strong> / Total: <strong>{summary?.overall?.total ?? 0}</strong> (Raw counts calculation)
          </div>
        </div>
      </div>

      {/* VIEW: SCAN ATTENDANCE / ACTIVE SESSIONS */}
      {(activeTab === 'dashboard' || activeTab === 'mark_attendance') && (
        <div style={{ marginBottom: '32px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
            <div>
              <h3 style={{ fontSize: '1.25rem', fontWeight: '700' }}>Active Classroom Attendance</h3>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.825rem' }}>
                Scan the dynamic rotating QR code or enter the active backup code displayed by your faculty
              </p>
            </div>
          </div>

          {/* Quick Attendance Code Entry */}
          <div className="glass-panel" style={{
            padding: '20px 24px',
            borderRadius: '20px',
            marginBottom: '20px',
            display: 'flex',
            flexWrap: 'wrap',
            justifyContent: 'space-between',
            alignItems: 'center',
            gap: '16px',
            border: '2px solid rgba(99, 102, 241, 0.25)',
            background: 'linear-gradient(135deg, rgba(99, 102, 241, 0.08), rgba(168, 85, 247, 0.05))'
          }}>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
                <KeyRound size={20} style={{ color: 'var(--accent-primary)' }} />
                <h4 style={{ fontSize: '1.05rem', fontWeight: '800' }}>Enter Lecture Attendance Code</h4>
              </div>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.825rem', margin: 0 }}>
                Type the 6-character backup code displayed on your faculty screen to mark attendance instantly.
              </p>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (standaloneCode.trim()) {
                  handleMarkAttendance({ backupCode: standaloneCode.trim() });
                }
              }}
              style={{ display: 'flex', gap: '10px', alignItems: 'center' }}
            >
              <input
                type="text"
                className="input-field"
                placeholder="e.g. 7X9K2M"
                maxLength={8}
                value={standaloneCode}
                onChange={e => setStandaloneCode(e.target.value.toUpperCase())}
                style={{
                  width: '160px',
                  fontFamily: 'var(--font-mono)',
                  fontSize: '1.2rem',
                  letterSpacing: '0.12em',
                  textTransform: 'uppercase',
                  fontWeight: '800',
                  textAlign: 'center'
                }}
                required
              />
              <button
                type="submit"
                className="btn-primary"
                disabled={scanLoading || !standaloneCode.trim()}
                style={{ padding: '11px 22px', whiteSpace: 'nowrap' }}
              >
                {scanLoading ? 'Verifying...' : 'Mark Present'}
              </button>
            </form>
          </div>

          {scanMessage && !isScannerOpen && (
            <div style={{
              background: scanMessage.success ? 'rgba(16, 185, 129, 0.15)' : 'rgba(239, 68, 68, 0.15)',
              color: scanMessage.success ? '#10b981' : '#ef4444',
              padding: '14px 18px',
              borderRadius: '12px',
              marginBottom: '20px',
              fontSize: '0.9rem',
              fontWeight: '700',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              border: scanMessage.success ? '1px solid rgba(16, 185, 129, 0.3)' : '1px solid rgba(239, 68, 68, 0.3)'
            }}>
              <span>{scanMessage.message}</span>
              <button onClick={() => setScanMessage(null)} style={{ background: 'none', border: 'none', color: 'inherit', cursor: 'pointer', fontSize: '1.2rem' }}>×</button>
            </div>
          )}

          {dashboardData?.activeSessions?.length === 0 ? (
            <div className="glass-panel" style={{ padding: '32px', textAlign: 'center', color: 'var(--text-muted)' }}>
              No active attendance sessions right now. Sessions appear when your instructor starts QR attendance.
            </div>
          ) : (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(360px, 1fr))', gap: '16px' }}>
              {dashboardData?.activeSessions?.map(sess => (
                <div key={sess.id} className="glass-panel" style={{ padding: '22px', borderRadius: '18px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '12px' }}>
                    <div>
                      <span className="badge badge-active">{sess.session_type}</span>
                      <h4 style={{ fontSize: '1.1rem', fontWeight: '700', marginTop: '6px' }}>{sess.subject_name}</h4>
                      <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>
                        {sess.subject_code} • Faculty: {sess.teacher_name}
                      </div>
                    </div>
                    <div style={{ padding: '6px 12px', background: 'var(--bg-tertiary)', borderRadius: '8px', fontSize: '0.8rem', fontWeight: '600' }}>
                      Room {sess.room}
                    </div>
                  </div>

                  {sess.student_marked_status === 'PRESENT' ? (
                    <div style={{
                      padding: '12px',
                      background: 'rgba(16, 185, 129, 0.15)',
                      color: '#10b981',
                      borderRadius: '10px',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      fontWeight: '600',
                      fontSize: '0.875rem'
                    }}>
                      <CheckCircle size={18} />
                      <span>Attendance Recorded (PRESENT)</span>
                    </div>
                  ) : (
                    <button
                      onClick={() => {
                        setSelectedSessionForAttendance(sess);
                        setIsScannerOpen(true);
                      }}
                      className="btn-primary"
                      style={{ width: '100%', padding: '11px', marginTop: '8px' }}
                    >
                      <Camera size={18} />
                      <span>Mark Attendance (Scan / Enter Code)</span>
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* VIEW: AVAILABLE QUIZZES & ACCESS CODE ENTRY */}
      {(activeTab === 'dashboard' || activeTab === 'quizzes') && (
        <div style={{ marginBottom: '32px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
            <div>
              <h3 style={{ fontSize: '1.25rem', fontWeight: '700' }}>Academic Examinations & Quizzes</h3>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.825rem' }}>
                Enter your access code to attempt live examinations under server-authoritative timers
              </p>
            </div>
          </div>

          {/* Quick Join Access Code Box */}
          <div className="glass-panel" style={{ padding: '24px', borderRadius: '18px', marginBottom: '20px' }}>
            <h4 style={{ fontSize: '1rem', fontWeight: '700', marginBottom: '6px' }}>Join Examination with Access Code</h4>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.825rem', marginBottom: '16px' }}>
              Your instructor issues a unique 6-character code before the examination begins.
            </p>

            {joinError && (
              <div style={{
                background: 'rgba(239, 68, 68, 0.15)',
                color: '#ef4444',
                padding: '10px 14px',
                borderRadius: '8px',
                fontSize: '0.825rem',
                marginBottom: '14px',
                display: 'flex',
                alignItems: 'center',
                gap: '8px'
              }}>
                <AlertCircle size={16} />
                <span>{joinError}</span>
              </div>
            )}

            <form onSubmit={handleJoinQuiz} style={{ display: 'flex', gap: '12px', maxWidth: '480px' }}>
              <input
                type="text"
                className="input-field"
                placeholder="Enter Quiz Code (e.g. VIOL01)"
                value={quizAccessCode}
                onChange={e => setQuizAccessCode(e.target.value.toUpperCase())}
                style={{ fontFamily: 'var(--font-mono)', fontSize: '1.1rem', letterSpacing: '0.08em', fontWeight: '700' }}
                required
              />
              <button type="submit" className="btn-primary" disabled={joinLoading || !quizAccessCode.trim()}>
                {joinLoading ? 'Validating...' : 'Enter Quiz'}
              </button>
            </form>
          </div>

          {/* Available Quizzes Grid */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(360px, 1fr))', gap: '16px' }}>
            {dashboardData?.quizzes?.map(q => (
              <div key={q.id} className="glass-panel" style={{ padding: '22px', borderRadius: '18px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '10px' }}>
                  <span className="badge badge-active">{q.duration_minutes} Mins</span>
                  {q.attempt_status ? (
                    <span className="badge badge-present">{q.attempt_status}</span>
                  ) : (
                    <span className="badge" style={{ background: 'var(--bg-tertiary)', color: 'var(--text-muted)' }}>Not Attempted</span>
                  )}
                </div>
                <h4 style={{ fontSize: '1.1rem', fontWeight: '700', marginBottom: '4px' }}>{q.title}</h4>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '14px' }}>
                  {q.subject_name} • Max Marks: {q.total_marks}
                </div>

                <div style={{ display: 'flex', gap: '8px' }}>
                  {!q.attempt_status ? (
                    <button
                      onClick={() => setQuizAccessCode('')}
                      className="btn-primary"
                      style={{ flex: 1, padding: '9px' }}
                    >
                      Enter with Code
                    </button>
                  ) : (
                    <button
                      onClick={() => loadQuizResult(q.id)}
                      className="btn-secondary"
                      style={{ flex: 1, padding: '9px' }}
                    >
                      <Eye size={16} /> View Result
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* VIEW: COMPREHENSIVE ATTENDANCE AUDIT & SUBJECT BREAKDOWN */}
      {(activeTab === 'attendance_view') && (
        <div style={{ marginBottom: '32px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
            <div>
              <h3 style={{ fontSize: '1.25rem', fontWeight: '700' }}>Subject-wise Attendance Breakdown</h3>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.825rem' }}>
                Raw session metrics calculated strictly without percent averaging
              </p>
            </div>
            <div style={{ display: 'flex', gap: '8px' }}>
              <a href={`/api/reports/attendance?format=pdf&token=${token}`} download className="btn-secondary" style={{ textDecoration: 'none', padding: '8px 14px', fontSize: '0.825rem' }}>
                <FileDown size={14} /> Download PDF
              </a>
              <a href={`/api/reports/attendance?format=excel&token=${token}`} download className="btn-secondary" style={{ textDecoration: 'none', padding: '8px 14px', fontSize: '0.825rem' }}>
                <FileText size={14} /> Excel
              </a>
            </div>
          </div>

          <div className="glass-panel" style={{ borderRadius: '18px', overflow: 'hidden', marginBottom: '24px' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.875rem' }}>
              <thead>
                <tr style={{ background: 'var(--bg-tertiary)', borderBottom: '1px solid var(--border-glass)' }}>
                  <th style={{ padding: '14px 20px', fontWeight: '600' }}>Subject</th>
                  <th style={{ padding: '14px 20px', fontWeight: '600' }}>Theory (P/T)</th>
                  <th style={{ padding: '14px 20px', fontWeight: '600' }}>Theory %</th>
                  <th style={{ padding: '14px 20px', fontWeight: '600' }}>Practical (P/T)</th>
                  <th style={{ padding: '14px 20px', fontWeight: '600' }}>Practical %</th>
                  <th style={{ padding: '14px 20px', fontWeight: '600' }}>Overall %</th>
                  <th style={{ padding: '14px 20px', textAlign: 'right' }}>Details</th>
                </tr>
              </thead>
              <tbody>
                {attendanceStats?.subjects?.map(s => {
                  const isExp = expandedSubject === s.subject_id;
                  return (
                    <React.Fragment key={s.subject_id}>
                      <tr style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                        <td style={{ padding: '14px 20px' }}>
                          <div style={{ fontWeight: '600' }}>{s.subject_name}</div>
                          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>{s.subject_code}</div>
                        </td>
                        <td style={{ padding: '14px 20px' }}>{s.theory.present} / {s.theory.total}</td>
                        <td style={{ padding: '14px 20px', fontWeight: '600' }}>{s.theory.percentage}%</td>
                        <td style={{ padding: '14px 20px' }}>{s.practical.present} / {s.practical.total}</td>
                        <td style={{ padding: '14px 20px', fontWeight: '600' }}>{s.practical.percentage}%</td>
                        <td style={{ padding: '14px 20px', fontWeight: '700', color: s.overall.percentage >= 75 ? 'var(--success)' : 'var(--danger)' }}>
                          {s.overall.percentage}%
                        </td>
                        <td style={{ padding: '14px 20px', textAlign: 'right' }}>
                          <button
                            onClick={() => setExpandedSubject(isExp ? null : s.subject_id)}
                            style={{ background: 'none', border: 'none', color: 'var(--accent-primary)', cursor: 'pointer' }}
                          >
                            {isExp ? <ChevronDown size={18} /> : <ChevronRight size={18} />}
                          </button>
                        </td>
                      </tr>
                      {isExp && (
                        <tr style={{ background: 'var(--bg-tertiary)' }}>
                          <td colSpan="7" style={{ padding: '16px 24px' }}>
                            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '16px', fontSize: '0.825rem' }}>
                              <div>
                                <strong>Theory Breakdown:</strong>
                                <div>Total Conducted: {s.theory.total}</div>
                                <div>Present: {s.theory.present} | Absent: {s.theory.absent} | Leave: {s.theory.leave}</div>
                              </div>
                              <div>
                                <strong>Practical Breakdown:</strong>
                                <div>Total Conducted: {s.practical.total}</div>
                                <div>Present: {s.practical.present} | Absent: {s.practical.absent} | Leave: {s.practical.leave}</div>
                              </div>
                              <div>
                                <strong>Curricular Ratio:</strong>
                                <div>Total Accumulated: {s.overall.total} Sessions</div>
                                <div>Formula: (Pres / Tot) × 100 = {s.overall.percentage}%</div>
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Datewise Log */}
          <h4 style={{ fontSize: '1.1rem', fontWeight: '700', marginBottom: '12px' }}>Datewise Session Log</h4>
          <div className="glass-panel" style={{ borderRadius: '18px', overflow: 'hidden' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.85rem' }}>
              <thead>
                <tr style={{ background: 'var(--bg-tertiary)' }}>
                  <th style={{ padding: '12px 18px' }}>Date & Time</th>
                  <th style={{ padding: '12px 18px' }}>Subject</th>
                  <th style={{ padding: '12px 18px' }}>Type</th>
                  <th style={{ padding: '12px 18px' }}>Room</th>
                  <th style={{ padding: '12px 18px' }}>Faculty</th>
                  <th style={{ padding: '12px 18px' }}>Status</th>
                </tr>
              </thead>
              <tbody>
                {attendanceStats?.datewise?.map((d, dIdx) => (
                  <tr key={dIdx} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                    <td style={{ padding: '12px 18px' }}>
                      <div style={{ fontWeight: '600' }}>{d.date}</div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{d.time}</div>
                    </td>
                    <td style={{ padding: '12px 18px' }}>{d.subject_name}</td>
                    <td style={{ padding: '12px 18px' }}>{d.session_type}</td>
                    <td style={{ padding: '12px 18px' }}>{d.room}</td>
                    <td style={{ padding: '12px 18px' }}>{d.faculty}</td>
                    <td style={{ padding: '12px 18px' }}>
                      <span className={`badge ${d.status === 'PRESENT' ? 'badge-present' : (d.status === 'LEAVE' ? 'badge-leave' : 'badge-absent')}`}>
                        {d.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* VIEW: LEARNIQUE AI ACADEMIC TUTOR */}
      {(activeTab === 'ai_doubt') && (
        <div style={{
          display: 'flex',
          flexDirection: 'column',
          minHeight: '740px',
          maxHeight: '86vh',
          background: 'var(--bg-secondary)',
          borderRadius: '28px',
          border: '1px solid var(--border-subtle)',
          overflow: 'hidden',
          boxShadow: '0 16px 48px rgba(0, 0, 0, 0.18)',
          position: 'relative'
        }}>
          {/* Learnique AI Top App Bar */}
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            padding: '16px 28px',
            borderBottom: '1px solid var(--border-subtle)',
            background: 'rgba(255, 255, 255, 0.02)',
            backdropFilter: 'blur(10px)',
            flexWrap: 'wrap',
            gap: '12px',
            zIndex: 10
          }}>
            {/* Learnique AI Brand & Model Badge */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <span style={{ fontSize: '1.25rem', fontWeight: '700', letterSpacing: '-0.02em' }}>
                    Learnique AI
                  </span>
                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '5px',
                    padding: '2px 8px',
                    borderRadius: '12px',
                    background: 'rgba(66, 133, 244, 0.12)',
                    border: '1px solid rgba(66, 133, 244, 0.25)',
                    fontSize: '0.72rem',
                    color: '#8ab4f8',
                    fontWeight: '600'
                  }}>
                    <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#34a853', display: 'inline-block' }} />
                    Learnique AI Engine
                  </div>
                </div>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                  Multimodal Academic Tutor & Concept Solver
                </div>
              </div>
            </div>

            {/* Context Selectors & Session Controls */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
              {/* Subject Pill Dropdown */}
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                background: 'var(--bg-tertiary)',
                borderRadius: '20px',
                padding: '5px 12px',
                border: '1px solid var(--border-subtle)'
              }}>
                <BookOpen size={13} style={{ color: '#8ab4f8' }} />
                <select
                  value={doubtSubject}
                  onChange={e => setDoubtSubject(e.target.value)}
                  style={{
                    background: 'transparent',
                    border: 'none',
                    color: 'var(--text-primary)',
                    fontSize: '0.8rem',
                    fontWeight: '500',
                    cursor: 'pointer',
                    outline: 'none',
                    maxWidth: '150px'
                  }}
                  title="Select Academic Subject for Context"
                >
                  <option value="General Academic">All / General Curriculum</option>
                  {dashboardData?.subjects?.map((s, idx) => (
                    <option key={s.id || s.code || idx} value={s.name}>
                      {s.name} {s.code ? `(${s.code})` : ''}
                    </option>
                  ))}
                  <option value="Computer Science">Computer Science & Algorithms</option>
                  <option value="Mathematics">Mathematics & Derivations</option>
                  <option value="Physics">Physics & Applied Science</option>
                </select>
              </div>

              {/* Topic Pill Input */}
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                background: 'var(--bg-tertiary)',
                borderRadius: '20px',
                padding: '5px 12px',
                border: '1px solid var(--border-subtle)',
                minWidth: '170px'
              }}>
                <span style={{ fontSize: '0.78rem' }}>🎯</span>
                <input
                  type="text"
                  placeholder="Target Concept..."
                  value={doubtTopic}
                  onChange={e => setDoubtTopic(e.target.value)}
                  style={{
                    background: 'transparent',
                    border: 'none',
                    color: 'var(--text-primary)',
                    fontSize: '0.8rem',
                    outline: 'none',
                    width: '100%'
                  }}
                  title="Target a specific curriculum topic (e.g. Deadlocks, Normalization)"
                />
              </div>

              {/* New Chat Button */}
              {doubtMessages.length > 0 && (
                <button
                  type="button"
                  onClick={handleClearDoubtChat}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    background: 'var(--bg-tertiary)',
                    border: '1px solid var(--border-subtle)',
                    borderRadius: '20px',
                    padding: '6px 14px',
                    fontSize: '0.8rem',
                    color: 'var(--text-secondary)',
                    cursor: 'pointer',
                    transition: 'all 0.15s ease'
                  }}
                  title="Clear conversation and start fresh"
                >
                  <Plus size={14} />
                  <span>New Chat</span>
                </button>
              )}

              {/* Full Session PDF Button */}
              {doubtMessages.length > 0 && (
                <button
                  type="button"
                  onClick={handleDownloadFullSessionPdf}
                  disabled={isGeneratingPdf}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    background: 'rgba(66, 133, 244, 0.12)',
                    border: '1px solid rgba(66, 133, 244, 0.3)',
                    borderRadius: '20px',
                    padding: '6px 14px',
                    fontSize: '0.8rem',
                    color: '#8ab4f8',
                    cursor: 'pointer',
                    fontWeight: '600'
                  }}
                  title="Download complete conversation history as PDF"
                >
                  <FileDown size={14} />
                  <span>Session PDF</span>
                </button>
              )}
            </div>
          </div>

          {/* Learnique AI Chat Scroll Stream */}
          <div style={{
            flex: 1,
            overflowY: 'auto',
            padding: '24px 32px 160px 32px',
            display: 'flex',
            flexDirection: 'column',
            gap: '24px'
          }}>
            {doubtMessages.length === 0 ? (
              /* Learnique AI Hero Landing Greeting & Prompt Grid */
              <div style={{ maxWidth: '820px', width: '100%', margin: '40px auto 10px auto' }}>
                <div style={{ marginBottom: '32px' }}>
                  <h1 style={{
                    fontSize: '2.8rem',
                    fontWeight: '700',
                    lineHeight: '1.18',
                    margin: 0,
                    background: 'linear-gradient(74deg, #4285f4 0%, #9b72cb 25%, #d96570 50%, #d96570 65%, #9b72cb 80%, #4285f4 100%)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                    letterSpacing: '-0.02em'
                  }}>
                    Hello, {user?.name?.split(' ')[0] || 'Scholar'}
                  </h1>
                  <h2 style={{
                    fontSize: '2.3rem',
                    fontWeight: '500',
                    color: 'var(--text-muted)',
                    margin: '6px 0 0 0',
                    opacity: 0.75,
                    letterSpacing: '-0.02em'
                  }}>
                    How can I help you learn today?
                  </h2>
                </div>

                {/* Learnique AI 4 Suggestion Cards */}
                <div style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
                  gap: '14px',
                  marginTop: '28px'
                }}>
                  {[
                    {
                      icon: <Lightbulb size={22} style={{ color: '#fbbc04' }} />,
                      bg: 'rgba(251, 188, 4, 0.1)',
                      title: "Explain core principles",
                      desc: "Deadlocks, Normalization, Fourier Transforms, or Memory Management",
                      prompt: "Explain Operating System Deadlocks & Banker's Algorithm with an allocation example"
                    },
                    {
                      icon: <Presentation size={22} style={{ color: '#ea580c' }} />,
                      bg: 'rgba(234, 88, 12, 0.1)',
                      title: "Analyze lecture slides",
                      desc: "Break down attached PPTX, PDF, or Word DOCX notes into exam summaries",
                      prompt: "Analyze attached lecture slides and highlight the highest-yield exam takeaways"
                    },
                    {
                      icon: <Code size={22} style={{ color: '#34a853' }} />,
                      bg: 'rgba(52, 168, 83, 0.1)',
                      title: "Step-by-step derivations",
                      desc: "Time & space complexity proofs with code and mathematical intuition",
                      prompt: "Explain why QuickSort worst-case is O(n²) and average is O(n log n) with derivation"
                    },
                    {
                      icon: <GraduationCap size={22} style={{ color: '#a142f4' }} />,
                      bg: 'rgba(161, 66, 244, 0.1)',
                      title: "Generate study guide",
                      desc: "Format complete review notes and download an official PDF cheat sheet",
                      prompt: "Create a PDF study sheet on Database Normalization from 1NF to BCNF with tables"
                    }
                  ].map((card, cIdx) => (
                    <div
                      key={cIdx}
                      onClick={() => setDoubtText(card.prompt)}
                      style={{
                        background: 'var(--bg-tertiary)',
                        borderRadius: '20px',
                        padding: '20px',
                        border: '1px solid var(--border-subtle)',
                        cursor: 'pointer',
                        display: 'flex',
                        flexDirection: 'column',
                        justifyContent: 'space-between',
                        minHeight: '140px',
                        transition: 'all 0.2s cubic-bezier(0.16, 1, 0.3, 1)',
                        position: 'relative'
                      }}
                      onMouseEnter={e => {
                        e.currentTarget.style.borderColor = '#8ab4f8';
                        e.currentTarget.style.transform = 'translateY(-3px)';
                        e.currentTarget.style.boxShadow = '0 8px 24px rgba(66, 133, 244, 0.15)';
                      }}
                      onMouseLeave={e => {
                        e.currentTarget.style.borderColor = 'var(--border-subtle)';
                        e.currentTarget.style.transform = 'translateY(0)';
                        e.currentTarget.style.boxShadow = 'none';
                      }}
                    >
                      <div>
                        <div style={{ fontSize: '0.92rem', fontWeight: '600', marginBottom: '6px', color: 'var(--text-primary)' }}>
                          {card.title}
                        </div>
                        <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', lineHeight: 1.45 }}>
                          {card.desc}
                        </div>
                      </div>
                      <div style={{
                        alignSelf: 'flex-end',
                        width: '38px',
                        height: '38px',
                        borderRadius: '50%',
                        background: card.bg,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        marginTop: '16px'
                      }}>
                        {card.icon}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              /* Learnique AI Messages Stream */
              <div style={{ maxWidth: '820px', width: '100%', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '28px' }}>
                {doubtMessages.map((m, idx) => {
                  const isUser = m.sender === 'USER';
                  return (
                    <div
                      key={idx}
                      style={{
                        display: 'flex',
                        flexDirection: isUser ? 'column' : 'row',
                        alignItems: isUser ? 'flex-end' : 'flex-start',
                        gap: '14px',
                        width: '100%'
                      }}
                    >
                      {/* AI Assistant Avatar */}
                      {!isUser && (
                        <div style={{
                          width: '38px',
                          height: '38px',
                          borderRadius: '12px',
                          background: 'linear-gradient(135deg, #4285f4 0%, #9b72cb 100%)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flexShrink: 0,
                          marginTop: '2px',
                          boxShadow: '0 4px 14px rgba(66, 133, 244, 0.35)',
                          color: '#ffffff'
                        }}>
                          <Sparkles size={20} />
                        </div>
                      )}

                      {/* Message Body Container */}
                      <div style={{
                        maxWidth: isUser ? '75%' : '100%',
                        flex: isUser ? undefined : 1,
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '6px'
                      }}>
                        {/* Sender Label for Assistant */}
                        {!isUser && (
                          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '2px' }}>
                            <span style={{ fontSize: '0.85rem', fontWeight: '700', color: 'var(--text-primary)' }}>
                              Learnique AI
                            </span>
                            <span style={{
                              fontSize: '0.68rem',
                              fontWeight: '600',
                              color: '#8ab4f8',
                              background: 'rgba(66, 133, 244, 0.12)',
                              border: '1px solid rgba(66, 133, 244, 0.25)',
                              padding: '1px 8px',
                              borderRadius: '10px'
                            }}>
                              Academic Tutor
                            </span>
                          </div>
                        )}
                        {/* Concept Tag for user question if targeted */}
                        {isUser && m.topic && m.topic !== 'Core Academic Concept' && (
                          <div style={{
                            fontSize: '0.72rem',
                            fontWeight: '600',
                            color: '#8ab4f8',
                            background: 'rgba(66, 133, 244, 0.1)',
                            border: '1px solid rgba(66, 133, 244, 0.25)',
                            padding: '2px 10px',
                            borderRadius: '12px',
                            alignSelf: 'flex-end',
                            marginBottom: '2px'
                          }}>
                            🎯 {m.topic}
                          </div>
                        )}

                        {/* Message Body */}
                        <div style={{
                          background: isUser ? 'var(--bg-tertiary)' : 'transparent',
                          color: 'var(--text-primary)',
                          padding: isUser ? '14px 20px' : '0px 4px',
                          borderRadius: isUser ? '22px 22px 6px 22px' : '0px',
                          border: isUser ? '1px solid var(--border-subtle)' : 'none',
                          fontSize: '0.94rem',
                          lineHeight: 1.68
                        }}>
                          {/* Attached File Preview if present */}
                          {m.attachment && (
                            <div style={{
                              marginBottom: '12px',
                              padding: '10px 14px',
                              borderRadius: '14px',
                              background: 'var(--bg-secondary)',
                              border: '1px solid var(--border-subtle)',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '12px'
                            }}>
                              {m.attachment.isImage || m.attachment.previewUrl ? (
                                <img
                                  src={m.attachment.previewUrl}
                                  alt={m.attachment.name}
                                  style={{ width: '46px', height: '46px', objectFit: 'cover', borderRadius: '8px', cursor: 'pointer' }}
                                  onClick={() => window.open(m.attachment.previewUrl, '_blank')}
                                />
                              ) : m.attachment.category === 'presentation' || (m.attachment.name && m.attachment.name.toLowerCase().match(/\.(ppt|pptx)$/)) ? (
                                <div style={{
                                  width: '42px',
                                  height: '42px',
                                  borderRadius: '8px',
                                  background: 'rgba(234, 88, 12, 0.15)',
                                  color: '#ea580c',
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                  flexShrink: 0
                                }}>
                                  <Presentation size={22} />
                                </div>
                              ) : m.attachment.category === 'word' || (m.attachment.name && m.attachment.name.toLowerCase().match(/\.(doc|docx)$/)) ? (
                                <div style={{
                                  width: '42px',
                                  height: '42px',
                                  borderRadius: '8px',
                                  background: 'rgba(37, 99, 235, 0.15)',
                                  color: '#2563eb',
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                  flexShrink: 0
                                }}>
                                  <FileText size={22} />
                                </div>
                              ) : m.attachment.category === 'pdf' || (m.attachment.name && m.attachment.name.toLowerCase().endsWith('.pdf')) ? (
                                <div style={{
                                  width: '42px',
                                  height: '42px',
                                  borderRadius: '8px',
                                  background: 'rgba(220, 38, 38, 0.15)',
                                  color: '#dc2626',
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                  flexShrink: 0
                                }}>
                                  <FileText size={22} />
                                </div>
                              ) : (
                                <div style={{
                                  width: '42px',
                                  height: '42px',
                                  borderRadius: '8px',
                                  background: 'rgba(66, 133, 244, 0.15)',
                                  color: '#8ab4f8',
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                  flexShrink: 0
                                }}>
                                  <FileText size={22} />
                                </div>
                              )}
                              <div style={{ fontSize: '0.825rem', overflow: 'hidden' }}>
                                <div style={{ fontWeight: '600', textOverflow: 'ellipsis', overflow: 'hidden', whiteSpace: 'nowrap' }}>
                                  {m.attachment.name}
                                </div>
                                <div style={{ fontSize: '0.72rem', opacity: 0.85, display: 'flex', gap: '8px', alignItems: 'center' }}>
                                  {m.attachment.size && <span>{m.attachment.size}</span>}
                                  {m.attachment.category && (
                                    <span style={{
                                      textTransform: 'uppercase',
                                      fontSize: '0.65rem',
                                      padding: '1px 6px',
                                      borderRadius: '4px',
                                      background: 'var(--border-subtle)',
                                      fontWeight: '700'
                                    }}>
                                      {m.attachment.category}
                                    </span>
                                  )}
                                </div>
                              </div>
                            </div>
                          )}

                          {/* Text Content */}
                          <div style={{ whiteSpace: 'pre-wrap' }}>
                            {formatAIResponse(m.content)}
                          </div>

                          {/* Learnique AI Bottom Action Bar for AI Response */}
                          {!isUser && (
                            <div style={{
                              marginTop: '16px',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '6px',
                              flexWrap: 'wrap'
                            }}>
                              {/* Thumbs Up Button */}
                              <button
                                type="button"
                                onClick={() => handleFeedback(idx, 'up')}
                                style={{
                                  width: '32px',
                                  height: '32px',
                                  borderRadius: '50%',
                                  background: doubtFeedback[idx] === 'up' ? 'rgba(66, 133, 244, 0.2)' : 'transparent',
                                  border: 'none',
                                  color: doubtFeedback[idx] === 'up' ? '#8ab4f8' : 'var(--text-muted)',
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                  cursor: 'pointer',
                                  transition: 'all 0.15s ease'
                                }}
                                title="Good response"
                              >
                                <ThumbsUp size={15} />
                              </button>

                              {/* Thumbs Down Button */}
                              <button
                                type="button"
                                onClick={() => handleFeedback(idx, 'down')}
                                style={{
                                  width: '32px',
                                  height: '32px',
                                  borderRadius: '50%',
                                  background: doubtFeedback[idx] === 'down' ? 'rgba(217, 101, 112, 0.2)' : 'transparent',
                                  border: 'none',
                                  color: doubtFeedback[idx] === 'down' ? '#d96570' : 'var(--text-muted)',
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                  cursor: 'pointer',
                                  transition: 'all 0.15s ease'
                                }}
                                title="Bad response"
                              >
                                <ThumbsDown size={15} />
                              </button>

                              {/* Copy Button */}
                              <button
                                type="button"
                                onClick={() => {
                                  navigator.clipboard.writeText(m.content);
                                  setCopiedIndex(idx);
                                  notify('Response copied to clipboard!', 'success');
                                  setTimeout(() => setCopiedIndex(null), 2000);
                                }}
                                style={{
                                  display: 'flex',
                                  alignItems: 'center',
                                  gap: '5px',
                                  padding: '5px 10px',
                                  borderRadius: '16px',
                                  background: 'transparent',
                                  border: '1px solid var(--border-subtle)',
                                  color: copiedIndex === idx ? 'var(--success)' : 'var(--text-muted)',
                                  fontSize: '0.76rem',
                                  cursor: 'pointer'
                                }}
                                title="Copy explanation"
                              >
                                {copiedIndex === idx ? <Check size={13} style={{ color: 'var(--success)' }} /> : <Copy size={13} />}
                                <span>{copiedIndex === idx ? 'Copied' : 'Copy'}</span>
                              </button>

                              {/* Download PDF Button */}
                              <button
                                type="button"
                                onClick={() => handleDownloadPdf(m.content, doubtSubject, doubtMessages[idx - 1]?.content || '')}
                                disabled={isGeneratingPdf}
                                style={{
                                  display: 'flex',
                                  alignItems: 'center',
                                  gap: '5px',
                                  padding: '5px 12px',
                                  borderRadius: '16px',
                                  background: 'rgba(66, 133, 244, 0.12)',
                                  border: '1px solid rgba(66, 133, 244, 0.25)',
                                  color: '#8ab4f8',
                                  fontSize: '0.76rem',
                                  fontWeight: '600',
                                  cursor: 'pointer'
                                }}
                                title="Export this study explanation as a downloadable PDF"
                              >
                                <FileDown size={13} />
                                <span>Export PDF</span>
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Thinking State Indicator */}
            {doubtLoading && (
              <div style={{ maxWidth: '820px', width: '100%', margin: '0 auto', color: 'var(--text-muted)', fontSize: '0.88rem' }}>
                Thinking...
              </div>
            )}

            <div ref={doubtChatEndRef} />
          </div>

          {/* Learnique AI Floating Prompt Capsule (Bottom Sticky Bar) */}
          <div style={{
            position: 'absolute',
            bottom: 0,
            left: 0,
            right: 0,
            padding: '10px 24px 16px 24px',
            background: 'linear-gradient(to top, var(--bg-secondary) 85%, transparent)',
            backdropFilter: 'blur(12px)',
            zIndex: 20
          }}>
            <div style={{ maxWidth: '820px', margin: '0 auto' }}>
              {/* Capsule Card */}
              <div style={{
                borderRadius: '28px',
                background: 'var(--bg-tertiary)',
                border: '1px solid rgba(255, 255, 255, 0.12)',
                boxShadow: '0 10px 32px rgba(0, 0, 0, 0.28)',
                padding: '12px 18px',
                display: 'flex',
                flexDirection: 'column',
                gap: '8px'
              }}>
                {/* Pending Attachment Preview Chip inside Capsule */}
                {doubtAttachment && (
                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    padding: '8px 12px',
                    borderRadius: '14px',
                    background: 'rgba(66, 133, 244, 0.1)',
                    border: '1px solid rgba(66, 133, 244, 0.25)',
                    marginBottom: '4px'
                  }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px', overflow: 'hidden' }}>
                      {doubtAttachment.isImage ? (
                        <img
                          src={doubtAttachment.previewUrl}
                          alt={doubtAttachment.name}
                          style={{ width: '36px', height: '36px', borderRadius: '6px', objectFit: 'cover' }}
                        />
                      ) : doubtAttachment.category === 'presentation' || (doubtAttachment.name && doubtAttachment.name.toLowerCase().match(/\.(ppt|pptx)$/)) ? (
                        <div style={{
                          width: '36px',
                          height: '36px',
                          borderRadius: '6px',
                          background: 'rgba(234, 88, 12, 0.15)',
                          color: '#ea580c',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flexShrink: 0
                        }}>
                          <Presentation size={20} />
                        </div>
                      ) : doubtAttachment.category === 'word' || (doubtAttachment.name && doubtAttachment.name.toLowerCase().match(/\.(doc|docx)$/)) ? (
                        <div style={{
                          width: '36px',
                          height: '36px',
                          borderRadius: '6px',
                          background: 'rgba(37, 99, 235, 0.15)',
                          color: '#2563eb',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flexShrink: 0
                        }}>
                          <FileText size={20} />
                        </div>
                      ) : doubtAttachment.category === 'pdf' || (doubtAttachment.name && doubtAttachment.name.toLowerCase().endsWith('.pdf')) ? (
                        <div style={{
                          width: '36px',
                          height: '36px',
                          borderRadius: '6px',
                          background: 'rgba(220, 38, 38, 0.15)',
                          color: '#dc2626',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flexShrink: 0
                        }}>
                          <FileText size={20} />
                        </div>
                      ) : (
                        <div style={{
                          width: '36px',
                          height: '36px',
                          borderRadius: '6px',
                          background: 'rgba(66, 133, 244, 0.15)',
                          color: '#8ab4f8',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flexShrink: 0
                        }}>
                          <FileText size={20} />
                        </div>
                      )}
                      <div>
                        <div style={{ fontSize: '0.84rem', fontWeight: '600', textOverflow: 'ellipsis', overflow: 'hidden', whiteSpace: 'nowrap', maxWidth: '380px' }}>
                          {doubtAttachment.name}
                        </div>
                        <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', display: 'flex', gap: '8px', alignItems: 'center' }}>
                          <span>{doubtAttachment.size}</span>
                          <span style={{
                            textTransform: 'uppercase',
                            fontSize: '0.62rem',
                            padding: '1px 5px',
                            borderRadius: '4px',
                            background: 'rgba(66, 133, 244, 0.2)',
                            color: '#8ab4f8',
                            fontWeight: '700'
                          }}>
                            {doubtAttachment.category || 'FILE'}
                          </span>
                          <span>• Ready to analyze</span>
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => setDoubtAttachment(null)}
                      style={{
                        padding: '4px',
                        borderRadius: '50%',
                        background: 'transparent',
                        border: 'none',
                        color: 'var(--text-muted)',
                        cursor: 'pointer'
                      }}
                      title="Remove attached file"
                    >
                      <X size={16} />
                    </button>
                  </div>
                )}

                {/* Form & Controls */}
                <form onSubmit={handleSendDoubt} style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                  {/* Hidden File Input */}
                  <input
                    type="file"
                    ref={doubtFileInputRef}
                    onChange={handleAttachmentChange}
                    style={{ display: 'none' }}
                    accept=".pdf,.ppt,.pptx,.doc,.docx,.png,.jpg,.jpeg,.webp,.gif,.bmp,.txt,.py,.java,.cpp,.c,.js,.json,.csv,.md"
                  />

                  {/* Question Prompt Input */}
                  <input
                    type="text"
                    value={doubtText}
                    onChange={e => setDoubtText(e.target.value)}
                    placeholder={
                      doubtAttachment
                        ? `Ask a question about ${doubtAttachment.name}...`
                        : (doubtTopic ? `Ask about '${doubtTopic}' or request derivations...` : "Ask Learnique AI or upload slides, documents, diagrams...")
                    }
                    style={{
                      width: '100%',
                      background: 'transparent',
                      border: 'none',
                      outline: 'none',
                      color: 'var(--text-primary)',
                      fontSize: '0.96rem',
                      padding: '4px 2px'
                    }}
                  />

                  {/* Actions & Utilities Bar */}
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingTop: '4px' }}>
                    {/* Left: Attachment & Context */}
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      {/* Plus Attachment Button */}
                      <button
                        type="button"
                        onClick={() => doubtFileInputRef.current?.click()}
                        style={{
                          width: '34px',
                          height: '34px',
                          borderRadius: '50%',
                          background: doubtAttachment ? 'rgba(66, 133, 244, 0.2)' : 'rgba(255, 255, 255, 0.05)',
                          border: doubtAttachment ? '1px solid #4285f4' : '1px solid var(--border-subtle)',
                          color: doubtAttachment ? '#8ab4f8' : 'var(--text-secondary)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          cursor: 'pointer',
                          transition: 'all 0.15s ease'
                        }}
                        title="Attach slides (.ppt/.pptx), notes (.docx/.pdf), diagram/image, or code (up to 25MB)"
                      >
                        <Plus size={18} />
                      </button>

                      {/* Small Active Subject Tag */}
                      <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                        {doubtSubject !== 'General Academic' ? doubtSubject : ''}
                      </span>
                    </div>

                    {/* Right: Direct PDF Button & Learnique AI Send Button */}
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      {/* Create PDF Button */}
                      <button
                        type="button"
                        onClick={(e) => handleSendDoubt(e, true)}
                        disabled={doubtLoading || (!doubtText.trim() && !doubtAttachment)}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '6px',
                          padding: '6px 14px',
                          borderRadius: '20px',
                          background: 'rgba(255, 255, 255, 0.05)',
                          border: '1px solid var(--border-subtle)',
                          color: 'var(--text-secondary)',
                          fontSize: '0.78rem',
                          fontWeight: '600',
                          cursor: (doubtText.trim() || doubtAttachment) && !doubtLoading ? 'pointer' : 'default',
                          opacity: (doubtText.trim() || doubtAttachment) && !doubtLoading ? 1 : 0.5
                        }}
                        title="Generate complete explanation and download directly as a formatted PDF"
                      >
                        <FileDown size={14} style={{ color: '#8ab4f8' }} />
                        <span>Create PDF</span>
                      </button>

                      {/* Circular Learnique AI Send Button */}
                      <button
                        type="submit"
                        disabled={doubtLoading || (!doubtText.trim() && !doubtAttachment)}
                        style={{
                          width: '36px',
                          height: '36px',
                          borderRadius: '50%',
                          background: (doubtText.trim() || doubtAttachment) && !doubtLoading
                            ? 'linear-gradient(135deg, #4285f4 0%, #9b72cb 100%)'
                            : 'rgba(255, 255, 255, 0.05)',
                          border: 'none',
                          color: (doubtText.trim() || doubtAttachment) && !doubtLoading ? '#ffffff' : 'var(--text-muted)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          cursor: (doubtText.trim() || doubtAttachment) && !doubtLoading ? 'pointer' : 'default',
                          boxShadow: (doubtText.trim() || doubtAttachment) && !doubtLoading ? '0 4px 12px rgba(66, 133, 244, 0.4)' : 'none',
                          transition: 'all 0.2s ease',
                          flexShrink: 0
                        }}
                        title="Send to Learnique AI Tutor"
                      >
                        {doubtLoading ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
                      </button>
                    </div>
                  </div>
                </form>
              </div>

              {/* Learnique AI Disclaimer */}
              <div style={{ textAlign: 'center', fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: '8px', opacity: 0.8 }}>
                Learnique AI may display inaccurate info, so verify responses with your curriculum textbooks.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* VIEW: MY SCHEDULE / WEEKLY TIMETABLE */}
      {activeTab === 'timetable' && (
        <div style={{ marginBottom: '32px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
            <div>
              <h3 style={{ fontSize: '1.25rem', fontWeight: '700' }}>My Academic Schedule & Timetable</h3>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.825rem' }}>
                Weekly class schedule for Division {profileData?.division_name || ''} {profileData?.batch_name ? `(Batch ${profileData.batch_name})` : ''}
              </p>
            </div>
            {/* Day Selector Tabs */}
            <div style={{ display: 'flex', gap: '6px', background: 'var(--bg-secondary)', padding: '4px', borderRadius: '12px' }}>
              {[
                { day: 1, label: 'Mon' },
                { day: 2, label: 'Tue' },
                { day: 3, label: 'Wed' },
                { day: 4, label: 'Thu' },
                { day: 5, label: 'Fri' },
              ].map(d => (
                <button
                  key={d.day}
                  type="button"
                  onClick={() => setSelectedTimetableDay(d.day)}
                  style={{
                    padding: '8px 16px',
                    borderRadius: '8px',
                    border: 'none',
                    fontWeight: '600',
                    fontSize: '0.85rem',
                    cursor: 'pointer',
                    background: selectedTimetableDay === d.day ? 'var(--accent-primary)' : 'transparent',
                    color: selectedTimetableDay === d.day ? '#ffffff' : 'var(--text-secondary)',
                    transition: 'all 0.15s ease'
                  }}
                >
                  {d.label}
                </button>
              ))}
            </div>
          </div>

          {/* Timetable Cards for Selected Day */}
          {(() => {
            const dayEntries = weeklyTimetable.filter(te => te.day_of_week === selectedTimetableDay);
            if (dayEntries.length === 0) {
              return (
                <div className="glass-panel" style={{ padding: '40px', textAlign: 'center', color: 'var(--text-muted)', borderRadius: '18px' }}>
                  No scheduled classes for this day. Enjoy your study session!
                </div>
              );
            }
            return (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(360px, 1fr))', gap: '16px' }}>
                {dayEntries.map(te => (
                  <div key={te.id} className="glass-panel" style={{ padding: '22px', borderRadius: '18px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '12px' }}>
                      <div style={{ display: 'flex', gap: '6px', alignItems: 'center' }}>
                        <span className="badge badge-active">{te.session_type}</span>
                        {te.is_proxy ? (
                          <span className="badge" style={{ background: 'rgba(234, 179, 8, 0.15)', color: '#eab308', border: '1px solid #eab308' }}>
                            Proxy: {te.specific_date}
                          </span>
                        ) : null}
                      </div>
                      <div style={{ padding: '6px 12px', background: 'var(--bg-tertiary)', borderRadius: '8px', fontSize: '0.8rem', fontWeight: '600' }}>
                        Room {te.room}
                      </div>
                    </div>
                    <h4 style={{ fontSize: '1.15rem', fontWeight: '700', marginBottom: '4px' }}>{te.subject_name}</h4>
                    <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', marginBottom: '14px' }}>
                      {te.subject_code} • Faculty: {te.teacher_name}
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '0.85rem', color: 'var(--accent-primary)', fontWeight: '600' }}>
                      <Clock size={16} />
                      <span>{te.start_time} - {te.end_time}</span>
                    </div>
                  </div>
                ))}
              </div>
            );
          })()}
        </div>
      )}

      {/* VIEW: ACADEMIC PROFILE */}
      {activeTab === 'profile' && (
        <div style={{ marginBottom: '32px' }}>
          <div style={{ marginBottom: '20px' }}>
            <h3 style={{ fontSize: '1.25rem', fontWeight: '700' }}>Student Academic Profile</h3>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.825rem' }}>
              Official university credentials and institutional enrollment details
            </p>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '320px 1fr', gap: '20px' }}>
            {/* Identity Card */}
            <div className="glass-panel" style={{ padding: '28px', borderRadius: '20px', textAlign: 'center' }}>
              <div style={{
                width: '90px',
                height: '90px',
                borderRadius: '50%',
                background: 'linear-gradient(135deg, var(--accent-primary), var(--accent-hover))',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 16px auto',
                color: '#ffffff',
                fontSize: '2rem',
                fontWeight: '800',
                boxShadow: '0 8px 24px var(--accent-glow)'
              }}>
                {profileData?.name ? profileData.name.charAt(0) : 'S'}
              </div>
              <h3 style={{ fontSize: '1.3rem', fontWeight: '800', marginBottom: '4px' }}>
                {profileData?.name || user?.name}
              </h3>
              <div style={{ fontSize: '0.85rem', color: 'var(--accent-primary)', fontFamily: 'var(--font-mono)', fontWeight: '700', marginBottom: '16px' }}>
                {profileData?.enrollment_number || user?.identifier}
              </div>
              <span className={`badge ${(summary?.overall?.percentage ?? 0) >= 75 ? 'badge-present' : 'badge-absent'}`} style={{ padding: '6px 14px' }}>
                {(summary?.overall?.percentage ?? 0) >= 75 ? 'Exam Eligible' : 'Attendance Shortage'}
              </span>

              <div style={{ marginTop: '24px', borderTop: '1px solid var(--border-subtle)', paddingTop: '18px', textAlign: 'left', display: 'flex', flexDirection: 'column', gap: '10px', fontSize: '0.85rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ color: 'var(--text-muted)' }}>Status</span>
                  <span style={{ fontWeight: '600', color: 'var(--success)' }}>Active Enrolled</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ color: 'var(--text-muted)' }}>Gender</span>
                  <span style={{ fontWeight: '600' }}>{profileData?.gender || 'Not Specified'}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ color: 'var(--text-muted)' }}>Date of Birth</span>
                  <span style={{ fontWeight: '600' }}>{profileData?.date_of_birth || 'N/A'}</span>
                </div>
              </div>
            </div>

            {/* Academic Dossier Details */}
            <div className="glass-panel" style={{ padding: '28px', borderRadius: '20px' }}>
              <h4 style={{ fontSize: '1.05rem', fontWeight: '700', marginBottom: '18px', paddingBottom: '10px', borderBottom: '1px solid var(--border-subtle)' }}>
                Academic Curriculum & Enrollment Details
              </h4>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '18px', marginBottom: '24px' }}>
                <div style={{ padding: '14px', background: 'var(--bg-tertiary)', borderRadius: '12px' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Degree / Program</div>
                  <div style={{ fontSize: '0.95rem', fontWeight: '700', marginTop: '4px' }}>
                    {profileData?.course_name || 'B.Tech Computer Science & Engineering'}
                  </div>
                </div>
                <div style={{ padding: '14px', background: 'var(--bg-tertiary)', borderRadius: '12px' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Branch / Department</div>
                  <div style={{ fontSize: '0.95rem', fontWeight: '700', marginTop: '4px' }}>
                    {profileData?.branch || 'Computer Science & Engineering'}
                  </div>
                </div>
                <div style={{ padding: '14px', background: 'var(--bg-tertiary)', borderRadius: '12px' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Current Semester</div>
                  <div style={{ fontSize: '0.95rem', fontWeight: '700', marginTop: '4px' }}>
                    Semester {profileData?.semester_number || 6}
                  </div>
                </div>
                <div style={{ padding: '14px', background: 'var(--bg-tertiary)', borderRadius: '12px' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Division & Batch</div>
                  <div style={{ fontSize: '0.95rem', fontWeight: '700', marginTop: '4px' }}>
                    Division {profileData?.division_name || 'A'} • Batch {profileData?.batch_name || 'A1'}
                  </div>
                </div>
              </div>

              <h4 style={{ fontSize: '1.05rem', fontWeight: '700', marginBottom: '18px', paddingBottom: '10px', borderBottom: '1px solid var(--border-subtle)' }}>
                Contact & Communication
              </h4>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '18px' }}>
                <div style={{ padding: '14px', background: 'var(--bg-tertiary)', borderRadius: '12px' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>University Email Address</div>
                  <div style={{ fontSize: '0.95rem', fontWeight: '600', marginTop: '4px' }}>
                    {profileData?.email || user?.email}
                  </div>
                </div>
                <div style={{ padding: '14px', background: 'var(--bg-tertiary)', borderRadius: '12px' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Mobile Number</div>
                  <div style={{ fontSize: '0.95rem', fontWeight: '600', marginTop: '4px' }}>
                    {profileData?.phone || 'Not registered'}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* VIEW: MY RESULTS */}
      {activeTab === 'reports' && (
        <div style={{ marginBottom: '32px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
            <div>
              <h3 style={{ fontSize: '1.25rem', fontWeight: '700' }}>My Examination Results & Transcripts</h3>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.825rem' }}>
                Official grading transcripts, percentages, and downloadable question-wise scorecards
              </p>
            </div>
          </div>

          {pastResults.length === 0 ? (
            <div className="glass-panel" style={{ padding: '40px', textAlign: 'center', color: 'var(--text-muted)', borderRadius: '18px' }}>
              No examination results recorded yet. Completed examinations will appear here once submitted.
            </div>
          ) : (
            <div className="glass-panel" style={{ borderRadius: '18px', overflow: 'hidden' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.875rem' }}>
                <thead>
                  <tr style={{ background: 'var(--bg-tertiary)', borderBottom: '1px solid var(--border-glass)' }}>
                    <th style={{ padding: '14px 20px', fontWeight: '600' }}>Quiz Title</th>
                    <th style={{ padding: '14px 20px', fontWeight: '600' }}>Subject</th>
                    <th style={{ padding: '14px 20px', fontWeight: '600' }}>Score</th>
                    <th style={{ padding: '14px 20px', fontWeight: '600' }}>Percentage</th>
                    <th style={{ padding: '14px 20px', fontWeight: '600' }}>Classification</th>
                    <th style={{ padding: '14px 20px', fontWeight: '600' }}>Date</th>
                    <th style={{ padding: '14px 20px', fontWeight: '600', textAlign: 'right' }}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {pastResults.map(r => (
                    <tr key={r.id} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                      <td style={{ padding: '14px 20px', fontWeight: '600' }}>{r.quiz_title}</td>
                      <td style={{ padding: '14px 20px', color: 'var(--text-secondary)' }}>{r.subject_name} ({r.subject_code})</td>
                      <td style={{ padding: '14px 20px', fontWeight: '700', color: 'var(--accent-primary)' }}>
                        {r.total_score} / {r.total_marks}
                      </td>
                      <td style={{ padding: '14px 20px', fontWeight: '700' }}>{r.percentage}%</td>
                      <td style={{ padding: '14px 20px' }}>
                        <span className={`badge ${r.percentage >= 75 ? 'badge-present' : 'badge-active'}`}>
                          {r.performance_level || 'Evaluated'}
                        </span>
                      </td>
                      <td style={{ padding: '14px 20px', color: 'var(--text-muted)', fontSize: '0.8rem' }}>
                        {new Date(r.submitted_at).toLocaleDateString()}
                      </td>
                      <td style={{ padding: '14px 20px', textAlign: 'right' }}>
                        <div style={{ display: 'inline-flex', gap: '8px' }}>
                          <button
                            onClick={() => loadQuizResult(r.quiz_id)}
                            className="btn-secondary"
                            style={{ padding: '6px 12px', fontSize: '0.8rem' }}
                          >
                            <Eye size={14} /> Review
                          </button>
                          <a
                            href={`/api/reports/quiz/${r.quiz_id}?format=pdf&token=${token}`}
                            download
                            className="btn-secondary"
                            style={{ padding: '6px 12px', fontSize: '0.8rem', textDecoration: 'none' }}
                          >
                            <FileDown size={14} /> PDF
                          </a>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* SCAN ATTENDANCE MODAL */}
      {isScannerOpen && selectedSessionForAttendance && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100vw',
          height: '100vh',
          background: 'rgba(0,0,0,0.75)',
          backdropFilter: 'blur(8px)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 9999
        }}>
          <div className="glass-panel" style={{ width: '450px', maxWidth: '90%', padding: '28px', borderRadius: '22px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <div>
                <h3 style={{ fontSize: '1.2rem', fontWeight: '800' }}>Mark Attendance</h3>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                  {selectedSessionForAttendance.subject_name} • Room {selectedSessionForAttendance.room}
                </div>
              </div>
              <button onClick={() => setIsScannerOpen(false)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
                <X size={20} />
              </button>
            </div>

            {scanMessage && (
              <div style={{
                background: scanMessage.success ? 'rgba(16, 185, 129, 0.15)' : 'rgba(239, 68, 68, 0.15)',
                color: scanMessage.success ? '#10b981' : '#ef4444',
                padding: '12px',
                borderRadius: '10px',
                marginBottom: '16px',
                fontSize: '0.85rem',
                fontWeight: '600'
              }}>
                {scanMessage.message}
              </div>
            )}

            {/* Modal Tabs */}
            <div style={{ display: 'flex', gap: '8px', marginBottom: '18px', background: 'var(--bg-tertiary)', padding: '4px', borderRadius: '12px' }}>
              <button
                type="button"
                onClick={() => setModalTab('CODE')}
                style={{
                  flex: 1,
                  padding: '9px 12px',
                  borderRadius: '9px',
                  border: 'none',
                  background: modalTab === 'CODE' ? 'var(--accent-primary)' : 'transparent',
                  color: modalTab === 'CODE' ? '#ffffff' : 'var(--text-secondary)',
                  fontWeight: modalTab === 'CODE' ? '700' : '500',
                  fontSize: '0.85rem',
                  cursor: 'pointer'
                }}
              >
                ⌨️ Enter 6-Digit Code
              </button>
              <button
                type="button"
                onClick={() => setModalTab('SCAN')}
                style={{
                  flex: 1,
                  padding: '9px 12px',
                  borderRadius: '9px',
                  border: 'none',
                  background: modalTab === 'SCAN' ? 'var(--accent-primary)' : 'transparent',
                  color: modalTab === 'SCAN' ? '#ffffff' : 'var(--text-secondary)',
                  fontWeight: modalTab === 'SCAN' ? '700' : '500',
                  fontSize: '0.85rem',
                  cursor: 'pointer'
                }}
              >
                📷 Camera QR Scan
              </button>
            </div>

            {modalTab === 'CODE' ? (
              <div style={{ padding: '20px', background: 'var(--bg-tertiary)', borderRadius: '16px' }}>
                <div style={{ fontSize: '0.825rem', color: 'var(--text-muted)', marginBottom: '12px', textAlign: 'center' }}>
                  Enter the backup attendance code displayed on the instructor's screen:
                </div>
                <div style={{ display: 'flex', gap: '10px' }}>
                  <input
                    type="text"
                    className="input-field"
                    placeholder="e.g. 7X9K2M"
                    maxLength={8}
                    value={manualBackupCode}
                    onChange={e => setManualBackupCode(e.target.value.toUpperCase())}
                    style={{
                      fontFamily: 'var(--font-mono)',
                      fontSize: '1.25rem',
                      letterSpacing: '0.15em',
                      textAlign: 'center',
                      fontWeight: '800'
                    }}
                    autoFocus
                  />
                  <button
                    type="button"
                    onClick={() => handleMarkAttendance({
                      sessionId: selectedSessionForAttendance.id,
                      backupCode: manualBackupCode
                    })}
                    disabled={scanLoading || !manualBackupCode.trim()}
                    className="btn-primary"
                    style={{ padding: '12px 20px', whiteSpace: 'nowrap' }}
                  >
                    {scanLoading ? 'Checking...' : 'Verify'}
                  </button>
                </div>
              </div>
            ) : (
              <div>
                <div id="qr-reader-container" style={{ width: '100%', borderRadius: '12px', overflow: 'hidden', marginBottom: '16px' }} />
                <div style={{ textAlign: 'center', fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                  Point your camera at the rotating QR code on screen
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* QUIZ RESULT MODAL */}
      {selectedResult && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100vw',
          height: '100vh',
          background: 'rgba(0,0,0,0.75)',
          backdropFilter: 'blur(8px)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 9999
        }}>
          <div className="glass-panel" style={{ width: '750px', maxWidth: '90%', maxHeight: '85vh', padding: '30px', borderRadius: '22px', overflowY: 'auto' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
              <div>
                <h3 style={{ fontSize: '1.3rem', fontWeight: '800' }}>Official Examination Result</h3>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>{selectedResult.quiz?.title}</div>
              </div>
              <button onClick={() => setSelectedResult(null)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
                <X size={22} />
              </button>
            </div>

            {selectedResult.status === 'PENDING_RELEASE' ? (
              <div style={{ padding: '40px', textAlign: 'center' }}>
                <Clock size={48} style={{ color: 'var(--accent-primary)', margin: '0 auto 16px' }} />
                <h4 style={{ fontSize: '1.1rem', fontWeight: '700', marginBottom: '8px' }}>Results Pending Official Publication</h4>
                <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>{selectedResult.message}</p>
              </div>
            ) : (
              <div>
                <div style={{
                  padding: '20px',
                  background: 'var(--bg-tertiary)',
                  borderRadius: '16px',
                  display: 'grid',
                  gridTemplateColumns: 'repeat(3, 1fr)',
                  gap: '12px',
                  marginBottom: '24px'
                }}>
                  <div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Marks Obtained</div>
                    <div style={{ fontSize: '1.6rem', fontWeight: '800', color: 'var(--accent-primary)' }}>
                      {selectedResult.attempt?.total_score} / {selectedResult.quiz?.total_marks}
                    </div>
                  </div>
                  <div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Percentage</div>
                    <div style={{ fontSize: '1.6rem', fontWeight: '800' }}>{selectedResult.attempt?.percentage}%</div>
                  </div>
                  <div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Academic Classification</div>
                    <div style={{ fontSize: '1.2rem', fontWeight: '700', color: 'var(--success)' }}>
                      {selectedResult.attempt?.performance_level || 'Developing'}
                    </div>
                  </div>
                </div>

                <div style={{ display: 'flex', gap: '10px', marginBottom: '20px' }}>
                  <a href={`/api/reports/quiz/${selectedResult.quiz.id}?format=pdf&token=${token}`} download className="btn-secondary" style={{ textDecoration: 'none' }}>
                    <FileDown size={14} /> Download PDF Transcript
                  </a>
                </div>

                <h4 style={{ fontSize: '1rem', fontWeight: '700', marginBottom: '12px' }}>Question-Wise Review</h4>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                  {selectedResult.questions?.map((q, qIdx) => (
                    <div key={qIdx} style={{ padding: '16px', background: 'var(--bg-secondary)', borderRadius: '12px', border: '1px solid var(--border-glass)' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
                        <span style={{ fontWeight: '700' }}>Q{qIdx + 1}: {formatAIResponse(q.question)}</span>
                        <span style={{ fontWeight: '700', color: q.is_correct ? 'var(--success)' : 'var(--danger)' }}>
                          {q.awarded_marks} / {q.max_marks}
                        </span>
                      </div>
                      <div style={{ fontSize: '0.825rem', color: 'var(--text-secondary)' }}>
                        <div>Your Answer: <strong>{formatAIResponse(q.student_answer) || '(No answer recorded)'}</strong></div>
                        <div>Correct Answer: <strong>{formatAIResponse(q.correct_answer)}</strong></div>
                        {q.explanation && (
                          <div style={{ marginTop: '6px', color: 'var(--text-muted)', fontStyle: 'italic' }}>
                            Explanation: {formatAIResponse(q.explanation)}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
