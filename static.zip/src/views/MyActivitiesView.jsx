import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNotifications } from '../context/NotificationContext';
import { 
  Calendar, Video, Ticket, Receipt, Users, CheckCircle2, 
  MapPin, Clock, ArrowRight, ShieldCheck, Download, PlusCircle, Megaphone, X 
} from 'lucide-react';

export default function MyActivitiesView({ onNavigate, onViewReceipt, onJoinMeetingWithCode }) {
  const { user, token } = useAuth();
  const { notify } = useNotifications();

  const [activeTab, setActiveTab] = useState('registered'); // 'registered' | 'hosted' | 'meetings'
  const [registrations, setRegistrations] = useState([]);
  const [hostedEvents, setHostedEvents] = useState([]);
  const [meetings, setMeetings] = useState([]);
  const [loading, setLoading] = useState(true);

  // Manage Attendees Modal
  const [selectedEventToManage, setSelectedEventToManage] = useState(null);
  const [attendees, setAttendees] = useState([]);
  const [announcementModalOpen, setAnnouncementModalOpen] = useState(false);
  const [announcementForm, setAnnouncementForm] = useState({ title: '', content: '' });

  useEffect(() => {
    if (!token) return;
    loadActivities();
  }, [token, activeTab]);

  const loadActivities = async () => {
    try {
      setLoading(true);
      if (activeTab === 'registered') {
        const res = await fetch('/api/events/my-registered', {
          headers: { Authorization: `Bearer ${token}` }
        });
        const data = await res.json();
        setRegistrations(data.registrations || []);
      } else if (activeTab === 'hosted') {
        const res = await fetch('/api/events/my-hosted', {
          headers: { Authorization: `Bearer ${token}` }
        });
        const data = await res.json();
        setHostedEvents(data.hosted_events || []);
      } else if (activeTab === 'meetings') {
        const res = await fetch('/api/meetings/history', {
          headers: { Authorization: `Bearer ${token}` }
        });
        const data = await res.json();
        setMeetings(data.history || []);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenAttendees = async (event) => {
    setSelectedEventToManage(event);
    try {
      const res = await fetch(`/api/events/${event.id}/registrations`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      setAttendees(data.registrations || []);
    } catch (e) {
      notify('Failed to load registrations', 'danger');
    }
  };

  const handleToggleCheckin = async (regId) => {
    try {
      const res = await fetch(`/api/events/${selectedEventToManage.id}/registrations/${regId}/checkin`, {
        method: 'PATCH',
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.success) {
        setAttendees(prev => prev.map(a => a.id === regId ? { ...a, attendance_status: data.attendance_status } : a));
        notify(`Attendee check-in status: ${data.attendance_status}`, 'info');
      }
    } catch (e) {}
  };

  const handlePostAnnouncement = async (e) => {
    e.preventDefault();
    if (!announcementForm.title.trim() || !announcementForm.content.trim()) return;

    try {
      const res = await fetch(`/api/events/${selectedEventToManage.id}/announcements`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(announcementForm)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed');

      notify('Announcement published to all attendees!', 'success');
      setAnnouncementModalOpen(false);
      setAnnouncementForm({ title: '', content: '' });
    } catch (err) {
      notify(err.message, 'danger');
    }
  };

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '10px 20px 80px 20px', display: 'flex', flexDirection: 'column', gap: '28px' }}>
      {/* Header */}
      <div style={{
        padding: '30px',
        borderRadius: '20px',
        background: 'linear-gradient(135deg, rgba(79, 70, 229, 0.12), rgba(147, 51, 234, 0.08))',
        border: '1px solid var(--border-glass)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '16px'
      }}>
        <div>
          <span className="badge" style={{ background: 'var(--accent-light)', color: 'var(--accent-primary)', marginBottom: '6px' }}>
            Personal Activity Portal
          </span>
          <h1 style={{ fontSize: '2rem', fontWeight: '800', margin: '4px 0 6px 0' }}>
            My Activities & Registrations
          </h1>
          <p style={{ fontSize: '0.88rem', color: 'var(--text-secondary)', margin: 0 }}>
            Track your registered events, access official receipts, manage hosted symposiums, and review meeting records.
          </p>
        </div>

        <div style={{ display: 'flex', gap: '10px' }}>
          <button
            onClick={() => onNavigate('events')}
            className="btn-primary"
            style={{ padding: '10px 18px', borderRadius: '10px', fontSize: '0.85rem', gap: '6px' }}
          >
            <Calendar size={15} /> Browse Events
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: '10px', borderBottom: '1px solid var(--border-subtle)', paddingBottom: '6px' }}>
        <button
          onClick={() => setActiveTab('registered')}
          style={{
            padding: '8px 16px',
            borderRadius: '10px',
            border: 'none',
            background: activeTab === 'registered' ? 'var(--accent-light)' : 'transparent',
            color: activeTab === 'registered' ? 'var(--accent-primary)' : 'var(--text-secondary)',
            fontWeight: activeTab === 'registered' ? '700' : '500',
            fontSize: '0.9rem',
            cursor: 'pointer'
          }}
        >
          My Registered Events
        </button>

        {user?.role !== 'STUDENT' && (
          <button
            onClick={() => setActiveTab('hosted')}
            style={{
              padding: '8px 16px',
              borderRadius: '10px',
              border: 'none',
              background: activeTab === 'hosted' ? 'var(--accent-light)' : 'transparent',
              color: activeTab === 'hosted' ? 'var(--accent-primary)' : 'var(--text-secondary)',
              fontWeight: activeTab === 'hosted' ? '700' : '500',
              fontSize: '0.9rem',
              cursor: 'pointer'
            }}
          >
            Events Hosted by Me
          </button>
        )}

        <button
          onClick={() => setActiveTab('meetings')}
          style={{
            padding: '8px 16px',
            borderRadius: '10px',
            border: 'none',
            background: activeTab === 'meetings' ? 'var(--accent-light)' : 'transparent',
            color: activeTab === 'meetings' ? 'var(--accent-primary)' : 'var(--text-secondary)',
            fontWeight: activeTab === 'meetings' ? '700' : '500',
            fontSize: '0.9rem',
            cursor: 'pointer'
          }}
        >
          Meeting History
        </button>
      </div>

      {/* Content Area */}
      {loading ? (
        <div style={{ textAlign: 'center', padding: '60px', color: 'var(--text-muted)' }}>
          Loading your activities...
        </div>
      ) : activeTab === 'registered' ? (
        /* Tab 1: Registered Events */
        registrations.length === 0 ? (
          <div style={{ padding: '50px 20px', textAlign: 'center', background: 'var(--bg-secondary)', borderRadius: '18px', border: '1px solid var(--border-glass)' }}>
            <Ticket size={40} style={{ opacity: 0.3, marginBottom: '12px' }} />
            <h4>No Event Registrations Yet</h4>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '4px' }}>
              Explore upcoming symposiums and workshops to register and earn certificates.
            </p>
            <button onClick={() => onNavigate('events')} className="btn-primary" style={{ marginTop: '16px', padding: '10px 20px' }}>
              Explore Events Catalog
            </button>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            {registrations.map(r => (
              <div
                key={r.id}
                className="glass-panel"
                style={{
                  padding: '22px',
                  borderRadius: '16px',
                  background: 'var(--bg-secondary)',
                  border: '1px solid var(--border-glass)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  flexWrap: 'wrap',
                  gap: '16px'
                }}
              >
                <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
                  {r.banner_url && (
                    <img
                      src={r.banner_url}
                      alt={r.event_title}
                      style={{ width: '90px', height: '70px', borderRadius: '10px', objectFit: 'cover' }}
                    />
                  )}
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
                      <span className="badge badge-present" style={{ fontSize: '0.72rem' }}>
                        CONFIRMED PASS
                      </span>
                      <span style={{ fontSize: '0.75rem', fontFamily: 'var(--font-mono)', color: 'var(--text-muted)' }}>
                        {r.registration_number}
                      </span>
                    </div>

                    <h3 style={{ fontSize: '1.15rem', margin: '2px 0 6px 0' }}>{r.event_title}</h3>

                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '14px', fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                      <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                        <Calendar size={13} style={{ color: 'var(--accent-primary)' }} />
                        {new Date(r.event_date).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })} at {r.start_time}
                      </span>
                      <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                        <MapPin size={13} style={{ color: '#06b6d4' }} />
                        {r.venue_type === 'ONLINE' ? 'Virtual Classroom' : (r.venue_address || 'Main Campus')}
                      </span>
                      <span>Tier: <strong style={{ color: 'var(--text-primary)' }}>{r.ticket_name}</strong></span>
                    </div>
                  </div>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
                  <button
                    onClick={() => {
                      if (onViewReceipt) {
                        onViewReceipt({
                          registration_number: r.registration_number,
                          receipt_number: r.receipt_number,
                          ticket_name: r.ticket_name,
                          ticket_price: r.ticket_price,
                          paid_amount: r.ticket_price,
                          amount: r.ticket_price,
                          participant_name: r.participant_name,
                          participant_email: r.participant_email,
                          participant_phone: r.participant_phone,
                          event_title: r.event_title,
                          event_date: r.event_date,
                          start_time: r.start_time,
                          venue_type: r.venue_type,
                          venue_address: r.venue_address,
                          organizer_name: r.organizer_name,
                          provider: r.payment_method || 'Complimentary'
                        });
                      }
                    }}
                    className="btn-secondary"
                    style={{ padding: '8px 14px', fontSize: '0.84rem', gap: '6px' }}
                  >
                    <Receipt size={14} /> View Receipt
                  </button>

                  {r.online_meeting_url && (
                    <button
                      onClick={() => onJoinMeetingWithCode && onJoinMeetingWithCode(r.online_meeting_url)}
                      className="btn-primary"
                      style={{ padding: '8px 16px', fontSize: '0.84rem', gap: '6px' }}
                    >
                      <Video size={14} /> Join Session
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )
      ) : activeTab === 'hosted' ? (
        /* Tab 2: Hosted Events */
        hostedEvents.length === 0 ? (
          <div style={{ padding: '50px 20px', textAlign: 'center', background: 'var(--bg-secondary)', borderRadius: '18px', border: '1px solid var(--border-glass)' }}>
            <Calendar size={40} style={{ opacity: 0.3, marginBottom: '12px' }} />
            <h4>No Events Hosted Yet</h4>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '4px' }}>
              Publish an academic workshop or conference to manage attendee tickets and check-ins.
            </p>
            <button onClick={() => onNavigate('host-event')} className="btn-primary" style={{ marginTop: '16px', padding: '10px 20px' }}>
              Host an Event Now
            </button>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            {hostedEvents.map(ev => (
              <div
                key={ev.id}
                className="glass-panel"
                style={{
                  padding: '22px',
                  borderRadius: '16px',
                  background: 'var(--bg-secondary)',
                  border: '1px solid var(--border-glass)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  flexWrap: 'wrap',
                  gap: '16px'
                }}
              >
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
                    <span className="badge" style={{ background: 'var(--accent-light)', color: 'var(--accent-primary)', fontSize: '0.72rem' }}>
                      {ev.category}
                    </span>
                    <span className="badge" style={{ background: ev.status === 'PUBLISHED' ? 'rgba(16, 185, 129, 0.15)' : 'rgba(245, 158, 11, 0.15)', color: ev.status === 'PUBLISHED' ? '#10b981' : '#f59e0b' }}>
                      {ev.status}
                    </span>
                  </div>

                  <h3 style={{ fontSize: '1.2rem', margin: '2px 0 6px 0' }}>{ev.title}</h3>

                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '14px', fontSize: '0.82rem', color: 'var(--text-muted)' }}>
                    <span>Date: {ev.event_date} ({ev.start_time} - {ev.end_time})</span>
                    <span>Total Registrations: <strong style={{ color: 'var(--text-primary)' }}>{ev.total_attendees || 0}</strong> / {ev.max_capacity}</span>
                    <span>Revenue: <strong style={{ color: 'var(--success)' }}>₹{ev.total_revenue || 0}</strong></span>
                  </div>
                </div>

                <div style={{ display: 'flex', gap: '10px' }}>
                  <button
                    onClick={() => handleOpenAttendees(ev)}
                    className="btn-primary"
                    style={{ padding: '8px 16px', fontSize: '0.85rem', gap: '6px' }}
                  >
                    <Users size={14} /> Manage Attendees
                  </button>
                </div>
              </div>
            ))}
          </div>
        )
      ) : (
        /* Tab 3: Meetings History */
        meetings.length === 0 ? (
          <div style={{ padding: '40px', textAlign: 'center', color: 'var(--text-muted)' }}>
            No meeting records found.
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {meetings.map(m => (
              <div
                key={m.id}
                style={{
                  padding: '16px 20px',
                  borderRadius: '14px',
                  background: 'var(--bg-secondary)',
                  border: '1px solid var(--border-subtle)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  flexWrap: 'wrap',
                  gap: '12px'
                }}
              >
                <div>
                  <h4 style={{ fontSize: '1rem', margin: 0 }}>{m.title}</h4>
                  <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginTop: '2px' }}>
                    Host: {m.host_name} • Code: <strong style={{ fontFamily: 'var(--font-mono)' }}>{m.code}</strong> • {new Date(m.created_at).toLocaleDateString()}
                  </div>
                </div>

                <button
                  onClick={() => onJoinMeetingWithCode && onJoinMeetingWithCode(m.code)}
                  className="btn-secondary"
                  style={{ padding: '8px 14px', fontSize: '0.82rem', gap: '6px' }}
                >
                  <Video size={14} /> Reopen Room
                </button>
              </div>
            ))}
          </div>
        )
      )}

      {/* Organizer Attendees Management Modal */}
      {selectedEventToManage && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0, 0, 0, 0.65)',
          backdropFilter: 'blur(4px)',
          zIndex: 1100,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '20px'
        }} onClick={() => setSelectedEventToManage(null)}>
          <div 
            onClick={e => e.stopPropagation()}
            className="glass-panel"
            style={{
              width: '100%',
              maxWidth: '750px',
              maxHeight: '90vh',
              borderRadius: '20px',
              background: 'var(--bg-secondary)',
              border: '1px solid var(--border-glass)',
              boxShadow: 'var(--shadow-card)',
              overflow: 'hidden',
              display: 'flex',
              flexDirection: 'column'
            }}
          >
            {/* Modal Header */}
            <div style={{
              padding: '20px 24px',
              borderBottom: '1px solid var(--border-subtle)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              background: 'var(--bg-tertiary)'
            }}>
              <div>
                <h3 style={{ fontSize: '1.15rem', margin: 0 }}>Attendee Management</h3>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                  {selectedEventToManage.title} ({attendees.length} Attendees)
                </div>
              </div>
              <div style={{ display: 'flex', gap: '8px' }}>
                <button
                  onClick={() => setAnnouncementModalOpen(true)}
                  className="btn-secondary"
                  style={{ padding: '6px 12px', fontSize: '0.8rem', gap: '6px' }}
                >
                  <Megaphone size={14} /> Send Announcement
                </button>
                <button
                  onClick={() => setSelectedEventToManage(null)}
                  className="btn-secondary"
                  style={{ padding: '6px', borderRadius: '8px' }}
                >
                  <X size={16} />
                </button>
              </div>
            </div>

            {/* Attendees Table */}
            <div style={{ flex: 1, overflowY: 'auto', padding: '20px' }}>
              {attendees.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '40px', color: 'var(--text-muted)' }}>
                  No participants have registered for this event yet.
                </div>
              ) : (
                <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.85rem' }}>
                  <thead>
                    <tr style={{ borderBottom: '2px solid var(--border-glass)', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase' }}>
                      <th style={{ padding: '8px' }}>Attendee</th>
                      <th style={{ padding: '8px' }}>Pass & Price</th>
                      <th style={{ padding: '8px' }}>Status</th>
                      <th style={{ padding: '8px', textAlign: 'center' }}>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {attendees.map(a => {
                      const isCheckedIn = a.attendance_status === 'CHECKED_IN';
                      return (
                        <tr key={a.id} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                          <td style={{ padding: '12px 8px' }}>
                            <div style={{ fontWeight: '600' }}>{a.participant_name}</div>
                            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{a.participant_email}</div>
                            <div style={{ fontSize: '0.72rem', fontFamily: 'var(--font-mono)', color: 'var(--accent-primary)' }}>{a.registration_number}</div>
                          </td>
                          <td style={{ padding: '12px 8px' }}>
                            <div>{a.ticket_name}</div>
                            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>₹{a.ticket_price} ({a.payment_status})</div>
                          </td>
                          <td style={{ padding: '12px 8px' }}>
                            <span className={isCheckedIn ? "badge badge-present" : "badge"}>
                              {isCheckedIn ? 'Checked In' : 'Registered'}
                            </span>
                          </td>
                          <td style={{ padding: '12px 8px', textAlign: 'center' }}>
                            <button
                              onClick={() => handleToggleCheckin(a.id)}
                              className="btn-secondary"
                              style={{ padding: '5px 10px', fontSize: '0.78rem' }}
                            >
                              {isCheckedIn ? 'Undo Check-in' : 'Mark Present'}
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Broadcast Announcement Modal */}
      {announcementModalOpen && selectedEventToManage && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0, 0, 0, 0.7)',
          zIndex: 1200,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '20px'
        }} onClick={() => setAnnouncementModalOpen(false)}>
          <div 
            onClick={e => e.stopPropagation()}
            className="glass-panel"
            style={{ width: '100%', maxWidth: '480px', borderRadius: '18px', background: 'var(--bg-secondary)', padding: '24px' }}
          >
            <h3 style={{ fontSize: '1.15rem', marginBottom: '14px' }}>Broadcast Announcement</h3>
            <form onSubmit={handlePostAnnouncement} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div>
                <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Announcement Title</label>
                <input
                  type="text"
                  required
                  value={announcementForm.title}
                  onChange={e => setAnnouncementForm({ ...announcementForm, title: e.target.value })}
                  className="input-field"
                  placeholder="e.g. Schedule Update or Lab Materials Link"
                />
              </div>
              <div>
                <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Message Content</label>
                <textarea
                  rows={3}
                  required
                  value={announcementForm.content}
                  onChange={e => setAnnouncementForm({ ...announcementForm, content: e.target.value })}
                  className="input-field"
                  placeholder="Details to notify all registered attendees..."
                />
              </div>
              <div style={{ display: 'flex', gap: '10px', marginTop: '10px' }}>
                <button type="submit" className="btn-primary" style={{ flex: 1, padding: '10px' }}>
                  Send Announcement
                </button>
                <button type="button" onClick={() => setAnnouncementModalOpen(false)} className="btn-secondary" style={{ flex: 1, padding: '10px' }}>
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
