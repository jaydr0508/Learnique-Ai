import io
from pathlib import Path
from typing import Tuple
from pypdf import PdfReader
from docx import Document

def extract_text_from_file(file_storage, filename: str) -> Tuple[bool, str, str]:
    """
    Extract readable text from uploaded PDF, DOCX, or TXT file.
    Returns: (success: bool, extracted_text: str, document_category: str)
    """
    ext = Path(filename).suffix.lower()
    extracted_text = ""

    try:
        if ext == ".pdf":
            file_bytes = file_storage.read()
            reader = PdfReader(io.BytesIO(file_bytes))
            text_parts = []
            for page in reader.pages:
                t = page.extract_text()
                if t:
                    text_parts.append(t)
            extracted_text = "\n\n".join(text_parts)

        elif ext in (".docx", ".doc"):
            file_bytes = file_storage.read()
            doc = Document(io.BytesIO(file_bytes))
            text_parts = [p.text for p in doc.paragraphs if p.text.strip()]
            extracted_text = "\n".join(text_parts)

        elif ext in (".txt", ".md", ".json", ".csv"):
            file_bytes = file_storage.read()
            extracted_text = file_bytes.decode("utf-8", errors="replace")

        else:
            return False, "", f"Unsupported file extension: {ext}. Please upload a PDF, DOCX, or TXT file."

        if not extracted_text.strip():
            return False, "", "The uploaded document contains no readable text."

        # Analyze whether document appears to be reference notes or existing exam questions
        lower_sample = extracted_text[:2000].lower()
        if any(marker in lower_sample for marker in ["q1.", "question 1", "marks:", "choose the correct", "opt a", "opt b"]):
            category = "QUESTION_PAPER"
        else:
            category = "EDUCATIONAL_REFERENCE"

        return True, extracted_text.strip(), category

    except Exception as e:
        return False, "", f"Error reading document: {str(e)}"
