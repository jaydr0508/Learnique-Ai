import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNotifications } from '../context/NotificationContext';
import { Ticket, CreditCard, CheckCircle2, ShieldCheck, AlertCircle, X, ArrowRight, Loader2, QrCode } from 'lucide-react';

export default function EventRegistrationModal({ isOpen, onClose, event, onRegistered, onViewReceipt }) {
  const { user, token } = useAuth();
  const { notify } = useNotifications();

  const [selectedTicket, setSelectedTicket] = useState(null);
  const [formData, setFormData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: user?.phone || '',
    notes: ''
  });
  const [step, setStep] = useState('FORM'); // 'FORM' | 'PAYMENT' | 'SUCCESS'
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [paymentData, setPaymentData] = useState(null);
  const [confirmedRecord, setConfirmedRecord] = useState(null);

  // Initialize selected ticket
  React.useEffect(() => {
    if (event?.tickets?.length > 0) {
      setSelectedTicket(event.tickets[0]);
    }
  }, [event]);

  React.useEffect(() => {
    if (user) {
      setFormData(prev => ({
        ...prev,
        name: prev.name || user.name || '',
        email: prev.email || user.email || '',
        phone: prev.phone || user.phone || ''
      }));
    }
  }, [user]);

  if (!isOpen || !event) return null;

  const handleSubmitRegistration = async (e) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.email.trim()) {
      setError('Please provide your name and a valid email address.');
      return;
    }

    try {
      setLoading(true);
      setError(null);

      const res = await fetch(`/api/events/${event.id}/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify({
          participant_name: formData.name.trim(),
          participant_email: formData.email.trim(),
          participant_phone: formData.phone.trim(),
          notes: formData.notes.trim(),
          ticket_id: selectedTicket?.id
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to complete registration');
      }

      if (data.requires_payment) {
        // Proceed to Payment Step
        setPaymentData(data);
        setStep('PAYMENT');
      } else {
        // Free ticket directly confirmed!
        setConfirmedRecord({
          registration_number: data.registration_number,
          receipt_number: data.receipt_number,
          ticket_name: selectedTicket?.name || 'General Admission',
          ticket_price: 0,
          participant_name: formData.name,
          participant_email: formData.email,
          event_title: event.title,
          event_date: event.event_date,
          start_time: event.start_time,
          venue_type: event.venue_type,
          venue_address: event.venue_address
        });
        setStep('SUCCESS');
        notify('Registration confirmed successfully!', 'success');
        if (onRegistered) onRegistered(data);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSimulatedPayment = async (method = 'RAZORPAY_SANDBOX') => {
    try {
      setLoading(true);
      setError(null);

      // Simulate payment authorization
      const paymentId = `pay_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      const signature = `sig_${Math.random().toString(36).substring(2, 10)}`;

      const res = await fetch(`/api/events/${event.id}/verify-payment`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify({
          order_id: paymentData.order_id,
          payment_id: paymentId,
          signature: signature,
          registration_number: paymentData.registration_number
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Payment verification failed');
      }

      setConfirmedRecord({
        registration_number: data.registration_number,
        receipt_number: data.receipt_number,
        ticket_name: paymentData.ticket_name,
        ticket_price: paymentData.amount,
        amount: paymentData.amount,
        participant_name: formData.name,
        participant_email: formData.email,
        event_title: event.title,
        event_date: event.event_date,
        start_time: event.start_time,
        venue_type: event.venue_type,
        venue_address: event.venue_address,
        provider: 'RAZORPAY',
        transaction_id: paymentId
      });
      setStep('SUCCESS');
      notify('Payment verified and registration confirmed!', 'success');
      if (onRegistered) onRegistered(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: 'rgba(0, 0, 0, 0.7)',
      backdropFilter: 'blur(5px)',
      zIndex: 1050,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '20px'
    }} onClick={onClose}>
      <div 
        onClick={e => e.stopPropagation()}
        className="glass-panel"
        style={{
          width: '100%',
          maxWidth: '560px',
          maxHeight: '90vh',
          borderRadius: '20px',
          background: 'var(--bg-secondary)',
          border: '1px solid var(--border-glass)',
          boxShadow: 'var(--shadow-card)',
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column'
        }}
      >
        {/* Header */}
        <div style={{
          padding: '20px 24px',
          borderBottom: '1px solid var(--border-subtle)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          background: 'var(--bg-tertiary)'
        }}>
          <div>
            <h3 style={{ fontSize: '1.15rem', margin: 0 }}>
              {step === 'SUCCESS' ? 'Registration Confirmed!' : `Register for ${event.title}`}
            </h3>
            <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginTop: '2px' }}>
              {event.event_date} • {event.venue_type === 'ONLINE' ? 'Virtual Classroom' : (event.venue_address || 'Main Campus')}
            </div>
          </div>
          <button onClick={onClose} className="btn-secondary" style={{ padding: '8px', borderRadius: '10px' }}>
            <X size={18} />
          </button>
        </div>

        {/* Modal Content */}
        <div style={{ padding: '24px', overflowY: 'auto', flex: 1 }}>
          {error && (
            <div style={{
              padding: '12px 16px',
              borderRadius: '10px',
              background: 'rgba(239, 68, 68, 0.12)',
              border: '1px solid rgba(239, 68, 68, 0.3)',
              color: '#ef4444',
              fontSize: '0.85rem',
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
              marginBottom: '18px'
            }}>
              <AlertCircle size={18} />
              <span>{error}</span>
            </div>
          )}

          {step === 'FORM' && (
            <form onSubmit={handleSubmitRegistration} style={{ display: 'flex', flexDirection: 'column', gap: '18px' }}>
              {/* Ticket Selection */}
              <div>
                <label style={{ fontSize: '0.82rem', fontWeight: '700', color: 'var(--text-muted)', textTransform: 'uppercase', marginBottom: '8px', display: 'block' }}>
                  Select Ticket Type
                </label>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  {(event.tickets || []).map(t => {
                    const isSelected = selectedTicket?.id === t.id;
                    return (
                      <div
                        key={t.id}
                        onClick={() => setSelectedTicket(t)}
                        style={{
                          padding: '12px 16px',
                          borderRadius: '12px',
                          border: isSelected ? '2px solid var(--accent-primary)' : '1px solid var(--border-subtle)',
                          background: isSelected ? 'var(--accent-light)' : 'var(--bg-surface)',
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                          transition: 'all var(--transition-fast)'
                        }}
                      >
                        <div>
                          <div style={{ fontWeight: '600', fontSize: '0.92rem' }}>{t.name}</div>
                          <div style={{ fontSize: '0.78rem', color: 'var(--text-secondary)' }}>{t.description || 'Access to all event sessions'}</div>
                        </div>
                        <div style={{ textAlign: 'right' }}>
                          <span style={{
                            fontWeight: '800',
                            fontSize: '1rem',
                            color: t.price === 0 ? 'var(--success)' : 'var(--accent-primary)'
                          }}>
                            {t.price === 0 ? 'FREE' : `₹${t.price}`}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Attendee Details */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                <div>
                  <label style={{ fontSize: '0.8rem', fontWeight: '600', color: 'var(--text-secondary)', marginBottom: '4px', display: 'block' }}>
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={e => setFormData({ ...formData, name: e.target.value })}
                    className="input-field"
                    placeholder="Enter your name"
                  />
                </div>

                <div>
                  <label style={{ fontSize: '0.8rem', fontWeight: '600', color: 'var(--text-secondary)', marginBottom: '4px', display: 'block' }}>
                    Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={e => setFormData({ ...formData, email: e.target.value })}
                    className="input-field"
                    placeholder="name@university.edu"
                  />
                </div>

                <div>
                  <label style={{ fontSize: '0.8rem', fontWeight: '600', color: 'var(--text-secondary)', marginBottom: '4px', display: 'block' }}>
                    Mobile Number (Optional)
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={e => setFormData({ ...formData, phone: e.target.value })}
                    className="input-field"
                    placeholder="+91 98765 43210"
                  />
                </div>

                <div>
                  <label style={{ fontSize: '0.8rem', fontWeight: '600', color: 'var(--text-secondary)', marginBottom: '4px', display: 'block' }}>
                    Questions / Special Requirements
                  </label>
                  <textarea
                    rows={2}
                    value={formData.notes}
                    onChange={e => setFormData({ ...formData, notes: e.target.value })}
                    className="input-field"
                    placeholder="E.g. dietary preference, accessibility, project queries..."
                  />
                </div>
              </div>

              {/* Submit CTA */}
              <button
                type="submit"
                disabled={loading}
                className="btn-primary"
                style={{
                  padding: '14px',
                  borderRadius: '12px',
                  fontSize: '0.95rem',
                  fontWeight: '700',
                  marginTop: '10px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '8px'
                }}
              >
                {loading ? (
                  <>
                    <Loader2 size={18} className="animate-spin" /> Processing...
                  </>
                ) : selectedTicket?.price === 0 ? (
                  <>
                    <ShieldCheck size={18} /> Confirm Free Registration
                  </>
                ) : (
                  <>
                    <CreditCard size={18} /> Proceed to Pay ₹{selectedTicket?.price}
                  </>
                )}
              </button>
            </form>
          )}

          {step === 'PAYMENT' && paymentData && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              <div style={{
                padding: '16px 20px',
                borderRadius: '14px',
                background: 'var(--bg-surface)',
                border: '1px solid var(--border-glass)',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center'
              }}>
                <div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Amount to Pay</div>
                  <div style={{ fontSize: '1.5rem', fontWeight: '800', color: 'var(--accent-primary)' }}>
                    ₹{paymentData.amount}.00
                  </div>
                  <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
                    {paymentData.ticket_name} • Order: {paymentData.order_id}
                  </div>
                </div>
                <div style={{
                  padding: '8px 12px',
                  borderRadius: '10px',
                  background: 'rgba(59, 130, 246, 0.1)',
                  color: '#3b82f6',
                  fontSize: '0.78rem',
                  fontWeight: '600'
                }}>
                  Razorpay Secured
                </div>
              </div>

              <div>
                <label style={{ fontSize: '0.85rem', fontWeight: '600', marginBottom: '10px', display: 'block' }}>
                  Select Payment Method:
                </label>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                  <button
                    onClick={() => handleSimulatedPayment('UPI')}
                    disabled={loading}
                    className="btn-secondary"
                    style={{
                      padding: '14px 16px',
                      borderRadius: '12px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      textAlign: 'left'
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                      <CreditCard size={20} style={{ color: 'var(--accent-primary)' }} />
                      <div>
                        <div style={{ fontWeight: '600', fontSize: '0.9rem' }}>UPI / QR Code Instant Pay</div>
                        <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Google Pay, PhonePe, Paytm, BHIM</div>
                      </div>
                    </div>
                    <ArrowRight size={16} />
                  </button>

                  <button
                    onClick={() => handleSimulatedPayment('CARD')}
                    disabled={loading}
                    className="btn-secondary"
                    style={{
                      padding: '14px 16px',
                      borderRadius: '12px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      textAlign: 'left'
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                      <CreditCard size={20} style={{ color: '#06b6d4' }} />
                      <div>
                        <div style={{ fontWeight: '600', fontSize: '0.9rem' }}>Credit / Debit Card</div>
                        <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Visa, MasterCard, RuPay</div>
                      </div>
                    </div>
                    <ArrowRight size={16} />
                  </button>

                  <button
                    onClick={() => handleSimulatedPayment('SANDBOX_TEST')}
                    disabled={loading}
                    className="btn-primary"
                    style={{
                      padding: '14px 16px',
                      borderRadius: '12px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      background: 'linear-gradient(135deg, var(--success), #059669)'
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                      <CheckCircle2 size={20} />
                      <div>
                        <div style={{ fontWeight: '700', fontSize: '0.9rem' }}>Instant Test Verification (Sandbox)</div>
                        <div style={{ fontSize: '0.75rem', opacity: 0.9 }}>Simulate verified payment and produce real receipt</div>
                      </div>
                    </div>
                    <ArrowRight size={16} />
                  </button>
                </div>
              </div>

              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textAlign: 'center', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}>
                <ShieldCheck size={14} style={{ color: 'var(--success)' }} />
                256-bit encrypted server verification. No card numbers or passwords stored.
              </div>
            </div>
          )}

          {step === 'SUCCESS' && confirmedRecord && (
            <div style={{ textAlign: 'center', padding: '10px 0' }}>
              <div style={{
                width: '64px',
                height: '64px',
                borderRadius: '50%',
                background: 'rgba(16, 185, 129, 0.15)',
                color: 'var(--success)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 16px auto'
              }}>
                <CheckCircle2 size={36} />
              </div>

              <h4 style={{ fontSize: '1.25rem', marginBottom: '6px' }}>You are officially registered!</h4>
              <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', maxWidth: '400px', margin: '0 auto 20px auto' }}>
                A confirmation alert has been generated. Your registration details and entry pass are ready below.
              </p>

              <div style={{
                padding: '16px',
                borderRadius: '14px',
                background: 'var(--bg-surface)',
                border: '1px solid var(--border-glass)',
                marginBottom: '24px',
                textAlign: 'left'
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                  <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>Registration Number:</span>
                  <span style={{ fontSize: '0.85rem', fontFamily: 'var(--font-mono)', fontWeight: '700' }}>
                    {confirmedRecord.registration_number}
                  </span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                  <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>Receipt Number:</span>
                  <span style={{ fontSize: '0.85rem', fontFamily: 'var(--font-mono)', fontWeight: '700', color: 'var(--accent-primary)' }}>
                    {confirmedRecord.receipt_number}
                  </span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>Ticket Tier:</span>
                  <span style={{ fontSize: '0.85rem', fontWeight: '600' }}>
                    {confirmedRecord.ticket_name} ({confirmedRecord.ticket_price === 0 ? 'FREE' : `₹${confirmedRecord.ticket_price}`})
                  </span>
                </div>
              </div>

              <div style={{ display: 'flex', gap: '10px' }}>
                <button
                  onClick={() => {
                    onClose();
                    if (onViewReceipt) onViewReceipt(confirmedRecord);
                  }}
                  className="btn-primary"
                  style={{ flex: 1, padding: '12px', fontSize: '0.88rem' }}
                >
                  View & Download Receipt
                </button>
                <button
                  onClick={onClose}
                  className="btn-secondary"
                  style={{ flex: 1, padding: '12px', fontSize: '0.88rem' }}
                >
                  Done
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
