from datetime import datetime
from flask import Blueprint, request, jsonify, send_file, Response, g
import io
from backend.auth.routes import require_auth
from backend.database.db import query_one, query_all
from backend.attendance.service import calculate_student_attendance
from backend.quiz.service import classify_performance
from backend.reports.generator import (
    generate_pdf_report,
    generate_docx_report,
    generate_csv_report,
    generate_excel_report
)

reports_bp = Blueprint("reports", __name__)

@reports_bp.route("/quiz/<int:quiz_id>", methods=["GET"])
@require_auth(["TEACHER", "ADMIN"])
def export_quiz_report(quiz_id: int):
    """Export comprehensive quiz results in PDF, DOCX, CSV, or Excel."""
    fmt = request.args.get("format", "pdf").lower()
    quiz = query_one(
        """
        SELECT q.*, s.name as subject_name, s.code as subject_code,
               d.name as division_name, u.full_name as teacher_name
        FROM quizzes q
        JOIN subjects s ON q.subject_id = s.id
        JOIN divisions d ON q.division_id = d.id
        JOIN teachers t ON q.teacher_id = t.id
        JOIN users u ON t.user_id = u.id
        WHERE q.id = ?
        """,
        (quiz_id,)
    )
    if not quiz:
        return jsonify({"success": False, "error": "Quiz not found"}), 404

    attempts = query_all(
        """
        SELECT a.*, st.enrollment_no, u.full_name as student_name, b.name as batch_name
        FROM quiz_attempts a
        JOIN students st ON a.student_id = st.id
        JOIN users u ON st.user_id = u.id
        JOIN batches b ON st.batch_id = b.id
        WHERE a.quiz_id = ?
        ORDER BY a.total_score DESC
        """,
        (quiz_id,)
    )

    metadata = [
        ("Quiz Title", quiz["title"]),
        ("Quiz Code", quiz["code"]),
        ("Subject", f"{quiz['subject_name']} ({quiz['subject_code']})"),
        ("Faculty", quiz["teacher_name"]),
        ("Division", quiz["division_name"]),
        ("Total Marks", str(quiz["total_marks"])),
        ("Passing Marks", str(quiz["passing_marks"])),
        ("Generated At", datetime.now().strftime("%Y-%m-%d %H:%M"))
    ]

    headers = ["Rank", "Enrollment", "Student Name", "Batch", "Score", "Percentage", "Status", "Classification", "Violations"]
    rows = []
    for rank, att in enumerate(attempts, 1):
        pct = round((att["total_score"] / quiz["total_marks"] * 100), 2) if quiz["total_marks"] > 0 else 0.0
        rows.append([
            rank,
            att["enrollment_no"],
            att["student_name"],
            att["batch_name"],
            f"{att['total_score']}/{quiz['total_marks']}",
            f"{pct}%",
            att["status"],
            classify_performance(pct),
            att["violations_count"]
        ])

    title = f"EXAMINATION REPORT: {quiz['title']}"
    subtitle = f"Official Academic Result Summary"

    if fmt == "pdf":
        pdf_bytes = generate_pdf_report(title, subtitle, metadata, headers, rows)
        return send_file(
            io.BytesIO(pdf_bytes),
            mimetype="application/pdf",
            as_attachment=True,
            download_name=f"QuizReport_{quiz['code']}.pdf"
        )
    elif fmt == "docx":
        docx_bytes = generate_docx_report(title, subtitle, metadata, headers, rows)
        return send_file(
            io.BytesIO(docx_bytes),
            mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            as_attachment=True,
            download_name=f"QuizReport_{quiz['code']}.docx"
        )
    elif fmt in ("xlsx", "excel"):
        xlsx_bytes = generate_excel_report(quiz["code"], headers, rows)
        return send_file(
            io.BytesIO(xlsx_bytes),
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            as_attachment=True,
            download_name=f"QuizReport_{quiz['code']}.xlsx"
        )
    else:
        # CSV
        csv_str = generate_csv_report(headers, rows)
        return Response(
            csv_str,
            mimetype="text/csv",
            headers={"Content-Disposition": f"attachment; filename=QuizReport_{quiz['code']}.csv"}
        )

@reports_bp.route("/attendance", methods=["GET"])
@require_auth(["TEACHER", "ADMIN"])
def export_attendance_report():
    """Export attendance summary for a division/subject."""
    fmt = request.args.get("format", "pdf").lower()
    division_id = request.args.get("division_id")
    subject_id = request.args.get("subject_id")

    if not division_id or not subject_id:
        return jsonify({"success": False, "error": "division_id and subject_id are required"}), 400

    div = query_one("SELECT name, semester, branch FROM divisions WHERE id = ?", (division_id,))
    sub = query_one("SELECT code, name FROM subjects WHERE id = ?", (subject_id,))
    if not div or not sub:
        return jsonify({"success": False, "error": "Division or Subject not found"}), 404

    students = query_all(
        """
        SELECT s.id, s.enrollment_no, u.full_name, b.name as batch_name
        FROM students s
        JOIN users u ON s.user_id = u.id
        JOIN batches b ON s.batch_id = b.id
        WHERE s.division_id = ? AND u.is_active = 1
        ORDER BY s.enrollment_no ASC
        """,
        (division_id,)
    )

    metadata = [
        ("Subject", f"{sub['name']} ({sub['code']})"),
        ("Division", div["name"]),
        ("Branch", div["branch"]),
        ("Semester", str(div["semester"])),
        ("Report Date", datetime.now().strftime("%Y-%m-%d %H:%M"))
    ]

    headers = ["Enrollment", "Student Name", "Batch", "Theory (Att/Tot)", "Theory %", "Practical (Att/Tot)", "Practical %", "Overall %"]
    rows = []

    for stu in students:
        stats = calculate_student_attendance(stu["id"])
        sub_stat = next((s for s in stats["subjects"] if s["subject_id"] == int(subject_id)), None)
        if sub_stat:
            th = sub_stat["theory"]
            pr = sub_stat["practical"]
            ov = sub_stat["overall"]
            rows.append([
                stu["enrollment_no"],
                stu["full_name"],
                stu["batch_name"],
                f"{th['present']}/{th['total']}",
                f"{th['percentage']}%",
                f"{pr['present']}/{pr['total']}",
                f"{pr['percentage']}%",
                f"{ov['percentage']}%"
            ])
        else:
            rows.append([stu["enrollment_no"], stu["full_name"], stu["batch_name"], "0/0", "0%", "0/0", "0%", "0%"])

    title = f"ATTENDANCE REPORT: {sub['code']}"
    subtitle = f"Division {div['name']} Attendance Roster"

    if fmt == "pdf":
        pdf_bytes = generate_pdf_report(title, subtitle, metadata, headers, rows)
        return send_file(
            io.BytesIO(pdf_bytes),
            mimetype="application/pdf",
            as_attachment=True,
            download_name=f"Attendance_{sub['code']}_{div['name']}.pdf"
        )
    elif fmt == "docx":
        docx_bytes = generate_docx_report(title, subtitle, metadata, headers, rows)
        return send_file(
            io.BytesIO(docx_bytes),
            mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            as_attachment=True,
            download_name=f"Attendance_{sub['code']}_{div['name']}.docx"
        )
    elif fmt in ("xlsx", "excel"):
        xlsx_bytes = generate_excel_report(f"Att_{sub['code']}", headers, rows)
        return send_file(
            io.BytesIO(xlsx_bytes),
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            as_attachment=True,
            download_name=f"Attendance_{sub['code']}_{div['name']}.xlsx"
        )
    else:
        csv_str = generate_csv_report(headers, rows)
        return Response(
            csv_str,
            mimetype="text/csv",
            headers={"Content-Disposition": f"attachment; filename=Attendance_{sub['code']}_{div['name']}.csv"}
        )
