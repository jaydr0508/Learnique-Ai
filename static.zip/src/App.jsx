import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';
import { NotificationProvider, useNotifications } from './context/NotificationContext';
import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';

// Views
import HomeView from './views/HomeView';
import EventsListView from './views/EventsListView';
import EventDetailView from './views/EventDetailView';
import HostEventView from './views/HostEventView';
import MeetingsDashboardView from './views/MeetingsDashboardView';
import MeetingLobbyView from './views/MeetingLobbyView';
import LiveMeetingRoomView from './views/LiveMeetingRoomView';
import MyActivitiesView from './views/MyActivitiesView';
import LoginView from './views/LoginView';
import AdminDashboard from './views/AdminDashboard';
import TeacherDashboard from './views/TeacherDashboard';
import StudentDashboard from './views/StudentDashboard';
import SettingsView from './views/SettingsView';

// Modals
import EventRegistrationModal from './components/EventRegistrationModal';
import ReceiptModal from './components/ReceiptModal';
import ScheduleMeetingModal from './components/ScheduleMeetingModal';

function MainApp() {
  const { user, loading } = useAuth();
  const { notify } = useNotifications();

  // Navigation State
  const [currentView, setCurrentView] = useState('home'); // 'home' | 'events' | 'event-detail' | 'host-event' | 'meetings' | 'meeting-lobby' | 'meeting-room' | 'my-activities' | 'dashboard' | 'settings' | 'login'
  const [dashboardTab, setDashboardTab] = useState('dashboard');
  const [selectedEventId, setSelectedEventId] = useState(null);
  const [selectedMeetingCode, setSelectedMeetingCode] = useState(null);
  const [meetingSessionData, setMeetingSessionData] = useState(null);

  // Global Modals State
  const [registerEventModalData, setRegisterEventModalData] = useState(null);
  const [receiptModalData, setReceiptModalData] = useState(null);
  const [scheduleModalOpen, setScheduleModalOpen] = useState(false);

  // Automatically switch to dashboard when user logs in
  React.useEffect(() => {
    if (user && currentView === 'login') {
      setCurrentView('dashboard');
    }
  }, [user, currentView]);

  // Return home if logged out while on dashboard
  React.useEffect(() => {
    if (!user && (currentView === 'dashboard' || currentView === 'my-activities')) {
      setCurrentView('home');
    }
  }, [user, currentView]);

  if (loading) {
    return (
      <div style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        color: 'var(--text-muted)',
        fontFamily: 'var(--font-heading)',
        fontSize: '1.25rem'
      }}>
        Initializing Learnique AI Collaboration & Academic Workspace...
      </div>
    );
  }

  // Navigation Handler
  const handleNavigate = (view) => {
    if (view === 'login') {
      setCurrentView('login');
      return;
    }
    if (view === 'dashboard' && !user) {
      notify('Please sign in to access your personal academic dashboard', 'info');
      setCurrentView('login');
      return;
    }
    if (view === 'host-event' && (!user || (user.role !== 'ADMIN' && user.role !== 'TEACHER'))) {
      if (!user) {
        notify('Please sign in with faculty credentials to host an event', 'info');
        setCurrentView('login');
      } else {
        notify('Faculty or Administrator privileges required to host events', 'warning');
      }
      return;
    }
    if (view === 'my-activities' && !user) {
      notify('Please sign in to view your registrations and activities', 'info');
      setCurrentView('login');
      return;
    }

    setCurrentView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Event handlers
  const handleViewEventDetail = (id) => {
    setSelectedEventId(id);
    setCurrentView('event-detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleRegisterEvent = (event) => {
    setRegisterEventModalData(event);
  };

  // Meeting handlers
  const handleJoinMeetingWithCode = (code) => {
    setSelectedMeetingCode(code);
    setCurrentView('meeting-lobby');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleEnterLiveRoom = (sessionConfig) => {
    setMeetingSessionData(sessionConfig);
    setCurrentView('meeting-room');
  };

  const handleLeaveLiveRoom = () => {
    setMeetingSessionData(null);
    setCurrentView('meetings');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenSchedule = () => {
    if (!user) {
      notify('Please sign in with faculty credentials to schedule a meeting', 'info');
      setCurrentView('login');
      return;
    }
    if (user.role === 'STUDENT') {
      notify('Faculty or Administrator privileges required to schedule meetings', 'warning');
      return;
    }
    setScheduleModalOpen(true);
  };

  // Full-screen Live Meeting Room View
  if (currentView === 'meeting-room' && meetingSessionData) {
    return (
      <LiveMeetingRoomView
        meetingData={meetingSessionData.meeting}
        displayName={meetingSessionData.displayName}
        initialCameraOn={meetingSessionData.initialCameraOn}
        initialMicOn={meetingSessionData.initialMicOn}
        initialStream={meetingSessionData.previewStream}
        onLeave={handleLeaveLiveRoom}
      />
    );
  }

  // Login View
  if (currentView === 'login') {
    return (
      <LoginView
        onBackToHome={() => setCurrentView('home')}
        onLoginSuccess={() => setCurrentView('dashboard')}
      />
    );
  }

  // Render Core Views
  function renderMainContent() {
    switch (currentView) {
      case 'home':
        return (
          <HomeView
            onNavigate={handleNavigate}
            onOpenSchedule={handleOpenSchedule}
            onRegisterEvent={handleRegisterEvent}
            onViewEventDetail={handleViewEventDetail}
            onJoinMeetingWithCode={handleJoinMeetingWithCode}
          />
        );

      case 'events':
        return (
          <EventsListView
            onNavigate={handleNavigate}
            onRegisterEvent={handleRegisterEvent}
            onViewEventDetail={handleViewEventDetail}
          />
        );

      case 'event-detail':
        return (
          <EventDetailView
            eventId={selectedEventId}
            onBack={() => setCurrentView('events')}
            onRegisterEvent={handleRegisterEvent}
            onViewReceipt={receipt => setReceiptModalData(receipt)}
          />
        );

      case 'host-event':
        return (
          <HostEventView
            onBack={() => setCurrentView('events')}
            onEventCreated={(eventId) => {
              setSelectedEventId(eventId);
              setCurrentView('event-detail');
            }}
          />
        );

      case 'meetings':
        return (
          <MeetingsDashboardView
            onNavigate={handleNavigate}
            onOpenSchedule={handleOpenSchedule}
            onJoinMeetingWithCode={handleJoinMeetingWithCode}
          />
        );

      case 'meeting-lobby':
        return (
          <MeetingLobbyView
            meetingCode={selectedMeetingCode}
            onBack={() => setCurrentView('meetings')}
            onJoinRoom={handleEnterLiveRoom}
          />
        );

      case 'my-activities':
        return (
          <MyActivitiesView
            onNavigate={handleNavigate}
            onViewReceipt={receipt => setReceiptModalData(receipt)}
            onJoinMeetingWithCode={handleJoinMeetingWithCode}
          />
        );

      case 'settings':
        return <SettingsView />;

      case 'dashboard':
        if (!user) return <HomeView onNavigate={handleNavigate} />;
        if (dashboardTab === 'settings') return <SettingsView />;
        if (user.role === 'ADMIN') {
          return <AdminDashboard activeTab={dashboardTab} setActiveTab={setDashboardTab} />;
        }
        if (user.role === 'TEACHER') {
          return <TeacherDashboard activeTab={dashboardTab} setActiveTab={setDashboardTab} />;
        }
        return <StudentDashboard activeTab={dashboardTab} setActiveTab={setDashboardTab} />;

      default:
        return <HomeView onNavigate={handleNavigate} />;
    }
  }

  const isDashboardView = currentView === 'dashboard';

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      {/* Central Navigation Bar */}
      <Navbar
        currentView={currentView}
        onNavigate={handleNavigate}
        onOpenSchedule={handleOpenSchedule}
      />

      {/* Main Body */}
      {isDashboardView ? (
        <div style={{ display: 'flex', flex: 1 }}>
          <Sidebar activeTab={dashboardTab} setActiveTab={setDashboardTab} />
          <main style={{ flex: 1, minWidth: 0, paddingRight: '20px' }}>
            {renderMainContent()}
          </main>
        </div>
      ) : (
        <main style={{ flex: 1, minWidth: 0 }}>
          {renderMainContent()}
        </main>
      )}

      {/* Global Modals */}
      <EventRegistrationModal
        isOpen={Boolean(registerEventModalData)}
        onClose={() => setRegisterEventModalData(null)}
        event={registerEventModalData}
        onRegistered={() => {}}
        onViewReceipt={(receipt) => setReceiptModalData(receipt)}
      />

      <ReceiptModal
        isOpen={Boolean(receiptModalData)}
        onClose={() => setReceiptModalData(null)}
        receipt={receiptModalData}
      />

      <ScheduleMeetingModal
        isOpen={scheduleModalOpen}
        onClose={() => setScheduleModalOpen(false)}
        onScheduled={(meeting) => {}}
      />
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <NotificationProvider>
        <AuthProvider>
          <MainApp />
        </AuthProvider>
      </NotificationProvider>
    </ThemeProvider>
  );
}
