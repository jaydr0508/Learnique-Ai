import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  Calendar, Search, Filter, MapPin, Tag, PlusCircle, 
  ChevronRight, ArrowRight, ShieldCheck, Ticket, Users, Clock 
} from 'lucide-react';

export default function EventsListView({ onNavigate, onRegisterEvent, onViewEventDetail }) {
  const { user } = useAuth();
  const [events, setEvents] = useState([]);
  const [categories, setCategories] = useState(['All']);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [search, setSearch] = useState('');
  const [venueFilter, setVenueFilter] = useState('All');
  const [freeOnly, setFreeOnly] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchEvents();
  }, [selectedCategory, venueFilter, freeOnly]);

  const fetchEvents = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (selectedCategory && selectedCategory !== 'All') params.append('category', selectedCategory);
      if (venueFilter && venueFilter !== 'All') params.append('venue_type', venueFilter);
      if (freeOnly) params.append('free', 'true');
      if (search.trim()) params.append('search', search.trim());

      const res = await fetch(`/api/events?${params.toString()}`);
      const data = await res.json();
      setEvents(data.events || []);
      if (data.categories) setCategories(data.categories);
    } catch (err) {
      console.error('Failed to load events:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    fetchEvents();
  };

  return (
    <div style={{ maxWidth: '1280px', margin: '0 auto', padding: '10px 20px 60px 20px', display: 'flex', flexDirection: 'column', gap: '32px' }}>
      {/* Header Banner */}
      <div style={{
        padding: '36px 32px',
        borderRadius: '20px',
        background: 'linear-gradient(135deg, rgba(79, 70, 229, 0.15), rgba(6, 182, 212, 0.1))',
        border: '1px solid var(--border-glass)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '20px'
      }}>
        <div>
          <span className="badge" style={{ background: 'var(--accent-light)', color: 'var(--accent-primary)', marginBottom: '8px' }}>
            Academic Conferences & Workshops
          </span>
          <h1 style={{ fontSize: '2.2rem', fontWeight: '800', margin: '4px 0 8px 0' }}>
            Explore All Campus Events
          </h1>
          <p style={{ fontSize: '0.95rem', color: 'var(--text-secondary)', maxWidth: '600px', margin: 0 }}>
            Discover technology symposiums, developer bootcamps, and academic workshops with instant registration and certified passes.
          </p>
        </div>

        {user && (user.role === 'ADMIN' || user.role === 'TEACHER') && (
          <button
            onClick={() => onNavigate('host-event')}
            className="btn-primary"
            style={{ padding: '12px 22px', borderRadius: '12px', fontSize: '0.92rem', gap: '8px' }}
          >
            <PlusCircle size={18} /> Host New Event
          </button>
        )}
      </div>

      {/* Filter and Search Bar */}
      <div style={{
        padding: '18px 20px',
        borderRadius: '16px',
        background: 'var(--bg-secondary)',
        border: '1px solid var(--border-glass)',
        display: 'flex',
        flexDirection: 'column',
        gap: '16px'
      }}>
        {/* Search & dropdown row */}
        <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between' }}>
          <form onSubmit={handleSearchSubmit} style={{ display: 'flex', gap: '8px', flex: 1, minWidth: '260px' }}>
            <div style={{ position: 'relative', flex: 1 }}>
              <Search size={16} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
              <input
                type="text"
                placeholder="Search event title, keywords, or organizer..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                style={{
                  width: '100%',
                  padding: '10px 14px 10px 36px',
                  borderRadius: '10px',
                  background: 'var(--bg-tertiary)',
                  border: '1px solid var(--border-subtle)',
                  color: 'var(--text-primary)',
                  fontSize: '0.88rem'
                }}
              />
            </div>
            <button type="submit" className="btn-primary" style={{ padding: '10px 18px', borderRadius: '10px', fontSize: '0.88rem' }}>
              Search
            </button>
          </form>

          <div style={{ display: 'flex', gap: '10px', alignItems: 'center', flexWrap: 'wrap' }}>
            <select
              value={venueFilter}
              onChange={e => setVenueFilter(e.target.value)}
              style={{
                padding: '10px 14px',
                borderRadius: '10px',
                background: 'var(--bg-tertiary)',
                border: '1px solid var(--border-subtle)',
                color: 'var(--text-primary)',
                fontSize: '0.85rem'
              }}
            >
              <option value="All">All Formats</option>
              <option value="HYBRID">Hybrid (In-person & Virtual)</option>
              <option value="ONLINE">Online Virtual Room</option>
              <option value="PHYSICAL">Physical On-Campus</option>
            </select>

            <button
              onClick={() => setFreeOnly(!freeOnly)}
              style={{
                padding: '9px 14px',
                borderRadius: '10px',
                border: freeOnly ? '2px solid var(--success)' : '1px solid var(--border-subtle)',
                background: freeOnly ? 'rgba(16, 185, 129, 0.15)' : 'var(--bg-tertiary)',
                color: freeOnly ? 'var(--success)' : 'var(--text-secondary)',
                fontWeight: '600',
                fontSize: '0.85rem',
                cursor: 'pointer'
              }}
            >
              Free Only
            </button>
          </div>
        </div>

        {/* Category Chips Bar */}
        <div style={{ display: 'flex', gap: '8px', overflowX: 'auto', paddingBottom: '4px' }}>
          {categories.map(cat => {
            const isSelected = selectedCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                style={{
                  padding: '6px 14px',
                  borderRadius: '20px',
                  border: 'none',
                  background: isSelected ? 'var(--accent-primary)' : 'var(--bg-tertiary)',
                  color: isSelected ? '#ffffff' : 'var(--text-secondary)',
                  fontWeight: isSelected ? '700' : '500',
                  fontSize: '0.8rem',
                  cursor: 'pointer',
                  whiteSpace: 'nowrap',
                  transition: 'all var(--transition-fast)'
                }}
              >
                {cat}
              </button>
            );
          })}
        </div>
      </div>

      {/* Events Grid */}
      {loading ? (
        <div style={{ textAlign: 'center', padding: '60px', color: 'var(--text-muted)' }}>
          Loading events catalog...
        </div>
      ) : events.length === 0 ? (
        <div style={{
          textAlign: 'center',
          padding: '60px 20px',
          background: 'var(--bg-secondary)',
          borderRadius: '20px',
          border: '1px solid var(--border-glass)'
        }}>
          <Calendar size={48} style={{ opacity: 0.3, marginBottom: '14px' }} />
          <h3>No events match your criteria</h3>
          <p style={{ fontSize: '0.88rem', color: 'var(--text-muted)', marginTop: '6px' }}>
            Try adjusting your search terms or clearing category filters.
          </p>
          <button
            onClick={() => {
              setSelectedCategory('All');
              setVenueFilter('All');
              setFreeOnly(false);
              setSearch('');
            }}
            className="btn-secondary"
            style={{ marginTop: '16px', padding: '8px 18px' }}
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(350px, 1fr))',
          gap: '24px'
        }}>
          {events.map(ev => {
            const isFree = ev.min_price === 0;
            return (
              <div
                key={ev.id}
                className="glass-panel"
                style={{
                  borderRadius: '20px',
                  overflow: 'hidden',
                  background: 'var(--bg-secondary)',
                  border: '1px solid var(--border-glass)',
                  display: 'flex',
                  flexDirection: 'column',
                  boxShadow: 'var(--shadow-card)'
                }}
              >
                {/* Banner Image */}
                <div style={{ height: '180px', position: 'relative' }}>
                  <img
                    src={ev.banner_url || "https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=800&q=80"}
                    alt={ev.title}
                    style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                  />
                  <div style={{ position: 'absolute', top: '12px', left: '12px' }}>
                    <span className="badge" style={{ background: 'rgba(0, 0, 0, 0.75)', color: '#ffffff', backdropFilter: 'blur(4px)' }}>
                      {ev.category}
                    </span>
                  </div>
                  <div style={{ position: 'absolute', top: '12px', right: '12px' }}>
                    <span className="badge" style={{
                      background: isFree ? 'rgba(16, 185, 129, 0.9)' : 'rgba(79, 70, 229, 0.9)',
                      color: '#ffffff',
                      fontWeight: '700'
                    }}>
                      {isFree ? 'FREE ENTRY' : `From ₹${ev.min_price}`}
                    </span>
                  </div>
                </div>

                {/* Content */}
                <div style={{ padding: '22px', flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '14px', fontSize: '0.78rem', color: 'var(--text-muted)', marginBottom: '8px' }}>
                      <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                        <Calendar size={13} style={{ color: 'var(--accent-primary)' }} />
                        {new Date(ev.event_date).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })}
                      </span>
                      <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                        <Clock size={13} style={{ color: '#f59e0b' }} />
                        {ev.start_time} - {ev.end_time}
                      </span>
                    </div>

                    <h3 style={{ fontSize: '1.15rem', fontWeight: '700', marginBottom: '8px', lineHeight: 1.35 }}>
                      {ev.title}
                    </h3>

                    <p style={{
                      fontSize: '0.85rem',
                      color: 'var(--text-secondary)',
                      lineHeight: 1.5,
                      display: '-webkit-box',
                      WebkitLineClamp: 3,
                      WebkitBoxOrient: 'vertical',
                      overflow: 'hidden',
                      marginBottom: '16px'
                    }}>
                      {ev.short_description || ev.description}
                    </p>
                  </div>

                  <div>
                    <div style={{
                      padding: '10px 12px',
                      borderRadius: '10px',
                      background: 'var(--bg-tertiary)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      fontSize: '0.78rem',
                      color: 'var(--text-muted)',
                      marginBottom: '14px'
                    }}>
                      <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                        <MapPin size={13} style={{ color: '#06b6d4' }} />
                        {ev.venue_type === 'ONLINE' ? 'Virtual Classroom' : (ev.venue_address || 'Main Campus')}
                      </span>
                      <span>
                        {ev.reg_count || 0}/{ev.max_capacity} Seats
                      </span>
                    </div>

                    <div style={{ display: 'flex', gap: '10px' }}>
                      <button
                        onClick={() => onViewEventDetail && onViewEventDetail(ev.id)}
                        className="btn-secondary"
                        style={{ flex: 1, padding: '10px', fontSize: '0.85rem', borderRadius: '10px' }}
                      >
                        View Details
                      </button>
                      <button
                        onClick={() => onRegisterEvent && onRegisterEvent(ev)}
                        className="btn-primary"
                        style={{ flex: 1, padding: '10px', fontSize: '0.85rem', borderRadius: '10px' }}
                      >
                        Register Now
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
