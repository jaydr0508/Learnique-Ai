import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNotification } from '../context/NotificationContext';
import {
  Layers,
  BookOpen,
  Calendar,
  Award,
  Users,
  Clock,
  Plus,
  QrCode,
  Eye,
  FileDown,
  Trash2,
  Edit,
  Search,
  ChevronRight,
  GraduationCap,
  Sparkles,
  CheckCircle,
  X
} from 'lucide-react';

export default function SemesterHierarchyView({
  role = 'ADMIN',
  onStartAttendance,
  onOpenQuizMonitor,
  onOpenQuizCreator,
  divisions = []
}) {
  const { token, user } = useAuth();
  const { notify, confirm: confirmModal } = useNotification();

  const [loading, setLoading] = useState(true);
  const [hierarchyData, setHierarchyData] = useState([]);
  const [selectedSemId, setSelectedSemId] = useState(null);
  const [selectedBranchName, setSelectedBranchName] = useState('');
  const [selectedCourseId, setSelectedCourseId] = useState(null);
  const [subTab, setSubTab] = useState('lectures'); // 'lectures' or 'quizzes'
  const [searchQuery, setSearchQuery] = useState('');

  // Admin Modals
  const [isAddCourseModalOpen, setIsAddCourseModalOpen] = useState(false);
  const [isEditCourseModalOpen, setIsEditCourseModalOpen] = useState(false);
  const [isAddLectureModalOpen, setIsAddLectureModalOpen] = useState(false);

  // Form states
  const [courseForm, setCourseForm] = useState({
    code: '',
    name: '',
    type: 'BOTH',
    branch: 'Computer Science & Engineering',
    semester_id: ''
  });
  const [editingCourse, setEditingCourse] = useState(null);

  const [lectureForm, setLectureForm] = useState({
    academic_year: '2025-2026',
    semester_id: '',
    subject_id: '',
    day_of_week: '1',
    start_time: '10:00',
    end_time: '10:50',
    teacher_id: '',
    session_type: 'THEORY',
    division_id: '1',
    batch_id: '',
    room: 'EA-511',
    building: 'Engineering Block A'
  });

  const [teachersList, setTeachersList] = useState([]);

  useEffect(() => {
    loadHierarchy();
    if (role === 'ADMIN') {
      loadTeachers();
    }
  }, [token]);

  async function loadTeachers() {
    try {
      const res = await fetch('/api/admin/teachers', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (res.ok) {
        setTeachersList(data.teachers || []);
      }
    } catch {
      // fallback
    }
  }

  async function loadHierarchy() {
    setLoading(true);
    try {
      const res = await fetch('/api/academic/hierarchy', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to load semester hierarchy');

      const hList = data.hierarchy || [];
      setHierarchyData(hList);

      if (hList.length > 0) {
        // Find default semester
        let defaultSem = hList[0];
        // If there is a semester with courses, pick it
        const withCourses = hList.find(s => s.total_courses > 0);
        if (withCourses) defaultSem = withCourses;

        setSelectedSemId(defaultSem.semester_id);

        if (defaultSem.branches.length > 0) {
          const firstBranch = defaultSem.branches.find(b => b.courses.length > 0) || defaultSem.branches[0];
          setSelectedBranchName(firstBranch.branch_name);

          if (firstBranch.courses.length > 0) {
            setSelectedCourseId(firstBranch.courses[0].id);
          }
        }
      }
    } catch (err) {
      notify('Hierarchy error: ' + err.message, 'error');
    } finally {
      setLoading(false);
    }
  }

  const currentSemester = hierarchyData.find(s => s.semester_id === selectedSemId);
  const currentBranch = currentSemester?.branches?.find(b => b.branch_name === selectedBranchName);
  const currentCourse = currentBranch?.courses?.find(c => c.id === selectedCourseId) ||
    (currentBranch?.courses?.length > 0 ? currentBranch.courses[0] : null);

  // When branch or semester changes, ensure valid selected course
  useEffect(() => {
    if (currentBranch && currentBranch.courses.length > 0) {
      if (!currentBranch.courses.some(c => c.id === selectedCourseId)) {
        setSelectedCourseId(currentBranch.courses[0].id);
      }
    } else {
      setSelectedCourseId(null);
    }
  }, [selectedSemId, selectedBranchName]);

  // Filter courses by search query if present
  const displayedCourses = (currentBranch?.courses || []).filter(c => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return c.code.toLowerCase().includes(q) || c.name.toLowerCase().includes(q);
  });

  const daysMap = {
    1: 'Monday',
    2: 'Tuesday',
    3: 'Wednesday',
    4: 'Thursday',
    5: 'Friday',
    6: 'Saturday',
    7: 'Sunday'
  };

  // Create course handler
  async function handleCreateCourse(e) {
    e.preventDefault();
    if (!courseForm.code || !courseForm.name) {
      notify('Code and Course Name are required', 'error');
      return;
    }
    try {
      const res = await fetch('/api/admin/subjects', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          code: courseForm.code,
          name: courseForm.name,
          type: courseForm.type,
          branch: courseForm.branch,
          semester_id: courseForm.semester_id || selectedSemId
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to create course');

      notify(`Course ${courseForm.code} added successfully!`, 'success');
      setIsAddCourseModalOpen(false);
      setCourseForm({ code: '', name: '', type: 'BOTH', branch: selectedBranchName || 'Computer Science & Engineering', semester_id: '' });
      await loadHierarchy();
    } catch (err) {
      notify(err.message, 'error');
    }
  }

  // Edit course handler
  async function handleUpdateCourse(e) {
    e.preventDefault();
    if (!editingCourse) return;
    try {
      const res = await fetch(`/api/admin/subjects/${editingCourse.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          code: editingCourse.code,
          name: editingCourse.name,
          type: editingCourse.type,
          branch: editingCourse.branch,
          semester_id: editingCourse.semester_id
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to update course');

      notify('Course updated successfully!', 'success');
      setIsEditCourseModalOpen(false);
      setEditingCourse(null);
      await loadHierarchy();
    } catch (err) {
      notify(err.message, 'error');
    }
  }

  // Delete course handler
  async function handleDeleteCourse(courseId, courseCode) {
    const ok = await confirmModal(`Are you sure you want to delete course ${courseCode}? This will remove its timetable entries and quizzes.`);
    if (!ok) return;

    try {
      const res = await fetch(`/api/admin/subjects/${courseId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to delete course');

      notify(`Course ${courseCode} deleted.`, 'success');
      await loadHierarchy();
    } catch (err) {
      notify(err.message, 'error');
    }
  }

  // Create lecture schedule handler
  async function handleCreateLecture(e) {
    e.preventDefault();
    if (!lectureForm.subject_id || !lectureForm.teacher_id) {
      notify('Course and Teacher are required', 'error');
      return;
    }
    try {
      const res = await fetch('/api/admin/timetable', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(lectureForm)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to schedule lecture');

      notify('Lecture scheduled successfully!', 'success');
      setIsAddLectureModalOpen(false);
      await loadHierarchy();
    } catch (err) {
      notify(err.message, 'error');
    }
  }

  // Delete lecture handler
  async function handleDeleteLecture(lectureId) {
    const ok = await confirmModal('Delete this scheduled lecture slot?');
    if (!ok) return;
    try {
      const res = await fetch(`/api/admin/timetable/${lectureId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to delete lecture');

      notify('Lecture removed.', 'success');
      await loadHierarchy();
    } catch (err) {
      notify(err.message, 'error');
    }
  }

  if (loading) {
    return (
      <div className="glass-panel" style={{ padding: '60px', textAlign: 'center', borderRadius: '24px' }}>
        <div style={{ color: 'var(--accent-primary)', fontSize: '1.1rem', fontWeight: '600' }}>
          Loading Academic Semester System...
        </div>
        <div style={{ color: 'var(--text-muted)', fontSize: '0.85rem', marginTop: '8px' }}>
          Synchronizing Semesters, Branches, Courses, Lectures, and Quizzes...
        </div>
      </div>
    );
  }

  if (hierarchyData.length === 0) {
    return (
      <div className="glass-panel" style={{ padding: '60px', textAlign: 'center', borderRadius: '24px' }}>
        <GraduationCap size={48} style={{ color: 'var(--text-muted)', margin: '0 auto 16px' }} />
        <h3 style={{ fontSize: '1.25rem', fontWeight: '700' }}>
          {role === 'TEACHER' ? 'No Assigned Semesters Found' : 'No Academic Semesters Found'}
        </h3>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem', marginTop: '6px', maxWidth: '420px', margin: '6px auto 20px' }}>
          {role === 'TEACHER'
            ? 'You are currently not assigned to any courses in active semesters. Please contact your administrator.'
            : 'Initialize the academic structure to populate semesters and branches.'}
        </p>
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '22px' }}>
      {/* TOP HEADER & BREADCRUMB */}
      <div className="glass-panel" style={{ padding: '22px 28px', borderRadius: '20px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--text-muted)', fontSize: '0.825rem', marginBottom: '6px' }}>
              <span>Academic System</span>
              <ChevronRight size={14} />
              <span style={{ color: 'var(--accent-primary)', fontWeight: '600' }}>
                Semester {currentSemester?.semester_number || 'Select'}
              </span>
              <ChevronRight size={14} />
              <span>{selectedBranchName || 'Branch'}</span>
              {currentCourse && (
                <>
                  <ChevronRight size={14} />
                  <span style={{ color: 'var(--text-primary)', fontWeight: '700' }}>
                    {currentCourse.code}
                  </span>
                </>
              )}
            </div>
            <h2 style={{ fontSize: '1.5rem', fontWeight: '800', display: 'flex', alignItems: 'center', gap: '10px' }}>
              <Layers size={26} style={{ color: 'var(--accent-primary)' }} />
              {role === 'TEACHER' ? 'My Assigned Academic Semesters' : 'Institutional Semester System'}
            </h2>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem', marginTop: '4px' }}>
              {role === 'TEACHER'
                ? 'Showing only the semesters and courses you are assigned to teach (Semester > Branch > Course > Lectures & Quizzes).'
                : 'Central university curriculum navigation: Semester > Branch > Courses > Lectures & Quizzes.'}
            </p>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
            <div style={{ position: 'relative' }}>
              <Search size={16} style={{ position: 'absolute', left: '12px', top: '11px', color: 'var(--text-muted)' }} />
              <input
                type="text"
                placeholder="Search courses..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="input-field"
                style={{ paddingLeft: '36px', width: '200px', fontSize: '0.85rem' }}
              />
            </div>

            {role === 'ADMIN' && (
              <>
                <button
                  onClick={() => {
                    setCourseForm({
                      code: '',
                      name: '',
                      type: 'BOTH',
                      branch: selectedBranchName || 'Computer Science & Engineering',
                      semester_id: selectedSemId || '1'
                    });
                    setIsAddCourseModalOpen(true);
                  }}
                  className="btn-primary"
                  style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.85rem', padding: '9px 16px' }}
                >
                  <Plus size={16} /> Add Course
                </button>

                <button
                  onClick={() => {
                    setLectureForm({
                      academic_year: currentSemester?.academic_year || '2025-2026',
                      semester_id: selectedSemId || '1',
                      subject_id: currentCourse?.id || '',
                      day_of_week: '1',
                      start_time: '10:00',
                      end_time: '10:50',
                      teacher_id: teachersList[0]?.id || '',
                      session_type: 'THEORY',
                      division_id: divisions[0]?.id || '1',
                      batch_id: '',
                      room: 'EA-511',
                      building: 'Engineering Block A'
                    });
                    setIsAddLectureModalOpen(true);
                  }}
                  className="btn-secondary"
                  style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.85rem', padding: '9px 16px' }}
                >
                  <Calendar size={16} /> Schedule Lecture
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* STEP 1: SEMESTER SELECTOR */}
      <div>
        <div style={{ fontSize: '0.75rem', fontWeight: '700', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: '10px' }}>
          Select Academic Semester {role === 'TEACHER' && '(Your Assigned Semesters)'}
        </div>
        <div style={{
          display: 'grid',
          gridTemplateColumns: `repeat(auto-fit, minmax(${role === 'TEACHER' ? '220px' : '185px'}, 1fr))`,
          gap: '12px'
        }}>
          {hierarchyData.map(sem => {
            const isSelected = sem.semester_id === selectedSemId;
            return (
              <button
                key={sem.semester_id}
                onClick={() => {
                  setSelectedSemId(sem.semester_id);
                  if (sem.branches.length > 0) {
                    setSelectedBranchName(sem.branches[0].branch_name);
                  }
                }}
                className="glass-panel"
                style={{
                  textAlign: 'left',
                  padding: '14px 18px',
                  borderRadius: '16px',
                  border: isSelected ? '2px solid var(--accent-primary)' : '1px solid var(--border-subtle)',
                  background: isSelected ? 'var(--accent-light)' : 'var(--bg-secondary)',
                  cursor: 'pointer',
                  transition: 'all 0.2s ease',
                  boxShadow: isSelected ? '0 0 20px var(--accent-glow)' : 'none',
                  minWidth: 0,
                  overflow: 'hidden'
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{
                    fontSize: '1.05rem',
                    fontWeight: '800',
                    color: isSelected ? 'var(--accent-primary)' : 'var(--text-primary)'
                  }}>
                    Semester {sem.semester_number}
                  </span>
                  {isSelected && (
                    <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: 'var(--accent-primary)' }} />
                  )}
                </div>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                  AY {sem.academic_year}
                </div>
                <div style={{
                  display: 'flex',
                  flexWrap: 'wrap',
                  alignItems: 'center',
                  gap: '4px 6px',
                  fontSize: '0.72rem',
                  fontWeight: '600',
                  marginTop: '10px',
                  color: isSelected ? 'var(--accent-primary)' : 'var(--text-secondary)'
                }}>
                  <span style={{ whiteSpace: 'nowrap' }}>{sem.total_courses} Courses</span>
                  <span style={{ opacity: 0.4 }}>•</span>
                  <span style={{ whiteSpace: 'nowrap' }}>{sem.total_lectures} Lect</span>
                  <span style={{ opacity: 0.4 }}>•</span>
                  <span style={{ whiteSpace: 'nowrap' }}>{sem.total_quizzes} Quiz</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* STEP 2: BRANCH SELECTOR */}
      {currentSemester && currentSemester.branches.length > 0 && (
        <div>
          <div style={{ fontSize: '0.75rem', fontWeight: '700', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: '10px' }}>
            Academic Branch (Semester {currentSemester.semester_number})
          </div>
          <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
            {currentSemester.branches.map(b => {
              const isSelected = b.branch_name === selectedBranchName;
              return (
                <button
                  key={b.branch_name}
                  onClick={() => setSelectedBranchName(b.branch_name)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    padding: '10px 18px',
                    borderRadius: '14px',
                    border: isSelected ? '2px solid var(--accent-primary)' : '1px solid var(--border-subtle)',
                    background: isSelected ? 'var(--accent-primary)' : 'var(--bg-secondary)',
                    color: isSelected ? '#ffffff' : 'var(--text-primary)',
                    fontWeight: isSelected ? '700' : '600',
                    fontSize: '0.875rem',
                    cursor: 'pointer',
                    transition: 'all 0.15s ease'
                  }}
                >
                  <GraduationCap size={16} />
                  <span>{b.branch_name}</span>
                  <span style={{
                    padding: '2px 8px',
                    borderRadius: '20px',
                    fontSize: '0.72rem',
                    background: isSelected ? 'rgba(255,255,255,0.25)' : 'var(--bg-tertiary)',
                    color: isSelected ? '#ffffff' : 'var(--accent-primary)'
                  }}>
                    {b.courses.length}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* STEP 3 & 4: COURSES & COURSE LECTURES / QUIZZES */}
      <div style={{ display: 'grid', gridTemplateColumns: 'minmax(280px, 340px) minmax(0, 1fr)', gap: '22px', alignItems: 'start' }}>
        {/* COURSES LIST (LEFT COLUMN) */}
        <div className="glass-panel" style={{ padding: '20px', borderRadius: '20px', display: 'flex', flexDirection: 'column', gap: '12px', minWidth: 0, overflow: 'hidden' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingBottom: '12px', borderBottom: '1px solid var(--border-subtle)' }}>
            <div>
              <h3 style={{ fontSize: '1.05rem', fontWeight: '800' }}>Courses</h3>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                {displayedCourses.length} {displayedCourses.length === 1 ? 'course' : 'courses'} available
              </div>
            </div>
            {role === 'ADMIN' && (
              <button
                onClick={() => {
                  setCourseForm({
                    code: '',
                    name: '',
                    type: 'BOTH',
                    branch: selectedBranchName || 'Computer Science & Engineering',
                    semester_id: selectedSemId || '1'
                  });
                  setIsAddCourseModalOpen(true);
                }}
                className="btn-primary"
                style={{ padding: '6px 12px', fontSize: '0.78rem' }}
              >
                <Plus size={14} /> Add
              </button>
            )}
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', maxHeight: '600px', overflowY: 'auto' }}>
            {displayedCourses.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '40px 10px', color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                No courses found in this branch for Semester {currentSemester?.semester_number}.
                {role === 'ADMIN' && (
                  <div style={{ marginTop: '12px' }}>
                    <button
                      onClick={() => setIsAddCourseModalOpen(true)}
                      className="btn-primary"
                      style={{ fontSize: '0.78rem', padding: '6px 14px' }}
                    >
                      <Plus size={14} /> Add First Course
                    </button>
                  </div>
                )}
              </div>
            ) : (
              displayedCourses.map(course => {
                const isSelected = course.id === selectedCourseId;
                return (
                  <div
                    key={course.id}
                    onClick={() => setSelectedCourseId(course.id)}
                    style={{
                      padding: '14px',
                      borderRadius: '14px',
                      border: isSelected ? '2px solid var(--accent-primary)' : '1px solid var(--border-subtle)',
                      background: isSelected ? 'var(--accent-light)' : 'var(--bg-tertiary)',
                      cursor: 'pointer',
                      transition: 'all 0.15s ease',
                      position: 'relative',
                      minWidth: 0,
                      overflow: 'hidden',
                      wordBreak: 'break-word'
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '8px' }}>
                      <span style={{
                        padding: '3px 8px',
                        borderRadius: '6px',
                        background: 'var(--accent-primary)',
                        color: '#ffffff',
                        fontSize: '0.72rem',
                        fontWeight: '800',
                        fontFamily: 'var(--font-mono)'
                      }}>
                        {course.code}
                      </span>
                      <span style={{
                        fontSize: '0.68rem',
                        padding: '2px 6px',
                        borderRadius: '4px',
                        background: 'rgba(0,0,0,0.1)',
                        color: 'var(--text-muted)',
                        fontWeight: '600'
                      }}>
                        {course.type}
                      </span>
                    </div>

                    <div style={{
                      fontWeight: '700',
                      fontSize: '0.925rem',
                      marginTop: '8px',
                      color: isSelected ? 'var(--accent-primary)' : 'var(--text-primary)'
                    }}>
                      {course.name}
                    </div>

                    {/* Faculty assigned */}
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '6px' }}>
                      {course.assigned_teachers.length > 0 ? (
                        <span>Faculty: {course.assigned_teachers.map(t => t.teacher_name).join(', ')}</span>
                      ) : (
                        <span style={{ fontStyle: 'italic' }}>No faculty assigned</span>
                      )}
                    </div>

                    {/* Counts footer */}
                    <div style={{
                      display: 'flex',
                      flexWrap: 'wrap',
                      gap: '8px 12px',
                      marginTop: '10px',
                      fontSize: '0.72rem',
                      color: 'var(--text-secondary)',
                      fontWeight: '600'
                    }}>
                      <span style={{ display: 'flex', alignItems: 'center', gap: '4px', whiteSpace: 'nowrap' }}>
                        <Calendar size={13} style={{ color: 'var(--accent-primary)' }} />
                        {course.lectures.length} Lectures
                      </span>
                      <span style={{ display: 'flex', alignItems: 'center', gap: '4px', whiteSpace: 'nowrap' }}>
                        <Award size={13} style={{ color: 'var(--accent-primary)' }} />
                        {course.quizzes.length} Quizzes
                      </span>
                    </div>

                    {role === 'ADMIN' && (
                      <div style={{ display: 'flex', gap: '6px', marginTop: '10px', justifyContent: 'flex-end' }}>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setEditingCourse(course);
                            setIsEditCourseModalOpen(true);
                          }}
                          style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', padding: '2px' }}
                          title="Edit Course"
                        >
                          <Edit size={14} />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteCourse(course.id, course.code);
                          }}
                          style={{ background: 'none', border: 'none', color: 'var(--danger)', cursor: 'pointer', padding: '2px' }}
                          title="Delete Course"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* COURSE DETAILS: LECTURES & QUIZZES (RIGHT COLUMN) */}
        <div className="glass-panel" style={{ padding: '24px', borderRadius: '20px', minWidth: 0, maxWidth: '100%', overflow: 'hidden' }}>
          {currentCourse ? (
            <div style={{ minWidth: 0 }}>
              {/* COURSE BANNER */}
              <div style={{
                padding: '20px',
                borderRadius: '16px',
                background: 'linear-gradient(135deg, var(--bg-tertiary), var(--accent-light))',
                border: '1px solid var(--border-subtle)',
                marginBottom: '20px',
                minWidth: 0,
                overflow: 'hidden'
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '14px' }}>
                  <div style={{ minWidth: 0, flex: '1 1 260px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
                      <span style={{
                        padding: '4px 10px',
                        borderRadius: '8px',
                        background: 'var(--accent-primary)',
                        color: '#ffffff',
                        fontSize: '0.8rem',
                        fontWeight: '800',
                        fontFamily: 'var(--font-mono)'
                      }}>
                        {currentCourse.code}
                      </span>
                      <span className="badge badge-active">{currentCourse.type}</span>
                      <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                        Semester {currentCourse.semester_number || currentSemester?.semester_number} • {currentCourse.branch}
                      </span>
                    </div>
                    <h2 style={{ fontSize: '1.4rem', fontWeight: '800', marginTop: '8px', wordBreak: 'break-word' }}>
                      {currentCourse.name}
                    </h2>
                    <div style={{ fontSize: '0.825rem', color: 'var(--text-secondary)', marginTop: '4px', wordBreak: 'break-word' }}>
                      {currentCourse.assigned_teachers.length > 0 ? (
                        <span>Assigned Faculty: <strong>{currentCourse.assigned_teachers.map(t => t.teacher_name).join(', ')}</strong></span>
                      ) : (
                        <span>Faculty: Not currently allocated</span>
                      )}
                    </div>
                  </div>

                  <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
                    <button
                      onClick={() => onOpenQuizCreator && onOpenQuizCreator(currentCourse)}
                      className="btn-primary"
                      style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.825rem', padding: '8px 14px' }}
                    >
                      <Plus size={15} /> Create Quiz for Course
                    </button>
                    {role === 'ADMIN' && (
                      <button
                        onClick={() => {
                          setLectureForm({
                            academic_year: currentSemester?.academic_year || '2025-2026',
                            semester_id: currentCourse.semester_id,
                            subject_id: currentCourse.id,
                            day_of_week: '1',
                            start_time: '10:00',
                            end_time: '10:50',
                            teacher_id: teachersList[0]?.id || '',
                            session_type: 'THEORY',
                            division_id: divisions[0]?.id || '1',
                            batch_id: '',
                            room: 'EA-511',
                            building: 'Engineering Block A'
                          });
                          setIsAddLectureModalOpen(true);
                        }}
                        className="btn-secondary"
                        style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.825rem', padding: '8px 14px' }}
                      >
                        <Calendar size={15} /> + Schedule Lecture
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* TABS: LECTURES vs QUIZZES */}
              <div style={{ display: 'flex', gap: '10px', borderBottom: '1px solid var(--border-subtle)', paddingBottom: '12px', marginBottom: '20px' }}>
                <button
                  onClick={() => setSubTab('lectures')}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    padding: '8px 18px',
                    borderRadius: '12px',
                    border: 'none',
                    background: subTab === 'lectures' ? 'var(--accent-primary)' : 'var(--bg-tertiary)',
                    color: subTab === 'lectures' ? '#ffffff' : 'var(--text-secondary)',
                    fontWeight: '700',
                    fontSize: '0.875rem',
                    cursor: 'pointer'
                  }}
                >
                  <Calendar size={16} />
                  Scheduled Lectures ({currentCourse.lectures.length})
                </button>
                <button
                  onClick={() => setSubTab('quizzes')}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    padding: '8px 18px',
                    borderRadius: '12px',
                    border: 'none',
                    background: subTab === 'quizzes' ? 'var(--accent-primary)' : 'var(--bg-tertiary)',
                    color: subTab === 'quizzes' ? '#ffffff' : 'var(--text-secondary)',
                    fontWeight: '700',
                    fontSize: '0.875rem',
                    cursor: 'pointer'
                  }}
                >
                  <Award size={16} />
                  Course Quizzes & Exams ({currentCourse.quizzes.length})
                </button>
              </div>

              {/* SUBTAB CONTENT: LECTURES */}
              {subTab === 'lectures' && (
                <div>
                  {currentCourse.lectures.length === 0 ? (
                    <div style={{ textAlign: 'center', padding: '40px', color: 'var(--text-muted)' }}>
                      <Calendar size={40} style={{ margin: '0 auto 12px', opacity: 0.5 }} />
                      <div style={{ fontWeight: '600', fontSize: '0.95rem' }}>No lectures scheduled for {currentCourse.name}</div>
                      <div style={{ fontSize: '0.8rem', marginTop: '4px' }}>
                        {role === 'ADMIN'
                          ? 'Click "+ Schedule Lecture" above to add timetable entries.'
                          : 'No timetable classes have been scheduled yet.'}
                      </div>
                    </div>
                  ) : (
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: '14px', minWidth: 0 }}>
                      {currentCourse.lectures.map(lec => (
                        <div
                          key={lec.id}
                          className="glass-panel"
                          style={{
                            padding: '16px',
                            borderRadius: '16px',
                            background: 'var(--bg-tertiary)',
                            display: 'flex',
                            flexDirection: 'column',
                            justifyContent: 'space-between',
                            gap: '12px',
                            minWidth: 0,
                            overflow: 'hidden',
                            wordBreak: 'break-word'
                          }}
                        >
                          <div>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                              <span style={{
                                fontWeight: '800',
                                fontSize: '0.95rem',
                                color: 'var(--accent-primary)'
                              }}>
                                {daysMap[lec.day_of_week] || 'Day'}
                              </span>
                              <span style={{
                                fontSize: '0.72rem',
                                padding: '3px 8px',
                                borderRadius: '6px',
                                background: lec.session_type === 'PRACTICAL' ? 'rgba(59, 130, 246, 0.15)' : 'rgba(16, 185, 129, 0.15)',
                                color: lec.session_type === 'PRACTICAL' ? '#3b82f6' : '#10b981',
                                fontWeight: '700'
                              }}>
                                {lec.session_type}
                              </span>
                            </div>

                            <div style={{
                              display: 'flex',
                              alignItems: 'center',
                              gap: '6px',
                              fontSize: '1rem',
                              fontWeight: '700',
                              marginTop: '8px',
                              fontFamily: 'var(--font-mono)'
                            }}>
                              <Clock size={16} style={{ color: 'var(--text-muted)' }} />
                              {lec.start_time} - {lec.end_time}
                            </div>

                            <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginTop: '8px' }}>
                              Room: <strong>{lec.room}</strong> {lec.building && `(${lec.building})`}
                            </div>
                            <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                              Division {lec.division_name} {lec.batch_name ? `• Batch ${lec.batch_name}` : '• Entire Division'}
                            </div>
                            <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                              Faculty: <strong>{lec.teacher_name}</strong>
                            </div>
                          </div>

                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: '10px', borderTop: '1px solid var(--border-subtle)' }}>
                            {role === 'TEACHER' && onStartAttendance && (
                              <button
                                onClick={() => onStartAttendance(lec)}
                                className="btn-primary"
                                style={{
                                  display: 'flex',
                                  alignItems: 'center',
                                  gap: '6px',
                                  fontSize: '0.78rem',
                                  padding: '7px 14px',
                                  background: 'linear-gradient(135deg, #10b981, #059669)'
                                }}
                              >
                                <QrCode size={14} /> Start Attendance
                              </button>
                            )}

                            {role === 'ADMIN' && (
                              <button
                                onClick={() => handleDeleteLecture(lec.id)}
                                style={{
                                  background: 'none',
                                  border: 'none',
                                  color: 'var(--danger)',
                                  cursor: 'pointer',
                                  display: 'flex',
                                  alignItems: 'center',
                                  gap: '4px',
                                  fontSize: '0.75rem',
                                  marginLeft: 'auto'
                                }}
                              >
                                <Trash2 size={14} /> Remove Slot
                              </button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* SUBTAB CONTENT: QUIZZES */}
              {subTab === 'quizzes' && (
                <div>
                  {currentCourse.quizzes.length === 0 ? (
                    <div style={{ textAlign: 'center', padding: '40px', color: 'var(--text-muted)' }}>
                      <Award size={40} style={{ margin: '0 auto 12px', opacity: 0.5 }} />
                      <div style={{ fontWeight: '600', fontSize: '0.95rem' }}>No quizzes created for {currentCourse.name}</div>
                      <div style={{ fontSize: '0.8rem', marginTop: '4px', marginBottom: '14px' }}>
                        Create a timed examination or rotating quiz for this course.
                      </div>
                      <button
                        onClick={() => onOpenQuizCreator && onOpenQuizCreator(currentCourse)}
                        className="btn-primary"
                        style={{ fontSize: '0.825rem', padding: '8px 16px' }}
                      >
                        <Plus size={15} /> Create First Quiz
                      </button>
                    </div>
                  ) : (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                      {currentCourse.quizzes.map(quiz => (
                        <div
                          key={quiz.id}
                          className="glass-panel"
                          style={{
                            padding: '18px 20px',
                            borderRadius: '16px',
                            background: 'var(--bg-tertiary)',
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center',
                            flexWrap: 'wrap',
                            gap: '14px',
                            minWidth: 0,
                            overflow: 'hidden'
                          }}
                        >
                          <div style={{ minWidth: 0, flex: '1 1 240px' }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
                              <h4 style={{ fontSize: '1.05rem', fontWeight: '800', wordBreak: 'break-word' }}>{quiz.title}</h4>
                              <span className={`badge ${quiz.status === 'ACTIVE' ? 'badge-present' : (quiz.status === 'CLOSED' ? 'badge-absent' : 'badge-active')}`}>
                                {quiz.status}
                              </span>
                            </div>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '10px 14px', fontSize: '0.8rem', color: 'var(--text-muted)', marginTop: '6px', flexWrap: 'wrap' }}>
                              <span>Code: <strong style={{ color: 'var(--accent-primary)', fontFamily: 'var(--font-mono)' }}>{quiz.access_code}</strong></span>
                              <span>•</span>
                              <span>Duration: <strong>{quiz.duration_minutes} mins</strong></span>
                              <span>•</span>
                              <span>Total Marks: <strong>{quiz.total_marks}</strong></span>
                              <span>•</span>
                              <span>Pass: <strong>{quiz.pass_percentage}%</strong></span>
                              <span>•</span>
                              <span>Attempts: <strong>{quiz.attempts_count || 0}</strong></span>
                            </div>
                          </div>

                          <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                            {onOpenQuizMonitor && (
                              <button
                                onClick={() => onOpenQuizMonitor(quiz.id)}
                                className="btn-secondary"
                                style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.8rem', padding: '7px 12px' }}
                              >
                                <Eye size={14} /> Monitor Live
                              </button>
                            )}

                            <a
                              href={`/api/reports/quiz/${quiz.id}?format=pdf&token=${token}`}
                              target="_blank"
                              rel="noreferrer"
                              className="btn-secondary"
                              style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.8rem', padding: '7px 12px', textDecoration: 'none' }}
                            >
                              <FileDown size={14} /> PDF
                            </a>

                            <a
                              href={`/api/reports/quiz/${quiz.id}?format=excel&token=${token}`}
                              target="_blank"
                              rel="noreferrer"
                              className="btn-secondary"
                              style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.8rem', padding: '7px 12px', textDecoration: 'none' }}
                            >
                              <FileDown size={14} /> Excel
                            </a>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          ) : (
            <div style={{ textAlign: 'center', padding: '60px', color: 'var(--text-muted)' }}>
              <BookOpen size={44} style={{ margin: '0 auto 12px', opacity: 0.5 }} />
              <div style={{ fontSize: '1.05rem', fontWeight: '700' }}>Select a Course from the left to view Lectures & Quizzes</div>
              <div style={{ fontSize: '0.825rem', marginTop: '6px' }}>
                Drill down into course schedules, launch attendance, or manage online examinations.
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ADMIN: ADD COURSE MODAL */}
      {isAddCourseModalOpen && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100vw',
          height: '100vh',
          background: 'rgba(0,0,0,0.7)',
          backdropFilter: 'blur(8px)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 9999
        }}>
          <div className="glass-panel" style={{ width: '480px', maxWidth: '90%', padding: '28px', borderRadius: '20px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <h3 style={{ fontSize: '1.2rem', fontWeight: '800' }}>Add Academic Course</h3>
              <button onClick={() => setIsAddCourseModalOpen(false)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleCreateCourse} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div>
                <label className="label">Course Code (e.g. CS501)</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. CS504"
                  value={courseForm.code}
                  onChange={e => setCourseForm({ ...courseForm, code: e.target.value.toUpperCase() })}
                  className="input-field"
                  style={{ textTransform: 'uppercase', fontFamily: 'var(--font-mono)' }}
                />
              </div>

              <div>
                <label className="label">Course Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Theory of Computation & Automata"
                  value={courseForm.name}
                  onChange={e => setCourseForm({ ...courseForm, name: e.target.value })}
                  className="input-field"
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                <div>
                  <label className="label">Course Type</label>
                  <select
                    value={courseForm.type}
                    onChange={e => setCourseForm({ ...courseForm, type: e.target.value })}
                    className="input-field"
                  >
                    <option value="BOTH">Theory & Practical</option>
                    <option value="THEORY">Theory Only</option>
                    <option value="PRACTICAL">Practical Only</option>
                  </select>
                </div>

                <div>
                  <label className="label">Target Semester</label>
                  <select
                    value={courseForm.semester_id || selectedSemId}
                    onChange={e => setCourseForm({ ...courseForm, semester_id: e.target.value })}
                    className="input-field"
                  >
                    {hierarchyData.map(s => (
                      <option key={s.semester_id} value={s.semester_id}>
                        Semester {s.semester_number}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="label">Academic Branch</label>
                <select
                  value={courseForm.branch}
                  onChange={e => setCourseForm({ ...courseForm, branch: e.target.value })}
                  className="input-field"
                >
                  <option value="Computer Science & Engineering">Computer Science & Engineering</option>
                  <option value="Information Technology">Information Technology</option>
                  <option value="Electronics & Communication">Electronics & Communication</option>
                </select>
              </div>

              <div style={{ display: 'flex', gap: '10px', marginTop: '10px' }}>
                <button type="submit" className="btn-primary" style={{ flex: 1 }}>
                  Create Course
                </button>
                <button type="button" onClick={() => setIsAddCourseModalOpen(false)} className="btn-secondary">
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADMIN: EDIT COURSE MODAL */}
      {isEditCourseModalOpen && editingCourse && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100vw',
          height: '100vh',
          background: 'rgba(0,0,0,0.7)',
          backdropFilter: 'blur(8px)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 9999
        }}>
          <div className="glass-panel" style={{ width: '480px', maxWidth: '90%', padding: '28px', borderRadius: '20px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <h3 style={{ fontSize: '1.2rem', fontWeight: '800' }}>Edit Course: {editingCourse.code}</h3>
              <button onClick={() => setIsEditCourseModalOpen(false)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleUpdateCourse} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div>
                <label className="label">Course Code</label>
                <input
                  type="text"
                  required
                  value={editingCourse.code}
                  onChange={e => setEditingCourse({ ...editingCourse, code: e.target.value.toUpperCase() })}
                  className="input-field"
                  style={{ textTransform: 'uppercase', fontFamily: 'var(--font-mono)' }}
                />
              </div>

              <div>
                <label className="label">Course Title</label>
                <input
                  type="text"
                  required
                  value={editingCourse.name}
                  onChange={e => setEditingCourse({ ...editingCourse, name: e.target.value })}
                  className="input-field"
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                <div>
                  <label className="label">Course Type</label>
                  <select
                    value={editingCourse.type}
                    onChange={e => setEditingCourse({ ...editingCourse, type: e.target.value })}
                    className="input-field"
                  >
                    <option value="BOTH">Theory & Practical</option>
                    <option value="THEORY">Theory Only</option>
                    <option value="PRACTICAL">Practical Only</option>
                  </select>
                </div>

                <div>
                  <label className="label">Semester</label>
                  <select
                    value={editingCourse.semester_id}
                    onChange={e => setEditingCourse({ ...editingCourse, semester_id: e.target.value })}
                    className="input-field"
                  >
                    {hierarchyData.map(s => (
                      <option key={s.semester_id} value={s.semester_id}>
                        Semester {s.semester_number}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="label">Branch</label>
                <select
                  value={editingCourse.branch || 'Computer Science & Engineering'}
                  onChange={e => setEditingCourse({ ...editingCourse, branch: e.target.value })}
                  className="input-field"
                >
                  <option value="Computer Science & Engineering">Computer Science & Engineering</option>
                  <option value="Information Technology">Information Technology</option>
                  <option value="Electronics & Communication">Electronics & Communication</option>
                </select>
              </div>

              <div style={{ display: 'flex', gap: '10px', marginTop: '10px' }}>
                <button type="submit" className="btn-primary" style={{ flex: 1 }}>
                  Save Changes
                </button>
                <button type="button" onClick={() => setIsEditCourseModalOpen(false)} className="btn-secondary">
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADMIN: SCHEDULE LECTURE MODAL */}
      {isAddLectureModalOpen && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100vw',
          height: '100vh',
          background: 'rgba(0,0,0,0.7)',
          backdropFilter: 'blur(8px)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 9999
        }}>
          <div className="glass-panel" style={{ width: '560px', maxWidth: '90%', padding: '28px', borderRadius: '20px', maxHeight: '90vh', overflowY: 'auto' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <h3 style={{ fontSize: '1.2rem', fontWeight: '800' }}>Schedule Lecture Slot</h3>
              <button onClick={() => setIsAddLectureModalOpen(false)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleCreateLecture} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div>
                <label className="label">Course</label>
                <select
                  value={lectureForm.subject_id}
                  onChange={e => setLectureForm({ ...lectureForm, subject_id: e.target.value })}
                  className="input-field"
                  required
                >
                  <option value="">-- Select Course --</option>
                  {hierarchyData.flatMap(s => s.branches.flatMap(b => b.courses)).map(c => (
                    <option key={c.id} value={c.id}>
                      {c.code} - {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="label">Assigned Faculty Member</label>
                <select
                  value={lectureForm.teacher_id}
                  onChange={e => setLectureForm({ ...lectureForm, teacher_id: e.target.value })}
                  className="input-field"
                  required
                >
                  <option value="">-- Select Teacher --</option>
                  {teachersList.map(t => (
                    <option key={t.id} value={t.id}>
                      {t.name} ({t.identifier})
                    </option>
                  ))}
                </select>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px' }}>
                <div>
                  <label className="label">Day of Week</label>
                  <select
                    value={lectureForm.day_of_week}
                    onChange={e => setLectureForm({ ...lectureForm, day_of_week: e.target.value })}
                    className="input-field"
                  >
                    <option value="1">Monday</option>
                    <option value="2">Tuesday</option>
                    <option value="3">Wednesday</option>
                    <option value="4">Thursday</option>
                    <option value="5">Friday</option>
                    <option value="6">Saturday</option>
                  </select>
                </div>

                <div>
                  <label className="label">Start Time</label>
                  <input
                    type="time"
                    value={lectureForm.start_time}
                    onChange={e => setLectureForm({ ...lectureForm, start_time: e.target.value })}
                    className="input-field"
                    required
                  />
                </div>

                <div>
                  <label className="label">End Time</label>
                  <input
                    type="time"
                    value={lectureForm.end_time}
                    onChange={e => setLectureForm({ ...lectureForm, end_time: e.target.value })}
                    className="input-field"
                    required
                  />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px' }}>
                <div>
                  <label className="label">Type</label>
                  <select
                    value={lectureForm.session_type}
                    onChange={e => setLectureForm({ ...lectureForm, session_type: e.target.value })}
                    className="input-field"
                  >
                    <option value="THEORY">THEORY</option>
                    <option value="PRACTICAL">PRACTICAL</option>
                  </select>
                </div>

                <div>
                  <label className="label">Division</label>
                  <select
                    value={lectureForm.division_id}
                    onChange={e => setLectureForm({ ...lectureForm, division_id: e.target.value })}
                    className="input-field"
                  >
                    {divisions.map(d => (
                      <option key={d.id} value={d.id}>
                        Division {d.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="label">Room</label>
                  <input
                    type="text"
                    value={lectureForm.room}
                    onChange={e => setLectureForm({ ...lectureForm, room: e.target.value })}
                    className="input-field"
                    required
                  />
                </div>
              </div>

              <div style={{ display: 'flex', gap: '10px', marginTop: '10px' }}>
                <button type="submit" className="btn-primary" style={{ flex: 1 }}>
                  Schedule Lecture
                </button>
                <button type="button" onClick={() => setIsAddLectureModalOpen(false)} className="btn-secondary">
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
