import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNotifications } from '../context/NotificationContext';
import { 
  Video, VideoOff, Mic, MicOff, Users, ArrowLeft, 
  ShieldCheck, AlertCircle, Sparkles, Settings 
} from 'lucide-react';

export default function MeetingLobbyView({ meetingCode, onBack, onJoinRoom }) {
  const { user } = useAuth();
  const { notify } = useNotifications();

  const [meeting, setMeeting] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [displayName, setDisplayName] = useState(user?.name || `Guest-${Math.floor(1000 + Math.random() * 9000)}`);
  const [isCameraOn, setIsCameraOn] = useState(true);
  const [isMicOn, setIsMicOn] = useState(true);
  const [mediaStream, setMediaStream] = useState(null);
  const [mediaPermissionDenied, setMediaPermissionDenied] = useState(false);

  const videoPreviewRef = useRef(null);

  useEffect(() => {
    fetchMeeting();
    startPreviewMedia();

    return () => {
      // Clean up local preview stream when exiting lobby
      if (mediaStream) {
        mediaStream.getTracks().forEach(t => t.stop());
      }
    };
  }, [meetingCode]);

  // Connect stream to video element
  useEffect(() => {
    if (videoPreviewRef.current && mediaStream) {
      videoPreviewRef.current.srcObject = mediaStream;
    }
  }, [mediaStream]);

  const fetchMeeting = async () => {
    try {
      setLoading(true);
      const res = await fetch(`/api/meetings/${meetingCode}`);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Invalid meeting code');
      setMeeting(data.meeting);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const startPreviewMedia = async () => {
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: true
        });
        setMediaStream(stream);
        setMediaPermissionDenied(false);
      }
    } catch (err) {
      console.warn('Camera/Mic permission denied or not available:', err);
      setMediaPermissionDenied(true);
      setIsCameraOn(false);
      setIsMicOn(false);
    }
  };

  const toggleCamera = () => {
    if (mediaStream) {
      const videoTrack = mediaStream.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled;
        setIsCameraOn(videoTrack.enabled);
      } else if (!isCameraOn) {
        // Try restart video track
        startPreviewMedia();
        setIsCameraOn(true);
      }
    } else {
      setIsCameraOn(!isCameraOn);
    }
  };

  const toggleMic = () => {
    if (mediaStream) {
      const audioTrack = mediaStream.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        setIsMicOn(audioTrack.enabled);
      }
    } else {
      setIsMicOn(!isMicOn);
    }
  };

  const handleJoin = () => {
    if (!displayName.trim()) {
      notify('Please enter your participant name', 'warning');
      return;
    }
    // Pass local media stream and configuration into live room
    if (onJoinRoom) {
      onJoinRoom({
        meeting,
        displayName: displayName.trim(),
        initialCameraOn: isCameraOn,
        initialMicOn: isMicOn,
        previewStream: mediaStream
      });
    }
  };

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '100px 20px', color: 'var(--text-muted)' }}>
        Loading meeting details...
      </div>
    );
  }

  if (error || !meeting) {
    return (
      <div style={{ maxWidth: '480px', margin: '80px auto', padding: '36px', borderRadius: '20px', background: 'var(--bg-secondary)', border: '1px solid var(--border-glass)', textAlign: 'center' }}>
        <AlertCircle size={44} style={{ color: 'var(--danger)', marginBottom: '14px' }} />
        <h3>Cannot Join Meeting</h3>
        <p style={{ fontSize: '0.88rem', color: 'var(--text-secondary)', marginTop: '6px', marginBottom: '20px' }}>
          {error || 'This meeting code does not exist or has expired.'}
        </p>
        <button onClick={onBack} className="btn-secondary" style={{ padding: '10px 20px' }}>
          Back to Meetings Dashboard
        </button>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: '960px', margin: '0 auto', padding: '20px 20px 80px 20px', display: 'flex', flexDirection: 'column', gap: '26px' }}>
      <button
        onClick={onBack}
        className="btn-secondary"
        style={{ alignSelf: 'flex-start', padding: '8px 14px', borderRadius: '10px', fontSize: '0.85rem', gap: '6px' }}
      >
        <ArrowLeft size={16} /> Cancel
      </button>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: '30px', alignItems: 'center' }}>
        {/* Left: Camera Preview Tile */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
          <div style={{
            height: '320px',
            borderRadius: '20px',
            background: '#0d1117',
            border: '2px solid var(--border-glass)',
            overflow: 'hidden',
            position: 'relative',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: 'var(--shadow-card)'
          }}>
            {isCameraOn && !mediaPermissionDenied ? (
              <video
                ref={videoPreviewRef}
                autoPlay
                playsInline
                muted
                style={{ width: '100%', height: '100%', objectFit: 'cover', transform: 'scaleX(-1)' }}
              />
            ) : (
              <div style={{ textAlign: 'center', color: 'var(--text-muted)' }}>
                <div style={{
                  width: '80px',
                  height: '80px',
                  borderRadius: '50%',
                  background: 'var(--bg-tertiary)',
                  color: 'var(--accent-primary)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '2rem',
                  fontWeight: '800',
                  margin: '0 auto 12px auto',
                  border: '2px solid var(--border-glass)'
                }}>
                  {displayName ? displayName[0].toUpperCase() : 'U'}
                </div>
                <div style={{ fontSize: '0.85rem' }}>Camera is off</div>
                {mediaPermissionDenied && (
                  <div style={{ fontSize: '0.72rem', color: 'var(--warning)', marginTop: '4px' }}>
                    Browser camera permission not granted
                  </div>
                )}
              </div>
            )}

            {/* Quick Floating Preview Controls */}
            <div style={{
              position: 'absolute',
              bottom: '16px',
              left: '50%',
              transform: 'translateX(-50%)',
              display: 'flex',
              gap: '12px',
              background: 'rgba(0, 0, 0, 0.65)',
              padding: '8px 16px',
              borderRadius: '30px',
              backdropFilter: 'blur(6px)'
            }}>
              <button
                type="button"
                onClick={toggleMic}
                style={{
                  width: '42px',
                  height: '42px',
                  borderRadius: '50%',
                  border: 'none',
                  background: isMicOn ? 'rgba(255,255,255,0.15)' : 'var(--danger)',
                  color: '#ffffff',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  cursor: 'pointer',
                  transition: 'all 0.2s ease'
                }}
                title={isMicOn ? 'Mute Microphone' : 'Unmute Microphone'}
              >
                {isMicOn ? <Mic size={18} /> : <MicOff size={18} />}
              </button>

              <button
                type="button"
                onClick={toggleCamera}
                style={{
                  width: '42px',
                  height: '42px',
                  borderRadius: '50%',
                  border: 'none',
                  background: isCameraOn ? 'rgba(255,255,255,0.15)' : 'var(--danger)',
                  color: '#ffffff',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  cursor: 'pointer',
                  transition: 'all 0.2s ease'
                }}
                title={isCameraOn ? 'Turn Off Camera' : 'Turn On Camera'}
              >
                {isCameraOn ? <Video size={18} /> : <VideoOff size={18} />}
              </button>
            </div>
          </div>

          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textAlign: 'center' }}>
            Check your audio and video before entering the live meeting room.
          </div>
        </div>

        {/* Right: Join Form & Meeting Summary */}
        <div className="glass-panel" style={{
          padding: '36px',
          borderRadius: '24px',
          background: 'var(--bg-secondary)',
          border: '1px solid var(--border-glass)',
          boxShadow: 'var(--shadow-card)',
          display: 'flex',
          flexDirection: 'column',
          gap: '22px'
        }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
              <span className="badge badge-present">Ready to Join</span>
              <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>
                {meeting.code}
              </span>
            </div>
            <h2 style={{ fontSize: '1.45rem', fontWeight: '800', lineHeight: 1.25, margin: '4px 0 6px 0' }}>
              {meeting.title}
            </h2>
            <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
              Host: <strong style={{ color: 'var(--text-primary)' }}>{meeting.host_name}</strong>
            </div>
          </div>

          {/* Active Participants preview */}
          {meeting.participants && meeting.participants.length > 0 && (
            <div style={{
              padding: '12px 14px',
              borderRadius: '12px',
              background: 'var(--bg-surface)',
              border: '1px solid var(--border-subtle)',
              fontSize: '0.8rem',
              color: 'var(--text-secondary)'
            }}>
              <div style={{ fontWeight: '600', marginBottom: '4px', display: 'flex', alignItems: 'center', gap: '6px' }}>
                <Users size={14} style={{ color: 'var(--accent-primary)' }} />
                {meeting.participants.length} Participant{meeting.participants.length > 1 ? 's' : ''} in room:
              </div>
              <div style={{ color: 'var(--text-muted)', fontSize: '0.76rem' }}>
                {meeting.participants.map(p => p.participant_name).join(', ')}
              </div>
            </div>
          )}

          {/* Participant Display Name Input */}
          <div>
            <label style={{ fontSize: '0.82rem', fontWeight: '600', color: 'var(--text-secondary)', marginBottom: '6px', display: 'block' }}>
              Your Display Name in Meeting *
            </label>
            <input
              type="text"
              required
              value={displayName}
              onChange={e => setDisplayName(e.target.value)}
              className="input-field"
              placeholder="e.g. Diya Sen or Dr. Verma"
            />
          </div>

          {/* Device Indicators */}
          <div style={{ display: 'flex', gap: '10px', fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
            <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              {isMicOn ? <Mic size={14} style={{ color: 'var(--success)' }} /> : <MicOff size={14} style={{ color: 'var(--danger)' }} />}
              Mic {isMicOn ? 'Enabled' : 'Muted'}
            </span>
            <span>•</span>
            <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              {isCameraOn ? <Video size={14} style={{ color: 'var(--success)' }} /> : <VideoOff size={14} style={{ color: 'var(--danger)' }} />}
              Camera {isCameraOn ? 'Enabled' : 'Off'}
            </span>
          </div>

          {/* Join CTA */}
          <button
            onClick={handleJoin}
            className="btn-primary"
            style={{
              padding: '14px',
              borderRadius: '12px',
              fontSize: '1rem',
              fontWeight: '700',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '8px'
            }}
          >
            <Video size={18} /> Join Meeting Now
          </button>
        </div>
      </div>
    </div>
  );
}
