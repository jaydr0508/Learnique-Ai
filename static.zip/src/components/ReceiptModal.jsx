import React, { useRef } from 'react';
import { Receipt, Download, Printer, CheckCircle2, ShieldCheck, X, Calendar, MapPin, User, Mail, CreditCard } from 'lucide-react';

export default function ReceiptModal({ isOpen, onClose, receipt }) {
  const printRef = useRef(null);

  if (!isOpen || !receipt) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPdf = () => {
    // Uses standard window print to PDF dialog or triggers clean printable document
    const printContent = document.getElementById('printable-receipt-card');
    const win = window.open('', '', 'height=700,width=800');
    win.document.write('<html><head><title>Official Registration Receipt - ' + (receipt.receipt_number || receipt.registration_number) + '</title>');
    win.document.write('<style>');
    win.document.write(`
      body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; padding: 40px; color: #1e293b; }
      .header { border-bottom: 2px solid #e2e8f0; padding-bottom: 20px; margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; }
      .brand { font-size: 24px; font-weight: 800; color: #4f46e5; }
      .title { font-size: 20px; font-weight: 700; margin-bottom: 16px; color: #0f172a; }
      .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 24px; }
      .item { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px; }
      .label { font-size: 11px; color: #64748b; text-transform: uppercase; font-weight: 600; margin-bottom: 4px; }
      .val { font-size: 14px; font-weight: 600; color: #0f172a; }
      .table { width: 100%; border-collapse: collapse; margin-top: 20px; }
      .table th { background: #f1f5f9; padding: 10px; text-align: left; font-size: 12px; border: 1px solid #cbd5e1; }
      .table td { padding: 12px; border: 1px solid #e2e8f0; font-size: 13px; }
      .footer { margin-top: 40px; border-top: 1px dashed #cbd5e1; padding-top: 16px; font-size: 11px; color: #94a3b8; text-align: center; }
    `);
    win.document.write('</style></head><body>');
    win.document.write(printContent.innerHTML);
    win.document.write('</body></html>');
    win.document.close();
    win.focus();
    setTimeout(() => {
      win.print();
      win.close();
    }, 350);
  };

  const isFree = (receipt.ticket_price === 0 || receipt.amount === 0 || receipt.paid_amount === 0);
  const amountPaid = receipt.paid_amount !== undefined ? receipt.paid_amount : (receipt.amount !== undefined ? receipt.amount : receipt.ticket_price || 0);
  const receiptNo = receipt.receipt_number || `CONF-${receipt.registration_number}`;

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: 'rgba(0, 0, 0, 0.65)',
      backdropFilter: 'blur(5px)',
      zIndex: 1100,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '20px'
    }} onClick={onClose}>
      <div 
        onClick={e => e.stopPropagation()}
        className="glass-panel"
        style={{
          width: '100%',
          maxWidth: '640px',
          maxHeight: '92vh',
          borderRadius: '20px',
          background: 'var(--bg-secondary)',
          border: '1px solid var(--border-glass)',
          boxShadow: 'var(--shadow-card)',
          display: 'flex',
          flexDirection: 'column',
          overflow: 'hidden'
        }}
      >
        {/* Modal Action Header */}
        <div style={{
          padding: '16px 24px',
          borderBottom: '1px solid var(--border-subtle)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          background: 'var(--bg-tertiary)'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Receipt size={20} style={{ color: 'var(--accent-primary)' }} />
            <span style={{ fontWeight: '700', fontSize: '1rem' }}>
              {isFree ? 'Registration Pass & Confirmation' : 'Official Payment Receipt'}
            </span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <button 
              onClick={handlePrint}
              className="btn-secondary"
              style={{ padding: '6px 12px', fontSize: '0.8rem', gap: '6px' }}
              title="Print Receipt"
            >
              <Printer size={14} /> Print
            </button>
            <button 
              onClick={handleDownloadPdf}
              className="btn-primary"
              style={{ padding: '6px 12px', fontSize: '0.8rem', gap: '6px' }}
              title="Download or Save as PDF"
            >
              <Download size={14} /> Download PDF
            </button>
            <button onClick={onClose} className="btn-secondary" style={{ padding: '6px', borderRadius: '8px' }}>
              <X size={16} />
            </button>
          </div>
        </div>

        {/* Printable Receipt Card Body */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '24px' }}>
          <div 
            id="printable-receipt-card"
            ref={printRef}
            style={{
              background: 'var(--bg-surface)',
              border: '1px solid var(--border-glass)',
              borderRadius: '16px',
              padding: '28px',
              position: 'relative'
            }}
          >
            {/* Top Brand Bar */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', borderBottom: '1px solid var(--border-subtle)', paddingBottom: '18px', marginBottom: '20px' }}>
              <div>
                <div style={{ fontSize: '1.4rem', fontWeight: '800', color: 'var(--accent-primary)', letterSpacing: '-0.02em' }}>
                  Learnique AI Platform
                </div>
                <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                  Academic Events & Live Collaboration System
                </div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div className="badge badge-present" style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', marginBottom: '6px' }}>
                  <ShieldCheck size={14} /> Verified Valid
                </div>
                <div style={{ fontSize: '0.8rem', fontFamily: 'var(--font-mono)', fontWeight: '700' }}>
                  {receiptNo}
                </div>
              </div>
            </div>

            {/* Event Title Banner */}
            <div style={{ marginBottom: '20px' }}>
              <div style={{ fontSize: '0.75rem', textTransform: 'uppercase', color: 'var(--text-muted)', fontWeight: '700', letterSpacing: '0.05em' }}>
                Event
              </div>
              <h3 style={{ fontSize: '1.2rem', margin: '4px 0 8px 0', color: 'var(--text-primary)' }}>
                {receipt.event_title || 'Academic Event'}
              </h3>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '16px', fontSize: '0.82rem', color: 'var(--text-secondary)' }}>
                <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <Calendar size={14} style={{ color: 'var(--accent-primary)' }} />
                  {receipt.event_date ? new Date(receipt.event_date).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' }) : 'Scheduled'} {receipt.start_time ? `at ${receipt.start_time}` : ''}
                </span>
                <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <MapPin size={14} style={{ color: '#06b6d4' }} />
                  {receipt.venue_type === 'ONLINE' ? 'Virtual Classroom' : (receipt.venue_address || 'Main Campus Venue')}
                </span>
              </div>
            </div>

            {/* Participant & Organizer Grid */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '14px', marginBottom: '20px' }}>
              <div style={{ padding: '12px 14px', borderRadius: '12px', background: 'var(--bg-tertiary)', border: '1px solid var(--border-subtle)' }}>
                <div style={{ fontSize: '0.72rem', textTransform: 'uppercase', color: 'var(--text-muted)', fontWeight: '700' }}>
                  Attendee Details
                </div>
                <div style={{ fontSize: '0.95rem', fontWeight: '700', marginTop: '4px' }}>
                  {receipt.participant_name}
                </div>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
                  {receipt.participant_email}
                </div>
                {receipt.participant_phone && (
                  <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                    Phone: {receipt.participant_phone}
                  </div>
                )}
              </div>

              <div style={{ padding: '12px 14px', borderRadius: '12px', background: 'var(--bg-tertiary)', border: '1px solid var(--border-subtle)' }}>
                <div style={{ fontSize: '0.72rem', textTransform: 'uppercase', color: 'var(--text-muted)', fontWeight: '700' }}>
                  Organized By
                </div>
                <div style={{ fontSize: '0.95rem', fontWeight: '700', marginTop: '4px' }}>
                  {receipt.organizer_name || 'Learnique University'}
                </div>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
                  {receipt.organizer_email || 'events@learnique.edu'}
                </div>
                <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                  Reg ID: <span style={{ fontFamily: 'var(--font-mono)' }}>{receipt.registration_number}</span>
                </div>
              </div>
            </div>

            {/* Ticket & Payment Summary Table */}
            <div style={{ marginBottom: '20px' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.85rem' }}>
                <thead>
                  <tr style={{ borderBottom: '2px solid var(--border-glass)', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase' }}>
                    <th style={{ padding: '8px 4px' }}>Item Description</th>
                    <th style={{ padding: '8px 4px', textAlign: 'center' }}>Pass Type</th>
                    <th style={{ padding: '8px 4px', textAlign: 'right' }}>Amount</th>
                  </tr>
                </thead>
                <tbody>
                  <tr style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                    <td style={{ padding: '12px 4px' }}>
                      <div style={{ fontWeight: '600' }}>Event Admission Access</div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                        Includes live participation, chat access & verified completion certificate
                      </div>
                    </td>
                    <td style={{ padding: '12px 4px', textAlign: 'center', fontWeight: '600' }}>
                      {receipt.ticket_name || 'Standard Pass'}
                    </td>
                    <td style={{ padding: '12px 4px', textAlign: 'right', fontWeight: '700' }}>
                      {isFree ? 'FREE (₹0.00)' : `₹${Number(amountPaid).toFixed(2)}`}
                    </td>
                  </tr>
                  <tr>
                    <td colSpan={2} style={{ padding: '12px 4px', textAlign: 'right', fontWeight: '700' }}>
                      Total Paid:
                    </td>
                    <td style={{ padding: '12px 4px', textAlign: 'right', fontWeight: '800', fontSize: '1rem', color: 'var(--accent-primary)' }}>
                      {isFree ? '₹0.00' : `₹${Number(amountPaid).toFixed(2)} ${receipt.currency || 'INR'}`}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Transaction metadata */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: '10px', padding: '12px 14px', borderRadius: '10px', background: 'var(--bg-tertiary)', fontSize: '0.78rem' }}>
              <div>
                <span style={{ color: 'var(--text-muted)' }}>Payment Method: </span>
                <span style={{ fontWeight: '600' }}>{receipt.provider || (isFree ? 'Complimentary' : 'Razorpay Secure')}</span>
              </div>
              <div>
                <span style={{ color: 'var(--text-muted)' }}>Txn Ref: </span>
                <span style={{ fontFamily: 'var(--font-mono)' }}>{receipt.transaction_id || receipt.payment_id || 'TXN-FREE-OK'}</span>
              </div>
              <div>
                <span style={{ color: 'var(--text-muted)' }}>Issue Date: </span>
                <span>{receipt.payment_date ? new Date(receipt.payment_date).toLocaleDateString() : new Date().toLocaleDateString()}</span>
              </div>
            </div>

            {/* Footer note */}
            <div style={{ marginTop: '20px', borderTop: '1px dashed var(--border-subtle)', paddingTop: '12px', textAlign: 'center', fontSize: '0.72rem', color: 'var(--text-muted)' }}>
              This is a computer-generated confirmation & receipt from Learnique AI Platform. Present this receipt or your Registration Number at the entry gate or online room.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
