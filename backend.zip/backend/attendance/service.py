from datetime import datetime, timedelta
from typing import Optional, Dict, Any, Tuple
from backend.config import config
from backend.database.db import query_one, query_all, execute_query, get_db
from backend.auth.security import generate_secure_token, hash_token, generate_backup_code
from backend.utils.qr_generator import generate_qr_data_url
from backend.utils.audit import log_audit

def create_attendance_session(
    teacher_id: int,
    subject_id: int,
    division_id: int,
    batch_id: Optional[int],
    session_type: str,
    room: str,
    date: str,
    scheduled_start: Optional[str] = None,
    scheduled_end: Optional[str] = None,
    timetable_id: Optional[int] = None,
    is_proxy: bool = False,
    proxy_teacher_id: Optional[int] = None,
    qr_interval_seconds: int = 30,
    max_qr_rotations: int = 5
) -> Dict[str, Any]:
    """Start an active attendance session and create Generation #1 QR and backup code."""
    # Determine semester from division
    division = query_one("SELECT semester FROM divisions WHERE id = ?", (division_id,))
    semester = division["semester"] if division else 1

    attendance_type = "PROXY" if is_proxy else "REGULAR"
    now = datetime.now()
    expires_at = now + timedelta(seconds=qr_interval_seconds)

    # 1. Insert session
    session_id = execute_query(
        """
        INSERT INTO attendance_sessions (
            timetable_id, teacher_id, proxy_teacher_id, attendance_type, subject_id,
            division_id, batch_id, semester, session_type, room, date,
            scheduled_start, scheduled_end, actual_start, status,
            qr_interval_seconds, max_qr_rotations, current_qr_generation, current_qr_expires_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'ACTIVE', ?, ?, 1, ?)
        """,
        (
            timetable_id, teacher_id, proxy_teacher_id if is_proxy else None,
            attendance_type, subject_id, division_id, batch_id, semester,
            session_type.upper(), room, date, scheduled_start, scheduled_end,
            now.strftime("%Y-%m-%d %H:%M:%S"), qr_interval_seconds, max_qr_rotations,
            expires_at.strftime("%Y-%m-%d %H:%M:%S")
        )
    )

    # 2. Generate Generation #1
    token = generate_secure_token(24)
    token_h = hash_token(token)
    backup_code = generate_backup_code(6)

    execute_query(
        """
        INSERT INTO qr_generations (session_id, generation_number, token_hash, backup_code, valid_from, valid_until)
        VALUES (?, 1, ?, ?, ?, ?)
        """,
        (
            session_id, token_h, backup_code,
            now.strftime("%Y-%m-%d %H:%M:%S"),
            expires_at.strftime("%Y-%m-%d %H:%M:%S")
        )
    )

    # 3. Create real web QR URL
    qr_url = f"{config.APP_BASE_URL}/join/attendance/{token}"
    qr_data_url = generate_qr_data_url(qr_url)

    log_audit("ATTENDANCE_SESSION_STARTED", "ATTENDANCE_SESSION", str(session_id), None, "Faculty", {
        "subject_id": subject_id, "division_id": division_id, "batch_id": batch_id,
        "type": session_type, "rotations": max_qr_rotations, "interval": qr_interval_seconds
    })

    return {
        "session_id": session_id,
        "generation": 1,
        "token": token,
        "backup_code": backup_code,
        "qr_url": qr_url,
        "qr_image": qr_data_url,
        "valid_from": now.isoformat(),
        "valid_until": expires_at.isoformat(),
        "expires_in_seconds": qr_interval_seconds,
        "max_rotations": max_qr_rotations
    }

def rotate_attendance_qr(session_id: int) -> Tuple[bool, Dict[str, Any], str]:
    """
    Advance session to the next QR generation. Invalidates the previous generation immediately.
    """
    session = query_one("SELECT * FROM attendance_sessions WHERE id = ?", (session_id,))
    if not session:
        return False, {}, "Attendance session not found"

    if session["status"] != "ACTIVE":
        return False, {}, f"Attendance session is no longer active (status: {session['status']})"

    current_gen = session["current_qr_generation"]
    max_rotations = session["max_qr_rotations"]

    if current_gen >= max_rotations:
        # Reached limit, close session
        close_attendance_session(session_id)
        return False, {"session_status": "COMPLETED"}, "Maximum QR rotations reached. Attendance session closed."

    next_gen = current_gen + 1
    now = datetime.now()
    expires_at = now + timedelta(seconds=session["qr_interval_seconds"])

    with get_db() as conn:
        cursor = conn.cursor()
        # Invalidate previous generation immediately
        cursor.execute(
            "UPDATE qr_generations SET invalidated_at = ? WHERE session_id = ? AND generation_number = ?",
            (now.strftime("%Y-%m-%d %H:%M:%S"), session_id, current_gen)
        )

        # Generate new credentials
        token = generate_secure_token(24)
        token_h = hash_token(token)
        backup_code = generate_backup_code(6)

        cursor.execute(
            """
            INSERT INTO qr_generations (session_id, generation_number, token_hash, backup_code, valid_from, valid_until)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                session_id, next_gen, token_h, backup_code,
                now.strftime("%Y-%m-%d %H:%M:%S"),
                expires_at.strftime("%Y-%m-%d %H:%M:%S")
            )
        )

        # Update session
        cursor.execute(
            """
            UPDATE attendance_sessions
            SET current_qr_generation = ?, current_qr_expires_at = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """,
            (next_gen, expires_at.strftime("%Y-%m-%d %H:%M:%S"), session_id)
        )

    qr_url = f"{config.APP_BASE_URL}/join/attendance/{token}"
    qr_data_url = generate_qr_data_url(qr_url)

    return True, {
        "session_id": session_id,
        "generation": next_gen,
        "token": token,
        "backup_code": backup_code,
        "qr_url": qr_url,
        "qr_image": qr_data_url,
        "valid_from": now.isoformat(),
        "valid_until": expires_at.isoformat(),
        "expires_in_seconds": session["qr_interval_seconds"],
        "max_rotations": max_rotations
    }, "Success"

def close_attendance_session(session_id: int) -> bool:
    """Manually or automatically finalize attendance session."""
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE attendance_sessions SET status = 'COMPLETED', actual_end = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
            (now_str, session_id)
        )
        cursor.execute(
            "UPDATE qr_generations SET invalidated_at = ? WHERE session_id = ? AND invalidated_at IS NULL",
            (now_str, session_id)
        )
    return True

def record_student_attendance(
    student_id: int,
    token: Optional[str] = None,
    backup_code: Optional[str] = None,
    session_id: Optional[int] = None,
    ip_address: Optional[str] = None
) -> Tuple[bool, str, Optional[Dict[str, Any]]]:
    """
    Validate and record a student's attendance.
    Strictly checks:
    - Active QR token or active backup code for current generation
    - Session active
    - Student active
    - Division match
    - Batch match
    - No duplicate marking
    """
    # 1. Fetch student
    student = query_one(
        """
        SELECT s.*, u.is_active, u.full_name, d.name as division_name, b.name as batch_name
        FROM students s
        JOIN users u ON s.user_id = u.id
        JOIN divisions d ON s.division_id = d.id
        JOIN batches b ON s.batch_id = b.id
        WHERE s.id = ?
        """,
        (student_id,)
    )
    if not student:
        return False, "Student record not found", None

    if not student["is_active"]:
        return False, "Student account is deactivated. Attendance cannot be recorded.", None

    now = datetime.now()
    now_str = now.strftime("%Y-%m-%d %H:%M:%S")
    gen_record = None
    sess_id = session_id
    method = "QR"

    if token:
        # Scanned QR URL token
        tok_hash = hash_token(token)
        gen_record = query_one(
            """
            SELECT qg.*, s.status as session_status, s.division_id as session_division_id,
                   s.batch_id as session_batch_id, s.session_type, s.room, sub.name as subject_name,
                   sub.code as subject_code
            FROM qr_generations qg
            JOIN attendance_sessions s ON qg.session_id = s.id
            JOIN subjects sub ON s.subject_id = sub.id
            WHERE qg.token_hash = ?
            """,
            (tok_hash,)
        )
        if not gen_record:
            return False, "Invalid attendance QR code.", None
        sess_id = gen_record["session_id"]
        method = "QR"

    elif backup_code and session_id:
        # Entered numeric 6-digit backup code
        gen_record = query_one(
            """
            SELECT qg.*, s.status as session_status, s.division_id as session_division_id,
                   s.batch_id as session_batch_id, s.session_type, s.room, sub.name as subject_name,
                   sub.code as subject_code
            FROM qr_generations qg
            JOIN attendance_sessions s ON qg.session_id = s.id
            JOIN subjects sub ON s.subject_id = sub.id
            WHERE qg.session_id = ? AND qg.backup_code = ?
            ORDER BY qg.generation_number DESC LIMIT 1
            """,
            (session_id, backup_code.strip())
        )
        if not gen_record:
            return False, "Invalid backup attendance code.", None
        method = "CODE"

    else:
        return False, "Either a valid QR token or a session ID with backup code must be provided.", None

    # Check session state
    if gen_record["session_status"] != "ACTIVE":
        return False, "Attendance is no longer active for this lecture.", None

    # Check if this generation was invalidated or expired
    if gen_record["invalidated_at"] is not None:
        return False, "This QR code has expired. Please scan the current QR displayed by your teacher.", None

    valid_until = datetime.strptime(gen_record["valid_until"], "%Y-%m-%d %H:%M:%S")
    if now > valid_until:
        return False, "This QR code has expired. Please scan the current QR displayed by your teacher.", None

    # 4. Division Check
    if student["division_id"] != gen_record["session_division_id"]:
        return False, "You are not enrolled in the division designated for this attendance session.", None

    # 5. Batch Check (If session is practical or specific to a batch)
    if gen_record["session_batch_id"] is not None:
        if student["batch_id"] != gen_record["session_batch_id"]:
            return False, "You are not enrolled in the batch designated for this practical session.", None

    # 6. Duplicate Check
    existing_rec = query_one(
        "SELECT id, marked_at FROM attendance_records WHERE session_id = ? AND student_id = ?",
        (sess_id, student_id)
    )
    if existing_rec:
        return False, "Your attendance has already been recorded for this session.", None

    # 7. Record Attendance
    try:
        execute_query(
            """
            INSERT INTO attendance_records (session_id, student_id, status, marked_at, verification_method, ip_address)
            VALUES (?, ?, 'PRESENT', ?, ?, ?)
            """,
            (sess_id, student_id, now_str, method, ip_address or "127.0.0.1")
        )
    except Exception as e:
        if "UNIQUE constraint failed" in str(e):
            return False, "Your attendance has already been recorded for this session.", None
        raise

    log_audit("ATTENDANCE_MARKED", "ATTENDANCE_RECORD", str(sess_id), student["user_id"], student["full_name"], {
        "student_id": student_id, "method": method, "generation": gen_record["generation_number"]
    }, ip_address)

    return True, "Attendance successfully recorded", {
        "status": "PRESENT",
        "subject_name": gen_record["subject_name"],
        "subject_code": gen_record["subject_code"],
        "session_type": gen_record["session_type"],
        "room": gen_record["room"],
        "marked_at": now_str,
        "verification_method": method
    }

def calculate_student_attendance(student_id: int) -> Dict[str, Any]:
    """
    Calculate raw counts and mathematically exact percentages for a student.
    Rules:
    - Theory % = (present_th / total_th) * 100
    - Practical % = (present_pr / total_pr) * 100
    - Overall % = (present_th + present_pr) / (total_th + total_pr) * 100
    NEVER average percentages!
    """
    # Fetch all subjects for student's semester/branch
    student = query_one("SELECT * FROM students WHERE id = ?", (student_id,))
    if not student:
        return {"subjects": [], "overall": {"total": 0, "present": 0, "percentage": 0.0}}

    subjects = query_all(
        "SELECT * FROM subjects WHERE semester = ? ORDER BY code ASC",
        (student["semester"],)
    )

    grand_total_th = 0
    grand_pres_th = 0
    grand_abs_th = 0
    grand_total_pr = 0
    grand_pres_pr = 0
    grand_abs_pr = 0

    subject_results = []

    for sub in subjects:
        # Theory counts
        th_total_row = query_one(
            """
            SELECT COUNT(ar.id) as total,
                   SUM(CASE WHEN ar.status = 'PRESENT' THEN 1 ELSE 0 END) as present,
                   SUM(CASE WHEN ar.status = 'ABSENT' THEN 1 ELSE 0 END) as absent,
                   SUM(CASE WHEN ar.status = 'LEAVE' THEN 1 ELSE 0 END) as leave
            FROM attendance_records ar
            JOIN attendance_sessions s ON ar.session_id = s.id
            WHERE ar.student_id = ? AND s.subject_id = ? AND s.session_type = 'THEORY' AND s.status != 'CANCELLED'
            """,
            (student_id, sub["id"])
        )
        th_tot = th_total_row["total"] if th_total_row and th_total_row["total"] else 0
        th_prs = th_total_row["present"] if th_total_row and th_total_row["present"] else 0
        th_abs = th_total_row["absent"] if th_total_row and th_total_row["absent"] else 0
        th_pct = round((th_prs / th_tot * 100), 2) if th_tot > 0 else 0.0

        # Practical counts
        pr_total_row = query_one(
            """
            SELECT COUNT(ar.id) as total,
                   SUM(CASE WHEN ar.status = 'PRESENT' THEN 1 ELSE 0 END) as present,
                   SUM(CASE WHEN ar.status = 'ABSENT' THEN 1 ELSE 0 END) as absent,
                   SUM(CASE WHEN ar.status = 'LEAVE' THEN 1 ELSE 0 END) as leave
            FROM attendance_records ar
            JOIN attendance_sessions s ON ar.session_id = s.id
            WHERE ar.student_id = ? AND s.subject_id = ? AND s.session_type = 'PRACTICAL' AND s.status != 'CANCELLED'
            """,
            (student_id, sub["id"])
        )
        pr_tot = pr_total_row["total"] if pr_total_row and pr_total_row["total"] else 0
        pr_prs = pr_total_row["present"] if pr_total_row and pr_total_row["present"] else 0
        pr_abs = pr_total_row["absent"] if pr_total_row and pr_total_row["absent"] else 0
        pr_pct = round((pr_prs / pr_tot * 100), 2) if pr_tot > 0 else 0.0

        sub_tot = th_tot + pr_tot
        sub_prs = th_prs + pr_prs
        sub_overall_pct = round((sub_prs / sub_tot * 100), 2) if sub_tot > 0 else 0.0

        grand_total_th += th_tot
        grand_pres_th += th_prs
        grand_abs_th += th_abs
        grand_total_pr += pr_tot
        grand_pres_pr += pr_prs
        grand_abs_pr += pr_abs

        subject_results.append({
            "subject_id": sub["id"],
            "subject_code": sub["code"],
            "subject_name": sub["name"],
            "theory": {
                "total": th_tot,
                "present": th_prs,
                "absent": th_abs,
                "percentage": th_pct
            },
            "practical": {
                "total": pr_tot,
                "present": pr_prs,
                "absent": pr_abs,
                "percentage": pr_pct
            },
            "overall": {
                "total": sub_tot,
                "present": sub_prs,
                "percentage": sub_overall_pct
            }
        })

    total_conducted = grand_total_th + grand_total_pr
    total_attended = grand_pres_th + grand_pres_pr
    grand_overall_pct = round((total_attended / total_conducted * 100), 2) if total_conducted > 0 else 0.0

    return {
        "subjects": subject_results,
        "theory_summary": {
            "total": grand_total_th,
            "present": grand_pres_th,
            "absent": grand_abs_th,
            "percentage": round((grand_pres_th / grand_total_th * 100), 2) if grand_total_th > 0 else 0.0
        },
        "practical_summary": {
            "total": grand_total_pr,
            "present": grand_pres_pr,
            "absent": grand_abs_pr,
            "percentage": round((grand_pres_pr / grand_total_pr * 100), 2) if grand_total_pr > 0 else 0.0
        },
        "overall_summary": {
            "total": total_conducted,
            "present": total_attended,
            "absent": (grand_abs_th + grand_abs_pr),
            "percentage": grand_overall_pct
        }
    }
