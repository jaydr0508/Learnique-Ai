import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNotification } from '../context/NotificationContext';
import {
  Calendar,
  Clock,
  QrCode,
  Users,
  Award,
  Sparkles,
  Plus,
  Play,
  RotateCw,
  StopCircle,
  Eye,
  CheckCircle,
  FileDown,
  AlertCircle,
  BookOpen,
  Send,
  FileText,
  X,
  Edit2,
  Trash2,
  User,
  Layers,
  ThumbsUp,
  ThumbsDown,
  Copy,
  Check,
  Lightbulb,
  Presentation,
  Code,
  GraduationCap,
  Paperclip
} from 'lucide-react';
import QuizCreatorModal from './QuizCreatorModal';
import SemesterHierarchyView from './SemesterHierarchyView';
import { formatAIResponse } from '../utils/textUtils';

export default function TeacherDashboard({ activeTab, setActiveTab }) {
  const { token, user } = useAuth();
  const { confirm: confirmModal, notify } = useNotification();

  const [loading, setLoading] = useState(true);
  const [dashboardData, setDashboardData] = useState(null);
  const [teacherProfileData, setTeacherProfileData] = useState(null);
  const [activeSession, setActiveSession] = useState(null);
  const [liveQRState, setLiveQRState] = useState(null);
  const [liveAttendees, setLiveAttendees] = useState([]);
  const [students, setStudents] = useState([]);
  const [quizzes, setQuizzes] = useState([]);
  const [structure, setStructure] = useState({ subjects: [], divisions: [], batches: [] });

  // Quiz Modal & Monitor Modals
  const [isQuizModalOpen, setIsQuizModalOpen] = useState(false);
  const [quizModalTab, setQuizModalTab] = useState('INFO');
  const [quizModalSubjectId, setQuizModalSubjectId] = useState('');
  const [monitorQuizId, setMonitorQuizId] = useState(null);
  const [monitorData, setMonitorData] = useState(null);
  const [evaluatingAttempt, setEvaluatingAttempt] = useState(null);
  const [evalMarks, setEvalMarks] = useState({});

  // Enroll Student Modal State
  const [isEnrollModalOpen, setIsEnrollModalOpen] = useState(false);
  const [enrollForm, setEnrollForm] = useState({
    enrollment_number: '',
    name: '',
    email: '',
    phone: '',
    password: '',
    division_id: '',
    batch_id: '',
    branch: 'Computer Science & Engineering',
    gender: 'Male'
  });
  const [enrollError, setEnrollError] = useState('');
  const [enrollSuccess, setEnrollSuccess] = useState('');

  // AI Assistant Chat State (Mirroring Student AI Doubt Solver with Faculty Pedagogy)
  const [aiMessage, setAiMessage] = useState('');
  const [aiSubject, setAiSubject] = useState('Academic Curriculum & Assessment Design');
  const [aiTopic, setAiTopic] = useState('');
  const [aiThreadId, setAiThreadId] = useState(null);
  const [aiChatHistory, setAiChatHistory] = useState([]);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiAttachment, setAiAttachment] = useState(null);
  const [isGeneratingAiPdf, setIsGeneratingAiPdf] = useState(false);
  const [aiCopiedIndex, setAiCopiedIndex] = useState(null);
  const [aiFeedback, setAiFeedback] = useState({});
  const aiFileInputRef = useRef(null);
  const aiChatEndRef = useRef(null);

  // Timetable & Proxy Scheduling State
  const [allTimetable, setAllTimetable] = useState([]);
  const [isLectureModalOpen, setIsLectureModalOpen] = useState(false);
  const [editingLectureId, setEditingLectureId] = useState(null);
  const [lectureForm, setLectureForm] = useState({
    subject_id: '',
    division_id: '',
    batch_id: '',
    day_of_week: 1,
    start_time: '09:00',
    end_time: '10:00',
    session_type: 'THEORY',
    room: 'EA-101'
  });
  const [editingMaxSwitches, setEditingMaxSwitches] = useState(null);

  useEffect(() => {
    loadTeacherData();
    loadAcademicStructure();
    loadTeacherTimetable();
  }, [token]);

  async function loadTeacherTimetable() {
    try {
      const res = await fetch('/api/teacher/timetable', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      setAllTimetable(data.timetable || []);
    } catch (e) {
      console.error('Failed to load teacher timetable', e);
    }
  }

  async function handleSaveLecture(e) {
    e.preventDefault();
    try {
      const url = editingLectureId ? `/api/teacher/timetable/${editingLectureId}` : '/api/teacher/timetable';
      const method = editingLectureId ? 'PUT' : 'POST';
      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(lectureForm)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save lecture schedule');
      setIsLectureModalOpen(false);
      setEditingLectureId(null);
      notify('Lecture schedule saved successfully.', 'success');
      loadTeacherData();
      loadTeacherTimetable();
    } catch (err) {
      notify(err.message, 'error');
    }
  }

  async function handleDeleteLecture(entryId) {
    const ok = await confirmModal({
      title: 'Remove Scheduled Class',
      message: 'Are you sure you want to remove this scheduled lecture/proxy class?',
      type: 'danger',
      confirmText: 'Yes, Remove'
    });
    if (!ok) return;

    try {
      const res = await fetch(`/api/teacher/timetable/${entryId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to delete lecture');
      notify('Class schedule removed.', 'info');
      loadTeacherData();
      loadTeacherTimetable();
    } catch (err) {
      notify(err.message, 'error');
    }
  }

  async function handleDeleteQuiz(quizId, quizTitle) {
    const ok = await confirmModal({
      title: 'Delete Examination',
      message: `Are you sure you want to permanently delete quiz "${quizTitle}"? All student attempts and records will be deleted.`,
      type: 'danger',
      confirmText: 'Yes, Delete'
    });
    if (!ok) return;

    try {
      const res = await fetch(`/api/quizzes/${quizId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to delete quiz');
      notify('Quiz deleted successfully.', 'info');
      loadTeacherData();
    } catch (err) {
      notify(err.message, 'error');
    }
  }

  function openEditLecture(lecture) {
    setEditingLectureId(lecture.id);
    setLectureForm({
      subject_id: lecture.subject_id,
      division_id: lecture.division_id,
      batch_id: lecture.batch_id || '',
      day_of_week: lecture.day_of_week || 1,
      start_time: lecture.start_time || '09:00',
      end_time: lecture.end_time || '10:00',
      session_type: lecture.session_type || 'THEORY',
      room: lecture.room || 'EA-101',
      is_proxy: Boolean(lecture.is_proxy),
      specific_date: lecture.specific_date || new Date().toISOString().split('T')[0]
    });
    setIsLectureModalOpen(true);
  }

  function openCreateLecture() {
    setEditingLectureId(null);
    setLectureForm({
      subject_id: structure.subjects[0]?.id || '',
      division_id: structure.divisions[0]?.id || '',
      batch_id: '',
      day_of_week: 1,
      start_time: '09:00',
      end_time: '10:00',
      session_type: 'THEORY',
      room: 'EA-101',
      is_proxy: false,
      specific_date: new Date().toISOString().split('T')[0]
    });
    setIsLectureModalOpen(true);
  }

  async function saveMaxViolations(quizId, newLimit) {
    try {
      const res = await fetch(`/api/quizzes/${quizId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ max_tab_switches: parseInt(newLimit, 10) })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to update max tab switches');
      notify('Maximum tab switch violation limit updated successfully!', 'success');
      if (monitorData && monitorData.quiz.id === quizId) {
        setMonitorData({
          ...monitorData,
          quiz: { ...monitorData.quiz, max_tab_switches: parseInt(newLimit, 10) }
        });
      }
      loadTeacherData();
    } catch (err) {
      notify(err.message, 'error');
    }
  }

  async function loadTeacherData() {
    setLoading(true);
    try {
      const [res, profRes] = await Promise.all([
        fetch('/api/teacher/dashboard', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/teacher/profile', { headers: { Authorization: `Bearer ${token}` } })
      ]);
      const data = await res.json();
      setDashboardData(data);

      try {
        const profData = await profRes.json();
        if (profData.profile) setTeacherProfileData(profData.profile);
      } catch (e) {}

      if (data.activeSessions && data.activeSessions.length > 0) {
        startTrackingSession(data.activeSessions[0].id);
      }

      // Populate structure directly from teacher's authorized assignments
      if (data.assignments && data.assignments.length > 0) {
        const subMap = new Map();
        const divMap = new Map();
        const batchMap = new Map();
        for (const a of data.assignments) {
          if (a.subject_id && !subMap.has(a.subject_id)) {
            subMap.set(a.subject_id, { id: a.subject_id, name: a.subject_name, code: a.subject_code });
          }
          if (a.division_id && !divMap.has(a.division_id)) {
            divMap.set(a.division_id, { id: a.division_id, name: a.division_name });
          }
          if (a.batch_id && !batchMap.has(a.batch_id)) {
            batchMap.set(a.batch_id, { id: a.batch_id, name: a.batch_name, division_id: a.division_id });
          }
        }
        setStructure({
          subjects: Array.from(subMap.values()),
          divisions: Array.from(divMap.values()),
          batches: Array.from(batchMap.values())
        });
      }

      // Load quizzes
      const qRes = await fetch('/api/quizzes', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const qData = await qRes.json();
      setQuizzes(qData.quizzes || []);

      // Load students
      const sRes = await fetch('/api/teacher/students', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const sData = await sRes.json();
      setStudents(sData.students || []);
    } catch (e) {
      console.error('Failed to load teacher dashboard', e);
    } finally {
      setLoading(false);
    }
  }

  async function loadAcademicStructure() {
    try {
      const res = await fetch('/api/admin/structure', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      setStructure(data);
    } catch (e) {}
  }

  // Poll Active QR Session
  useEffect(() => {
    if (!activeSession) return;
    const interval = setInterval(() => {
      fetch(`/api/attendance/session/${activeSession.id}/qr`, {
        headers: { Authorization: `Bearer ${token}` }
      })
        .then(res => res.json())
        .then(data => {
          if (data.sessionClosed) {
            notify('Attendance session completed or expired.', 'info');
            setActiveSession(null);
            setLiveQRState(null);
            loadTeacherData();
          } else {
            setLiveQRState(data.qr);
            setLiveAttendees(data.attendees || []);
          }
        })
        .catch(e => console.error(e));
    }, 2000);

    return () => clearInterval(interval);
  }, [activeSession]);

  async function startAttendanceFromTimetable(entry) {
    try {
      const res = await fetch('/api/attendance/start', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          timetable_entry_id: entry.id,
          subject_id: entry.subject_id,
          division_id: entry.division_id,
          batch_ids: entry.batch_id ? [entry.batch_id] : [],
          session_type: entry.session_type,
          room: entry.room,
          qr_interval_seconds: 30,
          max_qr_rotations: 5,
          scheduled_start: entry.start_time,
          scheduled_end: entry.end_time,
          is_proxy: Boolean(entry.is_proxy),
          attendance_type: entry.is_proxy ? 'PROXY' : 'REGULAR'
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to start attendance');

      setActiveSession(data.session);
      setLiveQRState(data.qr);
      notify('Attendance session started with rotating QR & backup code.', 'success');
    } catch (err) {
      notify(err.message, 'error');
    }
  }

  async function startTrackingSession(sessionId) {
    try {
      const res = await fetch(`/api/attendance/session/${sessionId}/qr`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (!data.sessionClosed) {
        setActiveSession(data.session);
        setLiveQRState(data.qr);
        setLiveAttendees(data.attendees || []);
      }
    } catch (e) {}
  }

  async function advanceRotation() {
    if (!activeSession) return;
    try {
      const res = await fetch(`/api/attendance/session/${activeSession.id}/qr?advance=true`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.sessionClosed) {
        notify('All QR rotations completed.', 'info');
        setActiveSession(null);
        setLiveQRState(null);
      } else {
        setLiveQRState(data.qr);
        notify('Advanced to next rotation cycle.', 'info');
      }
    } catch (e) {
      notify('Failed to advance rotation', 'error');
    }
  }

  async function endActiveSession() {
    if (!activeSession) return;
    const ok = await confirmModal({
      title: 'End Attendance Session',
      message: 'Are you sure you want to end this attendance session now?',
      type: 'warning',
      confirmText: 'Yes, End Session'
    });
    if (!ok) return;

    try {
      await fetch(`/api/attendance/session/${activeSession.id}/end`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      notify('Attendance session ended successfully.', 'success');
      setActiveSession(null);
      setLiveQRState(null);
      loadTeacherData();
    } catch (e) {
      notify('Failed to end session', 'error');
    }
  }

  async function openLiveMonitor(quizId) {
    setMonitorQuizId(quizId);
    try {
      const res = await fetch(`/api/quizzes/${quizId}/monitor`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      setMonitorData(data);
    } catch (e) {}
  }

  async function handleEnrollStudent(e) {
    e.preventDefault();
    setEnrollError('');
    setEnrollSuccess('');

    try {
      const res = await fetch('/api/teacher/students', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(enrollForm)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to enroll student');

      setEnrollSuccess('Student enrolled successfully in your assigned division/batch!');
      setEnrollForm({
        enrollment_number: '',
        name: '',
        email: '',
        phone: '',
        password: '',
        division_id: '',
        batch_id: '',
        branch: 'Computer Science & Engineering',
        gender: 'Male'
      });
      loadTeacherData();
    } catch (err) {
      setEnrollError(err.message);
    }
  }

  // Restore Faculty AI Assistant history when tab becomes active
  useEffect(() => {
    if (activeTab === 'ai_assistant' && aiChatHistory.length === 0 && token) {
      fetch('/api/teacher/ai/history', {
        headers: { Authorization: `Bearer ${token}` }
      })
      .then(res => res.json())
      .then(data => {
        if (data.messages && data.messages.length > 0) {
          setAiChatHistory(data.messages);
          if (data.thread) {
            setAiThreadId(data.thread.id);
            if (data.thread.subject) setAiSubject(data.thread.subject);
            if (data.thread.topic) setAiTopic(data.thread.topic);
          }
        }
      })
      .catch(() => {});
    }
  }, [activeTab, token]);

  // Auto-scroll AI chat to bottom
  useEffect(() => {
    if (activeTab === 'ai_assistant') {
      aiChatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [aiChatHistory, aiLoading, activeTab]);

  const handleAiFileUpload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 20 * 1024 * 1024) {
      notify('File is too large. Maximum supported file size is 20MB.', 'error');
      return;
    }

    const ext = file.name.split('.').pop()?.toLowerCase() || '';
    let fileCategory = 'document';
    if (['png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp'].includes(ext)) {
      fileCategory = 'image';
    } else if (['ppt', 'pptx'].includes(ext)) {
      fileCategory = 'presentation';
    } else if (['doc', 'docx'].includes(ext)) {
      fileCategory = 'word';
    } else if (ext === 'pdf') {
      fileCategory = 'pdf';
    } else if (['py', 'js', 'ts', 'jsx', 'tsx', 'html', 'css', 'json', 'sql', 'c', 'cpp', 'java'].includes(ext)) {
      fileCategory = 'code';
    }

    const reader = new FileReader();
    reader.onload = () => {
      setAiAttachment({
        name: file.name,
        type: file.type || `application/${ext}`,
        data: reader.result,
        size: `${(file.size / 1024).toFixed(1)} KB`,
        isImage: fileCategory === 'image',
        previewUrl: fileCategory === 'image' ? reader.result : null,
        category: fileCategory
      });
      notify(`Attached: ${file.name} (${fileCategory.toUpperCase()})`, 'info');
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  async function handleSendAIChat(e, forceCreatePdf = false, promptOverride = null) {
    if (e && e.preventDefault) e.preventDefault();
    const activeText = promptOverride || aiMessage;
    if (!activeText.trim() && !aiAttachment) return;

    const userText = activeText.trim() || (aiAttachment ? `Please analyze the attached course material ${aiAttachment.name} and provide pedagogical takeaways, lesson ideas, and quiz questions.` : '');
    const currentAttachment = aiAttachment;
    const currentTopic = aiTopic.trim() || 'Curriculum & Assessment';

    if (!promptOverride) setAiMessage('');
    setAiAttachment(null);

    const userMsgObj = {
      sender: 'USER',
      content: userText,
      topic: currentTopic,
      attachment: currentAttachment ? {
        name: currentAttachment.name,
        type: currentAttachment.type,
        previewUrl: currentAttachment.previewUrl,
        size: currentAttachment.size,
        isImage: currentAttachment.isImage,
        category: currentAttachment.category
      } : null
    };

    setAiChatHistory(prev => [...prev, userMsgObj]);
    setAiLoading(true);

    try {
      const res = await fetch('/api/teacher/ai/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          threadId: aiThreadId,
          message: forceCreatePdf ? `${userText}\n(Please format this systematically as an official academic lesson plan / exam rubrics guide to be downloaded as a PDF document.)` : userText,
          subject: aiSubject,
          topic: currentTopic,
          history: aiChatHistory.map(m => ({ sender: m.sender, content: m.content })),
          attachment: currentAttachment ? {
            name: currentAttachment.name,
            type: currentAttachment.type,
            data: currentAttachment.data
          } : null,
          createPdf: forceCreatePdf
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'AI Assistant failed');

      setAiThreadId(data.threadId);
      setAiChatHistory(prev => [...prev, {
        sender: 'AI',
        content: data.response,
        canCreatePdf: true,
        topic: currentTopic,
        subject: aiSubject
      }]);

      if (forceCreatePdf) {
        handleDownloadAiPdf(data.response, aiSubject, currentTopic || userText);
      }
    } catch (err) {
      notify('Faculty AI Assistant error: ' + err.message, 'error');
    } finally {
      setAiLoading(false);
    }
  }

  async function handleClearAIChat() {
    setAiChatHistory([]);
    setAiThreadId(null);
    setAiAttachment(null);
    try {
      await fetch('/api/teacher/ai/clear', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      notify('Conversation cleared. Started a fresh faculty session.', 'info');
    } catch (e) {}
  }

  async function handleDownloadAiPdf(content, subject = aiSubject, title = '') {
    try {
      setIsGeneratingAiPdf(true);
      notify('Generating faculty lesson plan / rubric PDF...', 'info');

      const res = await fetch('/api/teacher/ai/pdf', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          title: title ? `Faculty Guide: ${title.slice(0, 45)}` : `Teaching Notes - ${subject}`,
          subject: subject,
          topic: title || 'Lesson Plan & Assessment Guide',
          content: content,
          teacher_name: teacherProfileData?.name || user?.name || 'Faculty Instructor'
        })
      });

      if (!res.ok) throw new Error('Server PDF generation failed');

      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      const safeSubject = (subject || 'teaching').replace(/[^a-zA-Z0-9]/g, '_');
      a.download = `Learnique_AI_Faculty_Notes_${safeSubject}.pdf`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
      notify('Faculty teaching PDF downloaded successfully!', 'success');
    } catch (err) {
      try {
        const printWin = window.open('', '', 'height=750,width=850');
        printWin.document.write(`
          <html>
            <head>
              <title>Learnique AI Faculty Guide - ${subject}</title>
              <style>
                body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; padding: 40px; color: #1e293b; line-height: 1.6; }
                .header { border-bottom: 2px solid #4f46e5; padding-bottom: 15px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; }
                .brand { font-size: 22px; font-weight: 800; color: #4f46e5; }
                .meta { background: #f1f5f9; padding: 10px 14px; border-radius: 8px; margin-bottom: 20px; font-size: 13px; }
                .content { font-size: 14px; white-space: pre-wrap; line-height: 1.6; }
                .footer { margin-top: 30px; border-top: 1px dashed #cbd5e1; padding-top: 12px; font-size: 11px; color: #64748b; text-align: center; }
              </style>
            </head>
            <body>
              <div class="header">
                <div>
                  <div class="brand">LEARNIQUE AI ACADEMIC PLATFORM</div>
                  <div style="font-size: 12px; color: #64748b;">Faculty AI Academic Assistant • Lecture Preparation, Rubrics & Notes</div>
                </div>
                <div style="text-align: right; font-size: 12px; color: #64748b;">
                  <div>Instructor: <b>${teacherProfileData?.name || user?.name || 'Faculty Instructor'}</b></div>
                  <div>Date: ${new Date().toLocaleDateString()}</div>
                </div>
              </div>
              <div class="meta">
                <b>Subject:</b> ${subject} &nbsp;|&nbsp; <b>Topic:</b> ${title || 'Curriculum & Assessment Design'}
              </div>
              <div class="content">${content.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</div>
              <div class="footer">Generated by Learnique AI Faculty Academic Assistant • Designed for university instruction and assessment design</div>
            </body>
          </html>
        `);
        printWin.document.close();
        printWin.focus();
        setTimeout(() => {
          printWin.print();
          printWin.close();
        }, 350);
        notify('Opened printable PDF window', 'info');
      } catch (clientErr) {
        notify('Failed to generate PDF: ' + err.message, 'error');
      }
    } finally {
      setIsGeneratingAiPdf(false);
    }
  }

  function handleDownloadFullSessionAiPdf() {
    if (aiChatHistory.length === 0) {
      notify('No messages in current session to export', 'warning');
      return;
    }
    const fullText = aiChatHistory.map(m => {
      const sender = m.sender === 'USER' ? `INSTRUCTOR (${teacherProfileData?.name || user?.name || 'Faculty'})` : 'LEARNIQUE AI FACULTY TEACHING ASSISTANT';
      return `${sender}:\n${m.content}\n----------------------------------------\n`;
    }).join('\n\n');

    handleDownloadAiPdf(fullText, aiSubject, `Full Teaching Session - ${aiSubject}`);
  }

  const handleAiFeedback = (idx, type) => {
    setAiFeedback(prev => ({
      ...prev,
      [idx]: prev[idx] === type ? null : type
    }));
    notify(type === 'up' ? 'Helpful response feedback recorded' : 'Feedback recorded for future improvements', 'info');
  };

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '60px', color: 'var(--text-muted)' }}>
        Loading Faculty Portal...
      </div>
    );
  }

  return (
    <div style={{ padding: '0 24px 40px 24px', maxWidth: '1300px', margin: '0 auto' }}>
      {/* ACTIVE ATTENDANCE ROTATING QR OVERLAY / SECTION */}
      {activeSession && liveQRState && (
        <div className="glass-panel animate-fade-in" style={{
          padding: '28px',
          borderRadius: '24px',
          marginBottom: '28px',
          border: '2px solid var(--accent-primary)',
          boxShadow: '0 0 35px var(--accent-glow)'
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <div style={{
                width: '42px',
                height: '42px',
                borderRadius: '12px',
                background: 'var(--accent-light)',
                color: 'var(--accent-primary)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                <QrCode size={24} />
              </div>
              <div>
                <h2 style={{ fontSize: '1.4rem', fontWeight: '800' }}>Active Rotating QR Attendance</h2>
                <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                  {activeSession.session_type} Session • Room {activeSession.room} • Rotation {liveQRState.generation} of {liveQRState.maxRotations}
                </p>
              </div>
            </div>

            <div style={{ display: 'flex', gap: '10px' }}>
              <button onClick={advanceRotation} className="btn-secondary" style={{ padding: '9px 16px' }}>
                <RotateCw size={16} /> Next Rotation
              </button>
              <button onClick={endActiveSession} className="btn-primary" style={{ padding: '9px 16px', background: 'linear-gradient(135deg, #ef4444, #dc2626)' }}>
                <StopCircle size={16} /> End Attendance
              </button>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '360px 1fr', gap: '30px', alignItems: 'center' }}>
            {/* Left: Large High-Resolution QR Display */}
            <div style={{
              background: '#ffffff',
              padding: '16px',
              borderRadius: '20px',
              textAlign: 'center',
              boxShadow: '0 10px 30px rgba(0, 0, 0, 0.2)'
            }}>
              {liveQRState.qrDataUrl ? (
                <img
                  src={liveQRState.qrDataUrl}
                  alt="Live Attendance QR"
                  style={{ width: '100%', maxWidth: '320px', display: 'block', margin: '0 auto', borderRadius: '12px' }}
                />
              ) : (
                <div style={{ height: '300px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#64748b' }}>
                  Rotating cryptographic token...
                </div>
              )}

              {/* Prominent Backup Code */}
              <div style={{ marginTop: '14px', padding: '12px', background: '#f8fafc', borderRadius: '14px', border: '2px solid #e2e8f0' }}>
                <div style={{ fontSize: '0.75rem', fontWeight: '700', color: '#475569', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                  Student Attendance Code
                </div>
                <div style={{
                  fontSize: '1.9rem',
                  fontWeight: '900',
                  letterSpacing: '0.15em',
                  color: '#0f172a',
                  fontFamily: 'var(--font-mono)',
                  margin: '4px 0'
                }}>
                  {liveQRState.backupCode || '------'}
                </div>
                <div style={{ fontSize: '0.72rem', color: '#64748b', marginTop: '4px' }}>
                  Students can enter this code directly on their dashboard to mark attendance immediately.
                </div>
              </div>
            </div>

            {/* Right: Live Attendee Stats & List */}
            <div>
              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(3, 1fr)',
                gap: '14px',
                marginBottom: '20px'
              }}>
                <div style={{ padding: '16px', background: 'var(--bg-tertiary)', borderRadius: '14px' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Students Present</div>
                  <div style={{ fontSize: '1.75rem', fontWeight: '800', color: 'var(--success)' }}>
                    {liveAttendees.length}
                  </div>
                </div>
                <div style={{ padding: '16px', background: 'var(--bg-tertiary)', borderRadius: '14px' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Interval Validity</div>
                  <div style={{ fontSize: '1.75rem', fontWeight: '800', color: 'var(--text-primary)' }}>
                    {liveQRState.intervalSeconds}s
                  </div>
                </div>
                <div style={{ padding: '16px', background: 'var(--bg-tertiary)', borderRadius: '14px' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Current Rotation</div>
                  <div style={{ fontSize: '1.75rem', fontWeight: '800', color: 'var(--accent-primary)' }}>
                    {liveQRState.generation} / {liveQRState.maxRotations}
                  </div>
                </div>
              </div>

              {/* Attendee Feed */}
              <h4 style={{ fontSize: '0.9rem', fontWeight: '700', marginBottom: '10px' }}>
                Live Verification Stream
              </h4>
              <div style={{
                maxHeight: '220px',
                overflowY: 'auto',
                background: 'var(--bg-tertiary)',
                borderRadius: '14px',
                padding: '12px'
              }}>
                {liveAttendees.length === 0 ? (
                  <div style={{ textAlign: 'center', padding: '30px', color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                    Awaiting eligible student scans...
                  </div>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                    {liveAttendees.map((att, aIdx) => (
                      <div key={aIdx} style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        padding: '8px 12px',
                        background: 'var(--bg-secondary)',
                        borderRadius: '8px',
                        fontSize: '0.85rem'
                      }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                          <CheckCircle size={16} style={{ color: 'var(--success)' }} />
                          <span style={{ fontWeight: '600' }}>{att.name}</span>
                          <span style={{ color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', fontSize: '0.78rem' }}>
                            ({att.enrollment_number})
                          </span>
                        </div>
                        <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                          {new Date(att.marked_at).toLocaleTimeString()}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* VIEW: ASSIGNED SEMESTERS HIERARCHY (Semester > Branch > Courses > Lectures/Quizzes) */}
      {(activeTab === 'semester_system') && (
        <div style={{ marginBottom: '32px' }}>
          <SemesterHierarchyView
            role="TEACHER"
            divisions={structure.divisions}
            onStartAttendance={startAttendanceFromTimetable}
            onOpenQuizMonitor={openLiveMonitor}
            onOpenQuizCreator={(course) => {
              setQuizModalSubjectId(course.id);
              setQuizModalTab('INFO');
              setIsQuizModalOpen(true);
            }}
          />
        </div>
      )}

      {/* QUICK BANNER ON DASHBOARD */}
      {activeTab === 'dashboard' && setActiveTab && (
        <div
          onClick={() => setActiveTab('semester_system')}
          className="glass-panel"
          style={{
            padding: '18px 24px',
            borderRadius: '16px',
            marginBottom: '24px',
            background: 'linear-gradient(135deg, var(--bg-tertiary), var(--accent-light))',
            border: '1px solid var(--accent-primary)',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            cursor: 'pointer',
            transition: 'all 0.2s ease'
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
            <div style={{
              width: '42px',
              height: '42px',
              borderRadius: '12px',
              background: 'var(--accent-primary)',
              color: '#ffffff',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}>
              <Layers size={22} />
            </div>
            <div>
              <div style={{ fontWeight: '800', fontSize: '1.05rem', color: 'var(--text-primary)' }}>
                My Assigned Semesters (Semester &gt; Branch &gt; Courses &gt; Lectures / Quizzes)
              </div>
              <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                View only your assigned semesters, course schedules, and course examinations in one unified portal.
              </div>
            </div>
          </div>
          <button className="btn-primary" style={{ padding: '8px 16px', fontSize: '0.825rem' }}>
            Open Semester View
          </button>
        </div>
      )}

      {/* VIEW: TODAY'S SCHEDULE / ATTENDANCE */}
      {(activeTab === 'dashboard' || activeTab === 'timetable' || activeTab === 'attendance') && (
        <div style={{ marginBottom: '32px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
            <div>
              <h3 style={{ fontSize: '1.25rem', fontWeight: '700' }}>Scheduled Lectures & Proxy Classes</h3>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.825rem' }}>
                Schedule, edit, or customize lectures for any division/batch and launch real-time QR attendance
              </p>
            </div>
            <button
              onClick={openCreateLecture}
              className="btn-primary"
              style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 18px' }}
            >
              <Plus size={18} /> Schedule Lecture / Proxy Class
            </button>
          </div>

          {(dashboardData?.todayClasses?.length === 0 && allTimetable.length === 0) ? (
            <div className="glass-panel" style={{ padding: '36px', textAlign: 'center', color: 'var(--text-muted)' }}>
              <Calendar size={36} style={{ color: 'var(--accent-primary)', margin: '0 auto 12px' }} />
              <div style={{ fontSize: '1rem', fontWeight: '600', marginBottom: '6px' }}>No lectures scheduled yet</div>
              <p style={{ fontSize: '0.85rem', marginBottom: '16px' }}>Click above to schedule a regular or proxy lecture for any division & batch.</p>
              <button onClick={openCreateLecture} className="btn-secondary" style={{ padding: '8px 16px' }}>
                <Plus size={14} /> Schedule Now
              </button>
            </div>
          ) : (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(360px, 1fr))', gap: '16px' }}>
              {(dashboardData?.todayClasses && dashboardData.todayClasses.length > 0 ? dashboardData.todayClasses : allTimetable).map(c => (
                <div key={c.id} className="glass-panel" style={{ padding: '22px', borderRadius: '18px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '14px' }}>
                    <div>
                      <div style={{ display: 'flex', gap: '6px', alignItems: 'center', marginBottom: '6px' }}>
                        <span className="badge badge-active">
                          {c.session_type}
                        </span>
                        {c.is_proxy ? (
                          <span className="badge" style={{ background: 'rgba(234, 179, 8, 0.15)', color: '#eab308', border: '1px solid #eab308' }}>
                            Proxy: {c.specific_date}
                          </span>
                        ) : (
                          <span className="badge" style={{ background: 'var(--bg-tertiary)', color: 'var(--text-muted)' }}>
                            Weekly
                          </span>
                        )}
                      </div>
                      <h4 style={{ fontSize: '1.1rem', fontWeight: '700' }}>{c.subject_name}</h4>
                      <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>
                        {c.subject_code}
                      </div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <div style={{
                        padding: '6px 12px',
                        background: 'var(--bg-tertiary)',
                        borderRadius: '8px',
                        fontSize: '0.8rem',
                        fontWeight: '600',
                        color: 'var(--accent-primary)'
                      }}>
                        Room {c.room}
                      </div>
                      <button
                        onClick={() => openEditLecture(c)}
                        className="btn-secondary"
                        style={{ padding: '6px 8px', borderRadius: '8px' }}
                        title="Edit Lecture"
                      >
                        <Edit2 size={14} />
                      </button>
                      <button
                        onClick={() => handleDeleteLecture(c.id)}
                        className="btn-secondary"
                        style={{ padding: '6px 8px', borderRadius: '8px', color: '#ef4444' }}
                        title="Delete Lecture"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>

                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '16px',
                    fontSize: '0.825rem',
                    color: 'var(--text-secondary)',
                    marginBottom: '18px'
                  }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                      <Clock size={16} />
                      <span>{c.start_time} - {c.end_time}</span>
                    </div>
                    <div>
                      Div {c.division_name} {c.batch_name ? `(Batch ${c.batch_name})` : '(All Batches)'}
                    </div>
                  </div>

                  <button
                    onClick={() => startAttendanceFromTimetable(c)}
                    className="btn-primary"
                    style={{ width: '100%', padding: '10px' }}
                  >
                    <Play size={16} />
                    <span>Start Rotating QR Attendance</span>
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* VIEW: QUIZ MANAGEMENT */}
      {(activeTab === 'dashboard' || activeTab === 'quizzes') && (
        <div style={{ marginBottom: '32px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
            <div>
              <h3 style={{ fontSize: '1.25rem', fontWeight: '700' }}>Academic Examinations & Question Authoring</h3>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.825rem' }}>
                AI-assisted question generation, syllabus document parsing, and authoritative timed examinations
              </p>
            </div>
            <button onClick={() => { setQuizModalTab('INFO'); setIsQuizModalOpen(true); }} className="btn-primary">
              <Plus size={18} /> Schedule New Quiz
            </button>
          </div>

          {/* 3 High-Visibility Action Cards for Quiz Generation */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '16px', marginBottom: '24px' }}>
            <div
              className="glass-panel"
              style={{
                padding: '22px',
                borderRadius: '18px',
                border: '1px solid rgba(99, 102, 241, 0.35)',
                cursor: 'pointer',
                transition: 'transform 0.2s, box-shadow 0.2s',
                background: 'linear-gradient(135deg, rgba(99, 102, 241, 0.08), transparent)'
              }}
              onClick={() => { setQuizModalTab('AI_GEN'); setIsQuizModalOpen(true); }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '12px' }}>
                <div style={{ padding: '12px', borderRadius: '14px', background: 'rgba(99, 102, 241, 0.2)', color: 'var(--accent-primary)' }}>
                  <Sparkles size={24} />
                </div>
                <div>
                  <h4 style={{ fontSize: '1.1rem', fontWeight: '800' }}>⚡ Generate with AI</h4>
                  <span className="badge badge-active" style={{ fontSize: '0.72rem' }}>Learnique AI Engine</span>
                </div>
              </div>
              <p style={{ fontSize: '0.825rem', color: 'var(--text-muted)', lineHeight: '1.5', marginBottom: '14px' }}>
                Auto-synthesize Bloom's taxonomy MCQs, numerical problems, and explanations from curriculum topics.
              </p>
              <div style={{ fontWeight: '700', fontSize: '0.85rem', color: 'var(--accent-primary)', display: 'flex', alignItems: 'center', gap: '6px' }}>
                <span>Launch AI Generator</span> →
              </div>
            </div>

            <div
              className="glass-panel"
              style={{
                padding: '22px',
                borderRadius: '18px',
                border: '1px solid rgba(16, 185, 129, 0.35)',
                cursor: 'pointer',
                transition: 'transform 0.2s, box-shadow 0.2s',
                background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.08), transparent)'
              }}
              onClick={() => { setQuizModalTab('FILE_UPLOAD'); setIsQuizModalOpen(true); }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '12px' }}>
                <div style={{ padding: '12px', borderRadius: '14px', background: 'rgba(16, 185, 129, 0.2)', color: '#10b981' }}>
                  <FileText size={24} />
                </div>
                <div>
                  <h4 style={{ fontSize: '1.1rem', fontWeight: '800' }}>📄 Document Upload</h4>
                  <span className="badge badge-present" style={{ fontSize: '0.72rem' }}>PDF / DOCX Parser</span>
                </div>
              </div>
              <p style={{ fontSize: '0.825rem', color: 'var(--text-muted)', lineHeight: '1.5', marginBottom: '14px' }}>
                Extract questions automatically from uploaded lecture slides, question banks, or textbook chapters.
              </p>
              <div style={{ fontWeight: '700', fontSize: '0.85rem', color: '#10b981', display: 'flex', alignItems: 'center', gap: '6px' }}>
                <span>Upload & Parse Document</span> →
              </div>
            </div>

            <div
              className="glass-panel"
              style={{
                padding: '22px',
                borderRadius: '18px',
                border: '1px solid rgba(245, 158, 11, 0.35)',
                cursor: 'pointer',
                transition: 'transform 0.2s, box-shadow 0.2s',
                background: 'linear-gradient(135deg, rgba(245, 158, 11, 0.08), transparent)'
              }}
              onClick={() => { setQuizModalTab('INFO'); setIsQuizModalOpen(true); }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '12px' }}>
                <div style={{ padding: '12px', borderRadius: '14px', background: 'rgba(245, 158, 11, 0.2)', color: '#f59e0b' }}>
                  <Plus size={24} />
                </div>
                <div>
                  <h4 style={{ fontSize: '1.1rem', fontWeight: '800' }}>✍️ Schedule Quiz</h4>
                  <span className="badge" style={{ background: 'rgba(245, 158, 11, 0.15)', color: '#f59e0b', fontSize: '0.72rem' }}>Custom Composer</span>
                </div>
              </div>
              <p style={{ fontSize: '0.825rem', color: 'var(--text-muted)', lineHeight: '1.5', marginBottom: '14px' }}>
                Set examination window, server-authoritative timer, anti-cheat limits, and attendance prerequisites.
              </p>
              <div style={{ fontWeight: '700', fontSize: '0.85rem', color: '#f59e0b', display: 'flex', alignItems: 'center', gap: '6px' }}>
                <span>Create Custom Quiz</span> →
              </div>
            </div>
          </div>

          {quizzes.length === 0 ? (
            <div className="glass-panel" style={{ padding: '36px', textAlign: 'center', color: 'var(--text-muted)' }}>
              No quizzes created yet. Click any of the generation cards above to launch your first examination.
            </div>
          ) : (
            <div className="glass-panel" style={{ borderRadius: '18px', overflow: 'hidden' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.875rem' }}>
                <thead>
                  <tr style={{ background: 'var(--bg-tertiary)', borderBottom: '1px solid var(--border-glass)' }}>
                    <th style={{ padding: '14px 20px', fontWeight: '600' }}>Access Code</th>
                    <th style={{ padding: '14px 20px', fontWeight: '600' }}>Quiz Title</th>
                    <th style={{ padding: '14px 20px', fontWeight: '600' }}>Subject / Div</th>
                    <th style={{ padding: '14px 20px', fontWeight: '600' }}>Duration</th>
                    <th style={{ padding: '14px 20px', fontWeight: '600' }}>Marks</th>
                    <th style={{ padding: '14px 20px', fontWeight: '600' }}>Attempts</th>
                    <th style={{ padding: '14px 20px', fontWeight: '600', textAlign: 'right' }}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {quizzes.map(q => (
                    <tr key={q.id} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                      <td style={{ padding: '14px 20px', fontFamily: 'var(--font-mono)', fontWeight: '700', color: 'var(--accent-primary)' }}>
                        {q.access_code}
                      </td>
                      <td style={{ padding: '14px 20px', fontWeight: '600' }}>{q.title}</td>
                      <td style={{ padding: '14px 20px', color: 'var(--text-secondary)' }}>
                        {q.subject_name} • Div {q.division_name}
                      </td>
                      <td style={{ padding: '14px 20px' }}>{q.duration_minutes} mins</td>
                      <td style={{ padding: '14px 20px' }}>{q.total_marks}</td>
                      <td style={{ padding: '14px 20px' }}>{q.attempts_count || 0}</td>
                      <td style={{ padding: '14px 20px', textAlign: 'right' }}>
                        <div style={{ display: 'inline-flex', gap: '8px' }}>
                          <button
                            onClick={() => openLiveMonitor(q.id)}
                            className="btn-secondary"
                            style={{ padding: '6px 12px', fontSize: '0.8rem' }}
                          >
                            <Eye size={14} /> Monitor
                          </button>
                          <a
                            href={`/api/reports/quiz/${q.id}?format=pdf&token=${token}`}
                            download
                            className="btn-secondary"
                            style={{ padding: '6px 12px', fontSize: '0.8rem', textDecoration: 'none' }}
                          >
                            <FileDown size={14} /> PDF
                          </a>
                          <a
                            href={`/api/reports/quiz/${q.id}?format=excel&token=${token}`}
                            download
                            className="btn-secondary"
                            style={{ padding: '6px 12px', fontSize: '0.8rem', textDecoration: 'none' }}
                          >
                            <FileText size={14} /> Excel
                          </a>
                          <button
                            onClick={() => handleDeleteQuiz(q.id, q.title)}
                            className="btn-secondary"
                            style={{ padding: '6px 10px', fontSize: '0.8rem', color: 'var(--danger)' }}
                            title="Delete Quiz"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* VIEW: RESULTS & REPORTS */}
      {activeTab === 'reports' && (
        <div style={{ marginBottom: '32px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
            <div>
              <h3 style={{ fontSize: '1.25rem', fontWeight: '700' }}>Examination Reports & Result Analysis</h3>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.825rem' }}>
                Download institutional PDF scorecards and Excel grade sheets for all conducted assessments
              </p>
            </div>
          </div>

          <div className="glass-panel" style={{ borderRadius: '18px', overflow: 'hidden' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.875rem' }}>
              <thead>
                <tr style={{ background: 'var(--bg-tertiary)', borderBottom: '1px solid var(--border-glass)' }}>
                  <th style={{ padding: '14px 20px', fontWeight: '600' }}>Quiz Title</th>
                  <th style={{ padding: '14px 20px', fontWeight: '600' }}>Subject</th>
                  <th style={{ padding: '14px 20px', fontWeight: '600' }}>Division</th>
                  <th style={{ padding: '14px 20px', fontWeight: '600' }}>Total Marks</th>
                  <th style={{ padding: '14px 20px', fontWeight: '600' }}>Submissions</th>
                  <th style={{ padding: '14px 20px', fontWeight: '600', textAlign: 'right' }}>Official Downloads</th>
                </tr>
              </thead>
              <tbody>
                {quizzes.map(q => (
                  <tr key={q.id} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                    <td style={{ padding: '14px 20px', fontWeight: '600' }}>{q.title}</td>
                    <td style={{ padding: '14px 20px', color: 'var(--text-secondary)' }}>{q.subject_name}</td>
                    <td style={{ padding: '14px 20px' }}>Div {q.division_name}</td>
                    <td style={{ padding: '14px 20px' }}>{q.total_marks}</td>
                    <td style={{ padding: '14px 20px' }}>
                      <span className="badge badge-active">{q.attempts_count || 0} Attempts</span>
                    </td>
                    <td style={{ padding: '14px 20px', textAlign: 'right' }}>
                      <div style={{ display: 'inline-flex', gap: '8px' }}>
                        <a
                          href={`/api/reports/quiz/${q.id}?format=pdf&token=${token}`}
                          download
                          className="btn-secondary"
                          style={{ padding: '6px 12px', fontSize: '0.8rem', textDecoration: 'none' }}
                        >
                          <FileDown size={14} /> PDF Report
                        </a>
                        <a
                          href={`/api/reports/quiz/${q.id}?format=excel&token=${token}`}
                          download
                          className="btn-secondary"
                          style={{ padding: '6px 12px', fontSize: '0.8rem', textDecoration: 'none' }}
                        >
                          <FileText size={14} /> Excel Sheet
                        </a>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* VIEW: MY STUDENTS */}
      {(activeTab === 'students') && (
        <div style={{ marginBottom: '32px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
            <div>
              <h3 style={{ fontSize: '1.25rem', fontWeight: '700' }}>Students in Your Assigned Divisions</h3>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.825rem' }}>
                You can enroll and manage students strictly within divisions & batches assigned to you
              </p>
            </div>
            <button onClick={() => setIsEnrollModalOpen(true)} className="btn-primary">
              <Plus size={18} /> Enroll New Student
            </button>
          </div>

          <div className="glass-panel" style={{ borderRadius: '18px', overflow: 'hidden' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.875rem' }}>
              <thead>
                <tr style={{ background: 'var(--bg-tertiary)', borderBottom: '1px solid var(--border-glass)' }}>
                  <th style={{ padding: '14px 20px', fontWeight: '600' }}>Enrollment No</th>
                  <th style={{ padding: '14px 20px', fontWeight: '600' }}>Student Name</th>
                  <th style={{ padding: '14px 20px', fontWeight: '600' }}>Email</th>
                  <th style={{ padding: '14px 20px', fontWeight: '600' }}>Division</th>
                  <th style={{ padding: '14px 20px', fontWeight: '600' }}>Batch</th>
                  <th style={{ padding: '14px 20px', fontWeight: '600' }}>Status</th>
                </tr>
              </thead>
              <tbody>
                {students.map(s => (
                  <tr key={s.id} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                    <td style={{ padding: '14px 20px', fontFamily: 'var(--font-mono)', fontWeight: '600' }}>
                      {s.enrollment_number}
                    </td>
                    <td style={{ padding: '14px 20px', fontWeight: '600' }}>{s.name}</td>
                    <td style={{ padding: '14px 20px', color: 'var(--text-secondary)' }}>{s.email}</td>
                    <td style={{ padding: '14px 20px' }}>{s.division_name}</td>
                    <td style={{ padding: '14px 20px' }}>{s.batch_name}</td>
                    <td style={{ padding: '14px 20px' }}>
                      <span className="badge badge-present">Enrolled</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* VIEW: FACULTY AI TEACHING ASSISTANT (Matching the Student AI Doubt Solver with Faculty Pedagogy) */}
      {activeTab === 'ai_assistant' && (
        <div style={{
          display: 'flex',
          flexDirection: 'column',
          minHeight: '740px',
          maxHeight: '86vh',
          background: 'var(--bg-secondary)',
          borderRadius: '28px',
          border: '1px solid var(--border-subtle)',
          overflow: 'hidden',
          boxShadow: '0 16px 48px rgba(0, 0, 0, 0.18)',
          position: 'relative'
        }}>
          {/* Learnique AI Top App Bar */}
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            padding: '16px 28px',
            borderBottom: '1px solid var(--border-subtle)',
            background: 'rgba(255, 255, 255, 0.02)',
            backdropFilter: 'blur(10px)',
            flexWrap: 'wrap',
            gap: '12px',
            zIndex: 10
          }}>
            {/* Learnique AI Brand & Model Badge */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <span style={{ fontSize: '1.25rem', fontWeight: '700', letterSpacing: '-0.02em' }}>
                    Learnique AI
                  </span>
                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '5px',
                    padding: '2px 8px',
                    borderRadius: '12px',
                    background: 'rgba(66, 133, 244, 0.12)',
                    border: '1px solid rgba(66, 133, 244, 0.25)',
                    fontSize: '0.72rem',
                    color: '#8ab4f8',
                    fontWeight: '600'
                  }}>
                    <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#34a853', display: 'inline-block' }} />
                    Learnique AI Engine
                  </div>
                </div>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                  Faculty Pedagogical & Teaching Assistant
                </div>
              </div>
            </div>

            {/* Context Selectors & Session Controls */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
              {/* Subject Dropdown */}
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                background: 'var(--bg-tertiary)',
                borderRadius: '20px',
                padding: '5px 12px',
                border: '1px solid var(--border-subtle)'
              }}>
                <BookOpen size={13} style={{ color: '#8ab4f8' }} />
                <select
                  value={aiSubject}
                  onChange={e => setAiSubject(e.target.value)}
                  style={{
                    background: 'transparent',
                    border: 'none',
                    color: 'var(--text-primary)',
                    fontSize: '0.8rem',
                    fontWeight: '500',
                    cursor: 'pointer',
                    outline: 'none',
                    maxWidth: '170px'
                  }}
                  title="Select Academic Subject for Instruction Context"
                >
                  <option value="Academic Curriculum & Assessment Design">All / General Curriculum</option>
                  {structure?.subjects?.map((s, idx) => (
                    <option key={s.id || s.code || idx} value={s.name}>
                      {s.name} {s.code ? `(${s.code})` : ''}
                    </option>
                  ))}
                  <option value="Computer Science & Algorithms">Computer Science & Algorithms</option>
                  <option value="Database Systems & Architecture">Database Systems & Architecture</option>
                  <option value="Mathematics & Numerical Analysis">Mathematics & Numerical Analysis</option>
                  <option value="Physics & Engineering Sciences">Physics & Engineering Sciences</option>
                </select>
              </div>

              {/* Target Concept / Module Input */}
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                background: 'var(--bg-tertiary)',
                borderRadius: '20px',
                padding: '5px 12px',
                border: '1px solid var(--border-subtle)',
                minWidth: '170px'
              }}>
                <span style={{ fontSize: '0.78rem' }}>🎯</span>
                <input
                  type="text"
                  placeholder="Module / Topic..."
                  value={aiTopic}
                  onChange={e => setAiTopic(e.target.value)}
                  style={{
                    background: 'transparent',
                    border: 'none',
                    color: 'var(--text-primary)',
                    fontSize: '0.8rem',
                    outline: 'none',
                    width: '100%'
                  }}
                  title="Target a specific curriculum module or lecture concept"
                />
              </div>

              {/* New Chat Button */}
              {aiChatHistory.length > 0 && (
                <button
                  type="button"
                  onClick={handleClearAIChat}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    background: 'var(--bg-tertiary)',
                    border: '1px solid var(--border-subtle)',
                    borderRadius: '20px',
                    padding: '6px 14px',
                    fontSize: '0.8rem',
                    color: 'var(--text-secondary)',
                    cursor: 'pointer',
                    transition: 'all 0.15s ease'
                  }}
                  title="Clear conversation and start fresh"
                >
                  <Plus size={14} />
                  <span>New Chat</span>
                </button>
              )}

              {/* Full Session PDF Button */}
              {aiChatHistory.length > 0 && (
                <button
                  type="button"
                  onClick={handleDownloadFullSessionAiPdf}
                  disabled={isGeneratingAiPdf}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    background: 'rgba(66, 133, 244, 0.12)',
                    border: '1px solid rgba(66, 133, 244, 0.3)',
                    borderRadius: '20px',
                    padding: '6px 14px',
                    fontSize: '0.8rem',
                    color: '#8ab4f8',
                    cursor: 'pointer',
                    fontWeight: '600'
                  }}
                  title="Download complete teaching assistant session as PDF"
                >
                  <FileDown size={14} />
                  <span>Session PDF</span>
                </button>
              )}
            </div>
          </div>

          {/* Learnique AI Chat Scroll Stream */}
          <div style={{
            flex: 1,
            overflowY: 'auto',
            padding: '24px 32px 160px 32px',
            display: 'flex',
            flexDirection: 'column',
            gap: '24px'
          }}>
            {aiChatHistory.length === 0 ? (
              /* Learnique AI Hero Landing Greeting & 4 Suggestion Cards */
              <div style={{ maxWidth: '820px', width: '100%', margin: '40px auto 10px auto' }}>
                <div style={{ marginBottom: '32px' }}>
                  <h1 style={{
                    fontSize: '2.8rem',
                    fontWeight: '700',
                    lineHeight: '1.18',
                    margin: 0,
                    background: 'linear-gradient(74deg, #4285f4 0%, #9b72cb 25%, #d96570 50%, #d96570 65%, #9b72cb 80%, #4285f4 100%)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                    letterSpacing: '-0.02em'
                  }}>
                    Hello, {teacherProfileData?.name?.split(' ')[0] || user?.name?.split(' ')[0] || 'Professor'}
                  </h1>
                  <h2 style={{
                    fontSize: '2.3rem',
                    fontWeight: '500',
                    color: 'var(--text-muted)',
                    margin: '6px 0 0 0',
                    opacity: 0.75,
                    letterSpacing: '-0.02em'
                  }}>
                    How can I assist your teaching today?
                  </h2>
                </div>

                {/* Learnique AI 4 Suggestion Cards */}
                <div style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
                  gap: '14px',
                  marginTop: '28px'
                }}>
                  {[
                    {
                      icon: <Lightbulb size={22} style={{ color: '#fbbc04' }} />,
                      bg: 'rgba(251, 188, 4, 0.1)',
                      title: "Design Quiz Questions & MCQs",
                      desc: "Formulate rigorous MCQs, conceptual distractors, Bloom's ratings, and answer keys",
                      prompt: "Generate 5 rigorous multiple-choice questions for Dijkstra and Bellman-Ford algorithms with challenging distractors and clear explanation keys."
                    },
                    {
                      icon: <Presentation size={22} style={{ color: '#ea580c' }} />,
                      bg: 'rgba(234, 88, 12, 0.1)',
                      title: "Analyze Course Slides & Notes",
                      desc: "Break down attached PPTX, PDF, or Word DOCX notes into lesson plans & student exercises",
                      prompt: "Analyze attached lecture slides and generate a structured 50-minute lesson outline with discussion prompts."
                    },
                    {
                      icon: <Code size={22} style={{ color: '#34a853' }} />,
                      bg: 'rgba(52, 168, 83, 0.1)',
                      title: "Lecture Outlines & Derivations",
                      desc: "Step-by-step whiteboard derivations, intuitive analogies, and live code demos",
                      prompt: "Provide an intuitive step-by-step whiteboard derivation and teaching analogy for Dynamic Programming memoization vs tabulation."
                    },
                    {
                      icon: <GraduationCap size={22} style={{ color: '#a142f4' }} />,
                      bg: 'rgba(161, 66, 244, 0.1)',
                      title: "Lesson Plan & Rubric PDF",
                      desc: "Format complete lecture guides or examination rubrics and download official PDF",
                      prompt: "Create a comprehensive Faculty Lesson Plan & Assessment Rubric for Database Normalization from 1NF to BCNF."
                    }
                  ].map((card, cIdx) => (
                    <div
                      key={cIdx}
                      onClick={() => setAiMessage(card.prompt)}
                      style={{
                        background: 'var(--bg-tertiary)',
                        borderRadius: '20px',
                        padding: '20px',
                        border: '1px solid var(--border-subtle)',
                        cursor: 'pointer',
                        display: 'flex',
                        flexDirection: 'column',
                        justifyContent: 'space-between',
                        minHeight: '140px',
                        transition: 'all 0.2s cubic-bezier(0.16, 1, 0.3, 1)',
                        position: 'relative'
                      }}
                      onMouseEnter={e => {
                        e.currentTarget.style.borderColor = '#8ab4f8';
                        e.currentTarget.style.transform = 'translateY(-3px)';
                        e.currentTarget.style.boxShadow = '0 8px 24px rgba(66, 133, 244, 0.15)';
                      }}
                      onMouseLeave={e => {
                        e.currentTarget.style.borderColor = 'var(--border-subtle)';
                        e.currentTarget.style.transform = 'translateY(0)';
                        e.currentTarget.style.boxShadow = 'none';
                      }}
                    >
                      <div>
                        <div style={{ fontSize: '0.92rem', fontWeight: '600', marginBottom: '6px', color: 'var(--text-primary)' }}>
                          {card.title}
                        </div>
                        <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', lineHeight: 1.45 }}>
                          {card.desc}
                        </div>
                      </div>
                      <div style={{
                        alignSelf: 'flex-end',
                        width: '38px',
                        height: '38px',
                        borderRadius: '50%',
                        background: card.bg,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        marginTop: '16px'
                      }}>
                        {card.icon}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              /* Learnique AI Messages Stream */
              <div style={{ maxWidth: '820px', width: '100%', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '28px' }}>
                {aiChatHistory.map((m, idx) => {
                  const isUser = m.sender === 'USER';
                  return (
                    <div
                      key={idx}
                      style={{
                        display: 'flex',
                        flexDirection: isUser ? 'column' : 'row',
                        alignItems: isUser ? 'flex-end' : 'flex-start',
                        gap: '14px',
                        width: '100%'
                      }}
                    >
                      {/* AI Teaching Assistant Avatar */}
                      {!isUser && (
                        <div style={{
                          width: '38px',
                          height: '38px',
                          borderRadius: '12px',
                          background: 'linear-gradient(135deg, #4285f4 0%, #9b72cb 100%)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flexShrink: 0,
                          marginTop: '2px',
                          boxShadow: '0 4px 14px rgba(66, 133, 244, 0.35)',
                          color: '#ffffff'
                        }}>
                          <Sparkles size={20} />
                        </div>
                      )}

                      <div style={{
                        maxWidth: isUser ? '75%' : '100%',
                        flex: isUser ? undefined : 1,
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '6px'
                      }}>
                        {/* Sender Label for Assistant */}
                        {!isUser && (
                          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '2px' }}>
                            <span style={{ fontSize: '0.85rem', fontWeight: '700', color: 'var(--text-primary)' }}>
                              Learnique AI
                            </span>
                            <span style={{
                              fontSize: '0.68rem',
                              fontWeight: '600',
                              color: '#8ab4f8',
                              background: 'rgba(66, 133, 244, 0.12)',
                              border: '1px solid rgba(66, 133, 244, 0.25)',
                              padding: '1px 8px',
                              borderRadius: '10px'
                            }}>
                              Teaching Assistant
                            </span>
                          </div>
                        )}
                        {/* Concept Tag for user question if targeted */}
                        {isUser && m.topic && m.topic !== 'Curriculum & Assessment' && (
                          <div style={{
                            fontSize: '0.72rem',
                            fontWeight: '600',
                            color: '#8ab4f8',
                            background: 'rgba(66, 133, 244, 0.1)',
                            border: '1px solid rgba(66, 133, 244, 0.25)',
                            padding: '2px 10px',
                            borderRadius: '12px',
                            alignSelf: 'flex-end',
                            marginBottom: '2px'
                          }}>
                            🎯 {m.topic}
                          </div>
                        )}

                        {/* Message Body */}
                        <div style={{
                          background: isUser ? 'var(--bg-tertiary)' : 'transparent',
                          color: 'var(--text-primary)',
                          padding: isUser ? '14px 20px' : '0px 4px',
                          borderRadius: isUser ? '22px 22px 6px 22px' : '0px',
                          border: isUser ? '1px solid var(--border-subtle)' : 'none',
                          fontSize: '0.94rem',
                          lineHeight: 1.68
                        }}>
                          {/* Attached File Preview if present */}
                          {m.attachment && (
                            <div style={{
                              marginBottom: '12px',
                              padding: '10px 14px',
                              borderRadius: '14px',
                              background: 'var(--bg-secondary)',
                              border: '1px solid var(--border-subtle)',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '12px'
                            }}>
                              {m.attachment.isImage || m.attachment.previewUrl ? (
                                <img
                                  src={m.attachment.previewUrl}
                                  alt={m.attachment.name}
                                  style={{ width: '46px', height: '46px', objectFit: 'cover', borderRadius: '8px', cursor: 'pointer' }}
                                  onClick={() => window.open(m.attachment.previewUrl, '_blank')}
                                />
                              ) : m.attachment.category === 'presentation' || (m.attachment.name && m.attachment.name.toLowerCase().match(/\.(ppt|pptx)$/)) ? (
                                <div style={{
                                  width: '42px',
                                  height: '42px',
                                  borderRadius: '8px',
                                  background: 'rgba(234, 88, 12, 0.15)',
                                  color: '#ea580c',
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                  flexShrink: 0
                                }}>
                                  <Presentation size={22} />
                                </div>
                              ) : m.attachment.category === 'word' || (m.attachment.name && m.attachment.name.toLowerCase().match(/\.(doc|docx)$/)) ? (
                                <div style={{
                                  width: '42px',
                                  height: '42px',
                                  borderRadius: '8px',
                                  background: 'rgba(37, 99, 235, 0.15)',
                                  color: '#2563eb',
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                  flexShrink: 0
                                }}>
                                  <FileText size={22} />
                                </div>
                              ) : m.attachment.category === 'pdf' || (m.attachment.name && m.attachment.name.toLowerCase().endsWith('.pdf')) ? (
                                <div style={{
                                  width: '42px',
                                  height: '42px',
                                  borderRadius: '8px',
                                  background: 'rgba(220, 38, 38, 0.15)',
                                  color: '#dc2626',
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                  flexShrink: 0
                                }}>
                                  <FileText size={22} />
                                </div>
                              ) : (
                                <div style={{
                                  width: '42px',
                                  height: '42px',
                                  borderRadius: '8px',
                                  background: 'rgba(66, 133, 244, 0.15)',
                                  color: '#8ab4f8',
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                  flexShrink: 0
                                }}>
                                  <FileText size={22} />
                                </div>
                              )}
                              <div style={{ fontSize: '0.825rem', overflow: 'hidden' }}>
                                <div style={{ fontWeight: '600', textOverflow: 'ellipsis', overflow: 'hidden', whiteSpace: 'nowrap' }}>
                                  {m.attachment.name}
                                </div>
                                <div style={{ fontSize: '0.72rem', opacity: 0.85, display: 'flex', gap: '8px', alignItems: 'center' }}>
                                  {m.attachment.size && <span>{m.attachment.size}</span>}
                                  {m.attachment.category && (
                                    <span style={{
                                      textTransform: 'uppercase',
                                      fontSize: '0.65rem',
                                      padding: '1px 6px',
                                      borderRadius: '4px',
                                      background: 'var(--border-subtle)',
                                      fontWeight: '700'
                                    }}>
                                      {m.attachment.category}
                                    </span>
                                  )}
                                </div>
                              </div>
                            </div>
                          )}

                          {/* Text Content */}
                          <div style={{ whiteSpace: 'pre-wrap' }}>
                            {formatAIResponse(m.content)}
                          </div>

                          {/* Bottom Action Bar for AI Response */}
                          {!isUser && (
                            <div style={{
                              marginTop: '16px',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '6px',
                              flexWrap: 'wrap'
                            }}>
                              {/* Thumbs Up Button */}
                              <button
                                type="button"
                                onClick={() => handleAiFeedback(idx, 'up')}
                                style={{
                                  width: '32px',
                                  height: '32px',
                                  borderRadius: '50%',
                                  background: aiFeedback[idx] === 'up' ? 'rgba(66, 133, 244, 0.2)' : 'transparent',
                                  border: 'none',
                                  color: aiFeedback[idx] === 'up' ? '#8ab4f8' : 'var(--text-muted)',
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                  cursor: 'pointer',
                                  transition: 'all 0.15s ease'
                                }}
                                title="Good response"
                              >
                                <ThumbsUp size={15} />
                              </button>

                              {/* Thumbs Down Button */}
                              <button
                                type="button"
                                onClick={() => handleAiFeedback(idx, 'down')}
                                style={{
                                  width: '32px',
                                  height: '32px',
                                  borderRadius: '50%',
                                  background: aiFeedback[idx] === 'down' ? 'rgba(217, 101, 112, 0.2)' : 'transparent',
                                  border: 'none',
                                  color: aiFeedback[idx] === 'down' ? '#d96570' : 'var(--text-muted)',
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                  cursor: 'pointer',
                                  transition: 'all 0.15s ease'
                                }}
                                title="Bad response"
                              >
                                <ThumbsDown size={15} />
                              </button>

                              {/* Copy Button */}
                              <button
                                type="button"
                                onClick={() => {
                                  navigator.clipboard.writeText(m.content);
                                  setAiCopiedIndex(idx);
                                  notify('Response copied to clipboard!', 'success');
                                  setTimeout(() => setAiCopiedIndex(null), 2000);
                                }}
                                style={{
                                  display: 'flex',
                                  alignItems: 'center',
                                  gap: '5px',
                                  padding: '5px 10px',
                                  borderRadius: '16px',
                                  background: 'transparent',
                                  border: '1px solid var(--border-subtle)',
                                  color: aiCopiedIndex === idx ? 'var(--success)' : 'var(--text-muted)',
                                  fontSize: '0.76rem',
                                  cursor: 'pointer'
                                }}
                                title="Copy explanation"
                              >
                                {aiCopiedIndex === idx ? <Check size={13} style={{ color: 'var(--success)' }} /> : <Copy size={13} />}
                                <span>{aiCopiedIndex === idx ? 'Copied' : 'Copy'}</span>
                              </button>

                              {/* Download PDF Button */}
                              <button
                                type="button"
                                onClick={() => handleDownloadAiPdf(m.content, aiSubject, aiChatHistory[idx - 1]?.content || '')}
                                disabled={isGeneratingAiPdf}
                                style={{
                                  display: 'flex',
                                  alignItems: 'center',
                                  gap: '5px',
                                  padding: '5px 12px',
                                  borderRadius: '16px',
                                  background: 'rgba(66, 133, 244, 0.12)',
                                  border: '1px solid rgba(66, 133, 244, 0.25)',
                                  color: '#8ab4f8',
                                  fontSize: '0.76rem',
                                  fontWeight: '600',
                                  cursor: 'pointer'
                                }}
                                title="Export this teaching guide as a downloadable PDF"
                              >
                                <FileDown size={13} />
                                <span>Export PDF</span>
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Thinking State Indicator */}
            {aiLoading && (
              <div style={{ maxWidth: '820px', width: '100%', margin: '0 auto', color: 'var(--text-muted)', fontSize: '0.88rem' }}>
                Thinking...
              </div>
            )}

            <div ref={aiChatEndRef} />
          </div>

          {/* Learnique AI Floating Prompt Capsule (Bottom Sticky Bar) */}
          <div style={{
            position: 'absolute',
            bottom: 0,
            left: 0,
            right: 0,
            padding: '10px 24px 16px 24px',
            background: 'linear-gradient(to top, var(--bg-secondary) 85%, transparent)',
            backdropFilter: 'blur(12px)',
            zIndex: 20
          }}>
            <div style={{ maxWidth: '820px', margin: '0 auto' }}>
              {/* Capsule Card */}
              <div style={{
                borderRadius: '28px',
                background: 'var(--bg-tertiary)',
                border: '1px solid rgba(255, 255, 255, 0.12)',
                boxShadow: '0 10px 32px rgba(0, 0, 0, 0.28)',
                padding: '12px 18px',
                display: 'flex',
                flexDirection: 'column',
                gap: '8px'
              }}>
                {/* Pending Attachment Preview Chip inside Capsule */}
                {aiAttachment && (
                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    padding: '8px 12px',
                    borderRadius: '14px',
                    background: 'rgba(66, 133, 244, 0.1)',
                    border: '1px solid rgba(66, 133, 244, 0.25)',
                    marginBottom: '4px'
                  }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px', overflow: 'hidden' }}>
                      {aiAttachment.isImage ? (
                        <img
                          src={aiAttachment.previewUrl}
                          alt={aiAttachment.name}
                          style={{ width: '36px', height: '36px', borderRadius: '6px', objectFit: 'cover' }}
                        />
                      ) : aiAttachment.category === 'presentation' || (aiAttachment.name && aiAttachment.name.toLowerCase().match(/\.(ppt|pptx)$/)) ? (
                        <div style={{
                          width: '36px',
                          height: '36px',
                          borderRadius: '6px',
                          background: 'rgba(234, 88, 12, 0.15)',
                          color: '#ea580c',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flexShrink: 0
                        }}>
                          <Presentation size={20} />
                        </div>
                      ) : aiAttachment.category === 'word' || (aiAttachment.name && aiAttachment.name.toLowerCase().match(/\.(doc|docx)$/)) ? (
                        <div style={{
                          width: '36px',
                          height: '36px',
                          borderRadius: '6px',
                          background: 'rgba(37, 99, 235, 0.15)',
                          color: '#2563eb',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flexShrink: 0
                        }}>
                          <FileText size={20} />
                        </div>
                      ) : aiAttachment.category === 'pdf' || (aiAttachment.name && aiAttachment.name.toLowerCase().endsWith('.pdf')) ? (
                        <div style={{
                          width: '36px',
                          height: '36px',
                          borderRadius: '6px',
                          background: 'rgba(220, 38, 38, 0.15)',
                          color: '#dc2626',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flexShrink: 0
                        }}>
                          <FileText size={20} />
                        </div>
                      ) : (
                        <div style={{
                          width: '36px',
                          height: '36px',
                          borderRadius: '6px',
                          background: 'rgba(66, 133, 244, 0.15)',
                          color: '#8ab4f8',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flexShrink: 0
                        }}>
                          <FileText size={20} />
                        </div>
                      )}
                      <div style={{ fontSize: '0.8rem', overflow: 'hidden' }}>
                        <div style={{ fontWeight: '600', textOverflow: 'ellipsis', overflow: 'hidden', whiteSpace: 'nowrap' }}>
                          {aiAttachment.name}
                        </div>
                        <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>
                          {aiAttachment.size} • {aiAttachment.category?.toUpperCase()}
                        </div>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setAiAttachment(null)}
                      style={{
                        background: 'transparent',
                        border: 'none',
                        color: 'var(--text-muted)',
                        cursor: 'pointer',
                        padding: '4px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                      }}
                      title="Remove attached file"
                    >
                      <X size={16} />
                    </button>
                  </div>
                )}

                {/* Input row + actions */}
                <form
                  onSubmit={e => handleSendAIChat(e, false)}
                  style={{ display: 'flex', alignItems: 'center', gap: '10px' }}
                >
                  {/* Hidden file input */}
                  <input
                    ref={aiFileInputRef}
                    type="file"
                    style={{ display: 'none' }}
                    onChange={handleAiFileUpload}
                    accept=".png,.jpg,.jpeg,.webp,.gif,.bmp,.pdf,.ppt,.pptx,.doc,.docx,.txt,.csv,.py,.js,.ts,.json"
                  />

                  {/* Attachment button */}
                  <button
                    type="button"
                    onClick={() => aiFileInputRef.current?.click()}
                    style={{
                      width: '38px',
                      height: '38px',
                      borderRadius: '50%',
                      background: 'rgba(255, 255, 255, 0.04)',
                      border: '1px solid var(--border-subtle)',
                      color: 'var(--text-secondary)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      cursor: 'pointer',
                      flexShrink: 0,
                      transition: 'all 0.15s ease'
                    }}
                    title="Attach syllabus, lecture slides (PPTX), PDF papers, or lesson notes"
                  >
                    <Paperclip size={18} />
                  </button>

                  {/* Text input */}
                  <input
                    type="text"
                    value={aiMessage}
                    onChange={e => setAiMessage(e.target.value)}
                    placeholder="Ask about curriculum design, exam questions, grading rubrics, or analyze notes..."
                    disabled={aiLoading}
                    style={{
                      flex: 1,
                      background: 'transparent',
                      border: 'none',
                      color: 'var(--text-primary)',
                      fontSize: '0.94rem',
                      outline: 'none',
                      padding: '8px 4px'
                    }}
                  />

                  {/* Format as Lesson Plan / Rubric PDF button */}
                  <button
                    type="button"
                    onClick={e => handleSendAIChat(e, true)}
                    disabled={aiLoading || (!aiMessage.trim() && !aiAttachment)}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '5px',
                      padding: '7px 12px',
                      borderRadius: '18px',
                      background: 'rgba(66, 133, 244, 0.12)',
                      border: '1px solid rgba(66, 133, 244, 0.25)',
                      color: '#8ab4f8',
                      fontSize: '0.78rem',
                      fontWeight: '600',
                      cursor: 'pointer',
                      flexShrink: 0
                    }}
                    title="Ask AI to answer and automatically export as downloadable Faculty Guide PDF"
                  >
                    <FileDown size={14} />
                    <span>Lesson PDF</span>
                  </button>

                  {/* Send button */}
                  <button
                    type="submit"
                    disabled={aiLoading || (!aiMessage.trim() && !aiAttachment)}
                    style={{
                      width: '38px',
                      height: '38px',
                      borderRadius: '50%',
                      background: (aiMessage.trim() || aiAttachment) ? 'linear-gradient(135deg, #4285f4, #9b72cb)' : 'rgba(255, 255, 255, 0.08)',
                      border: 'none',
                      color: '#ffffff',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      cursor: (aiMessage.trim() || aiAttachment) && !aiLoading ? 'pointer' : 'default',
                      flexShrink: 0,
                      boxShadow: (aiMessage.trim() || aiAttachment) ? '0 4px 12px rgba(66, 133, 244, 0.35)' : 'none',
                      transition: 'all 0.15s ease'
                    }}
                    title="Send message"
                  >
                    <Send size={16} />
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* VIEW: FACULTY ACADEMIC PROFILE */}
      {activeTab === 'profile' && (
        <div style={{ marginBottom: '32px' }}>
          <div style={{ marginBottom: '20px' }}>
            <h3 style={{ fontSize: '1.25rem', fontWeight: '700' }}>Faculty Academic Profile</h3>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.825rem' }}>
              Official university credentials, instructional assignments, and departmental affiliation
            </p>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '320px 1fr', gap: '20px' }}>
            {/* Identity Card */}
            <div className="glass-panel" style={{ padding: '28px', borderRadius: '20px', textAlign: 'center' }}>
              <div style={{
                width: '90px',
                height: '90px',
                borderRadius: '50%',
                background: 'linear-gradient(135deg, var(--accent-primary), var(--accent-hover))',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 16px auto',
                color: '#ffffff',
                fontSize: '2rem',
                fontWeight: '800',
                boxShadow: '0 8px 24px var(--accent-glow)'
              }}>
                {teacherProfileData?.name ? teacherProfileData.name.charAt(0) : (user?.name?.charAt(0) || 'F')}
              </div>
              <h3 style={{ fontSize: '1.3rem', fontWeight: '800', marginBottom: '4px' }}>
                {teacherProfileData?.name || user?.name}
              </h3>
              <div style={{ fontSize: '0.85rem', color: 'var(--accent-primary)', fontFamily: 'var(--font-mono)', fontWeight: '700', marginBottom: '16px' }}>
                {teacherProfileData?.identifier || user?.identifier}
              </div>
              <span className="badge badge-present" style={{ padding: '6px 14px' }}>
                Active Faculty
              </span>

              <div style={{ marginTop: '24px', borderTop: '1px solid var(--border-subtle)', paddingTop: '18px', textAlign: 'left', display: 'flex', flexDirection: 'column', gap: '10px', fontSize: '0.85rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ color: 'var(--text-muted)' }}>Role</span>
                  <span style={{ fontWeight: '600', color: 'var(--accent-primary)' }}>Faculty / Instructor</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ color: 'var(--text-muted)' }}>Designation</span>
                  <span style={{ fontWeight: '600' }}>{teacherProfileData?.designation || 'Assistant Professor'}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ color: 'var(--text-muted)' }}>Department</span>
                  <span style={{ fontWeight: '600' }}>{teacherProfileData?.department || 'Computer Science & Engineering'}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ color: 'var(--text-muted)' }}>Status</span>
                  <span style={{ fontWeight: '600', color: 'var(--success)' }}>Verified Active</span>
                </div>
              </div>
            </div>

            {/* Academic Dossier & Teaching Assignments */}
            <div className="glass-panel" style={{ padding: '28px', borderRadius: '20px' }}>
              <h4 style={{ fontSize: '1.05rem', fontWeight: '700', marginBottom: '18px', paddingBottom: '10px', borderBottom: '1px solid var(--border-subtle)' }}>
                Departmental & Teaching Overview
              </h4>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '14px', marginBottom: '24px' }}>
                <div style={{ padding: '14px', background: 'var(--bg-tertiary)', borderRadius: '12px' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Sessions Conducted</div>
                  <div style={{ fontSize: '1.4rem', fontWeight: '800', marginTop: '4px' }}>
                    {teacherProfileData?.stats?.sessions_conducted ?? 0}
                  </div>
                </div>
                <div style={{ padding: '14px', background: 'var(--bg-tertiary)', borderRadius: '12px' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Examinations Authored</div>
                  <div style={{ fontSize: '1.4rem', fontWeight: '800', marginTop: '4px' }}>
                    {teacherProfileData?.stats?.quizzes_created ?? 0}
                  </div>
                </div>
                <div style={{ padding: '14px', background: 'var(--bg-tertiary)', borderRadius: '12px' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Students Enrolled</div>
                  <div style={{ fontSize: '1.4rem', fontWeight: '800', marginTop: '4px' }}>
                    {teacherProfileData?.stats?.students_reached ?? 0}
                  </div>
                </div>
              </div>

              <h4 style={{ fontSize: '1.05rem', fontWeight: '700', marginBottom: '14px', paddingBottom: '10px', borderBottom: '1px solid var(--border-subtle)' }}>
                Assigned Courses & Curriculum
              </h4>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginBottom: '24px' }}>
                {(teacherProfileData?.assignments || []).length === 0 ? (
                  <div style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>No academic courses currently assigned.</div>
                ) : (
                  (teacherProfileData?.assignments || []).map((a, i) => (
                    <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', background: 'var(--bg-tertiary)', borderRadius: '12px' }}>
                      <div>
                        <div style={{ fontWeight: '700', fontSize: '0.95rem', display: 'flex', alignItems: 'center', gap: '8px' }}>
                          <span>{a.subject_name} ({a.subject_code})</span>
                          <span className="badge badge-scheduled" style={{ fontSize: '0.7rem' }}>
                            Sem {a.semester_number || 5}
                          </span>
                        </div>
                        <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginTop: '2px' }}>
                          Division {a.division_name} {a.batch_name ? `• Batch ${a.batch_name}` : '• Entire Division'} • Type: {a.subject_type || 'BOTH'}
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>

              <h4 style={{ fontSize: '1.05rem', fontWeight: '700', marginBottom: '14px', paddingBottom: '10px', borderBottom: '1px solid var(--border-subtle)' }}>
                Contact & Communication
              </h4>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '18px' }}>
                <div style={{ padding: '14px', background: 'var(--bg-tertiary)', borderRadius: '12px' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>University Email Address</div>
                  <div style={{ fontSize: '0.95rem', fontWeight: '600', marginTop: '4px' }}>
                    {teacherProfileData?.email || user?.email}
                  </div>
                </div>
                <div style={{ padding: '14px', background: 'var(--bg-tertiary)', borderRadius: '12px' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Mobile Number</div>
                  <div style={{ fontSize: '0.95rem', fontWeight: '600', marginTop: '4px' }}>
                    {teacherProfileData?.phone || 'Not registered'}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* QUIZ CREATOR MODAL */}
      <QuizCreatorModal
        isOpen={isQuizModalOpen}
        initialTab={quizModalTab}
        initialSubjectId={quizModalSubjectId}
        onClose={() => {
          setIsQuizModalOpen(false);
          setQuizModalSubjectId('');
        }}
        onCreated={() => loadTeacherData()}
        subjects={structure.subjects}
        divisions={structure.divisions}
        batches={structure.batches}
      />

      {/* LIVE QUIZ MONITOR MODAL */}
      {monitorQuizId && monitorData && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100vw',
          height: '100vh',
          background: 'rgba(0, 0, 0, 0.75)',
          backdropFilter: 'blur(10px)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 9999
        }}>
          <div className="glass-panel" style={{ width: '850px', maxWidth: '95%', maxHeight: '85vh', padding: '28px', borderRadius: '24px', overflowY: 'auto' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
              <div>
                <h3 style={{ fontSize: '1.25rem', fontWeight: '800' }}>Live Examination Monitor: {monitorData.quiz.title}</h3>
                <div style={{ color: 'var(--text-muted)', fontSize: '0.8rem', display: 'flex', alignItems: 'center', gap: '14px', flexWrap: 'wrap', marginTop: '6px' }}>
                  <span>Access Code: <strong style={{ color: 'var(--accent-primary)', fontFamily: 'var(--font-mono)' }}>{monitorData.quiz.access_code}</strong></span>
                  <span>•</span>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <span>Max Allowed Tab Violations:</span>
                    <input
                      type="number"
                      min="1"
                      max="20"
                      value={editingMaxSwitches !== null ? editingMaxSwitches : monitorData.quiz.max_tab_switches}
                      onChange={e => setEditingMaxSwitches(e.target.value)}
                      style={{
                        width: '55px',
                        padding: '3px 8px',
                        borderRadius: '6px',
                        background: 'var(--bg-tertiary)',
                        border: '1px solid var(--accent-border)',
                        color: '#fff',
                        fontWeight: '700',
                        fontSize: '0.85rem'
                      }}
                    />
                    <button
                      onClick={() => {
                        const val = editingMaxSwitches !== null ? editingMaxSwitches : monitorData.quiz.max_tab_switches;
                        saveMaxViolations(monitorData.quiz.id, val);
                      }}
                      className="btn-primary"
                      style={{ padding: '4px 10px', fontSize: '0.75rem' }}
                    >
                      Update Limit
                    </button>
                  </div>
                </div>
              </div>
              <button onClick={() => setMonitorQuizId(null)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
                <X size={22} />
              </button>
            </div>

            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.85rem' }}>
              <thead>
                <tr style={{ background: 'var(--bg-tertiary)' }}>
                  <th style={{ padding: '10px 14px' }}>Candidate</th>
                  <th style={{ padding: '10px 14px' }}>Enrollment</th>
                  <th style={{ padding: '10px 14px' }}>Status</th>
                  <th style={{ padding: '10px 14px' }}>Violations & Duration</th>
                  <th style={{ padding: '10px 14px' }}>Score</th>
                </tr>
              </thead>
              <tbody>
                {monitorData.attempts.length === 0 ? (
                  <tr>
                    <td colSpan="5" style={{ textAlign: 'center', padding: '30px', color: 'var(--text-muted)' }}>
                      No students have entered this quiz yet.
                    </td>
                  </tr>
                ) : (
                  monitorData.attempts.map(att => (
                    <tr key={att.id} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                      <td style={{ padding: '12px 14px', fontWeight: '600' }}>{att.student_name}</td>
                      <td style={{ padding: '12px 14px', fontFamily: 'var(--font-mono)' }}>{att.enrollment_number}</td>
                      <td style={{ padding: '12px 14px' }}>
                        <span className={`badge ${att.status && att.status.includes('AUTO_SUBMITTED') ? 'badge-absent' : 'badge-active'}`}>
                          {att.status}
                        </span>
                      </td>
                      <td style={{ padding: '12px 14px', color: att.tab_switch_count > 0 ? 'var(--danger)' : 'inherit' }}>
                        <div style={{ fontWeight: '700' }}>
                          {att.tab_switch_count} Switches
                        </div>
                        <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '2px' }}>
                          {att.tab_switch_duration_seconds ? `${att.tab_switch_duration_seconds}s total away` : '0s away'}
                        </div>
                      </td>
                      <td style={{ padding: '12px 14px', fontWeight: '700' }}>
                        {att.total_score} / {monitorData.quiz.total_marks} ({att.percentage}%)
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ENROLL STUDENT MODAL */}
      {isEnrollModalOpen && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100vw',
          height: '100vh',
          background: 'rgba(0,0,0,0.7)',
          backdropFilter: 'blur(8px)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 9999
        }}>
          <div className="glass-panel" style={{ width: '480px', maxWidth: '90%', padding: '28px', borderRadius: '20px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <h3 style={{ fontSize: '1.2rem', fontWeight: '700' }}>Enroll Student</h3>
              <button onClick={() => setIsEnrollModalOpen(false)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
                <X size={20} />
              </button>
            </div>

            {enrollError && (
              <div style={{ background: 'rgba(239, 68, 68, 0.15)', color: '#ef4444', padding: '10px', borderRadius: '8px', marginBottom: '12px', fontSize: '0.825rem' }}>
                {enrollError}
              </div>
            )}
            {enrollSuccess && (
              <div style={{ background: 'rgba(16, 185, 129, 0.15)', color: '#10b981', padding: '10px', borderRadius: '8px', marginBottom: '12px', fontSize: '0.825rem' }}>
                {enrollSuccess}
              </div>
            )}

            <form onSubmit={handleEnrollStudent} style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <div>
                <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>Enrollment Number *</label>
                <input
                  type="text"
                  className="input-field"
                  placeholder="e.g. 2026CSE045"
                  value={enrollForm.enrollment_number}
                  onChange={e => setEnrollForm({ ...enrollForm, enrollment_number: e.target.value })}
                  required
                />
              </div>
              <div>
                <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>Full Name *</label>
                <input
                  type="text"
                  className="input-field"
                  placeholder="e.g. Priya Nair"
                  value={enrollForm.name}
                  onChange={e => setEnrollForm({ ...enrollForm, name: e.target.value })}
                  required
                />
              </div>
              <div>
                <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>Email *</label>
                <input
                  type="email"
                  className="input-field"
                  placeholder="priya@learnique.edu"
                  value={enrollForm.email}
                  onChange={e => setEnrollForm({ ...enrollForm, email: e.target.value })}
                  required
                />
              </div>
              <div>
                <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>Initial Password *</label>
                <input
                  type="password"
                  className="input-field"
                  placeholder="Minimum 8 characters"
                  value={enrollForm.password}
                  onChange={e => setEnrollForm({ ...enrollForm, password: e.target.value })}
                  required
                />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                <div>
                  <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>Division *</label>
                  <select
                    className="input-field"
                    value={enrollForm.division_id}
                    onChange={e => setEnrollForm({ ...enrollForm, division_id: e.target.value })}
                    required
                  >
                    <option value="">-- Div --</option>
                    {structure.divisions.map(d => (
                      <option key={d.id} value={d.id}>Div {d.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>Batch *</label>
                  <select
                    className="input-field"
                    value={enrollForm.batch_id}
                    onChange={e => setEnrollForm({ ...enrollForm, batch_id: e.target.value })}
                    required
                  >
                    <option value="">-- Batch --</option>
                    {structure.batches
                      .filter(b => !enrollForm.division_id || String(b.division_id) === String(enrollForm.division_id))
                      .map(b => (
                        <option key={b.id} value={b.id}>Batch {b.name}</option>
                      ))}
                  </select>
                </div>
              </div>
              <button type="submit" className="btn-primary" style={{ marginTop: '8px' }}>
                Enroll Student
              </button>
            </form>
          </div>
        </div>
      )}

      {/* SCHEDULE / EDIT LECTURE MODAL */}
      {isLectureModalOpen && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100vw',
          height: '100vh',
          background: 'rgba(0,0,0,0.75)',
          backdropFilter: 'blur(8px)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 9999
        }}>
          <div className="glass-panel animate-fade-in" style={{ width: '520px', maxWidth: '92%', padding: '28px', borderRadius: '20px', maxHeight: '90vh', overflowY: 'auto' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <div>
                <h3 style={{ fontSize: '1.25rem', fontWeight: '800' }}>
                  {editingLectureId ? 'Edit Scheduled Lecture / Proxy' : 'Schedule Lecture / Proxy Class'}
                </h3>
                <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                  Assign subject, division, and batch for immediate attendance tracking
                </p>
              </div>
              <button onClick={() => setIsLectureModalOpen(false)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSaveLecture} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div>
                <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>Subject *</label>
                <select
                  className="input-field"
                  value={lectureForm.subject_id}
                  onChange={e => setLectureForm({ ...lectureForm, subject_id: e.target.value })}
                  required
                >
                  <option value="">-- Select Subject --</option>
                  {structure.subjects.map(s => (
                    <option key={s.id} value={s.id}>{s.name} ({s.code})</option>
                  ))}
                </select>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                <div>
                  <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>Division *</label>
                  <select
                    className="input-field"
                    value={lectureForm.division_id}
                    onChange={e => setLectureForm({ ...lectureForm, division_id: e.target.value, batch_id: '' })}
                    required
                  >
                    <option value="">-- Select Division --</option>
                    {structure.divisions.map(d => (
                      <option key={d.id} value={d.id}>Division {d.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>Batch (Optional)</label>
                  <select
                    className="input-field"
                    value={lectureForm.batch_id}
                    onChange={e => setLectureForm({ ...lectureForm, batch_id: e.target.value })}
                  >
                    <option value="">All Batches (Entire Div)</option>
                    {structure.batches
                      .filter(b => !lectureForm.division_id || String(b.division_id) === String(lectureForm.division_id))
                      .map(b => (
                        <option key={b.id} value={b.id}>Batch {b.name}</option>
                      ))}
                  </select>
                </div>
              </div>

              {/* Recurrence Type: Weekly vs Single-Day Proxy */}
              <div style={{ marginBottom: '14px', padding: '12px', background: 'var(--bg-tertiary)', borderRadius: '12px' }}>
                <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginBottom: '8px', display: 'block', fontWeight: '600' }}>Lecture Recurrence *</label>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                  <label style={{
                    display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 12px',
                    borderRadius: '10px', cursor: 'pointer',
                    background: !lectureForm.is_proxy ? 'var(--accent-light)' : 'var(--bg-secondary)',
                    border: !lectureForm.is_proxy ? '2px solid var(--accent-primary)' : '1px solid var(--border-glass)',
                    color: !lectureForm.is_proxy ? 'var(--accent-primary)' : 'var(--text-secondary)',
                    fontWeight: !lectureForm.is_proxy ? '700' : '500', fontSize: '0.85rem'
                  }}>
                    <input
                      type="radio"
                      name="lectureType"
                      checked={!lectureForm.is_proxy}
                      onChange={() => setLectureForm({ ...lectureForm, is_proxy: false })}
                    />
                    <span>Regular (Weekly)</span>
                  </label>
                  <label style={{
                    display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 12px',
                    borderRadius: '10px', cursor: 'pointer',
                    background: lectureForm.is_proxy ? 'rgba(234, 179, 8, 0.15)' : 'var(--bg-secondary)',
                    border: lectureForm.is_proxy ? '2px solid #eab308' : '1px solid var(--border-glass)',
                    color: lectureForm.is_proxy ? '#eab308' : 'var(--text-secondary)',
                    fontWeight: lectureForm.is_proxy ? '700' : '500', fontSize: '0.85rem'
                  }}>
                    <input
                      type="radio"
                      name="lectureType"
                      checked={lectureForm.is_proxy}
                      onChange={() => setLectureForm({ ...lectureForm, is_proxy: true })}
                    />
                    <span>Proxy (One-Time Date)</span>
                  </label>
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                {lectureForm.is_proxy ? (
                  <div>
                    <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>Class Date (This Day Only) *</label>
                    <input
                      type="date"
                      className="input-field"
                      value={lectureForm.specific_date}
                      onChange={e => {
                        const val = e.target.value;
                        const dow = val ? (new Date(val).getDay() || 7) : lectureForm.day_of_week;
                        setLectureForm({
                          ...lectureForm,
                          specific_date: val,
                          day_of_week: dow === 0 ? 7 : dow
                        });
                      }}
                      required
                    />
                  </div>
                ) : (
                  <div>
                    <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>Day of Week (Repeats Weekly) *</label>
                    <select
                      className="input-field"
                      value={lectureForm.day_of_week}
                      onChange={e => setLectureForm({ ...lectureForm, day_of_week: parseInt(e.target.value, 10) })}
                      required
                    >
                      <option value={1}>Monday</option>
                      <option value={2}>Tuesday</option>
                      <option value={3}>Wednesday</option>
                      <option value={4}>Thursday</option>
                      <option value={5}>Friday</option>
                      <option value={6}>Saturday</option>
                    </select>
                  </div>
                )}

                <div>
                  <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>Session Type *</label>
                  <select
                    className="input-field"
                    value={lectureForm.session_type}
                    onChange={e => setLectureForm({ ...lectureForm, session_type: e.target.value })}
                    required
                  >
                    <option value="THEORY">Theory Lecture</option>
                    <option value="PRACTICAL">Practical / Lab Session</option>
                  </select>
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                <div>
                  <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>Start Time (HH:MM) *</label>
                  <input
                    type="time"
                    className="input-field"
                    value={lectureForm.start_time}
                    onChange={e => setLectureForm({ ...lectureForm, start_time: e.target.value })}
                    required
                  />
                </div>

                <div>
                  <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>End Time (HH:MM) *</label>
                  <input
                    type="time"
                    className="input-field"
                    value={lectureForm.end_time}
                    onChange={e => setLectureForm({ ...lectureForm, end_time: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div>
                <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>Classroom / Room Number *</label>
                <input
                  type="text"
                  className="input-field"
                  placeholder="e.g. EA-101, LH-204"
                  value={lectureForm.room}
                  onChange={e => setLectureForm({ ...lectureForm, room: e.target.value })}
                  required
                />
              </div>

              <div style={{ display: 'flex', gap: '10px', marginTop: '10px' }}>
                <button
                  type="button"
                  onClick={() => setIsLectureModalOpen(false)}
                  className="btn-secondary"
                  style={{ flex: 1, padding: '10px' }}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn-primary"
                  style={{ flex: 1, padding: '10px' }}
                >
                  {editingLectureId ? 'Save Changes' : 'Schedule Class'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
