import sqlite3
from pathlib import Path

db_path = Path(__file__).parent / "quizify.db"
conn = sqlite3.connect(db_path)
conn.row_factory = sqlite3.Row
cur = conn.cursor()

# 1. Ensure branch column exists
cols = [r[1] for r in cur.execute("PRAGMA table_info(subjects)").fetchall()]
if "branch" not in cols:
    cur.execute("ALTER TABLE subjects ADD COLUMN branch TEXT DEFAULT 'Computer Science & Engineering'")

# 2. Update existing subjects
cur.execute("UPDATE subjects SET branch = 'Computer Science & Engineering' WHERE branch IS NULL OR branch = ''")

# 3. Check semesters map
sem_rows = cur.execute("SELECT id, number FROM semesters").fetchall()
sem_map = {r["number"]: r["id"] for r in sem_rows}

# Ensure Semesters 1 to 8 exist
for num in range(1, 9):
    if num not in sem_map:
        cur.execute("INSERT INTO semesters (course_id, number, academic_year) VALUES (1, ?, '2025-2026')", (num,))
        sem_map[num] = cur.lastrowid

# 4. Sample subjects across Semesters & Branches
sample_subjects = [
    # Sem 1
    (sem_map[1], "CS101", "Programming in C & Data Structures", "THEORY", "Computer Science & Engineering"),
    (sem_map[1], "EC101", "Basic Electronics & Network Theory", "BOTH", "Electronics & Communication"),
    # Sem 2
    (sem_map[2], "CS201", "Object Oriented Programming with Java", "BOTH", "Computer Science & Engineering"),
    (sem_map[2], "IT201", "Digital Logic & Computer Organization", "BOTH", "Information Technology"),
    # Sem 3
    (sem_map[3], "CS301", "Discrete Mathematics & Graph Theory", "THEORY", "Computer Science & Engineering"),
    (sem_map[3], "CS302", "Data Communication & Protocols", "BOTH", "Computer Science & Engineering"),
    # Sem 4
    (sem_map[4], "CS404", "Operating Systems & System Programming", "BOTH", "Computer Science & Engineering"),
    (sem_map[4], "IT401", "Web Technologies & Frameworks", "BOTH", "Information Technology"),
    # Sem 5 (already has CS501, CS502, CS503)
    (sem_map[5], "IT501", "Information Security & Cryptography", "BOTH", "Information Technology"),
    # Sem 6
    (sem_map[6], "CS601", "Compiler Design & Automata", "THEORY", "Computer Science & Engineering"),
    (sem_map[6], "CS602", "Cloud Computing & Distributed Systems", "BOTH", "Computer Science & Engineering"),
    # Sem 7
    (sem_map[7], "CS701", "Machine Learning & Deep Learning", "BOTH", "Computer Science & Engineering"),
    (sem_map[7], "IT701", "Mobile App Development", "BOTH", "Information Technology"),
    # Sem 8
    (sem_map[8], "CS801", "Big Data Analytics & IoT", "BOTH", "Computer Science & Engineering"),
]

for sem_id, code, name, stype, branch in sample_subjects:
    existing = cur.execute("SELECT id FROM subjects WHERE code = ?", (code,)).fetchone()
    if not existing:
        cur.execute("INSERT INTO subjects (semester_id, code, name, type, branch) VALUES (?, ?, ?, ?, ?)", (sem_id, code, name, stype, branch))

# 5. Divisions check
div1 = cur.execute("SELECT id FROM divisions WHERE name = 'A1'").fetchone()
div1_id = div1["id"] if div1 else 1

# 6. Assign prof.sharma (id 2) to CS404 (Operating Systems) and CS602 (Cloud Computing)
cs404 = cur.execute("SELECT id FROM subjects WHERE code = 'CS404'").fetchone()
if cs404:
    cur.execute("INSERT OR IGNORE INTO teacher_assignments (teacher_id, subject_id, division_id) VALUES (2, ?, ?)", (cs404["id"], div1_id))

cs602 = cur.execute("SELECT id FROM subjects WHERE code = 'CS602'").fetchone()
if cs602:
    cur.execute("INSERT OR IGNORE INTO teacher_assignments (teacher_id, subject_id, division_id) VALUES (2, ?, ?)", (cs602["id"], div1_id))

# 7. Assign dr.verma (id 3) to IT401
it401 = cur.execute("SELECT id FROM subjects WHERE code = 'IT401'").fetchone()
if it401:
    cur.execute("INSERT OR IGNORE INTO teacher_assignments (teacher_id, subject_id, division_id) VALUES (3, ?, ?)", (it401["id"], div1_id))

# 8. Add lecture in timetable for CS404
if cs404:
    has_tt = cur.execute("SELECT id FROM timetable_entries WHERE subject_id = ?", (cs404["id"],)).fetchone()
    if not has_tt:
        cur.execute("""
            INSERT INTO timetable_entries (academic_year, semester_id, day_of_week, start_time, end_time, teacher_id, subject_id, session_type, division_id, room, building)
            VALUES ('2025-2026', ?, 2, '09:00', '09:50', 2, ?, 'THEORY', ?, 'EA-301', 'Engineering Block A')
        """, (sem_map[4], cs404["id"], div1_id))

# 9. Add quiz for CS404
if cs404:
    has_q = cur.execute("SELECT id FROM quizzes WHERE subject_id = ?", (cs404["id"],)).fetchone()
    if not has_q:
        cur.execute("""
            INSERT INTO quizzes (id, creator_id, title, subject_id, division_id, access_code, duration_minutes, start_time, end_time, result_release_time, status, total_marks, pass_percentage)
            VALUES ('quiz-os-unit1-auto', 2, 'OS Kernel & Process Management Quiz', ?, ?, 'OS404Q', 25, '2026-10-05 10:00:00', '2026-10-25 18:00:00', '2026-10-25 19:00:00', 'ACTIVE', 20.0, 40.0)
        """, (cs404["id"], div1_id))

conn.commit()
conn.close()
print("✓ Database enriched with multi-semester academic data!")
