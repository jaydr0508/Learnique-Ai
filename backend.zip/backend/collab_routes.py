import os
import sys
import json
import time
import secrets
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from flask import Blueprint, request, jsonify

# UTF-8 configuration
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

collab_bp = Blueprint("collab", __name__, url_prefix="/api")

DB_PATH = Path(__file__).resolve().parent / "database" / "quizify.db"

def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=25.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute("PRAGMA journal_mode = WAL;")
    return conn

def get_current_user():
    """Extract user from Authorization Bearer token or query param."""
    import jwt
    from backend.app import JWT_SECRET
    token = None
    auth_header = request.headers.get("Authorization")
    if auth_header and auth_header.startswith("Bearer "):
        token = auth_header.split(" ")[1].strip()
    if not token:
        token = request.args.get("token")
    if not token:
        return None
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
        conn = get_db()
        user = conn.execute("SELECT * FROM users WHERE id = ? AND is_active = 1", (payload["id"],)).fetchone()
        conn.close()
        if user:
            return dict(user)
        return None
    except Exception:
        return None

def create_notification(user_id, title, message, notif_type="INFO", link="", conn=None):
    should_close = False
    try:
        if conn is None:
            conn = get_db()
            should_close = True
        conn.execute("""
            INSERT INTO notifications (user_id, title, message, type, link)
            VALUES (?, ?, ?, ?, ?)
        """, (user_id, title, message, notif_type, link))
        if should_close:
            conn.commit()
            conn.close()
    except Exception as e:
        print(f"Error creating notification: {e}")

# ==============================================================================
# HOME PAGE OVERVIEW
# ==============================================================================

@collab_bp.route("/home/overview", methods=["GET"])
def get_home_overview():
    user = get_current_user()
    conn = get_db()
    cur = conn.cursor()

    # 1. Upcoming Public Events (next 6 events)
    events_raw = cur.execute("""
        SELECT e.*, 
               (SELECT MIN(price) FROM event_tickets WHERE event_id = e.id) as min_price,
               (SELECT MAX(price) FROM event_tickets WHERE event_id = e.id) as max_price,
               (SELECT COUNT(*) FROM event_registrations WHERE event_id = e.id) as reg_count
        FROM events e
        WHERE e.status = 'PUBLISHED'
        ORDER BY e.event_date ASC, e.start_time ASC
        LIMIT 6
    """).fetchall()
    upcoming_events = [dict(r) for r in events_raw]

    # 2. Live and Upcoming Meetings
    meetings_raw = cur.execute("""
        SELECT m.*, 
               (SELECT COUNT(*) FROM meeting_participants WHERE meeting_id = m.id AND status = 'JOINED' 
                AND datetime(last_heartbeat) > datetime('now', '-25 seconds')) as active_count
        FROM meetings m
        WHERE m.status IN ('LIVE', 'SCHEDULED')
        ORDER BY CASE WHEN m.status = 'LIVE' THEN 0 ELSE 1 END, m.scheduled_date ASC, m.scheduled_start_time ASC
        LIMIT 5
    """).fetchall()
    meetings = [dict(r) for r in meetings_raw]

    # 3. Platform Stats
    event_count = cur.execute("SELECT COUNT(*) FROM events WHERE status = 'PUBLISHED'").fetchone()[0]
    live_meet_count = cur.execute("SELECT COUNT(*) FROM meetings WHERE status = 'LIVE'").fetchone()[0]
    total_registrations = cur.execute("SELECT COUNT(*) FROM event_registrations").fetchone()[0]
    active_users = cur.execute("SELECT COUNT(*) FROM users WHERE is_active = 1").fetchone()[0]

    # 4. User-specific personalized data
    user_data = None
    if user:
        my_reg_count = cur.execute("SELECT COUNT(*) FROM event_registrations WHERE user_id = ?", (user["id"],)).fetchone()[0]
        my_hosted_count = cur.execute("SELECT COUNT(*) FROM events WHERE organizer_id = ?", (user["id"],)).fetchone()[0]
        unread_notifs = cur.execute("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0", (user["id"],)).fetchone()[0]
        my_recent_regs = cur.execute("""
            SELECT r.*, e.title as event_title, e.event_date, e.start_time, e.venue_type
            FROM event_registrations r
            JOIN events e ON r.event_id = e.id
            WHERE r.user_id = ?
            ORDER BY r.created_at DESC LIMIT 3
        """, (user["id"],)).fetchall()

        user_data = {
            "my_registered_count": my_reg_count,
            "my_hosted_count": my_hosted_count,
            "unread_notifications": unread_notifs,
            "recent_registrations": [dict(r) for r in my_recent_regs]
        }

    conn.close()

    return jsonify({
        "upcoming_events": upcoming_events,
        "meetings": meetings,
        "stats": {
            "published_events": event_count,
            "live_meetings": live_meet_count,
            "total_registrations": total_registrations,
            "active_users": active_users
        },
        "user_personalized": user_data
    })

# ==============================================================================
# EVENTS API
# ==============================================================================

@collab_bp.route("/events", methods=["GET"])
def list_events():
    category = request.args.get("category")
    search = request.args.get("search", "").strip()
    venue_type = request.args.get("venue_type")
    is_free = request.args.get("free")
    status_filter = request.args.get("status", "PUBLISHED")

    query = """
        SELECT e.*, 
               (SELECT MIN(price) FROM event_tickets WHERE event_id = e.id) as min_price,
               (SELECT MAX(price) FROM event_tickets WHERE event_id = e.id) as max_price,
               (SELECT COUNT(*) FROM event_registrations WHERE event_id = e.id) as reg_count
        FROM events e
        WHERE 1=1
    """
    params = []

    if status_filter != "ALL":
        query += " AND e.status = ?"
        params.append(status_filter)

    if category and category != "All":
        query += " AND e.category = ?"
        params.append(category)

    if venue_type and venue_type != "All":
        query += " AND e.venue_type = ?"
        params.append(venue_type)

    if search:
        query += " AND (e.title LIKE ? OR e.short_description LIKE ? OR e.organizer_name LIKE ?)"
        like_term = f"%{search}%"
        params.extend([like_term, like_term, like_term])

    query += " ORDER BY e.event_date ASC, e.start_time ASC"

    conn = get_db()
    rows = conn.execute(query, tuple(params)).fetchall()
    events = [dict(r) for r in rows]

    if is_free == "true":
        events = [e for e in events if e.get("min_price") == 0]

    # Fetch categories
    cats_raw = conn.execute("SELECT DISTINCT category FROM events WHERE status = 'PUBLISHED'").fetchall()
    categories = [r[0] for r in cats_raw if r[0]]

    conn.close()
    return jsonify({
        "events": events,
        "count": len(events),
        "categories": ["All"] + categories
    })

@collab_bp.route("/events/<id_or_slug>", methods=["GET"])
def get_event_detail(id_or_slug):
    conn = get_db()
    cur = conn.cursor()

    if id_or_slug.isdigit():
        event_row = cur.execute("SELECT * FROM events WHERE id = ?", (int(id_or_slug),)).fetchone()
    else:
        event_row = cur.execute("SELECT * FROM events WHERE slug = ?", (id_or_slug,)).fetchone()

    if not event_row:
        conn.close()
        return jsonify({"error": "Event not found"}), 404

    event = dict(event_row)

    # Fetch tickets
    tickets_rows = cur.execute("SELECT * FROM event_tickets WHERE event_id = ? AND is_active = 1 ORDER BY price ASC", (event["id"],)).fetchall()
    event["tickets"] = [dict(t) for t in tickets_rows]

    # Fetch announcements
    announcements_rows = cur.execute("""
        SELECT a.*, u.name as author_name 
        FROM event_announcements a
        LEFT JOIN users u ON a.author_id = u.id
        WHERE a.event_id = ? 
        ORDER BY a.created_at DESC
    """, (event["id"],)).fetchall()
    event["announcements"] = [dict(a) for a in announcements_rows]

    # Registration count
    reg_count = cur.execute("SELECT COUNT(*) FROM event_registrations WHERE event_id = ?", (event["id"],)).fetchone()[0]
    event["current_registrations"] = reg_count

    # Check if user is registered
    user = get_current_user()
    event["is_registered"] = False
    event["user_registration"] = None
    if user:
        user_reg = cur.execute("SELECT * FROM event_registrations WHERE event_id = ? AND user_id = ?", (event["id"], user["id"])).fetchone()
        if user_reg:
            event["is_registered"] = True
            event["user_registration"] = dict(user_reg)

    conn.close()
    return jsonify({"event": event})

@collab_bp.route("/events", methods=["POST"])
def create_event():
    user = get_current_user()
    if not user:
        return jsonify({"error": "Authentication required to host events"}), 401
    
    # Allow Admin, Teacher, or verified organizers
    if user["role"] not in ["ADMIN", "TEACHER"]:
        return jsonify({"error": "Faculty or Administrator privilege required to host events"}), 403

    data = request.get_json() or {}
    title = data.get("title", "").strip()
    if not title:
        return jsonify({"error": "Event title is required"}), 400

    import re
    base_slug = re.sub(r'[^a-zA-Z0-9]+', '-', title.lower()).strip('-')
    unique_suffix = secrets.token_hex(3)
    slug = f"{base_slug}-{unique_suffix}"

    short_desc = data.get("short_description", "").strip()
    desc = data.get("description", "").strip()
    category = data.get("category", "Academic Workshop")
    banner_url = data.get("banner_url") or "https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=1200&q=80"
    organizer_name = data.get("organizer_name") or user["name"]
    event_date = data.get("event_date")
    start_time = data.get("start_time")
    end_time = data.get("end_time")
    venue_type = data.get("venue_type", "HYBRID")
    venue_address = data.get("venue_address", "")
    online_meeting_url = data.get("online_meeting_url", "")
    max_capacity = int(data.get("max_capacity") or 100)
    contact_email = data.get("contact_email") or user["email"]
    contact_phone = data.get("contact_phone", "")
    rules = data.get("rules_and_requirements", "")
    cancellation_policy = data.get("cancellation_policy", "Cancellations allowed up to 24 hours prior to event.")
    terms = data.get("terms_and_conditions", "Standard academic event code of conduct applies.")
    status = data.get("status", "PUBLISHED") # DRAFT or PUBLISHED

    if not event_date or not start_time or not end_time:
        return jsonify({"error": "Event date, start time, and end time are required"}), 400

    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
        INSERT INTO events (
            title, slug, short_description, description, category, banner_url,
            organizer_name, organizer_id, event_date, start_time, end_time,
            venue_type, venue_address, online_meeting_url, max_capacity,
            contact_email, contact_phone, rules_and_requirements,
            cancellation_policy, terms_and_conditions, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        title, slug, short_desc, desc, category, banner_url,
        organizer_name, user["id"], event_date, start_time, end_time,
        venue_type, venue_address, online_meeting_url, max_capacity,
        contact_email, contact_phone, rules,
        cancellation_policy, terms, status
    ))
    event_id = cur.lastrowid

    # Create Tickets
    tickets = data.get("tickets") or []
    if not tickets:
        # Default free ticket
        cur.execute("""
            INSERT INTO event_tickets (event_id, name, description, price, currency, quantity)
            VALUES (?, 'General Admission', 'Standard attendee admission pass', 0, 'INR', ?)
        """, (event_id, max_capacity))
    else:
        for t in tickets:
            cur.execute("""
                INSERT INTO event_tickets (event_id, name, description, price, currency, quantity)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                event_id,
                t.get("name", "Standard Ticket"),
                t.get("description", ""),
                float(t.get("price", 0)),
                t.get("currency", "INR"),
                int(t.get("quantity", max_capacity))
            ))

    conn.commit()

    # Notify all users if published
    if status == "PUBLISHED":
        users = cur.execute("SELECT id FROM users WHERE id != ?", (user["id"],)).fetchall()
        for u in users:
            create_notification(
                u[0],
                f"New Event: {title}",
                f"{organizer_name} published a new event: '{title}' on {event_date}. Check it out now!",
                "EVENT",
                f"events/{event_id}"
            )

    conn.close()
    return jsonify({
        "success": True,
        "message": "Event hosted successfully!",
        "event_id": event_id,
        "slug": slug
    }), 201

@collab_bp.route("/events/<int:event_id>", methods=["PUT"])
def update_event(event_id):
    user = get_current_user()
    if not user:
        return jsonify({"error": "Authentication required"}), 401

    conn = get_db()
    cur = conn.cursor()
    event = cur.execute("SELECT * FROM events WHERE id = ?", (event_id,)).fetchone()
    if not event:
        conn.close()
        return jsonify({"error": "Event not found"}), 404

    if user["role"] != "ADMIN" and event["organizer_id"] != user["id"]:
        conn.close()
        return jsonify({"error": "Unauthorized to edit this event"}), 403

    data = request.get_json() or {}
    cur.execute("""
        UPDATE events SET
            title = COALESCE(?, title),
            short_description = COALESCE(?, short_description),
            description = COALESCE(?, description),
            category = COALESCE(?, category),
            banner_url = COALESCE(?, banner_url),
            event_date = COALESCE(?, event_date),
            start_time = COALESCE(?, start_time),
            end_time = COALESCE(?, end_time),
            venue_type = COALESCE(?, venue_type),
            venue_address = COALESCE(?, venue_address),
            online_meeting_url = COALESCE(?, online_meeting_url),
            max_capacity = COALESCE(?, max_capacity),
            contact_email = COALESCE(?, contact_email),
            contact_phone = COALESCE(?, contact_phone),
            rules_and_requirements = COALESCE(?, rules_and_requirements),
            cancellation_policy = COALESCE(?, cancellation_policy),
            terms_and_conditions = COALESCE(?, terms_and_conditions),
            status = COALESCE(?, status),
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
    """, (
        data.get("title"), data.get("short_description"), data.get("description"),
        data.get("category"), data.get("banner_url"), data.get("event_date"),
        data.get("start_time"), data.get("end_time"), data.get("venue_type"),
        data.get("venue_address"), data.get("online_meeting_url"), data.get("max_capacity"),
        data.get("contact_email"), data.get("contact_phone"), data.get("rules_and_requirements"),
        data.get("cancellation_policy"), data.get("terms_and_conditions"), data.get("status"),
        event_id
    ))
    conn.commit()
    conn.close()
    return jsonify({"success": True, "message": "Event updated successfully"})

@collab_bp.route("/events/<int:event_id>", methods=["DELETE"])
def cancel_event(event_id):
    user = get_current_user()
    if not user:
        return jsonify({"error": "Authentication required"}), 401

    conn = get_db()
    cur = conn.cursor()
    event = cur.execute("SELECT * FROM events WHERE id = ?", (event_id,)).fetchone()
    if not event:
        conn.close()
        return jsonify({"error": "Event not found"}), 404

    if user["role"] != "ADMIN" and event["organizer_id"] != user["id"]:
        conn.close()
        return jsonify({"error": "Unauthorized"}), 403

    cur.execute("UPDATE events SET status = 'CANCELLED' WHERE id = ?", (event_id,))
    conn.commit()

    # Notify registered users
    registrations = cur.execute("SELECT user_id, participant_email FROM event_registrations WHERE event_id = ?", (event_id,)).fetchall()
    for r in registrations:
        if r[0]:
            create_notification(r[0], f"Event Cancelled: {event['title']}", f"Unfortunately, '{event['title']}' has been cancelled by the organizer.", "EVENT", "events")

    conn.close()
    return jsonify({"success": True, "message": "Event marked as cancelled"})

# ==============================================================================
# EVENT REGISTRATION & PAYMENT
# ==============================================================================

@collab_bp.route("/events/<int:event_id>/register", methods=["POST"])
def register_for_event(event_id):
    user = get_current_user()
    data = request.get_json() or {}

    conn = get_db()
    cur = conn.cursor()

    event = cur.execute("SELECT * FROM events WHERE id = ?", (event_id,)).fetchone()
    if not event:
        conn.close()
        return jsonify({"error": "Event not found"}), 404

    if event["status"] != "PUBLISHED":
        conn.close()
        return jsonify({"error": "This event is currently closed for registrations"}), 400

    # Capacity check
    cur_regs = cur.execute("SELECT COUNT(*) FROM event_registrations WHERE event_id = ?", (event_id,)).fetchone()[0]
    if cur_regs >= event["max_capacity"]:
        conn.close()
        return jsonify({"error": "This event has reached full capacity"}), 400

    # User identification
    p_name = data.get("participant_name") or (user["name"] if user else "")
    p_email = data.get("participant_email") or (user["email"] if user else "")
    p_phone = data.get("participant_phone", "")
    notes = data.get("notes", "")

    if not p_name or not p_email:
        conn.close()
        return jsonify({"error": "Participant name and valid email are required"}), 400

    # Check for duplicate registration
    existing = cur.execute("""
        SELECT * FROM event_registrations 
        WHERE event_id = ? AND (participant_email = ? OR (user_id IS NOT NULL AND user_id = ?))
    """, (event_id, p_email, user["id"] if user else None)).fetchone()
    if existing:
        conn.close()
        return jsonify({"error": "You are already registered for this event", "registration_number": existing["registration_number"]}), 409

    ticket_id = data.get("ticket_id")
    ticket = None
    if ticket_id:
        ticket = cur.execute("SELECT * FROM event_tickets WHERE id = ? AND event_id = ?", (ticket_id, event_id)).fetchone()

    if not ticket:
        ticket = cur.execute("SELECT * FROM event_tickets WHERE event_id = ? ORDER BY price ASC LIMIT 1", (event_id,)).fetchone()

    price = float(ticket["price"]) if ticket else 0.0
    ticket_name = ticket["name"] if ticket else "General Admission"

    reg_number = f"REG-2026-{secrets.token_hex(4).upper()}"
    user_id = user["id"] if user else None

    # Free ticket -> Direct confirmation
    if price == 0:
        cur.execute("""
            INSERT INTO event_registrations (
                registration_number, event_id, ticket_id, user_id,
                participant_name, participant_email, participant_phone, notes,
                ticket_name, ticket_price, currency, payment_status, payment_method
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 'INR', 'COMPLETED', 'FREE')
        """, (
            reg_number, event_id, ticket["id"] if ticket else None, user_id,
            p_name, p_email, p_phone, notes, ticket_name
        ))
        reg_id = cur.lastrowid

        # Generate Receipt
        receipt_no = f"RCPT-FREE-{secrets.token_hex(4).upper()}"
        cur.execute("""
            INSERT INTO payment_transactions (
                receipt_number, registration_id, user_id, event_id,
                amount, currency, provider, order_id, payment_id, status
            ) VALUES (?, ?, ?, ?, 0, 'INR', 'FREE', ?, ?, 'SUCCESS')
        """, (
            receipt_no, reg_id, user_id, event_id,
            f"ORD-FREE-{reg_id}", f"PAY-FREE-{reg_id}"
        ))

        # Update ticket sold count
        if ticket:
            cur.execute("UPDATE event_tickets SET sold_count = sold_count + 1 WHERE id = ?", (ticket["id"],))

        conn.commit()

        if user_id:
            create_notification(
                user_id,
                f"Registration Confirmed: {event['title']}",
                f"You have successfully secured a free spot for {event['title']}. Registration No: {reg_number}",
                "EVENT",
                f"events/{event_id}"
            )

        conn.close()
        return jsonify({
            "success": True,
            "requires_payment": False,
            "registration_number": reg_number,
            "receipt_number": receipt_no,
            "message": "Registration successful! You are confirmed."
        }), 201

    # Paid ticket -> Generate Order for payment
    order_id = f"order_{secrets.token_hex(8)}"
    cur.execute("""
        INSERT INTO event_registrations (
            registration_number, event_id, ticket_id, user_id,
            participant_name, participant_email, participant_phone, notes,
            ticket_name, ticket_price, currency, payment_status, order_id, payment_method
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'INR', 'PENDING', ?, 'RAZORPAY')
    """, (
        reg_number, event_id, ticket["id"] if ticket else None, user_id,
        p_name, p_email, p_phone, notes, ticket_name, price, order_id
    ))
    conn.commit()
    conn.close()

    return jsonify({
        "success": True,
        "requires_payment": True,
        "registration_number": reg_number,
        "order_id": order_id,
        "amount": price,
        "currency": "INR",
        "ticket_name": ticket_name,
        "key_id": os.getenv("RAZORPAY_KEY_ID", "rzp_test_QuizifyPlatformKey2026"),
        "participant_name": p_name,
        "participant_email": p_email
    })

@collab_bp.route("/events/<int:event_id>/verify-payment", methods=["POST"])
def verify_payment(event_id):
    """
    Verifies payment for an event registration.
    Supports secure Razorpay verification and secure test sandbox verification.
    """
    data = request.get_json() or {}
    order_id = data.get("order_id")
    payment_id = data.get("payment_id")
    signature = data.get("signature", "")
    reg_number = data.get("registration_number")

    if not order_id or not payment_id or not reg_number:
        return jsonify({"error": "Incomplete payment verification payload"}), 400

    conn = get_db()
    cur = conn.cursor()

    reg = cur.execute("""
        SELECT * FROM event_registrations 
        WHERE registration_number = ? AND event_id = ?
    """, (reg_number, event_id)).fetchone()

    if not reg:
        conn.close()
        return jsonify({"error": "Registration record not found"}), 404

    # Idempotent check
    if reg["payment_status"] == "COMPLETED" or reg["payment_status"] == "PAID":
        receipt = cur.execute("SELECT * FROM payment_transactions WHERE registration_id = ?", (reg["id"],)).fetchone()
        conn.close()
        return jsonify({
            "success": True,
            "message": "Payment already confirmed",
            "receipt_number": receipt["receipt_number"] if receipt else None
        })

    # Server verification: Verify Razorpay signature if secret is configured
    razorpay_secret = os.getenv("RAZORPAY_KEY_SECRET", "")
    if razorpay_secret and signature:
        import hmac
        import hashlib
        msg = f"{order_id}|{payment_id}".encode("utf-8")
        expected_sig = hmac.new(razorpay_secret.encode("utf-8"), msg, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected_sig, signature):
            conn.close()
            return jsonify({"error": "Cryptographic payment signature mismatch"}), 400

    # Record successful transaction
    receipt_no = f"RCPT-2026-{secrets.token_hex(4).upper()}"
    cur.execute("""
        UPDATE event_registrations SET
            payment_status = 'COMPLETED',
            payment_id = ?,
            order_id = ?
        WHERE id = ?
    """, (payment_id, order_id, reg["id"]))

    cur.execute("""
        INSERT INTO payment_transactions (
            receipt_number, registration_id, user_id, event_id,
            amount, currency, provider, order_id, payment_id, signature, status
        ) VALUES (?, ?, ?, ?, ?, 'INR', 'RAZORPAY', ?, ?, ?, 'SUCCESS')
    """, (
        receipt_no, reg["id"], reg["user_id"], event_id,
        reg["ticket_price"], order_id, payment_id, signature
    ))

    # Increment ticket count
    if reg["ticket_id"]:
        cur.execute("UPDATE event_tickets SET sold_count = sold_count + 1 WHERE id = ?", (reg["ticket_id"],))

    conn.commit()

    if reg["user_id"]:
        event = cur.execute("SELECT title FROM events WHERE id = ?", (event_id,)).fetchone()
        title = event["title"] if event else "Event"
        create_notification(
            reg["user_id"],
            f"Payment Successful: {title}",
            f"Payment of INR {reg['ticket_price']} received. Receipt No: {receipt_no}. You are confirmed!",
            "PAYMENT",
            f"events/{event_id}"
        )

    conn.close()

    return jsonify({
        "success": True,
        "message": "Payment verified and registration confirmed!",
        "receipt_number": receipt_no,
        "registration_number": reg_number
    })

@collab_bp.route("/events/<int:event_id>/receipt/<reg_number>", methods=["GET"])
def get_receipt(event_id, reg_number):
    conn = get_db()
    cur = conn.cursor()

    reg = cur.execute("""
        SELECT r.*, e.title as event_title, e.event_date, e.start_time, e.end_time,
               e.organizer_name, e.venue_type, e.venue_address, e.contact_email as organizer_email,
               p.receipt_number, p.amount as paid_amount, p.provider, p.created_at as payment_date,
               p.payment_id as transaction_id
        FROM event_registrations r
        JOIN events e ON r.event_id = e.id
        LEFT JOIN payment_transactions p ON p.registration_id = r.id
        WHERE r.registration_number = ? AND r.event_id = ?
    """, (reg_number, event_id)).fetchone()

    conn.close()
    if not reg:
        return jsonify({"error": "Receipt or registration not found"}), 404

    return jsonify({"receipt": dict(reg)})

@collab_bp.route("/events/my-registered", methods=["GET"])
def get_my_registered_events():
    user = get_current_user()
    if not user:
        return jsonify({"error": "Authentication required"}), 401

    conn = get_db()
    cur = conn.cursor()
    rows = cur.execute("""
        SELECT r.*, e.title as event_title, e.slug, e.event_date, e.start_time, e.end_time,
               e.venue_type, e.venue_address, e.online_meeting_url, e.banner_url, e.organizer_name,
               p.receipt_number
        FROM event_registrations r
        JOIN events e ON r.event_id = e.id
        LEFT JOIN payment_transactions p ON p.registration_id = r.id
        WHERE r.user_id = ?
        ORDER BY e.event_date ASC, e.start_time ASC
    """, (user["id"],)).fetchall()

    conn.close()
    return jsonify({"registrations": [dict(r) for r in rows]})

@collab_bp.route("/events/my-hosted", methods=["GET"])
def get_my_hosted_events():
    user = get_current_user()
    if not user:
        return jsonify({"error": "Authentication required"}), 401

    conn = get_db()
    cur = conn.cursor()
    query = """
        SELECT e.*, 
               COUNT(r.id) as total_attendees,
               COALESCE(SUM(r.ticket_price), 0) as total_revenue
        FROM events e
        LEFT JOIN event_registrations r ON r.event_id = e.id AND r.payment_status = 'COMPLETED'
        WHERE e.organizer_id = ?
        GROUP BY e.id
        ORDER BY e.created_at DESC
    """
    if user["role"] == "ADMIN":
        query = """
            SELECT e.*, 
                   COUNT(r.id) as total_attendees,
                   COALESCE(SUM(r.ticket_price), 0) as total_revenue
            FROM events e
            LEFT JOIN event_registrations r ON r.event_id = e.id AND r.payment_status = 'COMPLETED'
            GROUP BY e.id
            ORDER BY e.created_at DESC
        """
        rows = cur.execute(query).fetchall()
    else:
        rows = cur.execute(query, (user["id"],)).fetchall()

    conn.close()
    return jsonify({"hosted_events": [dict(r) for r in rows]})

@collab_bp.route("/events/<int:event_id>/registrations", methods=["GET"])
def get_event_registrations_admin(event_id):
    user = get_current_user()
    if not user:
        return jsonify({"error": "Authentication required"}), 401

    conn = get_db()
    cur = conn.cursor()
    event = cur.execute("SELECT * FROM events WHERE id = ?", (event_id,)).fetchone()
    if not event:
        conn.close()
        return jsonify({"error": "Event not found"}), 404

    if user["role"] != "ADMIN" and event["organizer_id"] != user["id"]:
        conn.close()
        return jsonify({"error": "Unauthorized"}), 403

    rows = cur.execute("""
        SELECT r.*, p.receipt_number, p.provider, p.created_at as paid_at
        FROM event_registrations r
        LEFT JOIN payment_transactions p ON p.registration_id = r.id
        WHERE r.event_id = ?
        ORDER BY r.created_at DESC
    """, (event_id,)).fetchall()

    conn.close()
    return jsonify({"registrations": [dict(r) for r in rows]})

@collab_bp.route("/events/<int:event_id>/registrations/<int:reg_id>/checkin", methods=["PATCH"])
def toggle_checkin(event_id, reg_id):
    user = get_current_user()
    if not user:
        return jsonify({"error": "Authentication required"}), 401

    conn = get_db()
    cur = conn.cursor()
    event = cur.execute("SELECT * FROM events WHERE id = ?", (event_id,)).fetchone()
    if user["role"] != "ADMIN" and event["organizer_id"] != user["id"]:
        conn.close()
        return jsonify({"error": "Unauthorized"}), 403

    reg = cur.execute("SELECT attendance_status FROM event_registrations WHERE id = ? AND event_id = ?", (reg_id, event_id)).fetchone()
    if not reg:
        conn.close()
        return jsonify({"error": "Registration not found"}), 404

    new_status = "CHECKED_IN" if reg["attendance_status"] != "CHECKED_IN" else "REGISTERED"
    cur.execute("UPDATE event_registrations SET attendance_status = ? WHERE id = ?", (new_status, reg_id))
    conn.commit()
    conn.close()
    return jsonify({"success": True, "attendance_status": new_status})

@collab_bp.route("/events/<int:event_id>/announcements", methods=["POST"])
def post_event_announcement(event_id):
    user = get_current_user()
    if not user:
        return jsonify({"error": "Authentication required"}), 401

    data = request.get_json() or {}
    title = data.get("title", "").strip()
    content = data.get("content", "").strip()
    if not title or not content:
        return jsonify({"error": "Title and content required"}), 400

    conn = get_db()
    cur = conn.cursor()
    event = cur.execute("SELECT * FROM events WHERE id = ?", (event_id,)).fetchone()
    if not event:
        conn.close()
        return jsonify({"error": "Event not found"}), 404

    if user["role"] != "ADMIN" and event["organizer_id"] != user["id"]:
        conn.close()
        return jsonify({"error": "Unauthorized"}), 403

    cur.execute("""
        INSERT INTO event_announcements (event_id, author_id, title, content)
        VALUES (?, ?, ?, ?)
    """, (event_id, user["id"], title, content))

    # Notify attendees
    attendees = cur.execute("SELECT user_id FROM event_registrations WHERE event_id = ? AND user_id IS NOT NULL", (event_id,)).fetchall()
    for att in attendees:
        create_notification(
            att[0],
            f"Event Announcement: {event['title']}",
            f"{title}: {content[:100]}...",
            "ANNOUNCEMENT",
            f"events/{event_id}",
            conn=conn
        )

    conn.commit()
    conn.close()
    return jsonify({"success": True, "message": "Announcement published successfully"})

# ==============================================================================
# MEETINGS & VIRTUAL CLASSROOMS API
# ==============================================================================

def generate_meeting_code():
    """Generates unique friendly code e.g. quiz-w7k-9xm"""
    p1 = secrets.token_hex(2)
    p2 = secrets.token_hex(2)
    return f"quiz-{p1}-{p2}"

@collab_bp.route("/meetings", methods=["GET"])
def list_meetings():
    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
        SELECT m.*, 
               (SELECT COUNT(*) FROM meeting_participants WHERE meeting_id = m.id AND status = 'JOINED'
                AND datetime(last_heartbeat) > datetime('now', '-25 seconds')) as active_count
        FROM meetings m
        WHERE m.status IN ('LIVE', 'SCHEDULED')
        ORDER BY CASE WHEN m.status = 'LIVE' THEN 0 ELSE 1 END, m.scheduled_date ASC, m.scheduled_start_time ASC
    """)
    rows = cur.fetchall()
    conn.close()
    return jsonify({"meetings": [dict(r) for r in rows]})

@collab_bp.route("/meetings/instant", methods=["POST"])
def start_instant_meeting():
    user = get_current_user()
    data = request.get_json() or {}

    title = data.get("title", "").strip() or f"Live Meeting ({datetime.now().strftime('%b %d, %H:%M')})"
    desc = data.get("description", "Instant collaboration room with HD video, screen sharing, and real-time chat.")
    code = generate_meeting_code()

    host_id = user["id"] if user else None
    host_name = user["name"] if user else (data.get("host_name") or "Host Participant")

    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO meetings (
            code, title, description, host_id, host_name,
            meeting_type, status, started_at
        ) VALUES (?, ?, ?, ?, ?, 'INSTANT', 'LIVE', CURRENT_TIMESTAMP)
    """, (code, title, desc, host_id, host_name))
    meeting_id = cur.lastrowid
    conn.commit()
    conn.close()

    return jsonify({
        "success": True,
        "meeting": {
            "id": meeting_id,
            "code": code,
            "title": title,
            "host_name": host_name,
            "status": "LIVE"
        }
    }), 201

@collab_bp.route("/meetings/schedule", methods=["POST"])
def schedule_meeting():
    user = get_current_user()
    if not user:
        return jsonify({"error": "Authentication required to schedule meetings"}), 401

    if user.get("role") not in ["ADMIN", "TEACHER"]:
        return jsonify({"error": "Faculty or Administrator privilege required to schedule meetings"}), 403

    data = request.get_json() or {}
    title = data.get("title", "").strip()
    scheduled_date = data.get("scheduled_date")
    start_time = data.get("scheduled_start_time")
    duration = int(data.get("duration_minutes") or 60)

    if not title or not scheduled_date or not start_time:
        return jsonify({"error": "Meeting title, date, and start time are required"}), 400

    code = generate_meeting_code()
    desc = data.get("description", "")
    meeting_type = data.get("meeting_type", "SCHEDULED")

    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO meetings (
            code, title, description, host_id, host_name,
            scheduled_date, scheduled_start_time, duration_minutes,
            meeting_type, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'SCHEDULED')
    """, (code, title, desc, user["id"], user["name"], scheduled_date, start_time, duration, meeting_type))
    meeting_id = cur.lastrowid
    conn.commit()

    # If invitees provided, notify them
    invitee_emails = data.get("invitee_emails", [])
    for email in invitee_emails:
        u = cur.execute("SELECT id FROM users WHERE email = ?", (email.strip(),)).fetchone()
        if u:
            create_notification(
                u[0],
                f"Meeting Invitation: {title}",
                f"{user['name']} invited you to a scheduled meeting on {scheduled_date} at {start_time}.",
                "MEETING",
                f"meetings/{code}"
            )

    conn.close()
    return jsonify({
        "success": True,
        "message": "Meeting scheduled successfully!",
        "meeting_id": meeting_id,
        "code": code
    }), 201

@collab_bp.route("/meetings/history", methods=["GET"])
def get_meeting_history():
    user = get_current_user()
    if not user:
        return jsonify({"error": "Authentication required"}), 401

    conn = get_db()
    cur = conn.cursor()
    rows = cur.execute("""
        SELECT DISTINCT m.*, 
               (SELECT COUNT(*) FROM meeting_participants WHERE meeting_id = m.id) as total_participants
        FROM meetings m
        LEFT JOIN meeting_participants p ON p.meeting_id = m.id
        WHERE m.host_id = ? OR p.user_id = ?
        ORDER BY m.created_at DESC
        LIMIT 20
    """, (user["id"], user["id"])).fetchall()

    conn.close()
    return jsonify({"history": [dict(r) for r in rows]})

@collab_bp.route("/meetings/<code>", methods=["GET"])
def get_meeting_by_code(code):
    conn = get_db()
    cur = conn.cursor()

    meeting = cur.execute("SELECT * FROM meetings WHERE code = ?", (code,)).fetchone()
    if not meeting:
        conn.close()
        return jsonify({"error": "Meeting not found with this code"}), 404

    meeting_dict = dict(meeting)

    # Active participants (heartbeat within 25s)
    participants = cur.execute("""
        SELECT session_id, participant_name, role, is_muted, is_camera_off, 
               is_hand_raised, is_screen_sharing, status, joined_at
        FROM meeting_participants
        WHERE meeting_id = ? AND status = 'JOINED' 
          AND datetime(last_heartbeat) > datetime('now', '-25 seconds')
        ORDER BY CASE WHEN role = 'HOST' THEN 0 ELSE 1 END, joined_at ASC
    """, (meeting["id"],)).fetchall()
    meeting_dict["participants"] = [dict(p) for p in participants]

    conn.close()
    return jsonify({"meeting": meeting_dict})

@collab_bp.route("/meetings/<code>/join", methods=["POST"])
def join_meeting(code):
    user = get_current_user()
    data = request.get_json() or {}

    session_id = data.get("session_id")
    if not session_id:
        return jsonify({"error": "Browser session_id is required"}), 400

    conn = get_db()
    cur = conn.cursor()

    meeting = cur.execute("SELECT * FROM meetings WHERE code = ?", (code,)).fetchone()
    if not meeting:
        conn.close()
        return jsonify({"error": "Meeting code is invalid"}), 404

    if meeting["status"] == "ENDED":
        conn.close()
        return jsonify({"error": "This meeting has already ended."}), 410

    if meeting["status"] == "CANCELLED":
        conn.close()
        return jsonify({"error": "This meeting was cancelled."}), 410

    # Auto-activate scheduled meeting when host or participants join
    if meeting["status"] == "SCHEDULED":
        cur.execute("UPDATE meetings SET status = 'LIVE', started_at = CURRENT_TIMESTAMP WHERE id = ?", (meeting["id"],))

    participant_name = data.get("participant_name") or (user["name"] if user else f"Guest-{secrets.token_hex(2)}")
    is_host = False
    if user and meeting["host_id"] == user["id"]:
        is_host = True
    elif not meeting["host_id"]:
        # If instant meeting created without host_id, first joiner is host
        is_host = True

    role = "HOST" if is_host else "PARTICIPANT"
    user_id = user["id"] if user else None

    # Upsert participant
    cur.execute("""
        INSERT INTO meeting_participants (
            meeting_id, user_id, participant_name, session_id, role,
            status, last_heartbeat
        ) VALUES (?, ?, ?, ?, ?, 'JOINED', CURRENT_TIMESTAMP)
        ON CONFLICT(meeting_id, session_id) DO UPDATE SET
            participant_name = excluded.participant_name,
            status = 'JOINED',
            last_heartbeat = CURRENT_TIMESTAMP
    """, (meeting["id"], user_id, participant_name, session_id, role))

    # Send 'peer-joined' signal to other participants
    cur.execute("""
        INSERT INTO meeting_signals (meeting_id, from_session, to_session, signal_type, payload)
        VALUES (?, ?, '*', 'peer-joined', ?)
    """, (meeting["id"], session_id, json.dumps({
        "sessionId": session_id,
        "name": participant_name,
        "role": role
    })))

    conn.commit()

    # Fetch updated list of active peers
    peers = cur.execute("""
        SELECT session_id, participant_name, role, is_muted, is_camera_off, is_hand_raised, is_screen_sharing
        FROM meeting_participants
        WHERE meeting_id = ? AND status = 'JOINED' AND session_id != ?
          AND datetime(last_heartbeat) > datetime('now', '-25 seconds')
    """, (meeting["id"], session_id)).fetchall()

    conn.close()

    return jsonify({
        "success": True,
        "meeting": {
            "id": meeting["id"],
            "code": meeting["code"],
            "title": meeting["title"],
            "status": "LIVE",
            "host_name": meeting["host_name"]
        },
        "session": {
            "session_id": session_id,
            "participant_name": participant_name,
            "role": role,
            "is_host": is_host
        },
        "peers": [dict(p) for p in peers]
    })

@collab_bp.route("/meetings/<code>/heartbeat", methods=["POST"])
def meeting_heartbeat(code):
    data = request.get_json() or {}
    session_id = data.get("session_id")
    if not session_id:
        return jsonify({"error": "session_id required"}), 400

    conn = get_db()
    cur = conn.cursor()

    meeting = cur.execute("SELECT id, status FROM meetings WHERE code = ?", (code,)).fetchone()
    if not meeting:
        conn.close()
        return jsonify({"error": "Meeting not found"}), 404

    # Update heartbeat
    cur.execute("""
        UPDATE meeting_participants SET
            last_heartbeat = CURRENT_TIMESTAMP,
            is_muted = COALESCE(?, is_muted),
            is_camera_off = COALESCE(?, is_camera_off),
            is_hand_raised = COALESCE(?, is_hand_raised),
            is_screen_sharing = COALESCE(?, is_screen_sharing)
        WHERE meeting_id = ? AND session_id = ?
    """, (
        data.get("is_muted"), data.get("is_camera_off"),
        data.get("is_hand_raised"), data.get("is_screen_sharing"),
        meeting["id"], session_id
    ))

    # Mark stale participants (>25s) as LEFT
    cur.execute("""
        UPDATE meeting_participants SET status = 'LEFT'
        WHERE meeting_id = ? AND status = 'JOINED'
          AND datetime(last_heartbeat) <= datetime('now', '-25 seconds')
    """, (meeting["id"],))

    conn.commit()

    # Active participants
    participants = cur.execute("""
        SELECT session_id, participant_name, role, is_muted, is_camera_off, is_hand_raised, is_screen_sharing
        FROM meeting_participants
        WHERE meeting_id = ? AND status = 'JOINED'
        ORDER BY CASE WHEN role = 'HOST' THEN 0 ELSE 1 END, joined_at ASC
    """, (meeting["id"],)).fetchall()

    conn.close()

    return jsonify({
        "status": meeting["status"],
        "participants": [dict(p) for p in participants]
    })

@collab_bp.route("/meetings/<code>/leave", methods=["POST"])
def leave_meeting(code):
    data = request.get_json() or {}
    session_id = data.get("session_id")

    if session_id:
        conn = get_db()
        cur = conn.cursor()
        meeting = cur.execute("SELECT id FROM meetings WHERE code = ?", (code,)).fetchone()
        if meeting:
            cur.execute("UPDATE meeting_participants SET status = 'LEFT' WHERE meeting_id = ? AND session_id = ?", (meeting["id"], session_id))
            cur.execute("""
                INSERT INTO meeting_signals (meeting_id, from_session, to_session, signal_type, payload)
                VALUES (?, ?, '*', 'peer-left', ?)
            """, (meeting["id"], session_id, json.dumps({"sessionId": session_id})))
            conn.commit()
        conn.close()

    return jsonify({"success": True})

@collab_bp.route("/meetings/<code>/end", methods=["POST"])
def end_meeting_for_all(code):
    user = get_current_user()
    conn = get_db()
    cur = conn.cursor()

    meeting = cur.execute("SELECT * FROM meetings WHERE code = ?", (code,)).fetchone()
    if not meeting:
        conn.close()
        return jsonify({"error": "Meeting not found"}), 404

    # Host or Admin
    if user and (user["role"] == "ADMIN" or meeting["host_id"] == user["id"]):
        pass
    else:
        # Check if participant is registered as HOST in session
        data = request.get_json() or {}
        session_id = data.get("session_id")
        p = cur.execute("SELECT role FROM meeting_participants WHERE meeting_id = ? AND session_id = ?", (meeting["id"], session_id)).fetchone()
        if not p or p["role"] != "HOST":
            conn.close()
            return jsonify({"error": "Only the host can end the meeting for all participants"}), 403

    cur.execute("UPDATE meetings SET status = 'ENDED', ended_at = CURRENT_TIMESTAMP WHERE id = ?", (meeting["id"],))
    cur.execute("UPDATE meeting_participants SET status = 'LEFT' WHERE meeting_id = ?", (meeting["id"],))
    # Broadcast meeting ended signal
    cur.execute("""
        INSERT INTO meeting_signals (meeting_id, from_session, to_session, signal_type, payload)
        VALUES (?, 'system', '*', 'meeting-ended', ?)
    """, (meeting["id"], json.dumps({"reason": "Host ended the meeting for everyone"})))
    conn.commit()
    conn.close()

    return jsonify({"success": True, "message": "Meeting ended for all participants"})

# ==============================================================================
# WEBRTC SIGNALING API
# ==============================================================================

@collab_bp.route("/meetings/<code>/signal", methods=["POST"])
def send_signal(code):
    data = request.get_json() or {}
    from_session = data.get("from_session")
    to_session = data.get("to_session")
    signal_type = data.get("signal_type") # offer, answer, ice-candidate, hand-raise, mute-req
    payload = data.get("payload")

    if not from_session or not to_session or not signal_type:
        return jsonify({"error": "Incomplete signaling payload"}), 400

    conn = get_db()
    cur = conn.cursor()
    meeting = cur.execute("SELECT id FROM meetings WHERE code = ?", (code,)).fetchone()
    if not meeting:
        conn.close()
        return jsonify({"error": "Meeting not found"}), 404

    cur.execute("""
        INSERT INTO meeting_signals (meeting_id, from_session, to_session, signal_type, payload)
        VALUES (?, ?, ?, ?, ?)
    """, (meeting["id"], from_session, to_session, signal_type, json.dumps(payload)))
    conn.commit()
    conn.close()

    return jsonify({"success": True})

@collab_bp.route("/meetings/<code>/signals", methods=["GET"])
def get_signals(code):
    session_id = request.args.get("session_id")
    since_id = int(request.args.get("since_id", 0))

    if not session_id:
        return jsonify({"error": "session_id is required"}), 400

    conn = get_db()
    cur = conn.cursor()
    meeting = cur.execute("SELECT id FROM meetings WHERE code = ?", (code,)).fetchone()
    if not meeting:
        conn.close()
        return jsonify({"error": "Meeting not found"}), 404

    signals = cur.execute("""
        SELECT id, from_session, signal_type, payload, created_at
        FROM meeting_signals
        WHERE meeting_id = ? AND id > ? AND (to_session = ? OR to_session = '*') AND from_session != ?
        ORDER BY id ASC
        LIMIT 50
    """, (meeting["id"], since_id, session_id, session_id)).fetchall()

    conn.close()

    result = []
    max_id = since_id
    for s in signals:
        if s["id"] > max_id:
            max_id = s["id"]
        try:
            p = json.loads(s["payload"])
        except Exception:
            p = s["payload"]
        result.append({
            "id": s["id"],
            "from_session": s["from_session"],
            "signal_type": s["signal_type"],
            "payload": p,
            "created_at": s["created_at"]
        })

    return jsonify({"signals": result, "max_id": max_id})

# ==============================================================================
# IN-MEETING REAL-TIME CHAT
# ==============================================================================

@collab_bp.route("/meetings/<code>/chat", methods=["POST"])
def send_meeting_chat(code):
    data = request.get_json() or {}
    session_id = data.get("session_id")
    sender_name = data.get("sender_name", "Participant")
    sender_role = data.get("sender_role", "PARTICIPANT")
    content = data.get("content", "").strip()

    if not session_id or not content:
        return jsonify({"error": "Session ID and message content are required"}), 400

    conn = get_db()
    cur = conn.cursor()
    meeting = cur.execute("SELECT id FROM meetings WHERE code = ?", (code,)).fetchone()
    if not meeting:
        conn.close()
        return jsonify({"error": "Meeting not found"}), 404

    cur.execute("""
        INSERT INTO meeting_chat_messages (meeting_id, session_id, sender_name, sender_role, content)
        VALUES (?, ?, ?, ?, ?)
    """, (meeting["id"], session_id, sender_name, sender_role, content))
    msg_id = cur.lastrowid
    conn.commit()
    conn.close()

    return jsonify({
        "success": True,
        "message": {
            "id": msg_id,
            "session_id": session_id,
            "sender_name": sender_name,
            "sender_role": sender_role,
            "content": content,
            "created_at": datetime.now().isoformat()
        }
    }), 201

@collab_bp.route("/meetings/<code>/chat", methods=["GET"])
def get_meeting_chat(code):
    since_id = int(request.args.get("since_id", 0))

    conn = get_db()
    cur = conn.cursor()
    meeting = cur.execute("SELECT id FROM meetings WHERE code = ?", (code,)).fetchone()
    if not meeting:
        conn.close()
        return jsonify({"error": "Meeting not found"}), 404

    messages = cur.execute("""
        SELECT * FROM meeting_chat_messages
        WHERE meeting_id = ? AND id > ?
        ORDER BY id ASC
        LIMIT 100
    """, (meeting["id"], since_id)).fetchall()

    conn.close()
    return jsonify({"messages": [dict(m) for m in messages]})

# ==============================================================================
# NOTIFICATIONS API
# ==============================================================================

@collab_bp.route("/notifications", methods=["GET"])
def get_notifications():
    user = get_current_user()
    if not user:
        return jsonify({"notifications": [], "unread_count": 0})

    conn = get_db()
    cur = conn.cursor()
    rows = cur.execute("""
        SELECT * FROM notifications
        WHERE user_id = ?
        ORDER BY created_at DESC
        LIMIT 30
    """, (user["id"],)).fetchall()

    unread_count = cur.execute("""
        SELECT COUNT(*) FROM notifications
        WHERE user_id = ? AND is_read = 0
    """, (user["id"],)).fetchone()[0]

    conn.close()
    return jsonify({
        "notifications": [dict(r) for r in rows],
        "unread_count": unread_count
    })

@collab_bp.route("/notifications/<int:notif_id>/read", methods=["PATCH"])
def mark_notification_read(notif_id):
    user = get_current_user()
    if not user:
        return jsonify({"error": "Authentication required"}), 401

    conn = get_db()
    cur = conn.cursor()
    cur.execute("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?", (notif_id, user["id"]))
    conn.commit()
    conn.close()
    return jsonify({"success": True})

@collab_bp.route("/notifications/read-all", methods=["POST"])
def mark_all_notifications_read():
    user = get_current_user()
    if not user:
        return jsonify({"error": "Authentication required"}), 401

    conn = get_db()
    cur = conn.cursor()
    cur.execute("UPDATE notifications SET is_read = 1 WHERE user_id = ?", (user["id"],))
    conn.commit()
    conn.close()
    return jsonify({"success": True})
